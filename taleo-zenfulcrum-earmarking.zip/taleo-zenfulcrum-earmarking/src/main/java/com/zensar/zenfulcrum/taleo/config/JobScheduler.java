package com.zensar.zenfulcrum.taleo.config;

import java.util.Date;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.taleo.util.TaleoConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
//@Component
@RestController
public class JobScheduler {

	@Autowired
	private JobLauncher launcher;

	@Autowired
	private Job taleoEarmarkingJob;

	@Autowired
	private Job taleoOutboundJob;

	@Value("${EARMARKING_FILE_PATH}")
	private String earMarkingCsvFilename;

	@Value("${OUTBOUND_FILE_PATH}")
	private String outboundCsvFileName;

	@Value("${eamarking.job.cron}")
	private String cron;

	@Value("${outbound.job.cron}")
	private String cron1;

	//@Scheduled(cron = "${eamarking.job.cron}")
	@GetMapping("earmarking")
	public void earMarkingJobHandler() {

		log.info("TaleoEarmarkingApplication.Earmarking: Starting Scheduler cron Job: {} Timestamp - {}", cron, new Date());

		JobParametersBuilder jobBuilder = new JobParametersBuilder();
		jobBuilder.addString("JobID", String.valueOf(System.currentTimeMillis()));
		jobBuilder.addString(TaleoConstant.SOURCE_FILE_PATH, earMarkingCsvFilename);
		jobBuilder.addDate("date", new Date(), true);
		runJob(taleoEarmarkingJob, jobBuilder.toJobParameters());
	}

	//@Scheduled(cron = "${outbound.job.cron}")
	@GetMapping("outbound")
	public void outBoundJobHandler() {
		log.info("TaleoEarmarkingApplication.Outbound: Starting Scheduler cron Job: {} Timestamp - {}", cron1, new Date());

		JobParametersBuilder jobBuilder = new JobParametersBuilder();
		jobBuilder.addString("JobID", String.valueOf(System.currentTimeMillis()));
		jobBuilder.addString(TaleoConstant.SOURCE_FILE_PATH, outboundCsvFileName);
		jobBuilder.addDate("date", new Date(), true);
		runJob(taleoOutboundJob, jobBuilder.toJobParameters());
	}

	public void runJob(Job taleoJob, JobParameters jobParameters) {

		try {
			launcher.run(taleoJob, jobParameters);

		} catch (JobExecutionAlreadyRunningException e) {
			log.error("Job with fileName={} is already running.", jobParameters.getParameters().get(TaleoConstant.SOURCE_FILE_PATH));
		} catch (JobRestartException e) {
			log.error("Job with fileName={} was not restarted.", jobParameters.getParameters().get(TaleoConstant.SOURCE_FILE_PATH));
		} catch (JobInstanceAlreadyCompleteException e) {
			log.error("Job with fileName={} already completed.", jobParameters.getParameters().get(TaleoConstant.SOURCE_FILE_PATH));
		} catch (JobParametersInvalidException e) {
			log.error("Invalid job parameters. {} - {}", jobParameters.getParameters().get(TaleoConstant.SOURCE_FILE_PATH), e);
		}
	}
}
