package com.zensar.zenfulcrum.taleo.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zensar.zenfulcrum.taleo.model.TSrf;
import com.zensar.zenfulcrum.taleo.util.TaleoConstant;


@Repository
public interface TaleoMainRepository extends JpaRepository<TSrf, Long>{

	@Transactional
	@Query(value = "SELECT "+TaleoConstant.ADMIN_SCHEMA+".func_module_num(:moduleCode, :recordStatus)", nativeQuery = true)
	Long getStatusIdFromLookUP(@Param("moduleCode") String moduleCode, @Param("recordStatus") String recordStatus);

	@Transactional
	@Query(value = "SELECT COUNT(*) FROM "+TaleoConstant.RES_MANG_SCHEMA+".T_SRF WHERE candidate_id = :candidateId AND project_id = :projectId AND srf_number = :srfNumber", nativeQuery = true)
	long checkEmployeeExists(@Param("candidateId") Long candidateId, @Param("projectId") String projectId, @Param("srfNumber") String srfNumber);

	@Modifying
	@Transactional
	@Query(value = "UPDATE "+TaleoConstant.RES_MANG_SCHEMA+".T_SRF SET candidate_id=:#{#srfRecord.candidateId}, project_id=:#{#srfRecord.projectId}, status_start_date=:#{#srfRecord.statusStartDate}, status_end_date=:#{#srfRecord.statusEndDate}, resource_status=:#{#srfRecord.resourceStatus}, "
			+ "srf_number=:#{#srfRecord.srfNumber}, status_id=:#{#srfRecord.statusId}, is_selected=:#{#srfRecord.isSelected}, selection_date=:#{#srfRecord.selectionDate}, last_updated_date=:#{#srfRecord.lastUpdatedDate}, "
			+ "effective_start_date= :#{#srfRecord.effectiveStartDate}, effective_end_date= :#{#srfRecord.effectiveEndDate} WHERE srf_id=:id", nativeQuery = true)
	void updateEmployeeDetails(@Param("srfRecord") TSrf srfRecord, @Param("id") long id);

	@Transactional
	@Query(value = "SELECT srf_id FROM "+TaleoConstant.RES_MANG_SCHEMA+".T_SRF WHERE candidate_id = :#{#srfRecord.candidateId} AND project_id = :#{#srfRecord.projectId} AND srf_number=:#{#srfRecord.srfNumber} ORDER BY last_updated_date DESC LIMIT 1", nativeQuery = true)
	long getEmployeeIdToUpdate(@Param("srfRecord") TSrf srfRecord);


}
