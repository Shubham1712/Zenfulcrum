package com.zensar.zenfulcrum.taleo.config;

import java.io.IOException;
import java.io.Writer;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileHeaderCallback;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.listener.JobCompletionListener;
import com.zensar.zenfulcrum.taleo.mapper.EmployeeFileRowMapper;
import com.zensar.zenfulcrum.taleo.mapper.EmployeeRowMapper;
import com.zensar.zenfulcrum.taleo.mapper.OutBoundEmployeeRowMapper;
import com.zensar.zenfulcrum.taleo.model.Employee;
import com.zensar.zenfulcrum.taleo.model.OutboundEmployee;
import com.zensar.zenfulcrum.taleo.model.TSrf;
import com.zensar.zenfulcrum.taleo.processor.OutboundProcessor;
import com.zensar.zenfulcrum.taleo.processor.TaleoMainProcessor;
import com.zensar.zenfulcrum.taleo.processor.TaleoStagingProcessor;
import com.zensar.zenfulcrum.taleo.util.TaleoConstant;
import com.zensar.zenfulcrum.taleo.util.TaleoSqlQuery;
import com.zensar.zenfulcrum.taleo.writer.TaleoMainWriter;
import com.zensar.zenfulcrum.taleo.writer.TaleoStagingWriter;

import lombok.extern.slf4j.Slf4j;

/**
 * @author ST52015
 *
 */

@Slf4j
@Configuration
@EnableBatchProcessing
@ComponentScan(basePackages = { "com.zensar.zenfulcrum.taleo.processor"})
public class TaleoBatchConfig {
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
		
	@Autowired
	private ExecutionContext executionContext;
	
	@Autowired
	private DataSource dataSource;
	
	private SimpleDateFormat dateFormatSlash = new SimpleDateFormat(TaleoConstant.DATE_FORMAT_SLASH);
	
	@Value("${EMAIL_TO_ADDRESS}")
	private String[] emailToAddress;
	
	@Value("${EMAIL_CC_ADDRESS}")
	private String[] emailCcAddress;
	
	@Value("${OUTBOUND_SRC_FOLDER}")
	private String outboundSrcFolder;
	
	@Value("${OUTBOUND_DEST_FOLDER}")
	private String outboundDestFolder;
	
	@Value("${EARMARKING_SRC_FOLDER}")
	private String earmarkingSrcFolder;
	
	@Value("${EARMARKING_DEST_FOLDER}")
	private String earmarkingDestFolder;
	
	@Value("${EARMARKING_FILE_PATH}")
	private String earmarkingSrcFile;
	
	@Value("${EARMARKING_SHELL_SCRIPT}")
	private String earmarkingShellScriptFile;
	
	
	// Taleo-ZF-Earmarking Job
	@Qualifier(value = "EarmarkingJob")
	@Bean
	public Job taleoEarmarkingJob() {
		Job job = null;
		try {
			log.info("Starting Taleo-ZF-Earmarking Job at timestamp - {}", new Date());
			job = jobBuilderFactory.get("EarmarkingJob").incrementer(new RunIdIncrementer()).listener(listener()).start(taleoEarmarkingStep1()).next(taleoEarmarkingStep2()).build();

		} catch (TaleoException exp) {
			log.error("Encountered error in Taleo-ZF-Earmarking Job - {}", exp);
		}
		return job;
	}
	 
	// ZF-Taleo-Outbound/Interview-Collaborator Job
	@Qualifier(value = "OutboundJob")
	@Bean
	public Job taleoOutboundJob() {
		Job job = null;
		try {
			log.info("Starting ZF-Taleo-Outbound/Interview-Collaborator Job at timestamp - {}", new Date());
			job = jobBuilderFactory.get("OutboundJob").incrementer(new RunIdIncrementer()).listener(listener()).start(taleoOutboundStep1()).build();

		} catch (TaleoException exp) {
			log.error("Encountered error in ZF-Taleo-Outbound/Interview-Collaborator Job - {}", exp);
		}
		return job;
	}

	
	/** 
	 * we can increase the chunk size if needed, Reading from taleo CSV file
	 * Updating the record in Staging, Inserting records in chunk into staging
	 *  */ 
	@Qualifier(value = "EarmarkingStep1")
	@Bean
	public Step taleoEarmarkingStep1() throws TaleoException {
		return stepBuilderFactory.get("EarmarkingStep1").<Employee, Employee>chunk(TaleoConstant.CHUNK_SIZE).reader(readFromCSV()).processor(processorEarStep1()).writer(writerEarStep1()).build();	
	}
	


	//Reading from taleo Staging table
	@Qualifier(value = "EarmarkingStep2")
	@Bean
	public Step taleoEarmarkingStep2() throws TaleoException {
		
		return stepBuilderFactory.get("EarmarkingStep2").<Employee, TSrf>chunk(TaleoConstant.CHUNK_SIZE).reader(readerFromDB()).processor(processorEarStep2()).writer(writerEarStep2()).build();	
	}
	

	@Qualifier(value = "OutboundStep1")
	@Bean
	public Step taleoOutboundStep1() throws TaleoException {
		return stepBuilderFactory.get("OutboundStep1").<OutboundEmployee, OutboundEmployee>chunk(TaleoConstant.CHUNK_SIZE).reader(readFromMEmployee()).processor(processorOutStep1()).writer(writeIntoCsv()).build();
	}
	
	
	@Bean
	@StepScope
	public FlatFileItemWriter<OutboundEmployee> writeIntoCsv() throws TaleoException {
		try {
			 log.info("Entered TaleoBatchConfig.writeIntoCsv method, file - {}", outputFileResource(null));
			 FlatFileItemWriter<OutboundEmployee> writer = new FlatFileItemWriter<>();
			 writer.setResource(outputFileResource(null));
		     writer.setHeaderCallback(new FlatFileHeaderCallback() {
					
					@Override
					public void writeHeader(Writer writer) throws IOException {
						writer.write(TaleoConstant.COLUMN_HEADER);
					}
			  });
			  DelimitedLineAggregator<OutboundEmployee> delimitedLineAggregator = new DelimitedLineAggregator<>();
			  delimitedLineAggregator.setDelimiter(TaleoConstant.PIPE_DELIMETER);
			  BeanWrapperFieldExtractor<OutboundEmployee> beanWrapperFieldExtractor = new BeanWrapperFieldExtractor<>();
			  beanWrapperFieldExtractor.setNames(new String[] { TaleoConstant.EMPLOYEE_NUMBER, TaleoConstant.EMPLOYEE_NUMBER, TaleoConstant.CONFIG_PROFILE, TaleoConstant.USER_TYPE });
			  delimitedLineAggregator.setFieldExtractor(beanWrapperFieldExtractor);
			  writer.setLineAggregator(delimitedLineAggregator);
			  log.info("Exiting TaleoBatchConfig.writeIntoCsv method");
		  	  return writer;
		  	  
		} catch (DataAccessException exp ) {
			log.error("OutboundJob: Error while writing into CSV file", exp);
			throw new TaleoException(exp);
		}
	}
	
	@Bean(destroyMethod="")
	@StepScope
	public JdbcCursorItemReader<Employee> readerFromDB() throws TaleoException {
		
		try {
			 log.info("Entered TaleoBatchConfig.readerFromDB method");
			 java.util.Date utilDate = dateFormatSlash.parse(executionContext.getString(TaleoConstant.LAST_UPDATE_DATE).replace('-', '/'));
			 java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
			 PreparedStatementSetter preparedStatementSetter = new PreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setDate(1, sqlDate);
						preparedStatement.setDate(2, sqlDate);
					}
		     };
			 JdbcCursorItemReader<Employee> reader = new JdbcCursorItemReader<>();
			 reader.setDataSource(dataSource);
			 reader.setSql(TaleoSqlQuery.EAR_STAG_QUERY); 			// Conditional query
			 reader.setPreparedStatementSetter(preparedStatementSetter);
			 reader.setRowMapper(new EmployeeRowMapper());
			 log.info("Exiting TaleoBatchConfig.readerFromDB method");
			 return reader;  
			  
		} catch (ParseException | DataAccessException exp ) {
			log.error("Error while reading from PD staging table", exp);
			throw new TaleoException(exp);
		}
	}
	

	

	@Bean
	@StepScope
	public FlatFileItemReader<Employee> readFromCSV() throws TaleoException {
		 try {
			 log.info("Entered TaleoBatchConfig.readFromCSV method, file - {}", inputFileResource(null));
			 FlatFileItemReader<Employee> reader = new FlatFileItemReader<>();
		        reader.setResource(inputFileResource(null));													
		        reader.setLinesToSkip(1);												//Skipping first line as contains column headers
		        DefaultLineMapper<Employee> lineMapper = new DefaultLineMapper<>();
		        DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
		        tokenizer.setDelimiter(TaleoConstant.COMMA_DELIMETER);
		        tokenizer.setNames(TaleoConstant.CANDIDATE_ID, TaleoConstant.PROJECT_ID, TaleoConstant.STATUS_START_DATE,
		        		TaleoConstant.STATUS_END_DATE, TaleoConstant.RESOURCE_STATUS, TaleoConstant.SRF_NUMBER, TaleoConstant.RECORD_STATUS, TaleoConstant.IS_SELECTED, TaleoConstant.SELECTION_DATE);
		        lineMapper.setLineTokenizer(tokenizer);
		        lineMapper.setFieldSetMapper(new EmployeeFileRowMapper());
		        reader.setLineMapper(lineMapper);
		        log.info("Exiting TaleoBatchConfig.readFromCSV method");
		        return reader;
		        
		} catch (DataAccessException exp) {
			log.error("Error while reading from CSV file", exp);
			throw new TaleoException(exp);
		}
	}
	
	@Bean(destroyMethod="")
	@StepScope
	public JdbcCursorItemReader<OutboundEmployee> readFromMEmployee() throws TaleoException {
		try {
			log.info("Entered TaleoBatchConfig.readFromMEmployee method");
			 java.util.Date utilDate = dateFormatSlash.parse(executionContext.getString(TaleoConstant.LAST_RUNTIME).replace('-', '/'));
			 java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
			 PreparedStatementSetter preparedStatementSetter = new PreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setDate(1, sqlDate);
						preparedStatement.setDate(2, sqlDate);
					}
		     };
			 JdbcCursorItemReader<OutboundEmployee> reader = new JdbcCursorItemReader<>();
			 reader.setDataSource(dataSource);
			 reader.setSql(TaleoSqlQuery.GET_EMPLOYEE_NUMBER_M_EMP); 			// Conditional query
			 reader.setPreparedStatementSetter(preparedStatementSetter);
			 reader.setRowMapper(new OutBoundEmployeeRowMapper());
			 log.info("Exiting TaleoBatchConfigJDBC.readFromMEmployee method");
			 return reader;  
			  
		} catch (ParseException | DataAccessException exp ) {
			log.error("Error while reading from M_employee table", exp);
			throw new TaleoException(exp);
		}
	}
	
	
	
	@Bean
	@StepScope
	Resource inputFileResource(@Value("#{jobParameters['SOURCE_FILE_PATH']}") final String fileName)  {
		return new FileSystemResource(fileName);
		
	}
	
	@Bean
	@StepScope
	Resource outputFileResource(@Value("#{jobParameters['SOURCE_FILE_PATH']}") final String fileName)  {
		SimpleDateFormat dateFormat = new SimpleDateFormat(TaleoConstant.DATE_FORMAT);
		String file = fileName+dateFormat.format(new Date())+".csv";				//Creating filename as today's date
		log.info("Entered TaleoBatchConfig.outputFileResource: returning file name - {}", file);
		return new FileSystemResource(file);
		
	}
	
	public String[] getEmailToAddress() throws TaleoException {
		if(emailToAddress != null)
			return emailToAddress;
		else {
			log.error("Encountered error: to email address should not be null");
			throw new TaleoException("email address should not be null");
		}
	}
	
	public String[] getEmailCcAddress() {
		if(emailCcAddress != null)
			return emailCcAddress;
		return new String[0];
	}
	
	public String getOutboundSrcFolder() {
		return outboundSrcFolder;
	}
	
	public String getOutboundDestFolder() {
		return outboundDestFolder;
	}
	
	public String getEarmarkingSrcFolder() {
		return earmarkingSrcFolder;
	}
	
	public String getEarmarkingDestFolder() {
		return earmarkingDestFolder;
	}

	public String getEarmarkingSrcFile() {
		return earmarkingSrcFile;
	}
	
	public String getEarmarkingShellScriptFile() {
		return earmarkingShellScriptFile;
	}
	
	@Bean
	public JobExecutionListener listener() {
		return new JobCompletionListener();
	}
	
	@Bean
	public TaleoStagingWriter writerEarStep1() {
		return new TaleoStagingWriter();
	}

	@Bean
	public TaleoStagingProcessor processorEarStep1() {
		return new TaleoStagingProcessor();
	}
	
	@Bean
	public TaleoMainWriter writerEarStep2() {
		return new TaleoMainWriter();
	}

	@Bean
	public TaleoMainProcessor processorEarStep2() {
		return new TaleoMainProcessor();
	}
	
	@Bean
	public OutboundProcessor processorOutStep1() {
		return new OutboundProcessor();
	}

	

}
