package com.zensar.zenfulcrum.taleo.processor;

import java.util.Date;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.model.OutboundEmployee;
import com.zensar.zenfulcrum.taleo.util.TaleoConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class OutboundProcessor implements ItemProcessor<OutboundEmployee, OutboundEmployee>{

	@Override
	public OutboundEmployee process(OutboundEmployee item) throws TaleoException {
		
		log.info("Entered into OutboundProcessor.process method, Employee id : {}", item.getEmployeeNumber());
					
		item.setConfigProfile(TaleoConstant.CONFIG_PROFILE_DESP);	//Zen_Configuration Hiring_Manager
		item.setUserType(TaleoConstant.USER_TYPE_DESP);				//Zen_Interview Collaborator
		log.info("Exiting OutboundProcessor.process method");
				
		return item;
		
	}

}
