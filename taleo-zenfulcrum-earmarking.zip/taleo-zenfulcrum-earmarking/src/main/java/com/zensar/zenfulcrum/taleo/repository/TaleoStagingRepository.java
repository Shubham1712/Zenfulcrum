package com.zensar.zenfulcrum.taleo.repository;

import java.util.Date;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zensar.zenfulcrum.taleo.model.Employee;
import com.zensar.zenfulcrum.taleo.util.TaleoConstant;

@Repository
public interface TaleoStagingRepository extends JpaRepository<Employee, Long>{

	@Transactional
	@Query(value = "SELECT COUNT(*) FROM "+TaleoConstant.STAGING_SCHEMA+".STG_RESOURCE_EARMARKING_DETAILS WHERE candidate_id = :candidateId AND project_id = :projectId and srf_number=:srfNumber", nativeQuery = true)
	long checkEmployeeExists(@Param("candidateId") String candidateId, @Param("projectId") String projectId, @Param("srfNumber") String srfNumber);

	@Modifying
	@Transactional
	@Query(value = "UPDATE "+TaleoConstant.STAGING_SCHEMA+".STG_RESOURCE_EARMARKING_DETAILS SET candidate_id=:#{#employee.candidateId}, project_id=:#{#employee.projectId}, status_start_date=:#{#employee.statusStartDate}, status_end_date=:#{#employee.statusEndDate}, resource_status=:#{#employee.resourceStatus}, srf_number=:#{#employee.srfNumber}, record_status=:#{#employee.recordStatus}, is_selected=:#{#employee.isSelected}, selection_date=:#{#employee.selectionDate}, last_updated_date=:#{#employee.lastUpdatedDate} WHERE srf_resource_earmarking_details_id=:id", nativeQuery = true)
	public void updateEmployeeDetails(@Param("employee") Employee employee, @Param("id") long id);

	@Transactional
	@Query(value = "SELECT MAX(last_updated_date) FROM "+TaleoConstant.STAGING_SCHEMA+".STG_RESOURCE_EARMARKING_DETAILS", nativeQuery = true)
	Optional<Date> getLastUpdateDate();

	@Transactional
	@Query(value = "SELECT INTERFACE_RUNTIME FROM "+TaleoConstant.STAGING_SCHEMA+".INTERFACE_TRACKER WHERE INTERFACE_DESC= :taleoOutboundInterfaceDesp", nativeQuery = true)
	Optional<Date> getLastRunTime(@Param("taleoOutboundInterfaceDesp")  String taleoOutboundInterfaceDesp);

	@Modifying
	@Transactional
	@Query(value = "UPDATE "+TaleoConstant.STAGING_SCHEMA+".INTERFACE_TRACKER SET INTERFACE_RUNTIME= SYSDATE() WHERE INTERFACE_DESC= :taleoOutboundInterfaceDesp", nativeQuery = true)
	void updateLastRunTime(@Param("taleoOutboundInterfaceDesp") String taleoOutboundInterfaceDesp);

	@Transactional
	@Query(value = "SELECT srf_resource_earmarking_details_id FROM "+TaleoConstant.STAGING_SCHEMA+".STG_RESOURCE_EARMARKING_DETAILS WHERE candidate_id=:#{#employee.candidateId} AND project_id=:#{#employee.projectId} AND srf_number=:#{#employee.srfNumber} ORDER BY last_updated_date DESC LIMIT 1", nativeQuery = true)
	long getEmployeeIdToUpdate(@Param("employee") Employee employee);

}
