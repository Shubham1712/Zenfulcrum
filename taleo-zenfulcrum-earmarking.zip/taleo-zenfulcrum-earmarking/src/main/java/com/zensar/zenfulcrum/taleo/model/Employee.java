package com.zensar.zenfulcrum.taleo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.zensar.zenfulcrum.taleo.util.TaleoConstant;

import lombok.Data;

@Data
@Table(schema = TaleoConstant.STAGING_SCHEMA, name = "STG_RESOURCE_EARMARKING_DETAILS", catalog = TaleoConstant.STAGING_SCHEMA)
@Entity
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="srf_resource_earmarking_details_id")
	private Long srfResEarDetailsId;
	
	@Column(name="srf_number")
	private String srfNumber;
	
	@Column(name="candidate_id")
	private String candidateId;
	
	@Column(name="project_id")
	private String projectId;
	
	@Column(name="selection_date")
	private Date selectionDate;
	
	@Column(name="status_start_date")
	private Date statusStartDate;
	
	@Column(name="status_end_date")
	private Date statusEndDate;
	
	@Column(name="is_selected")
	private String isSelected;
	
	@Column(name="resource_status")
	private String resourceStatus;
	
	@Column(name="record_status")
	private String recordStatus;
	
	@Column(name="created_by")
	private Long createdBy;
	
	@Column(name="last_updated_by")
	private Long lastUpdatedBy;
	
	@Column(name="created_date")
	private Date createdDate;
	
	@Column(name="last_updated_date")
	private Date lastUpdatedDate;
}
