package com.zensar.zenfulcrum.taleo.model;

import lombok.Data;

@Data
public class OutboundEmployee {
	
	private long employeeNumber;
	private String configProfile;
	private String userType;
}


//Employee_Number|Employee_Number|Config_Profile|User_Type