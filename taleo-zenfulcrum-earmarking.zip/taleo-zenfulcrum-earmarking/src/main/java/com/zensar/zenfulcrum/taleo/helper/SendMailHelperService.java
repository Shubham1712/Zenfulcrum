package com.zensar.zenfulcrum.taleo.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.emailservice.EmailServiceUtility;
import com.zensar.zenfulcrum.emailservice.dto.LiferayDto;
import com.zensar.zenfulcrum.emailservice.dto.MailUtilityDetails;
import com.zensar.zenfulcrum.emailservice.exception.EmailUtilException;
import com.zensar.zenfulcrum.taleo.config.TaleoBatchConfig;
import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.util.TaleoConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SendMailHelperService {
	
	@Autowired
	private EmailServiceUtility serviceUtility;
	
	@Autowired
	private TaleoBatchConfig config;
	
	public void sendSuccesMail(String jobName) throws TaleoException, EmailUtilException{			
		log.info("Entered into SendMailHelperService.sendSuccesMail method: jobName - {}", jobName);
		MailUtilityDetails mailUtil;
		LiferayDto dto = new LiferayDto();
		
		mailUtil = createMailDetailObject();
		if(jobName.equalsIgnoreCase(TaleoConstant.EAR_JOB_NAME))
			dto.setPath(TaleoConstant.SH_TALEO_EAR_SUCCESS_TEMP_LIFERAY_URL);
		else
			dto.setPath(TaleoConstant.SH_TALEO_OUTBOUND_SUCCESS_TEMP_LIFERAY_URL);
	
		serviceUtility.sendSuccesOrExceptionMailWithLifeRay(mailUtil, dto);
		log.info("Exiting SendMailHelperService.sendSuccesMail method.");
	}
	
	public void sendFailureMail(String jobName) throws TaleoException, EmailUtilException{		
		log.info("Entered into SendMailHelperService.sendFailureMail method: jobName - {}", jobName);
		
		MailUtilityDetails mailUtil;
		LiferayDto dto = new LiferayDto();
		
		mailUtil = createMailDetailObject();
		if(jobName.equalsIgnoreCase(TaleoConstant.EAR_JOB_NAME))
			dto.setPath(TaleoConstant.SH_TALEO_EAR_EXCEP_TEMP_LIFERAY_URL);
		else
			dto.setPath(TaleoConstant.SH_TALEO_OUTBOUND_EXCEP_TEMP_LIFERAY_URL);
	
		serviceUtility.sendSuccesOrExceptionMailWithLifeRay(mailUtil, dto);
		log.info("Exiting SendMailHelperService.sendFailureMail method.");
	}
	
	private MailUtilityDetails createMailDetailObject() throws TaleoException {
		log.info("Entered into SendMailHelperService.createMailDetailObject method:");
		MailUtilityDetails utilityDetails = new MailUtilityDetails();
		List<String> mailToAddress = new ArrayList<>();
		List<String> mailCcAddress = new ArrayList<>();
		if(config.getEmailToAddress().length > 0)
			Collections.addAll(mailToAddress, config.getEmailToAddress());
		
		if(config.getEmailCcAddress().length > 0)
			Collections.addAll(mailCcAddress, config.getEmailCcAddress());
		
		utilityDetails.setMailToAddress(mailToAddress);
		utilityDetails.setMailCcAddress(mailCcAddress);
		utilityDetails.setMailFromAddress(TaleoConstant.FROM_EMAIL_ADDRESS);
		log.info("Exiting SendMailHelperService.createPricingMailUtilityDetails method:");
		return utilityDetails;
	}

}



