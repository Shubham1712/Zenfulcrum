package com.zensar.zenfulcrum.taleo.processor;

import java.util.Calendar;
import java.util.Date;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.model.Employee;
import com.zensar.zenfulcrum.taleo.model.TSrf;
import com.zensar.zenfulcrum.taleo.repository.TaleoMainRepository;
import com.zensar.zenfulcrum.taleo.util.TaleoConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class TaleoMainProcessor implements ItemProcessor<Employee, TSrf>{
	
	@Autowired
	private TaleoMainRepository mainRepository;
	
	@Override
	public TSrf process(Employee employee) throws TaleoException {
		
		try {
			log.info("Entered into TaleoMainProcessor.process method, Employee id : {}",employee.getCandidateId());
			TSrf srfRecord = mapEmployeeToSrf(employee);
			
			long result = mainRepository.checkEmployeeExists(srfRecord.getCandidateId(), srfRecord.getProjectId(), srfRecord.getSrfNumber());	// Need to fetch primary key for project_id from M_project
			if(result>0) {
				log.info("Updating Employee as already exists in tsrf - {}",employee.getCandidateId());
				long id = mainRepository.getEmployeeIdToUpdate(srfRecord);
				mainRepository.updateEmployeeDetails(srfRecord, id);
				log.info(TaleoConstant.EXIT_MSG_MAIN_PROCESSOR);
				return null;					// After updating sending record as null to Writer
			}
			else {
				log.info(TaleoConstant.EXIT_MSG_MAIN_PROCESSOR);
				return srfRecord;					// If not exists sending the actual record to writer
			}
			
		} catch (DataAccessException exp) {
			
			log.error("Encountered error TaleoMainProcessor.process method : {}", exp);
			throw new TaleoException(exp);
		}
		
	}

	private Long getStatudId(String moduleCode, String recordStatus) {
		return mainRepository.getStatusIdFromLookUP(moduleCode, recordStatus);
	}
	
	private TSrf mapEmployeeToSrf(Employee employee) {
		
		TSrf record = new TSrf();
		record.setSrfNumber(employee.getSrfNumber());
		record.setCandidateId(Long.parseLong(employee.getCandidateId()));
		record.setProjectId(employee.getProjectId());
		record.setSelectionDate(employee.getSelectionDate());
		record.setStatusStartDate(employee.getStatusStartDate());
		record.setStatusEndDate(employee.getStatusEndDate());
		record.setResourceStatus(employee.getResourceStatus());
		record.setCreatedDate(new Date());
		record.setLastUpdatedDate(new Date());
		record.setStatusId(getStatudId(TaleoConstant.MODULE_CODE, employee.getRecordStatus()));	// "SRF" as module code
		if(employee.getIsSelected().equalsIgnoreCase("YES"))				
			record.setIsSelected(true);
		else
			record.setIsSelected(false);
		record.setEffectiveStartDate(new Date());
		record.setEffectiveEndDate(getFutureDate(45));
		return record;
	}

	private Date getFutureDate(int days) {
		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); 	
		c.add(Calendar.DATE, days); 	//Adding days in current date
		return c.getTime();
	}

}
