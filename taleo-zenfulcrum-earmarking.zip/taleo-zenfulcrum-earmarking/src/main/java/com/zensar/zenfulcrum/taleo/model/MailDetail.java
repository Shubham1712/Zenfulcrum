package com.zensar.zenfulcrum.taleo.model;

import java.util.List;

import lombok.Data;

@Data
public class MailDetail {

	private List<String> mailToAddress;      
	private String mailFromAddress;     
	private List<String> mailCcAddress;    
	private List<String> mailBccAddress;     
	private String mailSubject;   
	private String mailBody;
}
