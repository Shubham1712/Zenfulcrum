package com.zensar.zenfulcrum.taleo.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.taleo.exception.TaleoException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class TaleoUtils {


	 public void moveFilesToBackUp(String sourcePath, String destPath) throws TaleoException{
	    	
         log.info("Entered TaleoUtils.moveFilesToBackUp method: srcFolder-{}  and destFolder-{}", sourcePath, destPath);
          try {
              File[] files = getTheFilesWithExtension(sourcePath, TaleoConstant.FILE_EXTENSION);
              for (File file : files){
                  moveFile(file.getPath(),destPath+file.getName());
              }
          } catch (IOException ioe) {
          	log.error("Encountered error while moving files to backup folder - {}", ioe.getMessage());
          	throw new TaleoException("error while moving files to backup folder");
          }
          log.info("Exiting TaleoUtils.moveFilesToBackUp method:");
      }
	 
	 
	private boolean moveFile(String source, String destination) throws IOException {
        Files.move(Paths.get(source), Paths.get(destination), StandardCopyOption.REPLACE_EXISTING);
        return true;
    }

    private File[] getTheFilesWithExtension(String filePath, String ext) {

        File fileDir = new File(filePath);
        return fileDir.listFiles((dir, name) -> name.toLowerCase().endsWith(ext));
    }

   
}
