package com.zensar.zenfulcrum.taleo.util;

public class TaleoSqlQuery {
	
	private TaleoSqlQuery() {}
	public static final String EAR_STAG_QUERY = "SELECT * FROM "+TaleoConstant.STAGING_SCHEMA+".STG_RESOURCE_EARMARKING_DETAILS where last_updated_date >= ? OR created_date >= ?";
	
	public static final String GET_EMPLOYEE_NUMBER_M_EMP = "SELECT emp.EMPLOYEE_NUMBER FROM "+TaleoConstant.ADMIN_SCHEMA+".M_EMPLOYEE emp WHERE \r\n" + 
										"(emp.grade LIKE 'A%' OR\r\n" + 
										"emp.grade LIKE 'B%' OR\r\n" + 
										"emp.grade LIKE 'C%' OR\r\n" + 
										"emp.grade LIKE 'D%' OR\r\n" + 
										"emp.grade LIKE 'E%') AND\r\n" + 
										"emp.termination_date IS NULL AND\r\n" + 
										"(emp.created_date >=  ?  OR  emp.last_updated_date  >= ? )";
	
}
