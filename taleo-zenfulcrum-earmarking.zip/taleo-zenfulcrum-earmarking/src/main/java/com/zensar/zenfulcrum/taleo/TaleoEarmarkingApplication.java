package com.zensar.zenfulcrum.taleo;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.zensar.zenfulcrum.emailservice.EmailServiceUtility;

/**
 * @author ST52015
 *
 */

@SpringBootApplication
@EnableBatchProcessing
@EnableScheduling
@ComponentScan("com.zensar.zenfulcrum.taleo.*")
public class TaleoEarmarkingApplication {

	
		public static void main(String[] args) {
			SpringApplication.run(TaleoEarmarkingApplication.class, args);
		}
		
			
		@Bean
		public ExecutionContext executionContext() {
			return new ExecutionContext();
		}
		
		@Bean
		public EmailServiceUtility emailServiceUtility(){
				return new EmailServiceUtility();
		}
}
