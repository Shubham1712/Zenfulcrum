package com.zensar.zenfulcrum.taleo.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.model.Employee;
import com.zensar.zenfulcrum.taleo.repository.TaleoStagingRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class TaleoStagingWriter implements ItemWriter<Employee>{

	@Autowired
	private TaleoStagingRepository stagingRepository;
	
	@Override
	public void write(List<? extends Employee> employees) throws TaleoException  {
		
			try {
					log.info("Entered into TaleoStagingWriter.write method: Inserting {} number of employees into staging table", employees.size());
					stagingRepository.saveAll(employees);					// Inserting in chunk i.e. list of records in ZF staging table
					log.info("Exiting TaleoStagingWriter.write method:");
					
			} catch (DataAccessException exp) {
				
				log.error("Encountered error in TaleoMainWriter.write method: {}", exp);
				throw new TaleoException(exp);
			}
	}

}
