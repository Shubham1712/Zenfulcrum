package com.zensar.zenfulcrum.taleo.mapper;


import java.util.Date;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.zensar.zenfulcrum.taleo.model.Employee;
import com.zensar.zenfulcrum.taleo.util.TaleoConstant;

public class EmployeeFileRowMapper implements FieldSetMapper<Employee>{
	
	@Override
	public Employee mapFieldSet(FieldSet fieldSet) throws BindException {
		Employee emp = new Employee();
		
		emp.setSrfNumber(fieldSet.readString(TaleoConstant.SRF_NUMBER));
		emp.setCandidateId(fieldSet.readString(TaleoConstant.CANDIDATE_ID));
		emp.setProjectId(fieldSet.readString(TaleoConstant.PROJECT_ID));
		emp.setSelectionDate(fieldSet.readDate(TaleoConstant.SELECTION_DATE, TaleoConstant.DATE_FORMAT));
		emp.setStatusStartDate(fieldSet.readDate(TaleoConstant.STATUS_START_DATE, TaleoConstant.DATE_FORMAT));
		emp.setStatusEndDate(fieldSet.readDate(TaleoConstant.STATUS_END_DATE, TaleoConstant.DATE_FORMAT));
		emp.setIsSelected(fieldSet.readString(TaleoConstant.IS_SELECTED));
		emp.setResourceStatus(fieldSet.readString(TaleoConstant.RESOURCE_STATUS));
		emp.setRecordStatus(fieldSet.readString(TaleoConstant.RECORD_STATUS));
		emp.setCreatedDate(new Date());
		emp.setLastUpdatedDate(new Date());
		
		return emp;
	}



	

	
}
