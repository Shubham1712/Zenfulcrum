package com.zensar.zenfulcrum.taleo.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.model.TSrf;
import com.zensar.zenfulcrum.taleo.repository.TaleoMainRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class TaleoMainWriter implements ItemWriter<TSrf>{

	@Autowired
	private TaleoMainRepository mainRepository;
	
	@Override
	public void write(List<? extends TSrf> employees) throws TaleoException {
		
		try {
				log.info("Entered into TaleoMainWriter.write method: Inserting {} number of employees into main table", employees.size());
				mainRepository.saveAll(employees);				// Inserting in chunk i.e. list of records in ZF main table
				log.info("Exiting TaleoMainWriter.write method:");
				
		} catch (DataAccessException exp) {
			
			log.error("Encountered error in TaleoMainWriter.write method: {}", exp);
			throw new TaleoException(exp);
		}
	}

	
}
