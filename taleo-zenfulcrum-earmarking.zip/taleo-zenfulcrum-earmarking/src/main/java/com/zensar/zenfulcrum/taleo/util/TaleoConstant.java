package com.zensar.zenfulcrum.taleo.util;


public class TaleoConstant {

	private TaleoConstant() {}
	public static final String SOURCE_FILE_PATH = "SOURCE_FILE_PATH";
	public static final String PIPE_DELIMETER = "|";
	public static final String LAST_RUNTIME = "lastRunTime";
	public static final String LAST_UPDATE_DATE = "lastUpdateDate";
	public static final String COMMA_DELIMETER = ",";
	public static final String EMAIL_TO_USERS = "shubham.topare@zensar.com";		// Need to add to user
	public static final String EMAIL_CC_USERS = "";
	public static final String EMAIL_BCC_USERS = "";
	public static final String FROM_EMAIL_ADDRESS = "ZenDirector@zensar.com";
	public static final String INSUFFICIENT_EMAIL_PARAMS = "Insufficient Email Input Params";
	public static final String EMAIL_ERROR_SUBJECT = "Alert:Error in PeoplesoftData Interface";
	public static final String STATUS_SUCCESS = "COMPLETED";
	public static final String STATUS_FAILED = "FAILED";
	public static final String EAR_JOB_NAME = "EarmarkingJob";
	public static final String OUTBOUND_JOB_NAME = "OutboundJob";
	public static final Integer CHUNK_SIZE = 5000000;
	public static final String SHELL_SCRIPT = "earmarking.sh";
	
	public static final String FILE_EXTENSION = ".csv";
	public static final String MODULE_CODE = "SRF";
	public static final String TALEO_OUTBOUND_INTERFACE_DESP = "PD_TALEO_INTEVIEW_INTERFACE";
	
	//Schemas
	public static final String STAGING_SCHEMA = "zf_staging";
	public static final String ADMIN_SCHEMA = "zf_admin";
	public static final String RES_MANG_SCHEMA = "zf_resourcemanagement";
	public static final String PROJ_DEF_SCHEMA = "zf_projectdefinition";
	
	public static final String SH_TALEO_EAR_EXCEP_TEMP_LIFERAY_URL = "Schedulers/Taleo/SH_TALEO_EAR_EXCEP_TEMP";
	public static final String SH_TALEO_EAR_SUCCESS_TEMP_LIFERAY_URL = "Schedulers/Taleo/SH_TALEO_EAR_SUCCESS_TEMP";
	public static final String SH_TALEO_OUTBOUND_EXCEP_TEMP_LIFERAY_URL = "Schedulers/Taleo/SH_TALEO_OUTBOUND_EXCEP_TEMP";
	public static final String SH_TALEO_OUTBOUND_SUCCESS_TEMP_LIFERAY_URL = "Schedulers/Taleo/SH_TALEO_OUTBOUND_SUCCESS_TEMP";
	
	
	public static final String CANDIDATE_ID = "candidateId";
	public static final String PROJECT_ID = "projectId";
	public static final String STATUS_START_DATE = "statusStartDate";
	public static final String STATUS_END_DATE = "statusEndDate";
	public static final String RESOURCE_STATUS = "resourceStatus";
	public static final String SRF_NUMBER = "srfNumber";
	public static final String RECORD_STATUS = "recordStatus";
	public static final String IS_SELECTED = "isSelected";
	public static final String SELECTION_DATE = "SelectionDate";
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String DATE_FORMAT_SLASH = "yyyy/MM/dd";
	
	
	public static final String EXIT_MSG_STAG_PROCESSOR = "Exiting TaleoStagingProcessor.process method";
	public static final String EXIT_MSG_MAIN_PROCESSOR = "Exiting TaleoMainProcessor.process method";
	
	//Taleo Outbound
	public static final String CONFIG_PROFILE_DESP = "Zen_Configuration Hiring_Manager";
	public static final String USER_TYPE_DESP = "Zen_Interview Collaborator";
	public static final String EMPLOYEE_NUMBER = "employeeNumber";
	public static final String CONFIG_PROFILE = "configProfile";
	public static final String USER_TYPE = "userType";
	public static final String COLUMN_HEADER = "Employee_Number|Employee_Number|Config_Profile|User_Type";
	
	
}
