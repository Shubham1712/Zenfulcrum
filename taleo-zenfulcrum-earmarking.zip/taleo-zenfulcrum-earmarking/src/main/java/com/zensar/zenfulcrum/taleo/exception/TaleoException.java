package com.zensar.zenfulcrum.taleo.exception;

public class TaleoException extends Exception{

	
	private static final long serialVersionUID = -6874242942736858470L;

	public TaleoException() {
		super();
	}

	public TaleoException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public TaleoException(String message, Throwable cause) {
		super(message, cause);
	}

	public TaleoException(String message) {
		super(message);
	}

	public TaleoException(Throwable cause) {
		super(cause);
	}
	
}
