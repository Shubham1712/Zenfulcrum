package com.zensar.zenfulcrum.taleo.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.zensar.zenfulcrum.taleo.model.Employee;

public class EmployeeRowMapper implements RowMapper<Employee> {

	@Override
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		
		Employee emp = new Employee();
		emp.setSrfNumber(rs.getString(2));
		emp.setCandidateId(rs.getString(3));
		emp.setProjectId(rs.getString(4));
		emp.setSelectionDate(rs.getDate(5));
		emp.setStatusStartDate(rs.getDate(6));
		emp.setStatusEndDate(rs.getDate(7));
		emp.setIsSelected(rs.getString(8));
		emp.setResourceStatus(rs.getString(9));
		emp.setRecordStatus(rs.getString(10));
		return emp;
	}

}
