package com.zensar.zenfulcrum.taleo.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.zensar.zenfulcrum.taleo.model.OutboundEmployee;

public class OutBoundEmployeeRowMapper implements RowMapper<OutboundEmployee> {

	@Override
	public OutboundEmployee mapRow(ResultSet rs, int rowNum) throws SQLException {
		OutboundEmployee emp = new OutboundEmployee();
		emp.setEmployeeNumber(rs.getLong(1));
		return emp;
	}

}
