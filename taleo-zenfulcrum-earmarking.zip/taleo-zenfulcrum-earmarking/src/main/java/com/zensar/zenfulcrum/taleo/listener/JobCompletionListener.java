package com.zensar.zenfulcrum.taleo.listener;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import com.zensar.zenfulcrum.emailservice.exception.EmailUtilException;
import com.zensar.zenfulcrum.taleo.config.TaleoBatchConfig;
import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.helper.SendMailHelperService;
import com.zensar.zenfulcrum.taleo.repository.TaleoStagingRepository;
import com.zensar.zenfulcrum.taleo.util.TaleoConstant;
import com.zensar.zenfulcrum.taleo.util.TaleoUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JobCompletionListener implements JobExecutionListener {

	@Autowired
	private SendMailHelperService mailService;
	
	@Autowired
	private TaleoUtils utils;
	
	@Autowired
	private TaleoStagingRepository repository;

	@Autowired
	private ExecutionContext executionContext;
	
	@Autowired
	private TaleoBatchConfig  config;

	@Override
	public void beforeJob(JobExecution jobExecution) {

		if (jobExecution.getJobInstance().getJobName().equalsIgnoreCase(TaleoConstant.EAR_JOB_NAME)) {
			try {
				log.info("Entered JobCompletionListener.beforeJob method");
				String[] cmd = { config.getEarmarkingShellScriptFile() };
				Process process;
				Optional<Date> lastUpdatedate = repository.getLastUpdateDate();
				String result = getStringFormat(lastUpdatedate);
				log.info("Retrieved last update date - {} from Staging, setting into execution context", result);
				executionContext.putString(TaleoConstant.LAST_UPDATE_DATE, result);
				log.info("Calling script to copying and removing file");
				//process = Runtime.getRuntime().exec(cmd);						//Calling Script
			} catch (DataAccessException exp) {
				log.error("Error in retrieving last update date from staging/Running script", exp);
			}
		} else {
			try {
				log.info("Entered JobCompletionListener.beforeJob method");
				Optional<Date> lastRunTime = repository.getLastRunTime(TaleoConstant.TALEO_OUTBOUND_INTERFACE_DESP);
				String result = getStringFormat(lastRunTime);
				log.info("Retrieved last Runtime date - {} from Interface tracker, setting into execution context",	result);
				executionContext.putString(TaleoConstant.LAST_RUNTIME, result);
				log.info("Moving old csv files to Backup folder");
				utils.moveFilesToBackUp(config.getOutboundSrcFolder(), config.getOutboundDestFolder());
			} catch (DataAccessException | TaleoException exp) {
				log.error("Error in retrieving last runtime date from Interface tracker", exp);
			}

		}

	}

	// Fault tolerant policy?
	@Override
	public void afterJob(JobExecution jobExecution) {
		
		final String jobName = jobExecution.getJobInstance().getJobName();
		try {
			if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
				log.info("Entered Listener: BATCH JOB COMPLETED SUCCESSFULLY FOR {}, SENDING SUCCES MAIL", jobName); // Current behaviour, not sending success mail
					if(jobName.equalsIgnoreCase(TaleoConstant.OUTBOUND_JOB_NAME)) {
						repository.updateLastRunTime(TaleoConstant.TALEO_OUTBOUND_INTERFACE_DESP);
						log.info("Updated Runtime date - {} in Interface tracker to current date", new Date());
					}else {
						log.info("Removing taleo earmarking file");
						Files.delete(Paths.get(config.getEarmarkingSrcFile()));
					}
				mailService.sendSuccesMail(jobName);
			} else {
				log.error("Entered Listener: BATCH JOB FAILED FOR {}, SENDING ERROR MAIL", jobName);
				mailService.sendFailureMail(jobName);
			}
		} catch (TaleoException | IOException | EmailUtilException exp) {
			log.error("Encountered error while sending mail - {}", exp);
		}
	}

	private String getStringFormat(Optional<Date> date) {

		if (date.isPresent()) {
			return date.get().toString();
		} else {
			SimpleDateFormat formatter = new SimpleDateFormat(TaleoConstant.DATE_FORMAT);
			return formatter.format(new Date());
		}
	}
}
