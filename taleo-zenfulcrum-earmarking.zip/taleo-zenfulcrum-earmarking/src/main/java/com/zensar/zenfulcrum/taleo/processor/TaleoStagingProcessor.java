package com.zensar.zenfulcrum.taleo.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.model.Employee;
import com.zensar.zenfulcrum.taleo.repository.TaleoStagingRepository;
import com.zensar.zenfulcrum.taleo.util.TaleoConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TaleoStagingProcessor implements ItemProcessor<Employee,Employee>{

	@Autowired
	private TaleoStagingRepository stagingRepository;
	
	@Override
	public Employee process(Employee employee) throws TaleoException {
		
		try {
			log.info("Entered into TaleoStagingProcessor.process method, Employee id : {}", employee.getCandidateId());
			
			long result = stagingRepository.checkEmployeeExists(employee.getCandidateId(), employee.getProjectId(), employee.getSrfNumber());
			if(result>0) {
				log.info("Updating Employee as already exists in staging - {}", employee.getCandidateId());
				long id = stagingRepository.getEmployeeIdToUpdate(employee);
				stagingRepository.updateEmployeeDetails(employee, id);
				log.info(TaleoConstant.EXIT_MSG_STAG_PROCESSOR);
				return null;									// After updating sending record as null to Writer
			}
			else {
				log.info(TaleoConstant.EXIT_MSG_STAG_PROCESSOR);
				return employee;								// If not exists sending the actual record to writer
			}
		} catch (DataAccessException exp) {
			
			log.error("Encountered error TaleoStagingProcessor.process method : {}", exp);
			throw new TaleoException(exp);
		}
			
	}

}
