DOW=`date +%d_%b_%Y_%H_%M`
/bin/cp /usr/local/taleoSchedulerLogs/CSV/Earmarking/EarMarking_ToPd*.csv /usr/local/taleoSchedulerLogs/CSV/Earmarking/Backup/EarMarking_ToPd-$DOW.csv
/bin/mv /usr/local/taleoSchedulerLogs/CSV/Earmarking/EarMarking_ToPd*.csv /usr/local/taleoSchedulerLogs/CSV/Earmarking/EarMarking_ToPd.csv
