package com.zensar.zenfulcrum.taleo.email;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.emailservice.EmailServiceUtility;
import com.zensar.zenfulcrum.emailservice.exception.EmailUtilException;
import com.zensar.zenfulcrum.taleo.config.TaleoBatchConfig;
import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.helper.SendMailHelperService;

@RunWith(SpringJUnit4ClassRunner.class)
public class SendMailHelperServiceTests {
	
	@InjectMocks
	private SendMailHelperService sendMailHelperService;
	
	@Mock
	private EmailServiceUtility serviceUtility;
	
	@Mock
	private TaleoBatchConfig config;
	
	private String[] input = {"abc","efg","xyz"};
	
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void sendMailSuccessjob1_test() throws TaleoException, EmailUtilException {
		
		when(config.getEmailToAddress()).thenReturn(input);
		when(config.getEmailCcAddress()).thenReturn(input);
		doNothing().when(serviceUtility).sendSuccesOrExceptionMailWithLifeRay(Mockito.any(), Mockito.any());
		sendMailHelperService.sendSuccesMail("EarmarkingJob");
	}
	
	@Test
	public void sendMailSuccessjob2_test() throws TaleoException, EmailUtilException {
		
		when(config.getEmailToAddress()).thenReturn(input);
		when(config.getEmailCcAddress()).thenReturn(input);
		doNothing().when(serviceUtility).sendSuccesOrExceptionMailWithLifeRay(Mockito.any(), Mockito.any());
		sendMailHelperService.sendSuccesMail("job");
	}
	
	@Test
	public void sendMailFailedJob1_test() throws TaleoException, EmailUtilException {
		
		when(config.getEmailToAddress()).thenReturn(input);
		when(config.getEmailCcAddress()).thenReturn(input);
		doNothing().when(serviceUtility).sendSuccesOrExceptionMailWithLifeRay(Mockito.any(), Mockito.any());
		sendMailHelperService.sendFailureMail("EarmarkingJob");
	}
	
	
	@Test
	public void sendMailFailedJob2_test() throws TaleoException, EmailUtilException {
		
		when(config.getEmailToAddress()).thenReturn(input);
		when(config.getEmailCcAddress()).thenReturn(input);
		doNothing().when(serviceUtility).sendSuccesOrExceptionMailWithLifeRay(Mockito.any(), Mockito.any());
		sendMailHelperService.sendFailureMail("job");
	}
		
	
}
