package com.zensar.zenfulcrum.taleo.processor;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator;
import org.springframework.jdbc.support.SQLErrorCodes;
import org.springframework.jdbc.support.SQLErrorCodesFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.model.Employee;
import com.zensar.zenfulcrum.taleo.repository.TaleoMainRepository;

@RunWith(SpringJUnit4ClassRunner.class)
public class TaleoMainProcessorTests {
	
	@InjectMocks
	private TaleoMainProcessor mainProcessor;
	
	@Mock
	private TaleoMainRepository mainRepository;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void process_success_test() throws TaleoException {
		
		
		Employee emp = getEmployeeObj();
		emp.setIsSelected("YES");
		
		when(mainRepository.checkEmployeeExists(Mockito.anyLong(), Mockito.any(), Mockito.any())).thenReturn(1l);
		doNothing().when(mainRepository).updateEmployeeDetails(Mockito.any(), Mockito.any());
		
		mainProcessor.process(emp);
		emp.setIsSelected("NO");
		mainProcessor.process(emp);
	}
	
	@Test(expected = TaleoException.class)
	public void process_failure_test() throws TaleoException {
		
		SQLErrorCodes codes = SQLErrorCodesFactory.getInstance().getErrorCodes("Test Error");
		SQLErrorCodeSQLExceptionTranslator sext = new SQLErrorCodeSQLExceptionTranslator();
		sext.setSqlErrorCodes(codes);

		DataAccessException exFor4200 = sext.translate("", "", new SQLException("Ouch", "42000", 42000));
		
		when(mainRepository.checkEmployeeExists(Mockito.anyLong(), Mockito.anyString(), Mockito.anyString())).thenThrow(exFor4200.getClass());
		mainProcessor.process(getEmployeeObj());
	}
	

	private Employee getEmployeeObj() {
		
		Employee emp = new Employee();
		emp.setSrfNumber("324234");
		emp.setCandidateId("101");
		emp.setProjectId("102");
		emp.setRecordStatus("Activate");
		emp.setResourceStatus("Earmarked");
		emp.setCreatedBy(Long.valueOf(101));
		emp.setLastUpdatedBy(Long.valueOf(101));
		emp.setIsSelected("YES");
		emp.setSelectionDate(new Date());
		emp.setCreatedDate(new Date());
		emp.setLastUpdatedDate(new Date());
		return emp;
	}

	
}
