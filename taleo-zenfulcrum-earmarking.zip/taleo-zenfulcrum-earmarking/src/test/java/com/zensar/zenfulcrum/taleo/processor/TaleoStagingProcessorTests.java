package com.zensar.zenfulcrum.taleo.processor;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.Date;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator;
import org.springframework.jdbc.support.SQLErrorCodes;
import org.springframework.jdbc.support.SQLErrorCodesFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.model.Employee;
import com.zensar.zenfulcrum.taleo.repository.TaleoStagingRepository;

@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class TaleoStagingProcessorTests {
	
	@InjectMocks
	private TaleoStagingProcessor stagingProcessor;
	
	@Mock
	private TaleoStagingRepository stagingRepository;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void process_test() throws TaleoException {
		
		when(stagingRepository.checkEmployeeExists(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
		
		doNothing().when(stagingRepository).updateEmployeeDetails(Mockito.any(), Mockito.any());
		
		stagingProcessor.process(getEmployeeObj());
	}
	

	@Test(expected = TaleoException.class)
	public void process_failure_test() throws TaleoException {
		
		SQLErrorCodes codes = SQLErrorCodesFactory.getInstance().getErrorCodes("Test Error");
		SQLErrorCodeSQLExceptionTranslator sext = new SQLErrorCodeSQLExceptionTranslator();
		sext.setSqlErrorCodes(codes);

		DataAccessException exFor4200 = sext.translate("", "", new SQLException("Ouch", "42000", 42000));
		
		when(stagingRepository.checkEmployeeExists(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenThrow(exFor4200.getClass());
			stagingProcessor.process(getEmployeeObj());
	}
	
	private Employee getEmployeeObj() {
		Employee emp = new Employee();
		emp.setSrfNumber("12345");
		emp.setCandidateId("1001");
		emp.setProjectId("1002");
		emp.setRecordStatus("Deactivate");
		emp.setCreatedBy(Long.valueOf(1002));
		emp.setCreatedDate(new Date());
		return emp;
	}
}
