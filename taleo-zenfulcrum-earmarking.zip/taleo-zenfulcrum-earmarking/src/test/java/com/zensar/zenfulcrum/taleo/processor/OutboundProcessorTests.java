package com.zensar.zenfulcrum.taleo.processor;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.model.OutboundEmployee;

@RunWith(SpringJUnit4ClassRunner.class)
public class OutboundProcessorTests {
	
	@InjectMocks
	OutboundProcessor outboundProcessor;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void process_success_test() throws TaleoException {
		
		
		OutboundEmployee emp = new OutboundEmployee();
		emp.setEmployeeNumber(101);
		emp.setConfigProfile("config");
		emp.setUserType("user");
		
		outboundProcessor.process(emp);
	}
	
}
