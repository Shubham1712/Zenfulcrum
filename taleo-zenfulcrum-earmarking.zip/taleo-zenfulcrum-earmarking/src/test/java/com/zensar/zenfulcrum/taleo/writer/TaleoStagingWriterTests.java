package com.zensar.zenfulcrum.taleo.writer;

import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator;
import org.springframework.jdbc.support.SQLErrorCodes;
import org.springframework.jdbc.support.SQLErrorCodesFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.model.Employee;
import com.zensar.zenfulcrum.taleo.repository.TaleoStagingRepository;

@RunWith(SpringJUnit4ClassRunner.class)
public class TaleoStagingWriterTests {
	
	@InjectMocks
	private TaleoStagingWriter stagingWriter;	
	
	@Mock
	private TaleoStagingRepository stagingRepository;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void write_success_test() throws TaleoException {
		
		when(stagingRepository.saveAll(Mockito.anyCollection())).thenReturn(getRecordList());
		stagingWriter.write(getRecordList());
	}
	
	@Test(expected = TaleoException.class)
	public void write_failure_test() throws TaleoException {
		
		SQLErrorCodes codes = SQLErrorCodesFactory.getInstance().getErrorCodes("Test Error");
		SQLErrorCodeSQLExceptionTranslator sext = new SQLErrorCodeSQLExceptionTranslator();
		sext.setSqlErrorCodes(codes);

		DataAccessException exFor4200 = sext.translate("", "", new SQLException("Ouch", "42000", 42000));
		
		when(stagingRepository.saveAll(Mockito.anyCollection())).thenThrow(exFor4200.getClass());
			stagingWriter.write(getRecordList());
	}
	
	private List<Employee> getRecordList() {
		
		Employee emp = new Employee();
		List<Employee> recordList = new ArrayList<>();
		emp.setSrfNumber("324234");
		emp.setCandidateId("101");
		emp.setProjectId("102");
		recordList.add(emp);
		emp.setSrfNumber("3242353434");
		emp.setCandidateId("102");
		emp.setProjectId("102");
		recordList.add(emp);
		return recordList;
	}

	
}
