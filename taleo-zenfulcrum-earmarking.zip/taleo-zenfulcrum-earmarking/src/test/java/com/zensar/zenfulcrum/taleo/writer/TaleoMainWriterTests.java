package com.zensar.zenfulcrum.taleo.writer;

import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator;
import org.springframework.jdbc.support.SQLErrorCodes;
import org.springframework.jdbc.support.SQLErrorCodesFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.taleo.exception.TaleoException;
import com.zensar.zenfulcrum.taleo.model.TSrf;
import com.zensar.zenfulcrum.taleo.repository.TaleoMainRepository;

@RunWith(SpringJUnit4ClassRunner.class)
public class TaleoMainWriterTests {
	
	@InjectMocks
	private TaleoMainWriter mainWriter;
	
	@Mock
	private TaleoMainRepository mainRepository;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void write_success_test() throws TaleoException {
		
		when(mainRepository.saveAll(Mockito.anyCollection())).thenReturn(getRecordList());
		mainWriter.write(getRecordList());
	}
	

	@Test(expected = TaleoException.class)
	public void write_failure_test() throws TaleoException {

		SQLErrorCodes codes = SQLErrorCodesFactory.getInstance().getErrorCodes("Test Error");
		SQLErrorCodeSQLExceptionTranslator sext = new SQLErrorCodeSQLExceptionTranslator();
		sext.setSqlErrorCodes(codes);

		DataAccessException exFor4200 = sext.translate("", "", new SQLException("Ouch", "42000", 42000));
		
		when(mainRepository.saveAll(Mockito.anyCollection())).thenThrow(exFor4200.getClass());
		mainWriter.write(getRecordList());
	}
	
	private List<TSrf> getRecordList() {
		TSrf srf = new TSrf();
		List<TSrf> recordList = new ArrayList<TSrf>();
		srf.setSrfNumber("324234");
		srf.setCandidateId(Long.valueOf(101));
		srf.setProjectId("101");
		recordList.add(srf);
		srf.setSrfNumber("3242353434");
		srf.setCandidateId(Long.valueOf(102));
		srf.setProjectId("102");
		recordList.add(srf);
		
		return recordList;
	}
	
}








