package com.zensar.zenfulcrum.authentication.authorization.config;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(value = "authenticateUser", url = "http://10.42.204.149/com.zensar.auth.ldap_v1/login")
public interface CASAuthenticationClient {
	
	@PostMapping("/authenticateUser")
    String authenticateUser(@RequestHeader("j_username") String userCode, @RequestHeader("j_password") String password);
	
	@PostMapping("/authenticateUser")
    String validateToken(@RequestHeader("encryptedtoken") String userTokenValue);
}
