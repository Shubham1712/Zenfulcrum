package com.zensar.zenfulcrum.authentication.authorization.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class LoginDetailsDto implements Serializable	{
	private static final long serialVersionUID = 3193995275938685005L;
	private String userSessionId;
	private String userCode;
	private String encryptedTokenValue;
	private Integer userId;
	private Integer roleId;
}
