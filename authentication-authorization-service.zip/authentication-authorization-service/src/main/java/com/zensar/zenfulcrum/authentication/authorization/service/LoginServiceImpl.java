package com.zensar.zenfulcrum.authentication.authorization.service;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zensar.zenfulcrum.authentication.authorization.config.CASAuthenticationClient;
import com.zensar.zenfulcrum.authentication.authorization.dto.LoginDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.UserAuthenticationDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.UserDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.exception.AuthServiceException;
import com.zensar.zenfulcrum.authentication.authorization.model.BackdoorInfo;
import com.zensar.zenfulcrum.authentication.authorization.model.Employee;
import com.zensar.zenfulcrum.authentication.authorization.model.LoginInfo;
import com.zensar.zenfulcrum.authentication.authorization.repository.BackdoorInfoRepository;
import com.zensar.zenfulcrum.authentication.authorization.repository.EmployeeRepository;
import com.zensar.zenfulcrum.authentication.authorization.repository.LoginInfoRepository;
import com.zensar.zenfulcrum.authentication.authorization.repository.UserInfoRepository;
import com.zensar.zenfulcrum.authentication.authorization.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.authentication.authorization.util.AuthServiceConstant;
import com.zensar.zenfulcrum.authentication.authorization.util.DecryptionUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LoginServiceImpl implements LoginService {

	@Autowired
	private AdminServiceClient adminServiceClient;

	@Autowired
	private CASAuthenticationClient casAuthenticationClient;

	@Autowired
	LoginInfoRepository loginRepo;
	@Autowired
	DecryptionUtil decryptionUtil;
	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	BackdoorInfoRepository backdoorHistoryRepository;

	@Autowired
	UserInfoRepository userInfoRepository;

	// commented by bhagyashri as not using (instead of this using encrypted values)
//	@Override
//	public UserDetailsDto authenticateUser(String userCode, String password) throws AuthServiceException {
//		log.info("Entered inside LoginServiceImpl.authenticateUser method:");
//		UserDetailsDto loggedInUserDetails = null;
//		userCode = userCode.toUpperCase();
//		// Adding below lines of code for bypassing tag usercode for UAT testing purpose
//		if (userCode.equalsIgnoreCase("97440") || userCode.contains("97440")) {
//			loggedInUserDetails = new UserDetailsDto();
//			loggedInUserDetails.setUserCode(userCode);
//			loggedInUserDetails.setEncryptedTokenValue("TESTENCRYPTEDTOKENFORTAGUSERUATBYPASS");
//		} else {
//			String authResponse = casAuthenticationClient.authenticateUser(userCode, password);
//			try {
//				if (authResponse != null) {
//					ObjectMapper objectMapper = new ObjectMapper();
//					UserAuthenticationDetailsDto authResponseDtls = objectMapper.readValue(authResponse,
//							UserAuthenticationDetailsDto.class);
//					log.info("authResponseDtls::" + authResponseDtls);
//					if (authResponseDtls.getStatusMessage()
//							.equalsIgnoreCase(AuthServiceConstant.LOGIN_SUCCESS_STATUS_MESSAGE)) {
//						loggedInUserDetails = new UserDetailsDto();
//						loggedInUserDetails.setUserCode(userCode);
//						loggedInUserDetails.setEncryptedTokenValue(authResponseDtls.getEncryptedToken());
//					}
//				}
//			} catch (Exception excep) {
//				throw new AuthServiceException(excep);
//			}
//		}
//		log.info("Just before leaving LoginServiceImpl.authenticateUser method:");
//		return loggedInUserDetails;
//	}

	@Override
	public UserDetailsDto getLoggedInUserDetails(LoginDetailsDto loginDetailsDto) throws AuthServiceException {
		log.info("Entered inside LoginServiceImpl.getUserDetails method:");
		UserDetailsDto userDetails = adminServiceClient.getLoggedInUserDetails(loginDetailsDto.getUserCode());
		if (userDetails != null && userDetails.getUserCode() != null) {
			String tmpUserCode = userDetails.getUserCode().toUpperCase();
			userDetails.setUserCode(tmpUserCode);
			String profilePicUrl = userInfoRepository
					.getProfilePicUrl(Integer.valueOf(loginDetailsDto.getUserCode().substring(2)));
			userDetails.setProfilePicUrl(profilePicUrl);
		}
		log.info("Just before leaving LoginServiceImpl.getUserDetails method:" + userDetails);
		return userDetails;
	}

	@Override
	public boolean validateToken(String userCode, String accessToken, String userSessionId)
			throws AuthServiceException {
		log.info("Entered inside LoginServiceImpl.validateToken method:");
		String tokenVal = null;
//		String validationResponseStr = adminServiceClient.validateToken(accessToken);
		String validationResponseStr = casAuthenticationClient.validateToken(accessToken);
		boolean validationRepsonse = false;
		try {
			if (validationResponseStr != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				UserAuthenticationDetailsDto validationResponseDtls = objectMapper.readValue(validationResponseStr,
						UserAuthenticationDetailsDto.class);
				if (validationResponseDtls.getStatusMessage()
						.equalsIgnoreCase(AuthServiceConstant.LOGIN_SUCCESS_STATUS_MESSAGE)) {
					LoginDetailsDto modifiedLoginDetailsDto = new LoginDetailsDto();
					modifiedLoginDetailsDto.setEncryptedTokenValue(accessToken + "NewOne");
					modifiedLoginDetailsDto.setUserCode(userCode);
					modifiedLoginDetailsDto.setUserSessionId(userSessionId);
					UserDetailsDto loggedInUserDetails = adminServiceClient.postLoginAction(modifiedLoginDetailsDto);
					if (loggedInUserDetails != null) {
						tokenVal = loggedInUserDetails.getEncryptedTokenValue();
					}
					if (tokenVal != null && tokenVal.equalsIgnoreCase(accessToken)) {
						validationRepsonse = true;
					}
				}
			}
		} catch (Exception excep) {
			throw new AuthServiceException(excep);
		}
		log.info("Just before leaving LoginServiceImpl.validateToken method:");
		return validationRepsonse;
	}

	// added by bhagyashri to save adoption data
	public void saveLoginHistory(String userId, String encryptedToken) throws AuthServiceException {
		log.info("Entered inside LoginServiceImpl.saveLoginHistory method:");
		LoginInfo userLogin = new LoginInfo();
		try {
			List<LoginInfo> userDetail = loginRepo.findByEmployeeId(userId.substring(2));
			if (userDetail != null) {
				loginRepo.updateLoginDetail(userId.substring(2), 1, encryptedToken);
			} else {
				Timestamp timestamp = new Timestamp(System.currentTimeMillis());
				userLogin.setEmployeeNumber(userId.substring(2));
				userLogin.setEncryptedToken(encryptedToken);
				userLogin.setCreatedDate(timestamp);
				userLogin.setLastUpdatedDate(timestamp);
				userLogin.setActive(1);
				loginRepo.save(userLogin);
			}

		} catch (Exception e) {
			throw new AuthServiceException(e);
		}
		log.info("Just before leaving LoginServiceImpl.SaveLoginHistory method:");
		return;
	}

	// added by bhagyashri to save logout info
	@Override
	public void logoutUserHistory(LoginDetailsDto loginDetailsDto) {
		log.info("Entered inside LoginServiceImpl.logoutUserHistory method:");
		List<LoginInfo> exist = loginRepo.findByEmployeeId(loginDetailsDto.getUserCode());
		if (exist != null) {
			loginRepo.updateLogoutDetail(loginDetailsDto.getUserCode().substring(2), 0);
		} else {
			LoginInfo userLogin = new LoginInfo();
			log.info("LoginHistory created while logout");
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			userLogin.setEmployeeNumber(loginDetailsDto.getUserCode().substring(2));
			userLogin.setEncryptedToken(loginDetailsDto.getEncryptedTokenValue());
			userLogin.setCreatedDate(timestamp);
			userLogin.setLastUpdatedDate(timestamp);
			userLogin.setActive(0);
			loginRepo.save(userLogin);
		}
		log.info("Just before leaving LoginServiceImpl.logoutUserHistory method:");
		return;

	}

	// added by bhagyashri for ldap authentication with encrypted usercode and
	// encrypted password
	@Override
	public UserDetailsDto authenticateuserWithToken(String encryptedUserCode, String userTokenValue)
			throws AuthServiceException {
		log.info("Entered inside LoginServiceImpl.authenticateuserWithToken method:");
		UserDetailsDto loggedInUserDetails = null;
		try {
			String userCode = decryptionUtil.decrypt(encryptedUserCode);
			String password = decryptionUtil.decrypt(userTokenValue);
			userCode = userCode.toUpperCase();
			// Adding below lines of code for bypassing tag usercode for UAT testing purpose
			if (userCode.equalsIgnoreCase("97440") || userCode.contains("97440")) {
				loggedInUserDetails = new UserDetailsDto();
				loggedInUserDetails.setUserCode(userCode);
				loggedInUserDetails.setEncryptedTokenValue("TESTENCRYPTEDTOKENFORTAGUSERUATBYPASS");
			} else {

				if (password != null && userCode != null) {
					String authResponse = casAuthenticationClient.authenticateUser(userCode, password);

					if (authResponse != null) {
						ObjectMapper objectMapper = new ObjectMapper();
						UserAuthenticationDetailsDto authResponseDtls = objectMapper.readValue(authResponse,
								UserAuthenticationDetailsDto.class);
						log.info("authResponseDtls::" + authResponseDtls);
						if (authResponseDtls.getStatusMessage()
								.equalsIgnoreCase(AuthServiceConstant.LOGIN_SUCCESS_STATUS_MESSAGE)) {
							loggedInUserDetails = new UserDetailsDto();
							loggedInUserDetails.setUserCode(userCode);
							loggedInUserDetails.setEncryptedTokenValue(authResponseDtls.getEncryptedToken());
						}
					}
				} else {
					log.error("Error while decrypting token");
					throw new AuthServiceException();
				}
			}
		} catch (Exception excep) {
			throw new AuthServiceException(excep);
		}

		log.info("Just before leaving LoginServiceImpl.authenticateuserWithToken method:");
		return loggedInUserDetails;

	}

	// added by bhagyashri to check if backdoor user is active or not
	@Override
	public UserDetailsDto validateBackdoorUserEmployee(Integer backDoorUserId, LoginDetailsDto loginDetailsDto)
			throws AuthServiceException {
		log.info("Entered inside LoginServiceImpl.validateBackdoorUserEmployee method:");
		UserDetailsDto loggedInUserDetails = new UserDetailsDto();
		try {
			Employee emp = employeeRepository.activeEmployee(backDoorUserId);
			if (emp != null) {
				loggedInUserDetails = adminServiceClient.getLoggedInUserDetails(backDoorUserId.toString());
				loggedInUserDetails.setActiveFlag(true);
				return loggedInUserDetails;
			} else {
				loggedInUserDetails.setActiveFlag(false);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			loggedInUserDetails.setActiveFlag(false);
			return loggedInUserDetails;
		}
		log.info("Just before leaving LoginServiceImpl.validateBackdoorUserEmployee method:");
		return loggedInUserDetails;

	}

	// added by bhagyashri to maintain backdoor entry history
	@Override
	public boolean saveBackdoorInfo(String adminUserCode, Integer backDoorUserId, Integer roleId)
			throws AuthServiceException {
		log.info("Entered inside LoginServiceImpl.saveBackdoorInfo method:");
		boolean saveInfo = false;
		;
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		try {
			BackdoorInfo backdoorDetail = backdoorHistoryRepository.getPreviousLoggedInDetail(adminUserCode,
					backDoorUserId);
			if (backdoorDetail != null) {
				backdoorHistoryRepository.updateLoggedInTime(adminUserCode, backDoorUserId, roleId);
				saveInfo = true;
			} else {
				backdoorDetail = new BackdoorInfo();
				backdoorDetail.setAdmin_id(adminUserCode);
				backdoorDetail.setEmployee_number(backDoorUserId);
				backdoorDetail.setRole_id(roleId);
				backdoorDetail.setCreated_date(timestamp);
				backdoorHistoryRepository.save(backdoorDetail);
				saveInfo = true;
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			saveInfo = false;
		}
		log.info("Just before leaving LoginServiceImpl.saveBackdoorInfo method:");
		return saveInfo;
	}
}
