package com.zensar.zenfulcrum.authentication.authorization.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "M_EMPLOYEE")
public class Employee {
	@Id
	private Integer employee_id;
	private Integer employee_number;
	private String employee_name;
	private String first_name;
	private String middle_name;
	private String last_name;
	private String name_prefix;
	private String gender;
	private String grade;
	private String email_id;
	private Integer termination_flag;
	private Timestamp hire_date;
	private Timestamp termination_date;
	private Integer payroll_id;
	private String payroll;
	private String employee_position;
	private Integer base_location_id;
	private Integer business_unit_id;
	private String hiring_sbu;
	private Integer status_id;
	private Integer created_by;
	private Integer last_updated_by;
	private Timestamp created_date;
	private Timestamp last_updated_date;
	private Timestamp effective_start_date;
	private Timestamp effective_end_date;

}
