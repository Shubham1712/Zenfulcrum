package com.zensar.zenfulcrum.authentication.authorization.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.zensar.zenfulcrum.authentication.authorization.model.UserInfo;

public interface UserInfoRepository extends JpaRepository<UserInfo, Integer> {

	@Query(value = "SELECT profilePicUrl FROM M_USERINFO WHERE userId= :userId ",nativeQuery = true)
	public String getProfilePicUrl(@Param("userId") Integer userId);
}
