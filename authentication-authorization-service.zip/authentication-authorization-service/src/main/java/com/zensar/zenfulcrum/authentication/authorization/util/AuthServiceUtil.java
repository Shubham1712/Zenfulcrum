package com.zensar.zenfulcrum.authentication.authorization.util;

import java.util.List;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import com.zensar.zenfulcrum.authentication.authorization.dto.AuthServiceDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.AuthServiceErrorDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.AuthServiceResponseDto;

@Component
public class AuthServiceUtil {
	private AuthServiceUtil() {
		super();
	}

	/**
	 * This method check uniqueness of list
	 * 
	 * @param collections
	 * @return
	 */
	public static boolean checkUnique(List<String> collections) {
		if (!CollectionUtils.isEmpty(collections)) {
			return collections.size() == collections.stream().distinct().count();
		}
		return true;
	}

	/**
	 * This method will create error response
	 * 
	 * @param APIResponse
	 * @param message
	 * @param cause
	 */
	public static void createBadRequest(AuthServiceResponseDto authServiceResponseDto, String message, String cause) {
		AuthServiceErrorDto authServiceErrorDto = new AuthServiceErrorDto();
		authServiceErrorDto.setErrorMessage(message);
		authServiceErrorDto.setErrorCause(cause);
		authServiceResponseDto.setError(authServiceErrorDto);
	}

	/**
	 * This method set API data to response
	 * 
	 * @param APIResponse
	 * @param object
	 */
	public static void setAuthServiceDto(AuthServiceResponseDto authServiceResponseDto, Object object) {
		AuthServiceDto authServiceDto = new AuthServiceDto();
		authServiceDto.setDataObject(object);
		authServiceResponseDto.setAuthServiceDto(authServiceDto);
	}
	
	/**
	 * This method set API data to response
	 * 
	 * @param APIResponse
	 * @param object
	 */
	public static void setAuthServiceDtoList(AuthServiceResponseDto authServiceResponseDto, List<Object> object) {
		AuthServiceDto authServiceDto = new AuthServiceDto();
		authServiceDto.setDataObjects(object);
		authServiceResponseDto.setAuthServiceDto(authServiceDto);
	}
	
	/* test method */
	public boolean setBooleanParamvalue(String valueSet) {
		if(valueSet.equalsIgnoreCase("true"))
			return true;
		else 
			return false;
	}
}
