package com.zensar.zenfulcrum.authentication.authorization.util;

public class AuthServiceConstant {

	private AuthServiceConstant() {

	}
	
	public static final String CONSTRAINT_EXCEPTION = "ConstraintViolationException";
	public static final String INSUFFICIENT_INPUT = "InsufficientInputException";
	public static final String INVALID_INPUT = "InValidInputException";
	public static final String SAML_PREFIX = "/saml/sp/";
	public static final String SAML_DISCOVERY_CONTEXT_PATH = "discovery?idp=";
	public static final String SAML_LOGOUT_CONTEXT_PATH = "logout";
	public static final String SAML_IDP_ADFS_URL = "http://testadfs.zensar.com/adfs/services/trust";
	public static final String URL_REDIRECT_STRING = "redirect:";
	public static final String SAML_LOGIN_SUCCESS_URL = "/loginSuccess";
	public static final String LOGIN_SUCCESS_STATUS_MESSAGE = "User login successfully.";
	public static final String LOGIN_FAIL_STATUS_MESSAGE = "Invalid credentials. Please enter the right credentials.";
}
