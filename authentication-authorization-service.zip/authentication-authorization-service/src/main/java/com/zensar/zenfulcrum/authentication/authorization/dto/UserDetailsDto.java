package com.zensar.zenfulcrum.authentication.authorization.dto;
import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class UserDetailsDto implements Serializable {
	private static final long serialVersionUID = 3193995275938685005L;
	private String userName;
	private String userEmailId;
	private Long userId;
	private String userCode;
	private List<RoleDetailsDto> userRoleList;	
	private String encryptedTokenValue;
	private boolean activeFlag;
	private String profilePicUrl;
}
