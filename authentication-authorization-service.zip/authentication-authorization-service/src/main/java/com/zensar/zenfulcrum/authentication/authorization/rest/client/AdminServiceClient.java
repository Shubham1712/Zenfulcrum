package com.zensar.zenfulcrum.authentication.authorization.rest.client;

import static java.util.Optional.ofNullable;

import java.text.MessageFormat;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.zensar.zenfulcrum.authentication.authorization.dto.LoginDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.UserDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.exception.AuthServiceException;
import com.zensar.zenfulcrum.authentication.authorization.util.HttpRequestUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AdminServiceClient {

	@Value("${LOGGED.IN.USER.DETAILS.LIST.REST.URL}")
	private String getLoggedInUserDetails;
	
	@Value("${ADMIN.AUTH.BASE.URL}")
	private String adminAuthBaseUrl;

	@Value("${CAS_AUTHENTICATE_URL}")
	private String authenticateUserUrl;
	
	@Value("${POST.LOGIN.ACTION.URL}")
	private String postLoginActionUrl;

	@Autowired
	private RestTemplate restTemplate;	

	public String authenticateUser(String userCode, String password) throws AuthServiceException {
		log.info("Entered into AdminServiceClient.authenticateUser method:");
		HttpHeaders headers = new HttpHeaders();
		headers.add("j_username", userCode);
		headers.add("j_password", password);
		HttpEntity<String> requestEntityObj = new HttpEntity<>(headers);
		String authenticationResponse = null;
		try {
			ResponseEntity<String> authresponse = restTemplate.postForEntity(authenticateUserUrl, requestEntityObj, String.class);
			if (authresponse.getStatusCode() == HttpStatus.OK) {
				authenticationResponse = authresponse.getBody();
			} 
		} catch (ResourceAccessException rae) {
			log.error("authenticateUser|url:{}|ResourceAccessException:{}", authenticateUserUrl, rae);
			throw new AuthServiceException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("authenticateUser|url:{}|exception:{}", authenticateUserUrl, hcee);
			throw new AuthServiceException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.authenticateUser method:");
		return authenticationResponse;
	}
	
	public UserDetailsDto getLoggedInUserDetails(String userCode)
			throws AuthServiceException {
		log.info("Entered into AdminServiceClient.getLoggedInUserDetails method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String url = adminAuthBaseUrl + MessageFormat.format(getLoggedInUserDetails, userCode);
		UserDetailsDto loggedInUserDetails = null;
		try {
			ResponseEntity<UserDetailsDto> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntityObj, new ParameterizedTypeReference<UserDetailsDto>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<UserDetailsDto> loggedInUserDetailsOptnObj = ofNullable(responseEntityObj.getBody());
				if (loggedInUserDetailsOptnObj.isPresent()) {
					loggedInUserDetails = loggedInUserDetailsOptnObj.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getLoggedInUserDetails|url:{}|ResourceAccessException:{}", url, rae);
			throw new AuthServiceException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getLoggedInUserDetails|url:{}|exception:{}", url, hcee);
			throw new AuthServiceException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.getLoggedInUserDetails method:");
		return loggedInUserDetails;
	}
	
	public String validateToken(String userTokenValue) throws AuthServiceException {
		log.info("Entered into AdminServiceClient.validateToken method:");
		HttpHeaders headers = new HttpHeaders();
		headers.add("encryptedtoken", userTokenValue);
		HttpEntity<String> requestEntityObj = new HttpEntity<>(headers);
		String validationResponse = null;
		try {
			ResponseEntity<String> validationresponseObj = restTemplate.postForEntity(authenticateUserUrl, requestEntityObj, String.class);
			if (validationresponseObj.getStatusCode() == HttpStatus.OK && validationresponseObj.getBody() != null) {
				validationResponse = validationresponseObj.getBody();
			} 
		} catch (ResourceAccessException rae) {
			log.error("validateToken|url:{}|ResourceAccessException:{}", authenticateUserUrl, rae);
			throw new AuthServiceException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("validateToken|url:{}|exception:{}", authenticateUserUrl, hcee);
			throw new AuthServiceException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.validateToken method:");
		return validationResponse;
	}
	
	
	public UserDetailsDto postLoginAction(LoginDetailsDto modifiedLoginDetailsDto) throws AuthServiceException {
		log.info("Entered into AdminServiceClient.postLoginAction method:");
		UserDetailsDto loggedInUserDetails = null;
		try {
			loggedInUserDetails = restTemplate.postForObject(postLoginActionUrl, modifiedLoginDetailsDto, UserDetailsDto.class);
		} catch (ResourceAccessException rae) {
			log.error("postLoginAction|url:{}|ResourceAccessException:{}", authenticateUserUrl, rae);
			throw new AuthServiceException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("postLoginAction|url:{}|exception:{}", authenticateUserUrl, hcee);
			throw new AuthServiceException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.postLoginAction method:");
		return loggedInUserDetails;
	}
}
