package com.zensar.zenfulcrum.authentication.authorization.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class ModuleDetailsDto implements Serializable {
	private static final long serialVersionUID = 3193995275938685005L;
	private Long moduleId;
	private String parentModule;
	private String subModule;
	private String action;
	private String moduleCode;
	private long moduleStatusId;
	private String statusType;
	private String moduleName;
	private boolean isLandingPage;
	private List<ModuleDetailsDto> subModules;
}
