package com.zensar.zenfulcrum.authentication.authorization.projection;

public interface UserRoleProjection {
	
	public Long getRoleId();
	public String getUserCode();
	public String getUserName();
	public String getRoleName();
	public String getUserEmailId();
	public void setRoleId(long roleId);
	public void setUserCode(String userCode);
	public void setUserName(String userName);
	public void setRoleName(String roleName);
	public void setUserEmailId(String userEmailId);

}
