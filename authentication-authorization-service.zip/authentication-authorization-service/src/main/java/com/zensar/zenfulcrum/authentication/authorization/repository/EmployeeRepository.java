package com.zensar.zenfulcrum.authentication.authorization.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.zensar.zenfulcrum.authentication.authorization.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	
	@Query(value = "SELECT * FROM M_EMPLOYEE e WHERE employee_number= :staffId AND termination_flag=0",nativeQuery = true)
	public Employee activeEmployee(@Param("staffId")Integer staffId);
}
