package com.zensar.zenfulcrum.authentication.authorization.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "M_LOGIN_INFO")
public class LoginInfo {	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="login_id")
	private Integer userId;
	@Column(name="employee_number")
	private String employeeNumber;
	@Column(name="encrypted_token")
	private String encryptedToken;
	@Column(name="created_date")
	private Timestamp createdDate;
	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;
	@Column(name="active")
	private int active;
	
	
}
