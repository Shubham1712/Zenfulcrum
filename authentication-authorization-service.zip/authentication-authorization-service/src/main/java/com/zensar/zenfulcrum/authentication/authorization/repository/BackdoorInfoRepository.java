package com.zensar.zenfulcrum.authentication.authorization.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.zensar.zenfulcrum.authentication.authorization.model.BackdoorInfo;


public interface BackdoorInfoRepository extends JpaRepository<BackdoorInfo, Integer> {

	@Query(value="SELECT * FROM M_BACKDOOR_INFO WHERE admin_id= :adminId AND employee_number = :userId",nativeQuery = true)
	BackdoorInfo getPreviousLoggedInDetail(@Param("adminId") String adminId,@Param("userId") Integer userId);

	
	@Transactional
	@Modifying
	@Query(value =" Update M_BACKDOOR_INFO set created_date= current_timestamp(), role_id= :roleId where admin_id= :adminId AND employee_number = :userId",nativeQuery = true)
	int updateLoggedInTime(@Param("adminId") String adminId,@Param("userId") Integer userId, @Param("roleId") Integer roleId);
}
