package com.zensar.zenfulcrum.authentication.authorization.dto;

import java.io.Serializable;

import lombok.Data;
@Data
public class AuthServiceErrorDto implements Serializable{
	private static final long serialVersionUID = -4166064560040839678L;
	private String errorMessage;
	private String errorCause;
}
