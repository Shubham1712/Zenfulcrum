package com.zensar.zenfulcrum.authentication.authorization.dto;

import lombok.Data;

@Data
public class UserAuthenticationDetailsDto {
	
	private String statusMessage;
	private String encryptedToken;
	private String status;
	private String fullName;
	private String employeeId;
	private String emailId;
	private String username;

}
