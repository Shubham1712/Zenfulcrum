package com.zensar.zenfulcrum.authentication.authorization.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zensar.zenfulcrum.authentication.authorization.model.LoginInfo;

@Repository
public interface LoginInfoRepository extends JpaRepository<LoginInfo, Integer>{
	@Modifying
	@Transactional
	@Query(value = "Update M_LOGIN_INFO set last_updated_date = CURRENT_TIMESTAMP() , active =:active , encrypted_token =:encryptedToken where employee_number =:employeeId", nativeQuery = true)
	int updateLoginDetail(@Param("employeeId") String employeeId,@Param("active") int active, @Param("encryptedToken") String encryptedToken );
	
	@Modifying
	@Transactional
	@Query(value = "Update M_LOGIN_INFO set last_updated_date = CURRENT_TIMESTAMP() , active =:active where employee_number =:employeeId", nativeQuery = true)
	int updateLogoutDetail(@Param("employeeId") String employeeId,@Param("active") int active );

	@Query(value = "SELECT * FROM M_LOGIN_INFO m WHERE employee_number = :employeeId ORDER BY last_updated_date DESC ", nativeQuery = true)
	List<LoginInfo> findByEmployeeId(@Param("employeeId") String employeeId );

}
