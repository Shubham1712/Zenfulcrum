package com.zensar.zenfulcrum.authentication.authorization.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "M_USERINFO")
public class UserInfo {

	@Id
	private Integer userId;
	private String profilePicUrl;
}
