package com.zensar.zenfulcrum.authentication.authorization.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.zensar.zenfulcrum.authentication.authorization.exception.AuthServiceException;
import com.zensar.zenfulcrum.authentication.authorization.model.BUserRole;
import com.zensar.zenfulcrum.authentication.authorization.projection.UserRoleProjection;

public interface BUserRoleRepository extends JpaRepository< BUserRole ,Long>  {
	
	@Query(value = "SELECT lval.lookup_value_code AS RoleName, emp.employee_name AS UserName, emp.email_id AS UserEmailId, muser.user_code AS UserCode, buserrole.role_id AS RoleId FROM M_EMPLOYEE emp \r\n" + 
			"INNER JOIN M_USER muser ON emp.employee_id = muser.employee_id\r\n" + 
			"INNER JOIN B_USER_ROLE buserrole ON  muser.user_id = buserrole.user_id  \r\n" + 
			"INNER JOIN M_LOOKUP_VALUE lval ON lval.lookup_value_id = buserrole.role_id \r\n" + 
			"WHERE muser.user_code=:loggedInUser", nativeQuery = true)
    List<UserRoleProjection> getUserRoleDetails(@Param("loggedInUser") String loggedInUser) throws AuthServiceException;

}