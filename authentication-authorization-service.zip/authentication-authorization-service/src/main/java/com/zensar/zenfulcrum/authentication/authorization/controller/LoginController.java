package com.zensar.zenfulcrum.authentication.authorization.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Caching;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.authentication.authorization.dto.AuthServiceResponseDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.LoginDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.UserDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.exception.AuthServiceException;
import com.zensar.zenfulcrum.authentication.authorization.service.LoginService;
import com.zensar.zenfulcrum.authentication.authorization.util.AuthServiceUtil;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Api(tags = "LoginController")
@RestController
@Slf4j
@Validated
@RequestMapping(path = "logincontroller")
@Configuration
public class LoginController {

	@Autowired
	private LoginService loginService;

//	@PostMapping(value = { "/authenticateuser" })
//	public ResponseEntity<AuthServiceResponseDto> authenticateUser(
//			@Valid @RequestHeader(name = "zfUserCode", required = true) String userCode,
//			@Valid @RequestHeader(name = "zfPassword", required = true) String password) throws AuthServiceException {
//		log.info("Entered inside LoginController.authenticateUser method:");
//		AuthServiceResponseDto authServiceResponseDto = new AuthServiceResponseDto();
//		UserDetailsDto loggedInUserDtls = loginService.authenticateUser(userCode, password);
//		if (loggedInUserDtls != null) {
//			AuthServiceUtil.setAuthServiceDto(authServiceResponseDto, loggedInUserDtls);
//			loginService.saveLoginHistory(loggedInUserDtls.getUserCode(), loggedInUserDtls.getEncryptedTokenValue());
//			log.info("Just before leaving LoginController.authenticateUser method:");
//			return new ResponseEntity<>(authServiceResponseDto, HttpStatus.OK);
//		} else {
//			return new ResponseEntity<>(authServiceResponseDto, HttpStatus.UNAUTHORIZED);
//		}
//	}

	@PostMapping(value = { "/postloginactions" })
//	@Cacheable(value = "Auth-Access-Token", key = "#loginDetailsDto.userCode")
	public UserDetailsDto postLoginActions(@RequestBody LoginDetailsDto loginDetailsDto) throws AuthServiceException {
		log.info("Entered inside LoginServiceImpl.postLoginActions method:");
		UserDetailsDto loggedInUserDetails = loginService.getLoggedInUserDetails(loginDetailsDto);
		if (loggedInUserDetails != null)
			loggedInUserDetails.setEncryptedTokenValue(loginDetailsDto.getEncryptedTokenValue());
		log.info("Just before leaving LoginServiceImpl.postLoginActions method:");
		return loggedInUserDetails;
	}

	@Caching(evict = { @CacheEvict(value = "Auth-Access-Token", key = "#loginDetailsDto.userCode"),
			@CacheEvict(value = "customers", key = "'customerDtlsKey'") })
	@PostMapping(value = { "/logoutuser" })
	public void logoutUser(@RequestBody LoginDetailsDto loginDetailsDto) throws AuthServiceException {
		log.info("Entered inside LoginController.logoutUser method:");
		loginService.logoutUserHistory(loginDetailsDto);
		log.info("Just before leaving LoginController.logoutUser method:");
	}

	@PostMapping(value = { "/tokenvalidation" })
	public boolean validateAccessToken(@Valid @RequestHeader(name = "zfUserCode", required = true) String userCode,
			@Valid @RequestHeader(name = "zfAccessToken", required = true) String accessToken,
			@Valid @RequestHeader(name = "zfUserSessionId", required = true) String userSessionId)
			throws AuthServiceException {
		log.info("Entered inside LoginController.validateAccessToken method:");
		boolean tokenValidationStatus = loginService.validateToken(userCode, accessToken, userSessionId);
		log.info("Just before leaving LoginController.validateUser method:");
		return tokenValidationStatus;
	}

	@PostMapping(value = {"/authenticateuser"})
	public ResponseEntity<AuthServiceResponseDto> authenticateuserWithToken(@Valid @RequestHeader(name = "zfEncryptUserCode", required = true) String encryptedUserCode, @Valid @RequestHeader(name = "zfEncryptPassword", required = true) String encryptedToken) throws AuthServiceException {
		log.info("Entered inside LoginController.authenticateuserWithToken method:");
		AuthServiceResponseDto authServiceResponseDto = new AuthServiceResponseDto();
		UserDetailsDto loggedInUserDtls = loginService.authenticateuserWithToken(encryptedUserCode, encryptedToken);
		if(loggedInUserDtls != null) {
			AuthServiceUtil.setAuthServiceDto(authServiceResponseDto, loggedInUserDtls);
			loginService.saveLoginHistory(loggedInUserDtls.getUserCode(),loggedInUserDtls.getEncryptedTokenValue());
			log.info("Just before leaving LoginController.authenticateuserWithToken method:");
			return new ResponseEntity<>(authServiceResponseDto, HttpStatus.OK);
		}else {
			return new ResponseEntity<>(authServiceResponseDto, HttpStatus.UNAUTHORIZED);
		}
	}

	@PostMapping(path = "/backdooremployeelogin", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AuthServiceResponseDto> backdoorLoginEmployee(@RequestBody LoginDetailsDto loginDetailsDto) {
		log.info("Entered inside LoginController.backdoorloginemployee method:");
		AuthServiceResponseDto authServiceResponseDto = new AuthServiceResponseDto();
		try {
			UserDetailsDto loggedInUserDtls = loginService.validateBackdoorUserEmployee(loginDetailsDto.getUserId(),
					loginDetailsDto);
			if (loggedInUserDtls != null) {
				AuthServiceUtil.setAuthServiceDto(authServiceResponseDto, loggedInUserDtls);
				log.info("Just before leaving LoginController.authenticateUser method:");
				return new ResponseEntity<>(authServiceResponseDto, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(authServiceResponseDto, HttpStatus.UNAUTHORIZED);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(authServiceResponseDto, HttpStatus.UNAUTHORIZED);

		}
	}

	@PostMapping(path = "/savebackdoorinfo", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AuthServiceResponseDto> saveBackdoorInfo(
			@Valid @RequestHeader(name = "zfUserCode", required = true) String adminUserCode,
			@RequestBody LoginDetailsDto loginDetailsDto) throws AuthServiceException {
		log.info("Entered inside LoginController.backdoorloginemployee method:");
		AuthServiceResponseDto authServiceResponseDto = new AuthServiceResponseDto();
		boolean userDetails = loginService.saveBackdoorInfo(adminUserCode, loginDetailsDto.getUserId(),
				loginDetailsDto.getRoleId());
		Map<String, Boolean> backdoorActive =new LinkedHashMap<String, Boolean>();
		
		if(userDetails)
		{
			backdoorActive.put("backdoorFlag", true);
			AuthServiceUtil.setAuthServiceDto(authServiceResponseDto, backdoorActive);
			log.info("Just before leaving LoginController.backdoorloginEmployee method:");
			return new ResponseEntity<>(authServiceResponseDto, HttpStatus.OK);
		} else {
			backdoorActive.put("backdoorFlag", false);
			AuthServiceUtil.setAuthServiceDto(authServiceResponseDto, backdoorActive);
			log.info("Just before leaving LoginController.backdoorloginEmployee method:");
			return new ResponseEntity<>(authServiceResponseDto, HttpStatus.UNAUTHORIZED);
		}

	}

}
