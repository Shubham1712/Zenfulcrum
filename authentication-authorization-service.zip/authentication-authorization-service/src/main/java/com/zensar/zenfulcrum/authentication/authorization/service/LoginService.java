package com.zensar.zenfulcrum.authentication.authorization.service;

import com.zensar.zenfulcrum.authentication.authorization.dto.LoginDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.UserDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.exception.AuthServiceException;

public interface LoginService {
	

	public UserDetailsDto getLoggedInUserDetails(LoginDetailsDto loginDetailsDto) throws AuthServiceException;
	
	public boolean validateToken(String userId, String accessToken, String userSessionId) throws AuthServiceException;
	
	//commented by bhagyashri as not using (instead of this using encrypted values)
	//public UserDetailsDto authenticateUser(String userCode, String password) throws AuthServiceException;
	
	public void saveLoginHistory(String userId , String encryptedToken) throws AuthServiceException;
	
	public void logoutUserHistory(LoginDetailsDto loginDetailsDto);
	
	public UserDetailsDto authenticateuserWithToken(String encryptedUserCode, String encryptedToken) throws AuthServiceException;
		
	public UserDetailsDto validateBackdoorUserEmployee(Integer backDoorUserId, LoginDetailsDto loginDetailsDto) throws AuthServiceException;

	public boolean saveBackdoorInfo(String adminUserCode, Integer backDoorUserId,Integer roleId) throws AuthServiceException;

}
