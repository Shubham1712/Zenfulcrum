package com.zensar.zenfulcrum.authentication.authorization.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "M_BACKDOOR_INFO")
public class BackdoorInfo {	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer backdoor_id;
	private String admin_id ;  
	private Integer employee_number ;  
	private Integer role_id;
	private Timestamp created_date  ;

}
