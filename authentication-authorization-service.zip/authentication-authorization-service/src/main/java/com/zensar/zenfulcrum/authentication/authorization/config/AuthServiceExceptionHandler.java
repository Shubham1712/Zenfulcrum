package com.zensar.zenfulcrum.authentication.authorization.config;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import com.zensar.zenfulcrum.authentication.authorization.dto.AuthServiceErrorDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.AuthServiceResponseDto;
import com.zensar.zenfulcrum.authentication.authorization.exception.AuthServiceException;
import com.zensar.zenfulcrum.authentication.authorization.util.AuthServiceConstant;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
public class AuthServiceExceptionHandler {
	@ExceptionHandler(ConstraintViolationException.class)
	public final ResponseEntity<AuthServiceResponseDto> handleConstraintViolationException(Exception ex) {
		log.error(ex.getMessage(), ex);
		AuthServiceResponseDto authServiceResponseDto = new AuthServiceResponseDto();
		AuthServiceErrorDto authServiceErrorDto = new AuthServiceErrorDto();
		if (null != ex.getMessage()) {
			List<String> list = Arrays.asList(ex.getMessage().split(","));
			authServiceErrorDto.setErrorMessage(list.stream().map(i -> i.split(":")[1]).collect(Collectors.toSet()).toString()
					.replace("[", "").replace("]", "").trim());
			authServiceErrorDto.setErrorCause("ConstraintViolationException");
			authServiceResponseDto.setError(authServiceErrorDto);
		}
		return ResponseEntity.badRequest().body(authServiceResponseDto);
	}

	@ExceptionHandler(RuntimeException.class)
	public final ResponseEntity<AuthServiceResponseDto> handleRuntimeException(Exception ex) {
		log.info("Inside handleRuntimeException");
		log.error(ex.getMessage(), ex);
		return processException(ex);

	}

	@ExceptionHandler(AuthServiceException.class)
	public final ResponseEntity<AuthServiceResponseDto> handleWorkflowException(Exception ex) {
		log.info("Inside handleWorkflowException");
		log.error(ex.getMessage(), ex);
		return processException(ex);
	}

	@ExceptionHandler(MissingServletRequestParameterException.class)
	public final ResponseEntity<AuthServiceResponseDto> handleMissingServletRequestParameterException(
			MissingServletRequestParameterException ex) {
		log.info("Inside handleMissingServletRequestParameterException");
		log.error(ex.getMessage(), ex);
		AuthServiceResponseDto authServiceResponseDto = new AuthServiceResponseDto();
		AuthServiceErrorDto authServiceErrorDto = new AuthServiceErrorDto();
		authServiceErrorDto.setErrorMessage(ex.getMessage());
		authServiceErrorDto.setErrorCause("MissingServletRequestParameterException");
		authServiceResponseDto.setError(authServiceErrorDto);
		return ResponseEntity.badRequest().body(authServiceResponseDto);

	}

	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public final ResponseEntity<AuthServiceResponseDto> handleMethodArgumentTypeMismatchException(
			MethodArgumentTypeMismatchException ex) {
		log.info("Inside handleMissingServletRequestParameterException");
		log.error(ex.getMessage(), ex);
		AuthServiceResponseDto authServiceResponseDto = new AuthServiceResponseDto();
		AuthServiceErrorDto authServiceErrorDto = new AuthServiceErrorDto();
		authServiceErrorDto.setErrorMessage(ex.getMessage());
		authServiceErrorDto.setErrorCause("MissingServletRequestParameterException");
		authServiceResponseDto.setError(authServiceErrorDto);
		return ResponseEntity.badRequest().body(authServiceResponseDto);
	}

	private ResponseEntity<AuthServiceResponseDto> processException(Exception ex) {
		AuthServiceResponseDto authServiceResponseDto = new AuthServiceResponseDto();
		AuthServiceErrorDto authServiceErrorDto = new AuthServiceErrorDto();
		if (ex.getCause() != null && AuthServiceConstant.CONSTRAINT_EXCEPTION.equals(ex.getCause().getMessage())) {
			authServiceErrorDto.setErrorMessage(ex.getMessage());
			authServiceErrorDto.setErrorCause(ex.getCause().getMessage());
			authServiceResponseDto.setError(authServiceErrorDto);
			return ResponseEntity.badRequest().body(authServiceResponseDto);
		}
		if (null != ex.getMessage()) {
			authServiceErrorDto.setErrorMessage("Unable to process your request");
			authServiceErrorDto.setErrorCause(ex.getMessage());
			authServiceResponseDto.setError(authServiceErrorDto);
		}
		return new ResponseEntity<>(authServiceResponseDto, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(org.springframework.dao.DataIntegrityViolationException.class)
	public ResponseEntity<AuthServiceResponseDto> handleSQLIntegrityConstraintViolationException(
			org.springframework.dao.DataIntegrityViolationException ex) {
		log.info("Inside handleSQLIntegrityConstraintViolationException");
		log.error(ex.getMessage(), ex);
		AuthServiceResponseDto authServiceResponseDto = new AuthServiceResponseDto();
		AuthServiceErrorDto authServiceErrorDto = new AuthServiceErrorDto();
		authServiceErrorDto.setErrorMessage(ex.getCause().getCause().getMessage());
		authServiceErrorDto.setErrorCause("SQLIntegrityConstraintViolationException");
		authServiceResponseDto.setError(authServiceErrorDto);
		return ResponseEntity.badRequest().body(authServiceResponseDto);
	}

	@ExceptionHandler(org.springframework.web.bind.MethodArgumentNotValidException.class)
	public ResponseEntity<AuthServiceResponseDto> handleMethodArgumentNotValidException(
			org.springframework.web.bind.MethodArgumentNotValidException ex) {
		log.info("Inside handleMethodArgumentNotValidException");
		log.error(ex.getMessage(), ex);
		BindingResult result = ex.getBindingResult();
		List<FieldError> fieldErrors = result.getAllErrors().stream().filter(e -> e instanceof FieldError)
				.map(a -> (FieldError) a).collect(Collectors.toList());
		AuthServiceResponseDto authServiceResponseDto = new AuthServiceResponseDto();
		AuthServiceErrorDto authServiceErrorDto = new AuthServiceErrorDto();
		authServiceErrorDto.setErrorMessage(fieldErrors.stream().map(FieldError::getDefaultMessage)
				.collect(Collectors.toSet()).toString().replace("[", "").replace("]", "").trim());
		authServiceErrorDto.setErrorCause("org.springframework.web.bind.MethodArgumentNotValidException");
		authServiceResponseDto.setError(authServiceErrorDto);
		return ResponseEntity.badRequest().body(authServiceResponseDto);
	}
	
	@ExceptionHandler(javax.persistence.EntityNotFoundException.class)
	public ResponseEntity<AuthServiceResponseDto> handleEntityNotFoundException(javax.persistence.EntityNotFoundException ex){
		log.info("Inside handleEntityNotFoundException");
		log.error(ex.getMessage(), ex);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
