package com.zensar.zenfulcrum.authentication.authorization.util;

import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

public final class HttpRequestUtil {

	private HttpRequestUtil() {
	}
	
	public static HttpHeaders getDefaultHttpHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return headers;
	}
	
	public static Map<String, String> getHttpHeadersMap() {
		return getDefaultHttpHeaders().toSingleValueMap();
	}
}
