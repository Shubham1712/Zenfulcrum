package com.zensar.zenfulcrum.authentication.authorization.util;

import java.util.Base64;
import java.util.Base64.Decoder;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class DecryptionUtil {
	public static String key = "qwertyuikjhgfdsa";
	public static String IV = "qwertyuikjhgfdsa";

	public String decrypt(String encryptedString) {
		log.info("Entered inside DecryptionUtil.decrypt method:");
		try {
			Decoder decoder = Base64.getDecoder();
			byte[] encrypted = decoder.decode(encryptedString);
			Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
			SecretKeySpec keyspec = new SecretKeySpec(key.getBytes(), "AES");
			IvParameterSpec ivspec = new IvParameterSpec(IV.getBytes());
			cipher.init(Cipher.DECRYPT_MODE, keyspec, ivspec);
			byte[] original = cipher.doFinal(encrypted);
			String password = new String(original);
			log.info("Just before leaving DecryptionUtil.decrypt method:");
			return password.trim();
		} catch (Exception e) {
			throw new RuntimeException("Error occured while decrypting data", e);
		}

	}
}
