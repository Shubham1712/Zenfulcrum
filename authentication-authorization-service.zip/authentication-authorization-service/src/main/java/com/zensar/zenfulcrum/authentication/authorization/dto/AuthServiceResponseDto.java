package com.zensar.zenfulcrum.authentication.authorization.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public   class AuthServiceResponseDto implements Serializable{
	private static final long serialVersionUID = 3193995275938685005L;
	private AuthServiceErrorDto error;
	private AuthServiceDto authServiceDto;
}
