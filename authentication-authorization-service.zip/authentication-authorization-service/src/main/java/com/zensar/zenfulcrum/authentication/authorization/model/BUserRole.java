package com.zensar.zenfulcrum.authentication.authorization.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "B_USER_ROLE")
public class BUserRole {
	@Id
	@Column(name="user_role_id")
	private long userRoleId;
	@Column(name="user_id")
	private long userId;
	@Column(name="role_id")
	private long roleId;
	@Column(name="status_id")
	private long statusId;
	@Column(name="created_by")
	private long createdBy;
	@Column(name="last_updated_by")
	private long lastUpdatedBy;
	@Column(name="created_date")
	private Date createdDate;
	@Column(name="last_updated_date")
	private Date lastUpdatedDate;
	@Column(name="effective_start_date")
	private Date effectiveStartDate;
	@Column(name="effective_end_date")
	private Date effectiveEndDate;
	
}

	