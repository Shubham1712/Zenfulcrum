package com.zensar.zenfulcrum.authentication.authorization.rest.client;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.zensar.zenfulcrum.authentication.authorization.dto.LoginDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.UserDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.exception.AuthServiceException;
import com.zensar.zenfulcrum.authentication.authorization.util.AuthServiceConstant;
@RunWith(SpringJUnit4ClassRunner.class)
public class AdminServiceClientTest {

	@Mock
	private RestTemplate restTemplate;

	@InjectMocks
	private AdminServiceClient adminSrvcClient;


	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(adminSrvcClient, "authenticateUserUrl", "authenticateUserUrl");
		ReflectionTestUtils.setField(adminSrvcClient, "getLoggedInUserDetails", "getLoggedInUserDetails");
		ReflectionTestUtils.setField(adminSrvcClient, "adminAuthBaseUrl", "adminAuthBaseUrl");	
		ReflectionTestUtils.setField(adminSrvcClient, "postLoginActionUrl", "postLoginActionUrl");			
	}


	@Test 
	public void authenticateUserTest() throws Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage",AuthServiceConstant.LOGIN_SUCCESS_STATUS_MESSAGE);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		Mockito.when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(),
				Mockito.any())) .thenReturn(new ResponseEntity(jsonObj.toString(), HttpStatus.OK)); 
		adminSrvcClient.authenticateUser("YS57280","XXXX");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
								Mockito.any(), Mockito.any()); }
	
	@Test 
	public void authenticateUserTestNotOk() throws Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage",AuthServiceConstant.LOGIN_SUCCESS_STATUS_MESSAGE);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		Mockito.when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(),
				Mockito.any())) .thenReturn(new ResponseEntity(jsonObj.toString(), HttpStatus.EXPECTATION_FAILED)); 
		adminSrvcClient.authenticateUser("YS57280","XXXX");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
								Mockito.any(), Mockito.any()); }

	@Test(expected = AuthServiceException.class)
	public void authenticateUserTestResourceAccessException() throws Exception {
		doThrow(new ResourceAccessException("Error")).when(restTemplate).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
		adminSrvcClient.authenticateUser("YS57280","XXXX");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
	}

	@Test(expected = AuthServiceException.class)
	public void authenticateUserTestHttpServerError() throws Exception {
		doThrow(HttpServerErrorException.class).when(restTemplate).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
		adminSrvcClient.authenticateUser("YS57280","XXXX");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
	}

	@Test(expected = AuthServiceException.class)
	public void authenticateUserTestHttpClientError() throws Exception {
		doThrow(HttpClientErrorException.class).when(restTemplate).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
		adminSrvcClient.authenticateUser("YS57280","XXXX");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
	}
	

	@Test(expected = AuthServiceException.class)
	public void getLoggedInUserDetailsTestHttpClientErrorException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDetailsDto>>>any())).thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getLoggedInUserDetails("YS57280");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDetailsDto>>>any());
	}

	@Test(expected = AuthServiceException.class)
	public void getLoggedInUserDetailsTestHttpServerErrorException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDetailsDto>>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getLoggedInUserDetails("YS57280");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDetailsDto>>>any());
	}

	@Test(expected = AuthServiceException.class)
	public void getLoggedInUserDetailsTestResourceAccessException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDetailsDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getLoggedInUserDetails("YS57280");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDetailsDto>>>any());
	}
	
	@Test 
	public void getLoggedInUserDetailsTest() throws Exception {
		UserDetailsDto loggedInUserDetails = new UserDetailsDto();
		ResponseEntity<UserDetailsDto> response = new ResponseEntity<UserDetailsDto>(
				loggedInUserDetails, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<UserDetailsDto>>any())).thenReturn(response);
		adminSrvcClient.getLoggedInUserDetails("YS57280");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDetailsDto>>>any());
	}
	
	@Test 
	public void validateTokenTest() throws Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage",AuthServiceConstant.LOGIN_SUCCESS_STATUS_MESSAGE);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		Mockito.when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(),
				Mockito.any())) .thenReturn(new ResponseEntity(jsonObj.toString(), HttpStatus.OK)); 
		adminSrvcClient.validateToken("sdbsbdsbjj");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
								Mockito.any(), Mockito.any()); }
	
	@Test 
	public void validateTokenTestNotOk() throws Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage",AuthServiceConstant.LOGIN_SUCCESS_STATUS_MESSAGE);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		Mockito.when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(),
				Mockito.any())) .thenReturn(new ResponseEntity(jsonObj.toString(), HttpStatus.EXPECTATION_FAILED)); 
		adminSrvcClient.validateToken("sdbsbdsbjj");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
								Mockito.any(), Mockito.any()); }

	@Test(expected = AuthServiceException.class)
	public void validateTokenTestResourceAccessException() throws Exception {
		doThrow(new ResourceAccessException("Error")).when(restTemplate).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
		adminSrvcClient.validateToken("sdbsbdsbjj");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
	}

	@Test(expected = AuthServiceException.class)
	public void validateTokenTestHttpServerError() throws Exception {
		doThrow(HttpServerErrorException.class).when(restTemplate).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
		adminSrvcClient.validateToken("sdbsbdsbjj");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
	}

	@Test(expected = AuthServiceException.class)
	public void validateTokenTestHttpClientError() throws Exception {
		doThrow(HttpClientErrorException.class).when(restTemplate).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
		adminSrvcClient.validateToken("sdbsbdsbjj");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
	}
	
	
	@Test 
	public void postLoginActionTest() throws Exception {
		UserDetailsDto loggedInUserDetails = new UserDetailsDto();
		LoginDetailsDto modifiedLoginDetailsDto = new LoginDetailsDto();
		Mockito.when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(),
				Mockito.any())) .thenReturn(loggedInUserDetails); 
		adminSrvcClient.postLoginAction(modifiedLoginDetailsDto);
		verify(restTemplate, times(1)).postForObject(Mockito.anyString(),
								Mockito.any(), Mockito.any()); }	
	

	@Test(expected = AuthServiceException.class)
	public void postLoginActionTestResourceAccessException() throws Exception {
		LoginDetailsDto modifiedLoginDetailsDto = new LoginDetailsDto();
		doThrow(new ResourceAccessException("Error")).when(restTemplate).postForObject(Mockito.anyString(),
				Mockito.any(), Mockito.any());
		adminSrvcClient.postLoginAction(modifiedLoginDetailsDto);
		verify(restTemplate, times(1)).postForObject(Mockito.anyString(),
				Mockito.any(), Mockito.any());
	}

	@Test(expected = AuthServiceException.class)
	public void postLoginActionTestHttpServerError() throws Exception {
		LoginDetailsDto modifiedLoginDetailsDto = new LoginDetailsDto();
		doThrow(HttpServerErrorException.class).when(restTemplate).postForObject(Mockito.anyString(),
				Mockito.any(), Mockito.any());
		adminSrvcClient.postLoginAction(modifiedLoginDetailsDto);
		verify(restTemplate, times(1)).postForObject(Mockito.anyString(),
				Mockito.any(), Mockito.any());
	}

	@Test(expected = AuthServiceException.class)
	public void postLoginActionTestHttpClientError() throws Exception {
		LoginDetailsDto modifiedLoginDetailsDto = new LoginDetailsDto();
		doThrow(HttpClientErrorException.class).when(restTemplate).postForObject(Mockito.anyString(),
				Mockito.any(), Mockito.any());
		adminSrvcClient.postLoginAction(modifiedLoginDetailsDto);
		verify(restTemplate, times(1)).postForObject(Mockito.anyString(),
				Mockito.any(), Mockito.any());
	}
	
}