package com.zensar.zenfulcrum.authentication.authorization.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.authentication.authorization.config.CASAuthenticationClient;
import com.zensar.zenfulcrum.authentication.authorization.dto.LoginDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.UserDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.exception.AuthServiceException;
import com.zensar.zenfulcrum.authentication.authorization.repository.BUserRoleRepository;
import com.zensar.zenfulcrum.authentication.authorization.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.authentication.authorization.util.AuthServiceConstant;
import com.zensar.zenfulcrum.authentication.authorization.util.AuthServiceUtil;


@RunWith(SpringJUnit4ClassRunner.class)
public class LoginServiceTest {

	@InjectMocks
	private LoginServiceImpl loginSrvcImpl;	

	@Mock
	private BUserRoleRepository bUserRoleRepository;
	
	@Mock
	private AuthServiceUtil authServiceUtil;
	
	@Mock
	private AdminServiceClient adminServiceClient;
	
	@Mock
	private CASAuthenticationClient casAuthenticationClient;
	
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void authenticateUserTest() throws AuthServiceException, Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage",AuthServiceConstant.LOGIN_SUCCESS_STATUS_MESSAGE);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		when(casAuthenticationClient.authenticateUser(Mockito.anyString(), Mockito.anyString())).thenReturn(jsonObj.toString());
		UserDetailsDto userDetailsDto = loginSrvcImpl.authenticateuserWithToken("YS57280","XXXXXX");
		assertNotNull(userDetailsDto);
		verify(casAuthenticationClient, times(1)).authenticateUser("YS57280","XXXXXX");
	}
	
	@Test(expected = AuthServiceException.class)
	public void authenticateUserTestException() throws AuthServiceException, Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage", null);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		when(casAuthenticationClient.authenticateUser(Mockito.anyString(), Mockito.anyString())).thenReturn(jsonObj.toString());
		loginSrvcImpl.authenticateuserWithToken("YS57280","XXXXXX");
		verify(casAuthenticationClient, times(1)).authenticateUser("YS57280","XXXXXX");
	}
	
	@Test
	public void authenticateUserTestNull() throws AuthServiceException, Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage",AuthServiceConstant.LOGIN_SUCCESS_STATUS_MESSAGE);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		when(casAuthenticationClient.authenticateUser(Mockito.anyString(), Mockito.anyString())).thenReturn(jsonObj.toString());
		loginSrvcImpl.authenticateuserWithToken("YS57280","XXXXXX");
		verify(casAuthenticationClient, times(1)).authenticateUser("YS57280","XXXXXX");
	}
	
	@Test
	public void authenticateUserTestInVaid() throws AuthServiceException, Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage",AuthServiceConstant.LOGIN_FAIL_STATUS_MESSAGE);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		//when(adminServiceClient.authenticateUser(Mockito.anyString(), Mockito.anyString())).thenReturn(jsonObj.toString());
		when(casAuthenticationClient.authenticateUser(Mockito.anyString(), Mockito.anyString())).thenReturn(jsonObj.toString());
		loginSrvcImpl.authenticateuserWithToken("YS57280","XXXXXX");
		verify(casAuthenticationClient, times(1)).authenticateUser("YS57280","XXXXXX");
	}
	
	
	@Test
	public void getLoggedInUserDetailsTest() throws AuthServiceException, Exception {
		UserDetailsDto userDetails = new UserDetailsDto();
		LoginDetailsDto loginDetailsDto = new LoginDetailsDto();
		loginDetailsDto.setUserCode("YS57280");
		when(adminServiceClient.getLoggedInUserDetails(Mockito.anyString())).thenReturn(userDetails);
		UserDetailsDto userDetailsDto = loginSrvcImpl.getLoggedInUserDetails(loginDetailsDto);
		assertNotNull(userDetailsDto);
		verify(adminServiceClient, times(1)).getLoggedInUserDetails("YS57280");
	}
	
	@Test
	public void validateTokenTest() throws AuthServiceException, Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage",AuthServiceConstant.LOGIN_SUCCESS_STATUS_MESSAGE);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		UserDetailsDto loggedInUserDetails = new UserDetailsDto();
		loggedInUserDetails.setEncryptedTokenValue("sdbsbdsbjj");
		when(casAuthenticationClient.validateToken(Mockito.anyString())).thenReturn(jsonObj.toString());
		when(adminServiceClient.postLoginAction(Mockito.anyObject())).thenReturn(loggedInUserDetails);
		boolean validationStatus = loginSrvcImpl.validateToken("YS57280","sdbsbdsbjj","12344dsd");
		assertNotNull(validationStatus);
		verify(casAuthenticationClient, times(1)).validateToken("sdbsbdsbjj");
	}
	
	@Test
	public void validateTokenTestNull() throws AuthServiceException, Exception {
		UserDetailsDto loggedInUserDetails = new UserDetailsDto();
		loggedInUserDetails.setEncryptedTokenValue("sdbsbdsbjj");
		when(casAuthenticationClient.validateToken(Mockito.anyString())).thenReturn(null);
		when(adminServiceClient.postLoginAction(Mockito.anyObject())).thenReturn(loggedInUserDetails);
		boolean validationStatus = loginSrvcImpl.validateToken("YS57280","sdbsbdsbjj","12344dsd");
		assertNotNull(validationStatus);
		verify(casAuthenticationClient, times(1)).validateToken("sdbsbdsbjj");
	}
	
	@Test
	public void validateTokenTestInValid() throws AuthServiceException, Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage",AuthServiceConstant.LOGIN_FAIL_STATUS_MESSAGE);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		UserDetailsDto loggedInUserDetails = new UserDetailsDto();
		loggedInUserDetails.setEncryptedTokenValue("sdbsbdsbjj");
		when(casAuthenticationClient.validateToken(Mockito.anyString())).thenReturn(jsonObj.toString());
		when(adminServiceClient.postLoginAction(Mockito.anyObject())).thenReturn(loggedInUserDetails);
		boolean validationStatus = loginSrvcImpl.validateToken("YS57280","sdbsbdsbjj","12344dsd");
		assertNotNull(validationStatus);
		verify(casAuthenticationClient, times(1)).validateToken("sdbsbdsbjj");
	}
	
	
	@Test
	public void validateTokenTestPostLoginNullCheck() throws AuthServiceException, Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage",AuthServiceConstant.LOGIN_SUCCESS_STATUS_MESSAGE);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		UserDetailsDto loggedInUserDetails = new UserDetailsDto();
		loggedInUserDetails.setEncryptedTokenValue("sdbsbdsbjj");
		when(casAuthenticationClient.validateToken(Mockito.anyString())).thenReturn(jsonObj.toString());
		when(adminServiceClient.postLoginAction(Mockito.anyObject())).thenReturn(null);
		boolean validationStatus = loginSrvcImpl.validateToken("YS57280","sdbsbdsbjj","12344dsd");
		assertNotNull(validationStatus);
		verify(casAuthenticationClient, times(1)).validateToken("sdbsbdsbjj");
	}
	
	@Test
	public void validateTokenTestPostLoginInValidCheck() throws AuthServiceException, Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage",AuthServiceConstant.LOGIN_SUCCESS_STATUS_MESSAGE);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		UserDetailsDto loggedInUserDetails = new UserDetailsDto();
		loggedInUserDetails.setEncryptedTokenValue("sdbsbdsbjjsdsfsf");
		when(casAuthenticationClient.validateToken(Mockito.anyString())).thenReturn(jsonObj.toString());
		when(adminServiceClient.postLoginAction(Mockito.anyObject())).thenReturn(loggedInUserDetails);
		boolean validationStatus = loginSrvcImpl.validateToken("YS57280","sdbsbdsbjj","12344dsd");
		assertNotNull(validationStatus);
		verify(casAuthenticationClient, times(1)).validateToken("sdbsbdsbjj");
	}
	
	@Test(expected = AuthServiceException.class)
	public void validateTokenTestException() throws AuthServiceException, Exception {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("statusMessage", null);
		jsonObj.put("encryptedToken", "sdbsbdsbjj");
		when(casAuthenticationClient.validateToken(Mockito.anyString())).thenReturn(jsonObj.toString());
		loginSrvcImpl.validateToken("YS57280","sdbsbdsbjj","12344dsd");
		verify(casAuthenticationClient, times(1)).validateToken("sdbsbdsbjj");
	}
	
}
