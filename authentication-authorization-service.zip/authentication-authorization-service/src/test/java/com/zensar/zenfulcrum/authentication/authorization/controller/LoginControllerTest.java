package com.zensar.zenfulcrum.authentication.authorization.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.zensar.zenfulcrum.authentication.authorization.dto.AuthServiceResponseDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.LoginDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.dto.UserDetailsDto;
import com.zensar.zenfulcrum.authentication.authorization.exception.AuthServiceException;
import com.zensar.zenfulcrum.authentication.authorization.service.LoginService;


@RunWith(SpringJUnit4ClassRunner.class)
public class LoginControllerTest {

	private MockMvc mockMvc;

	@InjectMocks
	private LoginController loginController;

	@Mock
	private LoginService loginService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(loginController).build();		
	}

	@Test
	public void authenticateUserTest() throws AuthServiceException {
		UserDetailsDto loggedInUserDtls = new UserDetailsDto();
		when(loginService.authenticateuserWithToken(Mockito.anyString(), Mockito.anyString())).thenReturn(loggedInUserDtls);
		ResponseEntity<AuthServiceResponseDto> responseEntityObj = loginController.authenticateuserWithToken("YS57280","XXX");
		assertNotNull(responseEntityObj);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(loginService, times(1)).authenticateuserWithToken("YS57280","XXX");
	}

	@Test
	public void authenticateUserTestUnAuthorized() throws	Exception { 
		when(loginService.authenticateuserWithToken(Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		ResponseEntity<AuthServiceResponseDto> responseEntityObj = loginController.authenticateuserWithToken("YS57280","XXX");
		assertEquals(401, responseEntityObj.getStatusCodeValue());
		verify(loginService, times(1)).authenticateuserWithToken("YS57280","XXX");
	}	
	
	@Test
	public void postLoginActionsTest() throws AuthServiceException {
		UserDetailsDto loggedInUserDetails = new UserDetailsDto();
		LoginDetailsDto loginDetailsDto = new LoginDetailsDto();
		loginDetailsDto.setEncryptedTokenValue("123erfgt");
		when(loginService.getLoggedInUserDetails(Mockito.anyObject())).thenReturn(loggedInUserDetails);
		loggedInUserDetails = loginController.postLoginActions(loginDetailsDto);
		assertNotNull(loggedInUserDetails);
		verify(loginService, times(1)).getLoggedInUserDetails(loginDetailsDto);
	}
	
	@Test
	public void postLoginActionsTestNull() throws AuthServiceException {
		LoginDetailsDto loginDetailsDto = new LoginDetailsDto();
		loginDetailsDto.setEncryptedTokenValue("123erfgt");
		when(loginService.getLoggedInUserDetails(Mockito.anyObject())).thenReturn(null);
		loginController.postLoginActions(loginDetailsDto);
		loginController.logoutUser(loginDetailsDto);	
		verify(loginService, times(1)).getLoggedInUserDetails(loginDetailsDto);
	}
	
	
	@Test
	public void validateAccessTokenTest() throws AuthServiceException {
		when(loginService.validateToken(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(true);
		boolean validationStatus = loginController.validateAccessToken("YS57280","123ertyfgfg","1234rf");
		assertNotNull(validationStatus);
		verify(loginService, times(1)).validateToken("YS57280","123ertyfgfg","1234rf");
	}
}