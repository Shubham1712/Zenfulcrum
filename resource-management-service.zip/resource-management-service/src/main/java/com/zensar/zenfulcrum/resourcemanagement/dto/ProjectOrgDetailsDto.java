package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class ProjectOrgDetailsDto {
	
	private String bu;
	private String rbu;
	private String accountingVertical ;
	private String costCenterName;
	private String locationName;
}
