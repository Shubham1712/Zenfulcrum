package com.zensar.zenfulcrum.resourcemanagement.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "T_ASSOCIATE_DEALLOCATION")
public class TAssociateDeAllocation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	@Column(name = "ASSOCIATE_DEALLOCATION_ID")
	private Long associateDeAllocationId;

	@Column(name = "ASSOCIATE_ALLOCATION_ID")
	private Long associateAllocationId;

	@Column(name = "EMPLOYEE_ID")
	private Long employeeId;

	@Column(name = "PROJECT_ID")
	private Long projectId;

	@Column(name = "DEALLOCATION_REASON_ID")
	private Long deallocationReasonId;

	@Column(name = "WORKFLOW_REASON_ID")
	private Long workflowReasonId;

	@Column(name = "DEALLOCATION_NOTIFICATION_date")
	private Date deallocationNotificationDate;

	@Column(name = "DEALLOCATION_DATE")
	private Date deallocationDate;

	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "STATUS_ID")
	private Long statusId;

	@Column(name = "CREATED_BY")
	private Long createdBy;

	@Column(name = "LAST_UPDATED_BY")
	private Long lastUpdatedBy;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "LAST_UPDATED_DATE")
	private Date lastUpdatedDate;

	@Column(name = "EFFECTIVE_START_DATE")
	private Date effectiveStartDate;

	@Column(name = "EFFECTIVE_END_DATE")
	private Date effectiveEndDate;

	@Column(name = "REQUIREMENT_ID")
	private Long requirementId;

	@Column(name = "WORKFLOW_STATUS_ID")
	private Long workflowStatusId;

	@Column(name = "FTE_PERCENT")
	private Double ftePercent;

	@Column(name = "std_cost")
	private Double stdCost;
	
	@Column(name = "is_auto_deallocated")
	private Boolean isAutoDeallocated;

}
