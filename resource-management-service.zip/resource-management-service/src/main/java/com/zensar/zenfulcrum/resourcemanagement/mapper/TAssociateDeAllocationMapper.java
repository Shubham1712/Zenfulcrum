package com.zensar.zenfulcrum.resourcemanagement.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateDeAllocation;

@Mapper(componentModel = "spring")
@Component
public interface TAssociateDeAllocationMapper {
	TAssociateDeAllocation associateDeallocationToTAssociateDeallocation(TAssociateDeAllocationDto valueDto);

	TAssociateDeAllocationDto associateDeallocationToAssociateDeallocationDto(TAssociateDeAllocation value);

	List<TAssociateDeAllocation> associateDeallocationDtoToAssociateDeallocations(List<TAssociateDeAllocationDto> valueDto);

	List<TAssociateDeAllocationDto> associateDeallocationsToAssociateDeallocationDto(List<TAssociateDeAllocation> value);
}
