package com.zensar.zenfulcrum.resourcemanagement.exception;

public class ReportServiceException extends Exception {

	public ReportServiceException() {
		super();
	}

	public ReportServiceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public ReportServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public ReportServiceException(String message) {
		super(message);
	}

	public ReportServiceException(Throwable cause) {
		super(cause);
	}
}
