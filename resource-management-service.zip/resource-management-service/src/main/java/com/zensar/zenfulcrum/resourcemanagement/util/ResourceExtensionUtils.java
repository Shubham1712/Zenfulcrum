package com.zensar.zenfulcrum.resourcemanagement.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueAndDescDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApproversDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.WrkflwStepDefinitionDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.SendMailHelperService;
import com.zensar.zenfulcrum.resourcemanagement.model.ResourceWorkflow;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateExtension;
import com.zensar.zenfulcrum.resourcemanagement.repository.AssociateAllocationBudgetRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.AssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceWorkflowRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.WrkflwEngineServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceManagementServiceImpl;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ResourceExtensionUtils {

	@Autowired
	private ResourceManagementServiceImpl resourceManagementServiceImpl;

	@Autowired
	private AdminServiceClient adminServiceClient;

	@Autowired
	private BAPServiceClient bapServiceClient;

	@Autowired
	private WrkflwEngineServiceClient wrkflwEngineServiceClient;

	@Autowired
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Autowired
	AssociateProjectRepository associateProjectRepository;

	//@Autowired
	//private SendMailHelperService sendMailHelperServiceObj;

	@Autowired
	AssociateAllocationBudgetRepository associateAllocationBudgetRepository;

	@Autowired
	ResourceWorkflowRepository resourceWorkflowRepository;

	public List<RMApproversDto> getRMApproversList(long projectId, long userId, long roleId, String requestType)
			throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.getRMApproversList method:");
		String wrkflwCode = setWrkflwCode(requestType);
		List<RMApproversDto> sortedRMApproversListObj = new ArrayList<>();
		List<WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsListObj = wrkflwEngineServiceClient
				.getWrkflwStepDetails(wrkflwCode);
		Map<Long, WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsMap = wrkflwStepDfntnDtlsListObj.stream()
				.collect(HashMap::new, (m, v) -> m.put(v.getRoleId(), v), HashMap::putAll);
		if (!CollectionUtils.isEmpty(wrkflwStepDfntnDtlsListObj)) {
			List<Long> roleIdListObj = wrkflwStepDfntnDtlsListObj.stream().map(WrkflwStepDefinitionDto::getRoleId)
					.collect(Collectors.toList());
			List<LookupValueAndDescDto> lookuIdByTypeAndDescrList = adminServiceClient.getLookuIdByTypeAndDescrList(
					ResourceManagementConstant.ROLE_TYPE, List.of(ResourceManagementConstant.PROJECT_MANAGER,
							ResourceManagementConstant.PROGRAM_MANAGER, ResourceManagementConstant.TAG_TEAM));

			Map<String, Long> lookupDescToIdMap = lookuIdByTypeAndDescrList.stream().collect(Collectors
					.toMap(LookupValueAndDescDto::getLookupValueDescr, LookupValueAndDescDto::getLookupValueId));

			if (lookupDescToIdMap.get(ResourceManagementConstant.PROJECT_MANAGER).equals(roleId) && requestType.equals(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD)) {
				roleIdListObj.remove(lookupDescToIdMap.get(ResourceManagementConstant.PROJECT_MANAGER));
				List<Long> userIdListObj = bapServiceClient.getPrimaryOwnersList(projectId);
				if (!CollectionUtils.isEmpty(userIdListObj) && !CollectionUtils.isEmpty(roleIdListObj) ) {
					List<RMApproversDto> rmApproversListObj = adminServiceClient.getRMApproversList(roleIdListObj,
							userIdListObj);
					if (!CollectionUtils.isEmpty(rmApproversListObj)) {
						sortedRMApproversListObj = sortRMApproversOPData(rmApproversListObj,
								wrkflwStepDfntnDtlsListObj);
					}
				}
			} else if (lookupDescToIdMap.get(ResourceManagementConstant.PROGRAM_MANAGER).equals(roleId) || requestType.equals(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)) {

				WrkflwStepDefinitionDto wfDto = wrkflwStepDfntnDtlsMap
						.get(lookupDescToIdMap.get(ResourceManagementConstant.TAG_TEAM));
				RMApproversDto rmApproversDtoIntrmObj = new RMApproversDto();
				rmApproversDtoIntrmObj.setRoleName("TAG");
				rmApproversDtoIntrmObj.setRoleId(lookupDescToIdMap.get(ResourceManagementConstant.TAG_TEAM));
				rmApproversDtoIntrmObj.setUserId(97440);
				rmApproversDtoIntrmObj.setStepId(wfDto.getStepId());
				rmApproversDtoIntrmObj.setUserName("TAG TEAM");
				sortedRMApproversListObj.add(rmApproversDtoIntrmObj);
			}

			// roleIdListObj.removeIf(i -> (i == roleId));
		}
		log.info("Just before leaving ResourceManagementServiceImpl.getRMApproversList method:");
		return sortedRMApproversListObj;
	}

	public List<RMApproversDto> sortRMApproversOPData(List<RMApproversDto> rmApproversListObj,
			List<WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsListObj) {
		log.info("Entered into ResourceManagementServiceImpl.sortRMApproversOPData method:");
		List<RMApproversDto> sortedRMApproversListObj = new ArrayList<>();
		Map<Long, WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsMap = wrkflwStepDfntnDtlsListObj.stream()
				.collect(HashMap::new, (m, v) -> m.put(v.getRoleId(), v), HashMap::putAll);
		for (RMApproversDto rmApproversDto : rmApproversListObj) {
			if (wrkflwStepDfntnDtlsMap.containsKey(rmApproversDto.getRoleId())) {
				RMApproversDto rmApproversDtoIntrmObj = new RMApproversDto();
				rmApproversDto.setStepId(wrkflwStepDfntnDtlsMap.get(rmApproversDto.getRoleId()).getStepId());
				rmApproversDtoIntrmObj = rmApproversDto;
				sortedRMApproversListObj.add(rmApproversDtoIntrmObj);
			}
		}
		Long stepIdForTag = tAssociateAllocationRepository.getLookupValueForTag();
		WrkflwStepDefinitionDto wfDto = wrkflwStepDfntnDtlsMap.get(stepIdForTag);
		setTagTeamDetails(sortedRMApproversListObj, wfDto, stepIdForTag);
		Collections.sort(sortedRMApproversListObj, Comparator.comparing(RMApproversDto::getStepId));
		log.info("Just before leaving ResourceManagementServiceImpl.sortRMApproversOPData method:");
		return sortedRMApproversListObj;
	}

	private void setTagTeamDetails(List<RMApproversDto> sortedRMApproversListObj, WrkflwStepDefinitionDto wfDto,
			Long stepIdForTag) {
		RMApproversDto rmApproversDtoIntrmObj = new RMApproversDto();
		rmApproversDtoIntrmObj.setRoleName("TAG");
		rmApproversDtoIntrmObj.setRoleId(stepIdForTag);
		rmApproversDtoIntrmObj.setUserId(97440);
		rmApproversDtoIntrmObj.setStepId(wfDto.getStepId());
		rmApproversDtoIntrmObj.setUserName("TAG TEAM");
		sortedRMApproversListObj.add(rmApproversDtoIntrmObj);
	}

	public void submitRMApproval(RMApprovalInputDto rmApprovalDtls) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.submitRMApproval method:");
		String wrkflwCode = setWrkflwCode(rmApprovalDtls.getRequestType());
		List<WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsListObj = wrkflwEngineServiceClient
				.getWrkflwStepDetails(wrkflwCode);
		resourceManagementServiceImpl.removeStepForPgm(rmApprovalDtls, wrkflwStepDfntnDtlsListObj);
		if (!CollectionUtils.isEmpty(wrkflwStepDfntnDtlsListObj)) {
			List<ResourceWorkflow> resourceWrkflwListObj = new ArrayList<>();
			Map<Long, RMApproversDto> rmSelectedApproversDtlsMap = rmApprovalDtls.getRmApproversList().stream()
					.collect(HashMap::new, (m, v) -> m.put(v.getRoleId(), v), HashMap::putAll);
			for (WrkflwStepDefinitionDto wrkflwStepDfntnDtls : wrkflwStepDfntnDtlsListObj) {
				long nextUserId = 0;
				long nextRoleId = wrkflwStepDfntnDtls.getNextRoleId();
				if ((nextRoleId > 0) && (rmSelectedApproversDtlsMap.containsKey(nextRoleId))) {
					nextUserId = rmSelectedApproversDtlsMap.get(nextRoleId).getUserId();
				}
				if (rmSelectedApproversDtlsMap.containsKey(wrkflwStepDfntnDtls.getRoleId())) {
					if (rmApprovalDtls.getRoleId() == wrkflwStepDfntnDtls.getRoleId()
							&& wrkflwStepDfntnDtls.getNextRoleId() == rmApprovalDtls.getRoleId()) {
						resourceWrkflwListObj.add(resourceManagementServiceImpl.createRsrcWrkflwDataObject(
								rmApprovalDtls.getRoleId(), rmApprovalDtls.getUserId(), nextRoleId, nextUserId,
								wrkflwStepDfntnDtls.getWrkflwDefinitionId(),
								getWrkflwTypeIdByRequestType(rmApprovalDtls.getRequestType()),
						        findSubmitStatusIdByRequestType(rmApprovalDtls.getRequestType())));
					} else {
						resourceWrkflwListObj.add(resourceManagementServiceImpl.createRsrcWrkflwDataObject(
								wrkflwStepDfntnDtls.getRoleId(),
								rmSelectedApproversDtlsMap.get(wrkflwStepDfntnDtls.getRoleId()).getUserId(), nextRoleId,
								nextUserId, wrkflwStepDfntnDtls.getWrkflwDefinitionId(),getWrkflwTypeIdByRequestType(rmApprovalDtls.getRequestType()),
								0));
					}
				} else {
					resourceWrkflwListObj.add(resourceManagementServiceImpl.createRsrcWrkflwDataObject(
							rmApprovalDtls.getRoleId(), rmApprovalDtls.getUserId(), nextRoleId, nextUserId,
							wrkflwStepDfntnDtls.getWrkflwDefinitionId(),
							getWrkflwTypeIdByRequestType(rmApprovalDtls.getRequestType()),
							findSubmitStatusIdByRequestType(rmApprovalDtls.getRequestType())));
				}
			}
			resourceManagementServiceImpl.saveResourceWrkflwData(rmApprovalDtls, resourceWrkflwListObj, wrkflwCode);
		}
		log.info("Just before leaving ResourceManagementServiceImpl.submitRMApproval method:");
	}

	public void saveResourceWrkflwData(RMApprovalInputDto rmApprovalDtls, List<ResourceWorkflow> resourceWrkflwListObj,
			String wrkflwCode) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.saveResourceWrkflwData method:");
		List<Long> empIdListObj = new ArrayList<>();
		if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)
				|| rmApprovalDtls.getRequestType().equalsIgnoreCase(
						ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD)) {

			for (TAssociateExtension tAssociateAllocationObj : rmApprovalDtls.getTAssociateExtensionList()) {
				for (ResourceWorkflow resourceWrkflwObj : resourceWrkflwListObj) {
					resourceWorkflowRepository.save(resourceManagementServiceImpl.createRsrcWrkflwDataObject(
							resourceWrkflwObj, tAssociateAllocationObj.getAssociateExtensionId(), rmApprovalDtls,
							ResourceManagementConstant.SUBMISSION_CONSTANT));
				}

				//sendMailHelperServiceObj.sendEmailForSubmissionConfirmation(rmApprovalDtls, wrkflwCode);
				//sendMailHelperServiceObj.sendEmailForSubmitApprovalPending(rmApprovalDtls, wrkflwCode,
				//		rmApprovalDtls.getTAssociateExtensionList().get(0).getAssociateExtensionId());
			}

		}

		log.info("Just before leaving ResourceManagementServiceImpl.saveResourceWrkflwData method:");
	}
	
	
	public String setWrkflwCode(String requestType) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.setWrkflwCode method:");
		String subModue = null;
		  if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)) {
			subModue = ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE;
		} else if (requestType
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD)) {
			subModue = ResourceManagementConstant.RESOURCE_EXTENSION_LOCKINGPERIOD;
		}
		if (subModue != null) {
			if(subModue.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE))
			{
				return ResourceManagementConstant.NON_LOCKING_EXTENSION;
			}else {
				
				return ResourceManagementConstant.LOCKING_EXTENSION;

			
			}
		} else {
			throw new ResourceManagementException(ResourceManagementConstant.INVALID_REQUEST_TYPE);
		}
	}
	
	public long getWrkflwTypeIdByRequestType(String requestType) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.getWrkflwTypeIdByRequestType method:");
		String subModule = null;
		subModule = ResourceManagementConstant.RESOURCE_EXTENSION;
		ModuleStatusDto moduleDtlsDto = adminServiceClient
				.getModuleDetails(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModule);
		log.info("Just before leaving ResourceManagementServiceImpl.getWrkflwTypeIdByRequestType method:");
		return moduleDtlsDto.getModuleId();
	}
	
	public long findSubmitStatusIdByRequestType(String requestType) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.findStatusIdByRequestType method:");
		long statusId = 0;
		statusId = resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION,
					ResourceManagementConstant.SUBMITTED);
		log.info("Just before leaving ResourceManagementServiceImpl.findStatusIdByRequestType method:");
		return statusId;
	}
}
