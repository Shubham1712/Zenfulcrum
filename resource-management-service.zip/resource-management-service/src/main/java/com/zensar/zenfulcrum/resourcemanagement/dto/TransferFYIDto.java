package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class TransferFYIDto {
	
	private Long userId;
	private long roleId;
}
