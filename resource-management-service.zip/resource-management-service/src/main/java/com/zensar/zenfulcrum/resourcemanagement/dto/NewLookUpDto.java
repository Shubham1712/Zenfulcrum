package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class NewLookUpDto {
	
	private Long lookupValueId;
	private String lookupValueCode;
	private String lookupValueDescription;
	
	public NewLookUpDto(Long lookupValueId, String lookupValueCode, String lookupValueDescription){
		this.lookupValueId = lookupValueId;
		this.lookupValueCode = lookupValueCode;
		this.lookupValueDescription = lookupValueDescription;
	}
	
	public NewLookUpDto() {}
	private long moduleStatusId;


}
