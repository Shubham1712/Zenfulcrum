package com.zensar.zenfulcrum.resourcemanagement.controller;

import java.text.ParseException;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.resourcemanagement.dto.QuarterDetailDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceUtilizationSummaryDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UtilizationDetailDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceUtilizationService;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementUtil;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Api(tags = "ResourceUtilizationController")
@RestController
@Slf4j
@Validated
@RequestMapping(path = "resourceutilization/")
public class ResourceUtilizationController {

	@Autowired
	private ResourceUtilizationService resourceUtilizationService;
	
	
	/**get Quarter Details For Year
	 * @return list of quarter along with dates
	 * @throws ResourceManagementException
	 */
	@GetMapping(path = "/quaterdetails")
	public ResponseEntity<RMResponseDto> getQuarterDetailsForYear() throws ResourceManagementException,ParseException {
		log.info("Start getQuarterDetailsForYear");
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<QuarterDetailDto> quarterDetailDtoList = resourceUtilizationService.getQuarterDetailsForYear();
		if (null != quarterDetailDtoList) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, quarterDetailDtoList);
		} else {
			log.info("Exit getQuarterDetailsForYear method");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getQuarterDetailsForYear");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**get Resource Utilization Details
	 * @return list of quarter along with dates
	 * @throws ResourceManagementException
	 */
	@GetMapping(path = "/resourceutilization")
	public ResponseEntity<RMResponseDto> getResourceUtilization(@RequestParam @NotNull Long empId,@RequestParam @NotNull @Valid String startDate,@RequestParam @NotNull @Valid String endDate) throws ResourceManagementException,ParseException {
		log.info("Start getResourceUtilization");
		RMResponseDto rmResponseDto = new RMResponseDto();
		UtilizationDetailDto utilizationDetailDto = resourceUtilizationService.getResourceUtilization(empId,startDate,endDate);
		if (null != utilizationDetailDto) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, utilizationDetailDto);
		} else {
			log.info("Exit getResourceUtilization method");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getResourceUtilization");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	@GetMapping(path = "/getresourceutilizationsummaryDetails")
	public ResponseEntity<ResourceUtilizationSummaryDto> getResourceUtilizationSummaryDetails(
			@RequestParam Long projectId) throws ResourceManagementException {
		log.info("start getAssociateAllocationIdByProjectId");
		ResourceUtilizationSummaryDto resourceUtilizationSummaryDetails = resourceUtilizationService
				.getResourceUtilizationSummaryDetails(projectId);
		if (resourceUtilizationSummaryDetails != null) {
			log.info("End getResourceUtilizationSummaryDetails - success");
			return new ResponseEntity<>(resourceUtilizationSummaryDetails, HttpStatus.OK);
		} else {
			log.info("End getResourceUtilizationSummaryDetails - No content");
			return new ResponseEntity<>(resourceUtilizationSummaryDetails, HttpStatus.NO_CONTENT);
		}
	}
}
