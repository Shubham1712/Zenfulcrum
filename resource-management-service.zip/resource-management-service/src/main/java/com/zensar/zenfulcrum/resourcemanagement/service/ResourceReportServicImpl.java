package com.zensar.zenfulcrum.resourcemanagement.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateHistoryReportDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.BapReportDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ConfluenceAllocData;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDetailsDTO;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ReportLookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectAndAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ReportServiceException;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.mapper.AssociateHistoryMapper;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateAllocationMapper;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateDeAllocation;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocDataProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.MModuleProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.TAssociateAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.TAssociateProjectAndAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class ResourceReportServicImpl implements ResourceReportService {

	@Autowired
	private TAssociateProjectRepository tAssociateProjectRepository;

	@Autowired
	private AssociateHistoryMapper associateHistoryMapper;

	@Autowired
	private ResourceManagementServiceImpl resourceManagementServiceImpl;

	@Autowired
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Autowired
	private TAssociateAllocationMapper tAssociateAllocationMapper;

	@Autowired
	TAssociateDeAllocationRepository tAssociateDeAllocationRepository;

	@Autowired
	private AdminServiceClient adminServiceClient;
	
	@Autowired
	private BAPServiceClient bAPServiceClient;
	
	@Override
	public List<TAssociateAllocationProjection> getAssociateAllocationIdByProjectId(List<Long> associateProjectIdList)
			throws ReportServiceException {
		List<Long> billableStatusIdForActive;
		List<ReportLookupValueDto> lookUpValues = new ArrayList<>();
		List<MModuleProjection> moduleStatus = new ArrayList<>();
		try {
			lookUpValues = adminServiceClient.getAllocatedResourcesStatuses(
					ResourceManagementConstant.RESOURCE_BILLABLE_TYPE, ResourceManagementConstant.ACTIVATE);
			billableStatusIdForActive = lookUpValues.stream().map(ReportLookupValueDto::getLookupValueId)
					.collect(Collectors.toList());
			moduleStatus = adminServiceClient.getStatusByName(ResourceManagementConstant.RESOURCE_ALLOCATION,
					ResourceManagementConstant.ACTIVATE_STATUS);

		} catch (ResourceManagementException e) {
			throw new ReportServiceException("Getting Active status for Allocation exeption");
		}

		
		  return
		  tAssociateAllocationRepository.getAssociateAllocationIdByProjectIdAndStatusId
		  (associateProjectIdList, billableStatusIdForActive,
		  moduleStatus.get(0).getModuleStatusId());
		 
//		return tAssociateAllocationRepository.getAssociateAllocationIdByProjectIdAndStatusId(associateProjectIdList,
//				billableStatusIdForActive);

	}

	@Override
	public List<AssociateHistoryReportDto> resourceAllocationHistory(long empId) {

		log.info("Start resourceAllocationHistory method");

		return associateHistoryMapper.associateHistoryProjecationToAssociateHistoryReportDto(
				tAssociateProjectRepository.getAssociateHistory(empId));

	}

	@Override
	public TAssociateAllocationDto getActualAndEstAllocationDate(long projectId, long empId)
			throws ResourceManagementException {
		log.info("Start getActualAndEstAllocationDate");

		Long activeStatus = resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVE_ACTION);

		log.info("Status is : {}", activeStatus);
		return tAssociateAllocationMapper.tAssociateAllocationToTAssociateAllocationDto(
				tAssociateAllocationRepository.getActualAndEstAllocationDate(projectId, empId, 60));

	}

	@Override
	public BapReportDto getRequirementIds(long projectId) throws ResourceManagementException {
		BapReportDto bapReportDto = new BapReportDto();
		Long statusIdForActive = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);

		bapReportDto.setRequirementIds(tAssociateAllocationRepository.getRequirementIds(projectId, statusIdForActive));
		return bapReportDto;

	}

	@Override
	public List<TAssociateProjectAndAllocationDto> getAssociateDetailsByAssociateId(Long associateId) {
		List<TAssociateProjectAndAllocationDto> dtos = null;
		if (Optional.ofNullable(associateId).isPresent()) {
			List<TAssociateProjectAndAllocationProjection> tAssociateProjectProjections = tAssociateProjectRepository
					.findByEmployeeId(associateId);

			dtos = tAssociateProjectProjections.stream().map(projectionData -> {
				TAssociateProjectAndAllocationDto dto = new TAssociateProjectAndAllocationDto();
				dto.setProjectId(projectionData.getprojectId());
				dto.setEmployeeId(projectionData.getemployeeId());
				dto.setWorkLocationId(projectionData.getworkLocationId());
				dto.setBillableStatusId(projectionData.getbillableStatusId());
				dto.setActualAllocationStartDate(projectionData.getactualAllocationStartDate());
				dto.setActualAllocationEndDate(projectionData.getactualAllocationEndDate());
				dto.setEstAllocationEndDate(projectionData.getestAllocationEndDate());
				dto.setStatusId(projectionData.getstatusId());
				dto.setCreatedDate(projectionData.getcreatedDate());
				dto.setFtePercent(projectionData.getftePercent());
				dto.setSrfNo(projectionData.getsrfNo());
				dto.setServiceLineId(projectionData.getserviceLineId());
				return dto;
			}).collect(Collectors.toList());
		}
		return dtos;
	}

	@Override
	public List<TAssociateDeAllocationDto> getAssociateDeallocationDetails() {
		List<TAssociateDeAllocation> associateDeAllocations = tAssociateDeAllocationRepository.getDeallocationDetails();
		List<TAssociateDeAllocationDto> deAllocationDtos = null;
		if (CollectionUtils.isNotEmpty(associateDeAllocations)) {
			deAllocationDtos = associateDeAllocations.stream().map(data -> {
				TAssociateDeAllocationDto dto = new TAssociateDeAllocationDto();
				dto.setAssociateDeallocationId(data.getAssociateDeAllocationId());
				dto.setAssociateAllocationId(data.getAssociateAllocationId());
				dto.setEmployeeId(data.getEmployeeId());
				dto.setProjectId(data.getProjectId());
				dto.setDeallocationReasonId(data.getDeallocationReasonId());
				dto.setWorkflowReasonId(data.getWorkflowReasonId());
				dto.setDeallocationDate(data.getDeallocationDate());
				dto.setRemarks(data.getRemarks());
				dto.setStatusId(data.getStatusId());
				dto.setCreatedBy(data.getCreatedBy());
				dto.setLastUpdatedBy(data.getLastUpdatedBy());
				dto.setEffectiveStartDate(data.getEffectiveStartDate());
				dto.setEffectiveEndDate(data.getEffectiveEndDate());
				dto.setRequirementId(data.getRequirementId());
				dto.setWorkflowStatusId(data.getWorkflowStatusId());
				if (data.getFtePercent() != null)
					dto.setFtePercent(data.getFtePercent());

				return dto;
			}).collect(Collectors.toList());
		}
		return deAllocationDtos;
	}

	@Override
	public List<TAssociateProjectAndAllocationDto> getAllocationWorkflowDetails() {
		List<TAssociateProjectAndAllocationDto> allocationDtos = null;
		List<TAssociateProjectAndAllocationProjection> allocationWorkflowDetails = tAssociateAllocationRepository
				.getAllocationWorkflowDetails();
		if (CollectionUtils.isNotEmpty(allocationWorkflowDetails)) {
			allocationDtos = allocationWorkflowDetails.stream().map(obj -> {
				TAssociateProjectAndAllocationDto dto = new TAssociateProjectAndAllocationDto();
				dto.setProjectId(obj.getprojectId());
				dto.setEmployeeId(obj.getemployeeId());
				dto.setStdCost(obj.getstdCost());
				dto.setActualAllocationStartDate(obj.getactualAllocationStartDate());
				dto.setActualAllocationEndDate(obj.getactualAllocationEndDate());
				dto.setFtePercent(obj.getftePercent());
				dto.setRemarks(obj.getremarks());
				dto.setWorkflowStatusId(obj.getworkflowStatusId());
				dto.setStatusId(obj.getstatusId());
				return dto;
			}).collect(Collectors.toList());
		}
		return allocationDtos;
	}

	@Override
	public Long getAllocatedCount(Long projectId) {
		long count = 0;
		try {
			 count = tAssociateAllocationRepository.getActiveStatusCount(projectId,
					getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE));
		} catch (ResourceManagementException e) {
			e.printStackTrace();
		}
		return count;
	}
	
	public long getModuleStatusId(String subModuleName, String actionName) throws ResourceManagementException {
		ModuleStatusDto moduleStatusDto = adminServiceClient
				.getModuleStatus(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModuleName, actionName);
		if (moduleStatusDto != null)
			return moduleStatusDto.getModuleStatusId();
		else
			return 0;
	}

	//Added by Shubham- ZenConflence API
	@Override
	public List<ConfluenceAllocData> getProjAllocationDetails(@Valid long employeeNum) throws ResourceManagementException {
		log.info("Entered getProjAllocationDetails method");
		List<ConfluenceAllocData> confluenceAllocData = null;
		Long statusIdForActive = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
		EmployeeDetailsDTO empDto = adminServiceClient.getEmployeeDetailsByEmployeeNumber(employeeNum);
		List<AllocDataProjection> allocDataList = tAssociateAllocationRepository.getProjAllocationDetails(empDto.getEmployeeId(), statusIdForActive);
		if(!allocDataList.isEmpty()) {
			confluenceAllocData = associateHistoryMapper.allocDataProjectionToConfluenceAllocData(allocDataList);
			List<Long> projectIds = confluenceAllocData.stream().map(ConfluenceAllocData::getProjectId).distinct().collect(Collectors.toList());
			List<ProjectDto> projectDetails = bAPServiceClient.getProjectDetailByIds(projectIds);
			Map<Long, ProjectDto> projectDetailsMap = projectDetails.stream().collect(Collectors.toMap(ProjectDto::getProjectId, projectDto -> projectDto));
			confluenceAllocData.stream().forEach(record -> {
				record.setEmpNum(employeeNum);
				record.setEmpName(empDto.getEmployeeName());
				record.setProjectCode(projectDetailsMap.get(record.getProjectId()).getProjectCode());
				record.setProjectName(projectDetailsMap.get(record.getProjectId()).getProjectName());
			});
		}
		log.info("Exiting getProjAllocationDetails method");
		return confluenceAllocData;
	}
	

}
