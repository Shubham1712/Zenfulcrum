package com.zensar.zenfulcrum.resourcemanagement.projection;

import java.util.Date;

public interface AssociateHistoryProjecation {
	Long getProjectId(); 
	String getSrfNo();
	Double getUtilization();
	String getActualAllocationStartDate();
	String getActualAllocationEndDate();
	String getEstimatedReleaseDate();
	String getAllocationStatus();
	Long getServiceLineId();
	Long getStatusId();
	String getcreatedDate();

	
	void setProjectId(Long projectId); 
	void setSrfNo(String srfNo);
	void setUtilization(Double utilization);
	void setActualAllocationStartDate(String actualAllocationStartDate);
	void setActualAllocationEndDate(String actualAllocationEndDate);
	void setEstimatedReleaseDateDate(String estimatedReleaseDate);
	void setAllocationStatus(String status);
	void setServiceLineId(Long serviceLineId);
	void setStatusId(Long statusId);
	void setcreatedDate(String createdDate);

}
