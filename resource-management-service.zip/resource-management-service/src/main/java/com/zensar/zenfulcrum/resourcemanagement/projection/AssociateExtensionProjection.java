package com.zensar.zenfulcrum.resourcemanagement.projection;

import java.util.Date;

public interface AssociateExtensionProjection {
	
	 public Long getallocationId();
	 public Long getrequirmentId();
	 public Long getextensionId();
	 public Date getextendedDate();
	 public void setallocationId(Long l);
	 public void setrequirmentId(Long l);
	 public void setextensionId(Long l);
	 public void setextendedDate(Date d);


}
