package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Transient;

import lombok.Data;

@Data
public class ResourceRequirementAndFteDto implements Serializable {
	private static final long serialVersionUID = 1L;
	private double totalBapFte;
	private double ebrFte;
	@Transient
	private double totalAllocatedBillableFte;
	@Transient
	private double totalAllocatedEBRFte;
	private double totalAvailableFTEBillableorEBR;
    
	// margins
	private double estimatdMargin;
    private double actualMargin;
	private double projectedMargin;
   
	private double totalBudget;
	private double consumedBudget;
	private double projectAvailableBudget;
    private List<ResourceRequirementDto> resourceRequirementDto;
	private List<EmployeeDto> employeeList;
	private double poOrderValue;
	private Long projectBillingTypeId;
	private String projectBillingType;
    private Boolean budgetAndCostCheck;
	private String currency;
	//code by mounika-start
	private String currencyName;
	//code by mounika-end

}
