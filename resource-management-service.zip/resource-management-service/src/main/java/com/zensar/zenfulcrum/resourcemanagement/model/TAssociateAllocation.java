package com.zensar.zenfulcrum.resourcemanagement.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Entity
@Table(name ="T_ASSOCIATE_ALLOCATION")
@Data
public class TAssociateAllocation {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ASSOCIATE_ALLOCATION_ID")	
	private Long associateAllocationId;
	
	@Column(name="ROLE_ID")	
	private Long roleId;
	
	@Column(name="REQUIREMENT_ID")	
	private Long requirementId;
	
	@Column(name="WORK_LOCATION_ID")	
	private Long workLocationId;
	
	@Column(name="BILLABLE_STATUS_ID")	
	private Long billableStatusId;
	
	@Column(name="BILLABLE_STATUS_REASON_ID")	
	private Long billableStatusReasonId;
	
	@Column(name="WORKFLOW_REASON_ID")	
	private Long workflowReasonId ;
	
	 
	@Column(name="EST_ALLOCATION_END_DATE")	
	private Date estAllocationEndDate;
	
	@Column(name="ACTUAL_ALLOCATION_START_DATE")	
	private Date actualAllocationStartDate;
	
	@Column(name="ACTUAL_ALLOCATION_END_DATE")	
	private Date actualAllocationEndDate ;
	
	@Column(name="BASE_HOURS")	
	private Double baseHours;
	
	@Column(name="FTE_PERCENT")	
	private Double ftePercent;
	
	@Column(name="REMARKS")	
	private String remarks;
	
	@Column(name="WORKFLOW_STATUS_ID")	
	private Long workflowStatusId;
	
	@Column(name="STATUS_ID")	
	private Long statusId;
	
	@Column(name="CREATED_BY")	
	private Long createdBy;
	
	@Column(name="LAST_UPDATED_BY")	
	private Long lastUpdatedBy;
	
	@Column(name="CREATED_DATE")	
	private Date createdDate;
	
	@Column(name="LAST_UPDATED_DATE")	
	private Date lastUpdatedDate;
	
	@Column(name="EFFECTIVE_START_DATE")	
	private Date effectiveStartDate;
	
	@Column(name="EFFECTIVE_END_DATE")	
	private Date effectiveEndDate;
	
	@Column(name="TRANSACTION_HISTORY_ID")
	private Long transactionHistoryId;
	
	@Column(name="ALLOCATION_TYPE_ID")
	private Long allocationTypeId;
	
	@Column(name="CAP_HR")
	private Double capHours;
	
	@Column(name="SKILL_CHAMPION_FLAG")
	private Boolean skillChampionFlag;
	
	@Column(name="SUPERVISOR_ID")
	private Long supervisorId;
	
	@Column(name="skill_id")
	private Long skillId;
	
	@Column(name="sr_reference")
	private String srReference;
	
	@Column(name="std_cost")
	private Double stdCost;
	
	@Column(name="service_line_id")
	private Long serviceLineId;
	
	@OneToOne
	@JoinColumn(name = "ASSOCIATE_PROJECT_ID")
	private TAssociateProject tAssociateProject;
	
	@OneToMany(mappedBy="tAssociateAllocation" ,fetch = FetchType.EAGER,cascade = {CascadeType.ALL})
	private List<TAssociateAllocationBudget> tAssociateAllocationBudget;
	
	//Added by Mrunal Marne for source budget release
	private transient Double targetFtePercent = 0.0;
}
