package com.zensar.zenfulcrum.resourcemanagement.projection;

import java.util.Date;

public interface TAssociateProjectAndAllocationProjection {

	
	public Long getemployeeId();
	public Long getprojectId();
	public Long getworkLocationId();
	public Long getbillableStatusId();
	public String getsrfNo();
	public Double getutilization();
	public Long getroleId();
	public Long getrequirementId();
	public Long getskillId();
	public Double getstdCost();
	public Date getestAllocationEndDate();
	public Date getactualAllocationStartDate();
	public Date getactualAllocationEndDate();
	public Double getbaseHours();
	public Double getftePercent();
	public String getremarks();
	public Long getworkflowStatusId();
	public Long getstatusId();
	public Date getcreatedDate();
	public Long getserviceLineId();

	
	
	public void setemployeeId(Long employeeId);
	public void setprojectId(Long projectId);
	public void setworkLocationId(Long workLocationId);
	public void setbillableStatusId(Long billableStatusId);
	public void setsrfNo(String srfNo);
	public void setutilization(Double utilization);
	public void setroleId(Long roleId);
	public void setrequirementId(Long requirementId);
	public void setskillId(Long skillId);
	public Double setstdCost(Double stdCost);
	public Date setestAllocationEndDate(Date estAllocationEndDate);
	public Date setactualAllocationStartDate(Long actualAllocationStartDate);
	public Date setactualAllocationEndDate(Long actualAllocationEndDate);
	public Double setbaseHours(Double baseHours);
	public Double setftePercent(Double ftePercent);
	public void setremarks(String remarks);
	public void setworkflowStatusId(Long workflowStatusId);
	public void setstatusId(Long statusId);
	public void setcreatedDate(Date createdDate);
	public void setserviceLineId(Long serviceLineId);


}
