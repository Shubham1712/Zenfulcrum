package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;

import lombok.Data;

@Data
public class RTResourceDto {

	private long empId;
	private String empName;
	private boolean transferUtilizationToTargetProject;
	private RTProjectDto currentProjectDetails;
	private RTProjectDto targetProjectDetails;
	//Added by Mrunal Marne for milestone selection while resource transfer
	private Long puchaseOrderId;
	private List<Long> poMilestoneIdList;
}
