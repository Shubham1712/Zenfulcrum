package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class LocationDto {

	private Long locationId;
	private String locationName;
	private Long shoreId;
	private Long geographyId;
	
}
