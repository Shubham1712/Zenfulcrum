package com.zensar.zenfulcrum.resourcemanagement.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "T_ALLOCATION_TABLE")
public class AllocatedResource 
{
	@Id
	@Column(name="associate_allocation_id")
	private long associate_allocation_id;
	@Column(name="employee_id")
	private long employee_id;
	@Column(name="project_id")
    private long project_id;
	@Column(name="role_id")
	private String role_id;
	@Column(name="billable_status_id")
    private int	billable_status_id;
	@Column(name="fte_percent")
    private double fte_percent;
	@Column(name="requirement_id")
    private long requirement_id;
	@Column(name="status_id")
	private int status_id;

}
