package com.zensar.zenfulcrum.resourcemanagement.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.MailDetail;
import com.zensar.zenfulcrum.resourcemanagement.dto.MailTemplateDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PrimaryUsersDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTResourceDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TransferFYIDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.WrkflwStepDefinitionDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.model.ResourceWorkflow;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateExtension;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateSkill;
import com.zensar.zenfulcrum.resourcemanagement.projection.ResourceWorkflowProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceWorkflowRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.LiferayServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.WrkflwEngineServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceManagementServiceImpl;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.SendMailUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SendMailHelperService {

	@Autowired
	private SendMailUtil sendMailUtil;

	@Autowired
	private AdminServiceClient adminServiceClient;

	@Autowired
	private BAPServiceClient bapServiceClient;

	@Autowired
	private LiferayServiceClient liferayServiceClient;

	@Autowired
	private ResourceWorkflowRepository resourceWrkflwRepository;

	@Autowired
	private WrkflwEngineServiceClient wrkflwEngineServiceClient;
	
	@Autowired
	private ResourceManagementServiceImpl resourceManagementServiceImpl;
	

	public void sendEmailForSubmissionConfirmation(RMApprovalInputDto rmApprovalDtls, String wrkflwCode)
			throws ResourceManagementException {
		log.info("Entered into SendMailUtility.sendEmailForSubmissionConfirmation method:");
		Map<String, Object> userDtlsMap = createUserDetailsMapForSubmitConfirmation(rmApprovalDtls, wrkflwCode);
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		List<Long> ccUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_CC_USERS);
		List<Long> toUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_TO_USERS);
		if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_ALLOCATION_SUBMISSION_CNFIRMATION_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_DEALLOCATION_SUBMISSION_CNFIRMATION_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_TRNSFR_SUBMIT_PENDING_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)
				|| rmApprovalDtls.getRequestType().equalsIgnoreCase(
						ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_EXTNSN_SUBMIT_PENDING_LIFERAY_URL);
		MailDetail mailDetailObj = createMailDetailObject(mailTemplateDtls, userDtlsMap, rmApprovalDtls.getRoleName(),
				rmApprovalDtls.getUserName(), rmApprovalDtls);
		if (CollectionUtils.isNotEmpty(toUsersList))
			mailDetailObj.setMailToAddress(adminServiceClient.getAssociatesEmailAddress(toUsersList));
		if (CollectionUtils.isNotEmpty(ccUsersList))
			mailDetailObj.setMailCcAddress(adminServiceClient.getAssociatesEmailAddress(ccUsersList));
		sendMailUtil.sendMail(mailDetailObj);
		log.info("Just before leaving SendMailUtility.sendEmailForSubmissionConfirmation method:");
	}

	public void sendEmailForSubmitApprovalPending(RMApprovalInputDto rmApprovalDtls, String wrkflwCode,
			long wrkflwTrnsctnId) throws ResourceManagementException {
		log.info("Entered into SendMailUtility.sendEmailForSubmitApprovalPending method:");
		Map<String, Object> userDtlsMap = createUserDetailsMapForSubmitPending(rmApprovalDtls, wrkflwCode,
				wrkflwTrnsctnId);
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		List<Long> ccUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_CC_USERS);
		List<Long> toUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_TO_USERS);
		if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_ALLOCATION_APPROVAL_PENDING_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_DEALLOCATION_APPROVAL_PENDING_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_TRNSFR_APPROVAL_PENDING_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)
				|| rmApprovalDtls.getRequestType().equalsIgnoreCase(
						ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_EXTNSN_APPROVAL_PENDING_LIFERAY_URL);
//		MailDetail mailDetailObj = createMailDetailObject(mailTemplateDtls, userDtlsMap,
//				userDtlsMap.get(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY).toString(),
//				rmApprovalDtls.getUserName(), rmApprovalDtls);
		
		MailDetail mailDetailObj = createMailDetailObject(mailTemplateDtls, userDtlsMap,
				userDtlsMap.get(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY).toString(),
				userDtlsMap.get(ResourceManagementConstant.EMAIL_To_USER_NAME).toString(), rmApprovalDtls);

		if (CollectionUtils.isNotEmpty(toUsersList))
			mailDetailObj.setMailToAddress(adminServiceClient.getAssociatesEmailAddress(toUsersList));
		if (CollectionUtils.isNotEmpty(ccUsersList))
			mailDetailObj.setMailCcAddress(adminServiceClient.getAssociatesEmailAddress(ccUsersList));
		sendMailUtil.sendMail(mailDetailObj);
		log.info("Just before leaving SendMailUtility.sendEmailForSubmitApprovalPending method:");
	}

	public void sendEmailForApprovalConfirmation(RMApprovalInputDto rmApprovalDtls, String wrkflwCode)
			throws ResourceManagementException {
		log.info("Entered into SendMailUtility.sendEmailForApprovalConfirmation method:");
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		Map<String, Object> userDtlsMap = createUserDetailsMapForApproveOrRejectConfirmation(rmApprovalDtls,
				wrkflwCode);
		List<Long> ccUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_CC_USERS);
		List<Long> toUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_TO_USERS);
		if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_ALLOCATION_APPROVAL_CONFIRMATION_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_DEALLOCATION_APPROVAL_CONFIRMATION_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_TRNSFR_APPROVAL_CONFIRMATION_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)
				|| rmApprovalDtls.getRequestType()
						.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_APPROVAL_PENDING_LIFERAY_URL)) {
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE, rmApprovalDtls.getRoleName());
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_EXTENSION_APPR_CNF_LIFERAY_URL);

		}

		MailDetail mailDetailObj = createMailDetailObject(mailTemplateDtls, userDtlsMap, rmApprovalDtls.getRoleName(),
				rmApprovalDtls.getUserName(), rmApprovalDtls);
		if (CollectionUtils.isNotEmpty(toUsersList))
			mailDetailObj.setMailToAddress(adminServiceClient.getAssociatesEmailAddress(toUsersList));
		if (CollectionUtils.isNotEmpty(ccUsersList))
			mailDetailObj.setMailCcAddress(adminServiceClient.getAssociatesEmailAddress(ccUsersList));
		sendMailUtil.sendMail(mailDetailObj);
		log.info("Just before leaving SendMailUtility.sendEmailForApprovalConfirmation method:");
	}

	public void sendEmailForFinalApprovalConfirmation(RMApprovalInputDto rmApprovalDtls, String wrkflwCode,
			long wrkflwTranscId) throws ResourceManagementException {
		log.info("Entered into SendMailUtility.sendEmailForFinalApprovalConfirmation method:");
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		Map<String, Object> userDtlsMap = createUserDetailsMapForApproveOrRejectConfirmation(rmApprovalDtls,
				wrkflwCode);
		List<Long> ccUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_CC_USERS);
		List<Long> toUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_TO_USERS);
		if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_ALLOCATION_FINAL_APPROVAL_CONFIRMATION_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient.getEmailTemplate(
					ResourceManagementConstant.RM_DEALLOCATION_FINAL_APPROVAL_CONFIRMATION_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_TRNSFR_FINAL_APPROVAL_CNF_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)) {
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_EXTENSION_APPR_FINAL_LIFERAY_URL);
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE, rmApprovalDtls.getRoleName());
		}
		MailDetail mailDetailObj = createMailDetailObject(mailTemplateDtls, userDtlsMap, rmApprovalDtls.getRoleName(),
				rmApprovalDtls.getUserName(), rmApprovalDtls);
		if (CollectionUtils.isNotEmpty(toUsersList))
			mailDetailObj.setMailToAddress(adminServiceClient.getAssociatesEmailAddress(toUsersList));
		if (CollectionUtils.isNotEmpty(ccUsersList))
			mailDetailObj.setMailCcAddress(adminServiceClient.getAssociatesEmailAddress(ccUsersList));
		if (CollectionUtils.isNotEmpty(rmApprovalDtls.getEmployeeIdList()))
			mailDetailObj.setMailBccAddress(
					adminServiceClient.getAssociatesEmailAddress(rmApprovalDtls.getEmployeeIdList()));
		sendMailUtil.sendMail(mailDetailObj);
		log.info("Just before leaving SendMailUtility.sendEmailForFinalApprovalConfirmation method:");
	}

	public void sendEmailForRejectionConfirmation(RMApprovalInputDto rmApprovalDtls, String wrkflwCode)
			throws ResourceManagementException {
		log.info("Entered into SendMailUtility.sendEmailForRejectionConfirmation method:");
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		Map<String, Object> userDtlsMap = createUserDetailsMapForApproveOrRejectConfirmation(rmApprovalDtls,
				wrkflwCode);
		List<Long> ccUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_CC_USERS);
		List<Long> toUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_TO_USERS);
		if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_ALLOCATION_REJECTION_CONFIRMATION_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_DEALLOCATION_REJECTION_CONFIRMATION_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE))
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_TRNSFR_REJECTION_CNF_LIFERAY_URL);
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)) {
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_EXTENSION_APPR_REJECTED_LIFERAY_URL);
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE, rmApprovalDtls.getRoleName());
		}
		MailDetail mailDetailObj = createMailDetailObject(mailTemplateDtls, userDtlsMap, rmApprovalDtls.getRoleName(),
				rmApprovalDtls.getUserName(), rmApprovalDtls);
		if (CollectionUtils.isNotEmpty(toUsersList))
			mailDetailObj.setMailToAddress(adminServiceClient.getAssociatesEmailAddress(toUsersList));
		if (CollectionUtils.isNotEmpty(ccUsersList))
			mailDetailObj.setMailCcAddress(adminServiceClient.getAssociatesEmailAddress(ccUsersList));
		sendMailUtil.sendMail(mailDetailObj);
		log.info("Just before leaving SendMailUtility.sendEmailForRejectionConfirmation method:");
	}

	public void sendEmailForApproveOrRejectionPending(RMApprovalInputDto rmApprovalDtls, String wrkflwCode,
			long wrkflwTrnsctnId) throws ResourceManagementException {
		log.info("Entered into SendMailUtility.sendEmailForApproveOrRejectionPending method:");
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		Map<String, Object> userDtlsMap = createUserDetailsMapForApproveOrRejectPending(rmApprovalDtls, wrkflwCode,
				wrkflwTrnsctnId);
		List<Long> ccUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_CC_USERS);
		List<Long> toUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_TO_USERS);
		if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE)) {
			if (rmApprovalDtls.getApproverAction()
					.equalsIgnoreCase(ResourceManagementConstant.RM_APPROVER_APPROVE_ACTION))
				mailTemplateDtls = liferayServiceClient
						.getEmailTemplate(ResourceManagementConstant.RM_ALLOCATION_APPROVAL_PENDING_LIFERAY_URL);
			else if (rmApprovalDtls.getApproverAction()
					.equalsIgnoreCase(ResourceManagementConstant.RM_APPROVER_REJECT_ACTION))
				mailTemplateDtls = liferayServiceClient
						.getEmailTemplate(ResourceManagementConstant.RM_ALLOCATION_PENDING_REJECTION_LIFERAY_URL);
		} else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE)) {
			if (rmApprovalDtls.getApproverAction()
					.equalsIgnoreCase(ResourceManagementConstant.RM_APPROVER_APPROVE_ACTION))
				mailTemplateDtls = liferayServiceClient
						.getEmailTemplate(ResourceManagementConstant.RM_DEALLOCATION_APPROVAL_PENDING_LIFERAY_URL);
			else if (rmApprovalDtls.getApproverAction()
					.equalsIgnoreCase(ResourceManagementConstant.RM_APPROVER_REJECT_ACTION))
				mailTemplateDtls = liferayServiceClient
						.getEmailTemplate(ResourceManagementConstant.RM_DEALLOCATION_PENDING_REJECTION_LIFERAY_URL);
		} else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
			if (rmApprovalDtls.getApproverAction()
					.equalsIgnoreCase(ResourceManagementConstant.RM_APPROVER_APPROVE_ACTION))
				mailTemplateDtls = liferayServiceClient
						.getEmailTemplate(ResourceManagementConstant.RM_TRNSFR_APPROVAL_PENDING_LIFERAY_URL);
			else if (rmApprovalDtls.getApproverAction()
					.equalsIgnoreCase(ResourceManagementConstant.RM_APPROVER_REJECT_ACTION))
				mailTemplateDtls = liferayServiceClient
						.getEmailTemplate(ResourceManagementConstant.RM_TRNSFR_REJECTION_PENDING_LIFERAY_URL);
		} else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)) {
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_EXTNSN_APPROVAL_PENDING_LIFERAY_URL);
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE, rmApprovalDtls.getRoleName());
		}
		//by devAk
//		MailDetail mailDetailObj = createMailDetailObjectForApproveRejectPending(mailTemplateDtls, userDtlsMap, rmApprovalDtls.getRoleName(),
//				rmApprovalDtls.getUserName(), rmApprovalDtls);
		MailDetail mailDetailObj = createMailDetailObjectForApproveRejectPending(mailTemplateDtls, userDtlsMap, rmApprovalDtls.getRoleName(),
				userDtlsMap.get(ResourceManagementConstant.EMAIL_To_USER_NAME).toString(), rmApprovalDtls);
		//ended
		if (CollectionUtils.isNotEmpty(toUsersList))
			mailDetailObj.setMailToAddress(adminServiceClient.getAssociatesEmailAddress(toUsersList));
		if (CollectionUtils.isNotEmpty(ccUsersList))
			mailDetailObj.setMailCcAddress(adminServiceClient.getAssociatesEmailAddress(ccUsersList));
		sendMailUtil.sendMail(mailDetailObj);
		log.info("Just before leaving SendMailUtility.sendEmailForApproveOrRejectionPending method:");
	}

	public Map<String, Object> createUserDetailsMapForSubmitConfirmation(RMApprovalInputDto rmApprovalDtls,
			String wrkflwCode) throws ResourceManagementException {
		log.info("Entered into SendMailUtility.createUserDetailsMapForSubmitConfirmation method:");
		Map<String, Object> userDtlsMap = new HashMap<>();
		List<Long> ccUsersList = new ArrayList<>();
		List<Long> toUsersList = new ArrayList<>();
		List<Long> roleIdList = new ArrayList<>();
		String projectCode = "";
		String projectName = "";
		String customerName = "";
		ProjectDto sourceProjectDto=bapServiceClient.getProjectDetail(rmApprovalDtls.getCurrentProjectId());
		ProjectDto targetProjectDto=bapServiceClient.getProjectDetail(rmApprovalDtls.getProjectId());
		toUsersList.add(rmApprovalDtls.getUserId());
		if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
			ccUsersList.add(rmApprovalDtls.getFyiCurrentProgramManagerId());
			ccUsersList.add(rmApprovalDtls.getFyiTargetProgramManagerId());
			userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_SOURCE,
					sourceProjectDto.getProjectName()+"("+sourceProjectDto.getProjectCode()+")");
					//bapServiceClient.getProjectDetail(rmApprovalDtls.getCurrentProjectId()).getProjectName());			
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE, rmApprovalDtls.getRoleName());
			userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_TARGET,
					targetProjectDto.getProjectName()+"("+targetProjectDto.getProjectCode()+")");
					//bapServiceClient.getProjectDetail(rmApprovalDtls.getProjectId()).getProjectName());
		}
		if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)
				|| rmApprovalDtls.getRequestType().equalsIgnoreCase(
						ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD)) {
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE, rmApprovalDtls.getRoleName());
		}

		List<WrkflwStepDefinitionDto> configuredEmailRoles = wrkflwEngineServiceClient.getWrkflwStepEmailDetails(
				wrkflwCode, ResourceManagementConstant.RM_SUBMIT_WRKLFW_DECISION_CODE,
				ResourceManagementConstant.EMAIL_UI_DISPLAY_FLAG_FALSE, rmApprovalDtls.getRoleId());
		if (CollectionUtils.isNotEmpty(configuredEmailRoles))
			roleIdList = configuredEmailRoles.stream().map(WrkflwStepDefinitionDto::getRoleId)
					.collect(Collectors.toList());
		roleIdList.add(rmApprovalDtls.getRoleId());
		List<PrimaryUsersDto> primaryUserDtls = bapServiceClient
				.getRoleBasedPrimaryOwnersList(rmApprovalDtls.getProjectId(), roleIdList);
		if (CollectionUtils.isNotEmpty(primaryUserDtls)) {
			ccUsersList = primaryUserDtls.stream().map(PrimaryUsersDto::getUserId).collect(Collectors.toList());
			projectCode = primaryUserDtls.get(0).getProjectCode();
			projectName = primaryUserDtls.get(0).getProjectName();
			customerName = primaryUserDtls.get(0).getCustomerCode();
		}
		if(rmApprovalDtls.getTransferFYIList()!=null && !rmApprovalDtls.getTransferFYIList().isEmpty()) {
			for (TransferFYIDto fyiDto : rmApprovalDtls.getTransferFYIList()) {
				ccUsersList.add(fyiDto.getUserId());
			}
		}
		ccUsersList.removeAll(toUsersList);
		ccUsersList = ccUsersList.stream().distinct().collect(Collectors.toList());
		String projNameWithCode=projectName+"("+projectCode+")";
		userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY, projNameWithCode);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY, customerName);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_TO_USERS, toUsersList);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_CC_USERS, ccUsersList);

		log.info("Just before leaving SendMailUtility.createUserDetailsMapForSubmitConfirmation method:");
		return userDtlsMap;
	}

	public Map<String, Object> createUserDetailsMapForSubmitPending(RMApprovalInputDto rmApprovalDtls,
			String wrkflwCode, long wrkflwTrnsctnId) throws ResourceManagementException {
		log.info("Entered into SendMailUtility.createUserDetailsMapForSubmitPending method:");
		Map<String, Object> userDtlsMap = new HashMap<>();
		List<Long> ccUsersList = new ArrayList<>();
		List<Long> toUsersList = new ArrayList<>();
		List<Long> roleIdList = new ArrayList<>();
		Map<Long, PrimaryUsersDto> primaryUsersDtlsMap = new HashMap<>();
		String projectName = "";
		String projectCode = "";
		String userRoleName = "";
		String customerName = "";
		ProjectDto sourceProjectDto=bapServiceClient.getProjectDetail(rmApprovalDtls.getCurrentProjectId());
		ProjectDto targetProjectDto=bapServiceClient.getProjectDetail(rmApprovalDtls.getProjectId());
		ResourceWorkflow resourceWrkflwDataObj = resourceWrkflwRepository.getRowData(wrkflwTrnsctnId,
				rmApprovalDtls.getUserId(), rmApprovalDtls.getRoleId());
		toUsersList.add(resourceWrkflwDataObj.getNextUserId());
		List<String> mailToUserNames=new ArrayList<>();
		try {
		mailToUserNames=adminServiceClient.getAssociatesNames(List.of(resourceWrkflwDataObj.getNextUserId()));
		} catch (ResourceManagementException e) {
		throw new ResourceManagementException(e);
		}
				if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
			ccUsersList.add(rmApprovalDtls.getFyiCurrentProgramManagerId());
			ccUsersList.add(rmApprovalDtls.getFyiTargetProgramManagerId());
			userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_SOURCE, 
					sourceProjectDto.getProjectName()+"("+sourceProjectDto.getProjectCode()+")");
					//bapServiceClient.getProjectDetail(rmApprovalDtls.getCurrentProjectId()).getProjectName());
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE, rmApprovalDtls.getRoleName());
			userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_TARGET, 
					targetProjectDto.getProjectName()+"("+targetProjectDto.getProjectCode()+")");
					//bapServiceClient.getProjectDetail(rmApprovalDtls.getProjectId()).getProjectName());
		}
		List<WrkflwStepDefinitionDto> configuredEmailRoles = wrkflwEngineServiceClient.getWrkflwStepEmailDetails(
				wrkflwCode, ResourceManagementConstant.RM_SUBMIT_WRKLFW_DECISION_CODE,
				ResourceManagementConstant.EMAIL_UI_DISPLAY_FLAG_FALSE, rmApprovalDtls.getRoleId());
		if (CollectionUtils.isNotEmpty(configuredEmailRoles))
			roleIdList = configuredEmailRoles.stream().map(WrkflwStepDefinitionDto::getRoleId)
					.collect(Collectors.toList());
		roleIdList.add(resourceWrkflwDataObj.getNextRoleId());
		roleIdList.add(rmApprovalDtls.getRoleId());
		List<PrimaryUsersDto> primaryUserDtls = bapServiceClient
				.getRoleBasedPrimaryOwnersList(rmApprovalDtls.getProjectId(), roleIdList);
		if (CollectionUtils.isNotEmpty(primaryUserDtls)) {
			primaryUsersDtlsMap = primaryUserDtls.stream().collect(HashMap::new, (m, v) -> m.put(v.getRoleId(), v),
					HashMap::putAll);
			userRoleName = primaryUsersDtlsMap.containsKey(resourceWrkflwDataObj.getNextRoleId())
					? primaryUsersDtlsMap.get(resourceWrkflwDataObj.getNextRoleId()).getRoleName()
					: userRoleName;
			ccUsersList = primaryUserDtls.stream().map(PrimaryUsersDto::getUserId).collect(Collectors.toList());
			ccUsersList.add(rmApprovalDtls.getUserId());
			projectName = primaryUserDtls.get(0).getProjectName();
			projectCode = primaryUserDtls.get(0).getProjectCode();
			customerName = primaryUserDtls.get(0).getCustomerCode();
		}
		if(rmApprovalDtls.getTransferFYIList()!=null && !rmApprovalDtls.getTransferFYIList().isEmpty()) {
			for (TransferFYIDto fyiDto : rmApprovalDtls.getTransferFYIList()) {
				ccUsersList.add(fyiDto.getUserId());
			}
		}
		ccUsersList.removeAll(toUsersList);
		ccUsersList = ccUsersList.stream().distinct().collect(Collectors.toList());
		String projNameWithCode=projectName+"("+projectCode+")";
		userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY, projNameWithCode);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY, customerName);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY, userRoleName);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE, userRoleName);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_TO_USERS, toUsersList);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_CC_USERS, ccUsersList);
		//added by devAk
		userDtlsMap.put(ResourceManagementConstant.EMAIL_To_USER_NAME, mailToUserNames.get(0));
		log.info("Just before leaving SendMailUtility.createUserDetailsMapForSubmitPending method:");
		return userDtlsMap;
	}

	public Map<String, Object> createUserDetailsMapForApproveOrRejectConfirmation(RMApprovalInputDto rmApprovalDtls,
			String wrkflwCode) throws ResourceManagementException {
		log.info("Entered into SendMailUtility.createUserDetailsMapForApproveOrRejectConfirmation method:");
		Map<String, Object> userDtlsMap = new HashMap<>();
		List<Long> ccUsersList = new ArrayList<>();
		List<Long> toUsersList = new ArrayList<>();
		List<Long> roleIdList = new ArrayList<>();
		String projectCode = "";
		String projectName = "";
		String customerName = "";
		ProjectDto sourceProjectDto=bapServiceClient.getProjectDetail(rmApprovalDtls.getCurrentProjectId());
		ProjectDto targetProjectDto=bapServiceClient.getProjectDetail(rmApprovalDtls.getProjectId());
		toUsersList.add(rmApprovalDtls.getUserId());
		List<WrkflwStepDefinitionDto> configuredEmailRoles = wrkflwEngineServiceClient.getWrkflwStepEmailDetails(
				wrkflwCode, ResourceManagementConstant.RM_APPROVE_WRKFLW_DECISION_CODE,
				ResourceManagementConstant.EMAIL_UI_DISPLAY_FLAG_FALSE, rmApprovalDtls.getRoleId());
		if (CollectionUtils.isNotEmpty(configuredEmailRoles))
			roleIdList = configuredEmailRoles.stream().map(WrkflwStepDefinitionDto::getRoleId)
					.collect(Collectors.toList());
		roleIdList.add(rmApprovalDtls.getRoleId());
		List<PrimaryUsersDto> primaryUserDtls = bapServiceClient
				.getRoleBasedPrimaryOwnersList(rmApprovalDtls.getProjectId(), roleIdList);
		if (CollectionUtils.isNotEmpty(primaryUserDtls)) {
			ccUsersList = primaryUserDtls.stream().map(PrimaryUsersDto::getUserId).collect(Collectors.toList());
			ccUsersList.add(rmApprovalDtls.getUserId());
			projectName = primaryUserDtls.get(0).getProjectName();
			projectCode = primaryUserDtls.get(0).getProjectCode();
			customerName = primaryUserDtls.get(0).getCustomerCode();
		}
		
		if(rmApprovalDtls.getRequestType()!=null 
				&& rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE) 
				&& (rmApprovalDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.TAG_ROLE_NAME) 
						|| rmApprovalDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.ADMIN_ROLE_NAME))){
			Long primaryPMLookUpValueId = adminServiceClient.getLookuIdByTypeAndDescr(ResourceManagementConstant.ROLE_TYPE, ResourceManagementConstant.PROJECT_MANAGER);
			List<PrimaryUsersDto> primaryUserList = bapServiceClient.getRoleBasedPrimaryOwnersList(rmApprovalDtls.getProjectId(), List.of(primaryPMLookUpValueId));
			List<PrimaryUsersDto> currentPrimaryUserList = bapServiceClient.getRoleBasedPrimaryOwnersList(rmApprovalDtls.getCurrentProjectId(), List.of(primaryPMLookUpValueId));
			
			if(!CollectionUtils.isEmpty(primaryUserList)) {
			ccUsersList.addAll(primaryUserList.stream().map(PrimaryUsersDto::getUserId).collect(Collectors.toList()));
			}	
			if(!CollectionUtils.isEmpty(currentPrimaryUserList)) {
				ccUsersList.addAll(currentPrimaryUserList.stream().map(PrimaryUsersDto::getUserId).collect(Collectors.toList()));
			}	
		}
		
		ccUsersList.removeAll(toUsersList);
		ccUsersList = ccUsersList.stream().distinct().collect(Collectors.toList());
		String projNameWithCode=projectName+"("+projectCode+")";
		userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY, projNameWithCode);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY, customerName);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_TO_USERS, toUsersList);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_CC_USERS, ccUsersList);
		if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
			userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_SOURCE, 
					sourceProjectDto.getProjectName()+"("+sourceProjectDto.getProjectCode()+")");
					//bapServiceClient.getProjectDetail(rmApprovalDtls.getCurrentProjectId()).getProjectName());
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE, rmApprovalDtls.getRoleName());
			userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_TARGET, 
					targetProjectDto.getProjectName()+"("+targetProjectDto.getProjectCode()+")");
					//bapServiceClient.getProjectDetail(rmApprovalDtls.getProjectId()).getProjectName());
		}
		log.info("Just before leaving SendMailUtility.createUserDetailsMapForApproveOrRejectConfirmation method:");
		return userDtlsMap;
	}

	public Map<String, Object> createUserDetailsMapForApproveOrRejectPending(RMApprovalInputDto rmApprovalDtls,
			String wrkflwCode, long wrkflwTrnsctnId) throws ResourceManagementException {
		log.info("Entered into SendMailUtility.createUserDetailsMapForApproveOrRejectPending method:");
		Map<String, Object> userDtlsMap = new HashMap<>();
		ResourceWorkflow resourceWrkflwDataObj = new ResourceWorkflow();
		ResourceWorkflow resourceWrkflwDataObjNext = new ResourceWorkflow();
		List<Long> ccUsersList = new ArrayList<>();
		List<Long> toUsersList = new ArrayList<>();
		List<Long> roleIdList = new ArrayList<>();
		Map<Long, PrimaryUsersDto> primaryUsersDtlsMap = new HashMap<>();
		String projectCode = "";
		String projectName = "";
		String userRoleName = "";
		String approverName = "";
		String customerName = "";
		long approverRoleId = 0L;
		ProjectDto sourceProjectDto=bapServiceClient.getProjectDetail(rmApprovalDtls.getCurrentProjectId());
		ProjectDto targetProjectDto=bapServiceClient.getProjectDetail(rmApprovalDtls.getProjectId());
		if (rmApprovalDtls.getApproverAction()
				.equalsIgnoreCase(ResourceManagementConstant.RM_APPROVER_APPROVE_ACTION)) {
			resourceWrkflwDataObj = resourceWrkflwRepository.getRowData(wrkflwTrnsctnId, rmApprovalDtls.getUserId(),
					rmApprovalDtls.getRoleId());
			
			if(resourceWrkflwDataObj.getCreatedBy().equals(rmApprovalDtls.getUserId()) && rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
				long allocApprovedStatusId = resourceManagementServiceImpl
						.getModuleStatusId(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.APPROVED);
				List<Long> status=List.of(allocApprovedStatusId);
				resourceWrkflwDataObj = resourceWrkflwRepository.getRowDataOfDefaultStatus(wrkflwTrnsctnId,status,rmApprovalDtls.getUserId(),
						rmApprovalDtls.getRoleId());
			}
			toUsersList.add(resourceWrkflwDataObj.getNextUserId());
			approverRoleId = resourceWrkflwDataObj.getNextRoleId();
		} else if (rmApprovalDtls.getApproverAction()
				.equalsIgnoreCase(ResourceManagementConstant.RM_APPROVER_REJECT_ACTION)) {
			resourceWrkflwDataObj = resourceWrkflwRepository.getPreviousRowData(wrkflwTrnsctnId,
					rmApprovalDtls.getUserId(), rmApprovalDtls.getRoleId());
			toUsersList.add(resourceWrkflwDataObj.getCurrentUserId());
			approverRoleId = resourceWrkflwDataObj.getCurrentRoleId();
		}
		List<WrkflwStepDefinitionDto> configuredEmailRoles = wrkflwEngineServiceClient.getWrkflwStepEmailDetails(
				wrkflwCode, ResourceManagementConstant.RM_APPROVE_WRKFLW_DECISION_CODE,
				ResourceManagementConstant.EMAIL_UI_DISPLAY_FLAG_FALSE, rmApprovalDtls.getRoleId());
		if (CollectionUtils.isNotEmpty(configuredEmailRoles))
			roleIdList = configuredEmailRoles.stream().map(WrkflwStepDefinitionDto::getRoleId)
					.collect(Collectors.toList());
		roleIdList.add(rmApprovalDtls.getRoleId());
		List<ResourceWorkflowProjection> rmSelectedApproversIdList = resourceWrkflwRepository
				.getAllApproversIdList(wrkflwTrnsctnId);
		if (CollectionUtils.isNotEmpty(rmSelectedApproversIdList)) {
			roleIdList.addAll(rmSelectedApproversIdList.stream().map(ResourceWorkflowProjection::getCurrentRoleId)
					.collect(Collectors.toList()));
		}
		List<PrimaryUsersDto> primaryUserDtls = bapServiceClient
				.getRoleBasedPrimaryOwnersList(rmApprovalDtls.getProjectId(), roleIdList);
		if (CollectionUtils.isNotEmpty(primaryUserDtls)) {
			primaryUsersDtlsMap = primaryUserDtls.stream().collect(HashMap::new, (m, v) -> m.put(v.getRoleId(), v),
					HashMap::putAll);
			userRoleName = primaryUsersDtlsMap.containsKey(approverRoleId)
					? primaryUsersDtlsMap.get(approverRoleId).getRoleName()
					: userRoleName;
			approverName = primaryUsersDtlsMap.containsKey(approverRoleId)
					? primaryUsersDtlsMap.get(approverRoleId).getUserName()
					: approverName;
			ccUsersList = (primaryUserDtls.stream().map(PrimaryUsersDto::getUserId).collect(Collectors.toList()));
			ccUsersList.add(rmApprovalDtls.getUserId());
			projectCode = primaryUserDtls.get(0).getProjectCode();
			projectName = primaryUserDtls.get(0).getProjectName();
			customerName = primaryUserDtls.get(0).getCustomerCode();
		}
		//by devAk
		List<String> mailToUserNames=new ArrayList<>();
		try {
			 mailToUserNames=adminServiceClient.getAssociatesNames(List.of(resourceWrkflwDataObj.getNextUserId()));
		} catch (ResourceManagementException e) {
			throw new ResourceManagementException(e);
		}
		
		ccUsersList.removeAll(toUsersList);
		ccUsersList = ccUsersList.stream().distinct().collect(Collectors.toList());
		String projNameWithCode=projectName+"("+projectCode+")";
		userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY, projNameWithCode);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY, customerName);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_TO_USERS, toUsersList);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_CC_USERS, ccUsersList);
		//added by devAk
		userDtlsMap.put(ResourceManagementConstant.EMAIL_To_USER_NAME, mailToUserNames.get(0));
				
		if(rmApprovalDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.PROJECT_MANAGER) && 
				(rmApprovalDtls.getApproverAction().equalsIgnoreCase(ResourceManagementConstant.APPROVED))) {
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY, ResourceManagementConstant.PROGRAM_MANAGER);
		}
		else if(rmApprovalDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.PROGRAM_MANAGER) && 
				(rmApprovalDtls.getApproverAction().equalsIgnoreCase(ResourceManagementConstant.APPROVED))) {
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY, ResourceManagementConstant.TAG_TEAM);
		}
		else if(rmApprovalDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.TAG_TEAM) && 
				(rmApprovalDtls.getApproverAction().equalsIgnoreCase(ResourceManagementConstant.REJECTED))) {
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY, ResourceManagementConstant.PROGRAM_MANAGER);
		}
		else if(rmApprovalDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.PROGRAM_MANAGER) && 
				(rmApprovalDtls.getApproverAction().equalsIgnoreCase(ResourceManagementConstant.REJECTED))) {
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY, ResourceManagementConstant.PROJECT_MANAGER);
		}
		else if(rmApprovalDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.PROJECT_MANAGER) && 
				(rmApprovalDtls.getApproverAction().equalsIgnoreCase(ResourceManagementConstant.REJECTED))) {
			userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY, ResourceManagementConstant.PROJECT_MANAGER);
		}
		//userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY, userRoleName);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_APPROVER_NAME_KEY, approverName);
		if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
			userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_SOURCE, 
					sourceProjectDto.getProjectName()+"("+sourceProjectDto.getProjectCode()+")");
					//bapServiceClient.getProjectDetail(rmApprovalDtls.getCurrentProjectId()).getProjectName());
			if(rmApprovalDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.PROJECT_MANAGER) && 
					(rmApprovalDtls.getApproverAction().equalsIgnoreCase(ResourceManagementConstant.APPROVED))) {
				userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE,ResourceManagementConstant.TAG_TEAM);
			}
			else if(rmApprovalDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.TAG_TEAM) && 
					(rmApprovalDtls.getApproverAction().equalsIgnoreCase(ResourceManagementConstant.REJECTED))) {
				userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE, ResourceManagementConstant.PROJECT_MANAGER);
			}
			else if(rmApprovalDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.PROJECT_MANAGER) && 
					(rmApprovalDtls.getApproverAction().equalsIgnoreCase(ResourceManagementConstant.REJECTED))) {
				userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE, ResourceManagementConstant.PROJECT_MANAGER);
			}
			//userDtlsMap.put(ResourceManagementConstant.EMAIL_USER_ROLE, rmApprovalDtls.getRoleName());
			userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_TARGET, 
					targetProjectDto.getProjectName()+"("+targetProjectDto.getProjectCode()+")");
					//bapServiceClient.getProjectDetail(rmApprovalDtls.getProjectId()).getProjectName());
		}
		log.info("Just before leaving SendMailUtility.createUserDetailsMapForApproveOrRejectPending method:");
		return userDtlsMap;
	}

	public StringBuffer createTableDataForAllocation(List<EmployeeDto> employeeDtlsList, String[] tableColumnNamesList)
			throws ResourceManagementException {
		// For Now using the deallocation table data only
		return createTableDataForDeAllocation(employeeDtlsList, tableColumnNamesList);
	}

	public StringBuffer createTableDataForDeAllocation(List<EmployeeDto> employeeDtlsList,
			String[] tableColumnNamesList) throws ResourceManagementException {
		StringBuffer tableData = new StringBuffer();
		tableData.append("<table border = '1' style='border-collapse:collapse;' cellpadding = '10' ><tr>");
		for (String columnName : tableColumnNamesList) {
			tableData.append("<th>" + columnName + "</th>");
		}
		tableData.append("</tr>");
		for (EmployeeDto employeeDtls : employeeDtlsList) {
			tableData.append(
					"<tr><td>" + employeeDtls.getEmployeeName() + " / " + employeeDtls.getEmployeeNumber() + "</td>");
			tableData.append("<td>" + employeeDtls.getBand() + "</td>");
			tableData.append("<td>" + employeeDtls.getEmployeeLocation() + "</td></tr>");
		}
		tableData.append("</table>");
		return tableData;
	}

	public StringBuffer createTableDataForExtension(List<EmployeeDto> employeeDtlsList, String[] tableColumnNamesList,
			Date proposedEstEndDate) throws ResourceManagementException {
		StringBuffer tableData = new StringBuffer();
		tableData.append("<table border = '1' style='border-collapse:collapse;' cellpadding = '10' ><tr>");
		for (String columnName : tableColumnNamesList) {
			tableData.append("<th>" + columnName + "</th>");
		}
		tableData.append("</tr>");
		for (EmployeeDto employeeDtls : employeeDtlsList) {
			//Dev by Ravi
			Date estEndDate=null;
			if(employeeDtls.getEstimatedEndDate()!=null)
				estEndDate=employeeDtls.getEstimatedEndDate();
			//End
			tableData.append(
					"<tr><td>" + employeeDtls.getEmployeeName() + " / " + employeeDtls.getEmployeeNumber() + "</td>");
			tableData.append("<td>" + employeeDtls.getBand() + "</td>");
			tableData.append("<td>" + employeeDtls.getEmployeeLocation() + "</td>");
			tableData.append("<td>" + estEndDate + "</td>");
			tableData.append("<td>" + proposedEstEndDate + "</td></tr>");
		}
		tableData.append("</table>");
		return tableData;
	}

	public MailDetail createMailDetailObject(MailTemplateDto mailTemplateDtls, Map projectDtlsMap, String roleName,
			String approverName, RMApprovalInputDto rmApprovalDtls) throws ResourceManagementException {
		log.info("Entered into SendMailUtility.createMailDetailObject method:");
		MailDetail mailDetailObj = new MailDetail();
		StringBuffer tableData = new StringBuffer();
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		List<TAssociateExtension> tAssociateAllocationList = new ArrayList<>();
		mailDetailObj.setMailSubject((mailTemplateDtls.getSubject() != null) ? mailTemplateDtls.getSubject() : null);
		String msgHeader = (mailTemplateDtls.getMessageBodyHeader() != null)
				? mailTemplateDtls.getMessageBodyHeader().replace(ResourceManagementConstant.EMAIL_APPROVER_NAME_KEY,
						approverName)
				: null;
		String msgContent = (mailTemplateDtls.getMessageBodyContent() != null)
				? mailTemplateDtls.getMessageBodyContent()
						.replace(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY,
								projectDtlsMap.get(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY).toString())
						.replace(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY,
								projectDtlsMap.get(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY).toString())
						.replace(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY, roleName)
				: null;
		setDataIntoMailObject(mailTemplateDtls, projectDtlsMap, rmApprovalDtls, mailDetailObj, tableData,
				employeeDtlsList, msgHeader, msgContent);
		log.info("Just before leaving SendMailUtility.createMailDetailObject method:");

		return mailDetailObj;
	}

	private void setDataIntoMailObject(MailTemplateDto mailTemplateDtls, Map projectDtlsMap,
			RMApprovalInputDto rmApprovalDtls, MailDetail mailDetailObj, StringBuffer tableData,
			List<EmployeeDto> employeeDtlsList, String msgHeader, String msgContent)
			throws ResourceManagementException {
		List<TAssociateExtension> tAssociateAllocationList;
		String msgFooter = (mailTemplateDtls.getMessageBodyFooter() != null) ? mailTemplateDtls.getMessageBodyFooter()
				: null;
		if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE))
			// employeeDtlsList =
			// adminServiceClient.getAssociatesDetails(rmApprovalDtls.getEmployeeIdList());
			employeeDtlsList = adminServiceClient.getAssociatesDetailsbyEmpIds(rmApprovalDtls.getEmployeeIdList());
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE)) {
			employeeDtlsList =adminServiceClient.getAssociatesDetailsbyEmpIds(rmApprovalDtls.getEmployeeIdList());
			/*
			 * List<List<Long>> resourceDtoEmpIdList =
			 * rmApprovalDtls.getResourceRequirementList().stream()
			 * .map(ResourceRequirementDto::getEmployeeIdList).collect(Collectors.toList());
			 * 
			 * List<Long> empIdList = new ArrayList<>(); for (List<Long> empIdListObj :
			 * resourceDtoEmpIdList) { empIdList.addAll(empIdListObj); } employeeDtlsList =
			 * adminServiceClient.getAssociatesDetailsbyEmpIds(empIdList);
			 */
			// employeeDtlsList = adminServiceClient.getAssociatesDetails(empIdList);
		} else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
			List<Long> employeeIdList = rmApprovalDtls.getResourceList().stream().map(RTResourceDto::getEmpId)
					.collect(Collectors.toList());
			// employeeDtlsList = adminServiceClient.getAssociatesDetails(employeeIdList);
			employeeDtlsList = adminServiceClient.getAssociatesDetailsbyEmpIds(employeeIdList);
			msgContent = (mailTemplateDtls.getMessageBodyContent() != null)
					? mailTemplateDtls.getMessageBodyContent()
							.replace(ResourceManagementConstant.EMAIL_PROJECT_NAME_SOURCE,
									projectDtlsMap.get(ResourceManagementConstant.EMAIL_PROJECT_NAME_SOURCE).toString())
							.replace(ResourceManagementConstant.EMAIL_USER_ROLE,
									projectDtlsMap.get(ResourceManagementConstant.EMAIL_USER_ROLE).toString())
							.replace(ResourceManagementConstant.EMAIL_PROJECT_NAME_TARGET,
									projectDtlsMap.get(ResourceManagementConstant.EMAIL_PROJECT_NAME_TARGET).toString())
					: null;
		} else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)
				|| rmApprovalDtls.getRequestType().equalsIgnoreCase(
						ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD)) {
			if(rmApprovalDtls.getEmployeeIdList()!=null)
				employeeDtlsList =adminServiceClient.getAssociatesDetailsbyEmpIds(rmApprovalDtls.getEmployeeIdList());
			tAssociateAllocationList = rmApprovalDtls.getTAssociateExtensionList();
			msgContent = (mailTemplateDtls.getMessageBodyContent() != null)
					? mailTemplateDtls.getMessageBodyContent().replace(
							ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY,
							projectDtlsMap.get(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY).toString())
							.replace(ResourceManagementConstant.EMAIL_USER_ROLE,
									projectDtlsMap.get(ResourceManagementConstant.EMAIL_USER_ROLE).toString())
							.replace(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY,
									projectDtlsMap.get(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY).toString())
					// .replace(ResourceManagementConstant.EMAIL_USER_ROLE,
					// projectDtlsMap.get(ResourceManagementConstant.EMAIL_USER_ROLE).toString())
					: null;
		}
		String[] tableColumnNamesList = (mailTemplateDtls.getTableColumnNames() != null)
				? mailTemplateDtls.getTableColumnNames().split(",")
				: new String[0];
		if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE)
				|| rmApprovalDtls.getRequestType()
						.equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE))
			tableData = createTableDataForAllocation(employeeDtlsList, tableColumnNamesList);
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE))
			tableData = createTableDataForDeAllocation(employeeDtlsList, tableColumnNamesList);
		else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)
				|| rmApprovalDtls.getRequestType().equalsIgnoreCase(
						ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD)) {
			//added by Ravi
			if(rmApprovalDtls.getEmpCurrentEstEndDateMap()!=null) {
			employeeDtlsList.stream().forEach( emp->{
				emp.setEstimatedEndDate(rmApprovalDtls.getEmpCurrentEstEndDateMap().get(emp.getEmployeeId()));
			});
			}
			//end
			tableData = createTableDataForExtension(employeeDtlsList, tableColumnNamesList,
					rmApprovalDtls.getProposedEsEndDate());
		}
		mailDetailObj.setMailBody(msgHeader + msgContent + tableData + msgFooter);
	}

	public void sendEmailForTravelSubmissionConfirmation(List<TAssociateProjectDto> tAssociateProjectDto)
			throws ResourceManagementException {
		log.info("Entered into SendMailUtility.sendEmailForSubmissionConfirmation method:");
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		MailDetail mailDetailObj = new MailDetail();
		List<Long> toUsersList = new ArrayList<>();
		List<Long> bccUsersList = new ArrayList<>();
		List<Long> ccUsersList = new ArrayList<>();

		toUsersList.add(tAssociateProjectDto.get(0).getUserId());
		bccUsersList.addAll(
				tAssociateProjectDto.stream().map(TAssociateProjectDto::getEmployeeId).collect(Collectors.toList()));
		List<Long> sourceProjectId = tAssociateProjectDto.stream().map(TAssociateProjectDto::getProjectId)
				.collect(Collectors.toList());

		List<PrimaryUsersDto> primaryUserDtls = bapServiceClient.getProjectBasedPrimaryOwnersList(sourceProjectId,
				tAssociateProjectDto.get(0).getRoleId());
		ccUsersList.add(primaryUserDtls.get(0).getUserId());
		mailTemplateDtls = liferayServiceClient
				.getEmailTemplate(ResourceManagementConstant.RM_TRAVEL_ALLOCATION_SUBMISSION_CNFIRMATION_LIFERAY_URL);
		String projectName = bapServiceClient.getProjectDetail(tAssociateProjectDto.get(0).getProjectId())
				.getProjectName();
		if (projectName != null && !projectName.isEmpty())
			mailDetailObj = createMailDetailObjectForTravel(mailTemplateDtls, projectName,
					tAssociateProjectDto.get(0).getRoleName(), tAssociateProjectDto.get(0).getUserName(),
					tAssociateProjectDto);
		if (CollectionUtils.isNotEmpty(toUsersList))
			mailDetailObj.setMailToAddress(adminServiceClient.getAssociatesEmailAddress(toUsersList));
		if (CollectionUtils.isNotEmpty(ccUsersList))
			mailDetailObj.setMailCcAddress(adminServiceClient.getAssociatesEmailAddress(ccUsersList));
		if (CollectionUtils.isNotEmpty(bccUsersList))
			mailDetailObj.setMailCcAddress(adminServiceClient.getAssociatesEmailAddress(bccUsersList));

		sendMailUtil.sendMail(mailDetailObj);

	}

	public MailDetail createMailDetailObjectForTravel(MailTemplateDto mailTemplateDtls, String projectName,
			String roleName, String approverName, List<TAssociateProjectDto> tassociateProjectDto)
			throws ResourceManagementException {
		log.info("Entered into SendMailUtility.createMailDetailObjectForTravel method:");
		MailDetail mailDetailObj = new MailDetail();

		StringBuffer tableData = new StringBuffer();
		mailDetailObj.setMailSubject((mailTemplateDtls.getSubject() != null) ? mailTemplateDtls.getSubject() : null);
		String msgHeader = (mailTemplateDtls.getMessageBodyHeader() != null) ? mailTemplateDtls.getMessageBodyHeader()
				.replace(ResourceManagementConstant.EMAIL_APPROVER_NAME_KEY, tassociateProjectDto.get(0).getUserName())
				: null;
		String msgContent = (mailTemplateDtls.getMessageBodyContent() != null) ? mailTemplateDtls
				.getMessageBodyContent().replace(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY, projectName)
				.replace(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY, "CISCO")
				.replace(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY, roleName) : null;
		String msgFooter = (mailTemplateDtls.getMessageBodyFooter() != null) ? mailTemplateDtls.getMessageBodyFooter()
				: null;
		// List<EmployeeDto> employeeDtlsList = adminServiceClient.getAssociatesDetails(
		// tassociateProjectDto.stream().map(TAssociateProjectDto::getEmployeeId).collect(Collectors.toList()));
		List<EmployeeDto> employeeDtlsList = adminServiceClient.getAssociatesDetailsbyEmpIds(
				tassociateProjectDto.stream().map(TAssociateProjectDto::getEmployeeId).collect(Collectors.toList()));

		String[] tableColumnNamesList = (mailTemplateDtls.getTableColumnNames() != null)
				? mailTemplateDtls.getTableColumnNames().split(",")
				: new String[0];
		tableData = createTableDataForAllocation(employeeDtlsList, tableColumnNamesList);
		mailDetailObj.setMailBody(msgHeader + msgContent + tableData + msgFooter);
		log.info("Just before leaving SendMailUtility.createMailDetailObjectForTravel method:");

		return mailDetailObj;

	}
	
	
	public MailDetail createMailDetailObjectForApproveRejectPending(MailTemplateDto mailTemplateDtls, Map projectDtlsMap, String roleName,
			String approverName, RMApprovalInputDto rmApprovalDtls) throws ResourceManagementException {
		log.info("Entered into SendMailUtility.createMailDetailObject method:");
		MailDetail mailDetailObj = new MailDetail();
		StringBuffer tableData = new StringBuffer();
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		List<TAssociateExtension> tAssociateAllocationList = new ArrayList<>();
		mailDetailObj.setMailSubject((mailTemplateDtls.getSubject() != null) ? mailTemplateDtls.getSubject() : null);
		String msgHeader = (mailTemplateDtls.getMessageBodyHeader() != null)
				? mailTemplateDtls.getMessageBodyHeader().replace(ResourceManagementConstant.EMAIL_APPROVER_NAME_KEY,
						approverName)
				: null;
		String msgContent = (mailTemplateDtls.getMessageBodyContent() != null)
				? mailTemplateDtls.getMessageBodyContent()
						.replace(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY,
								projectDtlsMap.get(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY).toString())
						.replace(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY,
								projectDtlsMap.get(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY).toString())
						.replace(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY, projectDtlsMap.get(ResourceManagementConstant.EMAIL_USER_ROLE_NAME_KEY).toString())
				: null;
		setDataIntoMailObject(mailTemplateDtls, projectDtlsMap, rmApprovalDtls, mailDetailObj, tableData,
				employeeDtlsList, msgHeader, msgContent);
		log.info("Just before leaving SendMailUtility.createMailDetailObjectForApproveRejectPending method:");
		return mailDetailObj;
	}

	// added by devAk 
	public void sendEmailForAssociateFinalConfirmationMail(RMApprovalInputDto rmApprovalDtls,String wrkflwCode) 
			throws ResourceManagementException{
		log.info("Entered into SendMailUtility.sendEmailForAssociateFinalConfirmationMail method:");
		Map<String, Object> userDtlsMap = createUserDetailsMapForAssociateFinalConfirmationMail(rmApprovalDtls, wrkflwCode);
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		List<Long> ccUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_CC_USERS);
		List<Long> toUsersList = (List<Long>) userDtlsMap.get(ResourceManagementConstant.EMAIL_TO_USERS);
		if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE)) {
			mailTemplateDtls = liferayServiceClient
					.getEmailTemplate(ResourceManagementConstant.RM_ALLOCATION_ASSOCIATE_FINAL_CNFIRMATION_LIFERAY_URL);
		}
		
		MailDetail mailDetailObj = createMailDetailObject(mailTemplateDtls, userDtlsMap,
				userDtlsMap.get(ResourceManagementConstant.EMAIL_To_USER_NAME).toString(), rmApprovalDtls);
     
		if (CollectionUtils.isNotEmpty(toUsersList))
			mailDetailObj.setMailToAddress(adminServiceClient.getAssociatesEmailAddress(toUsersList));
		if (CollectionUtils.isNotEmpty(ccUsersList))
			mailDetailObj.setMailCcAddress(adminServiceClient.getAssociatesEmailAddress(ccUsersList));
		sendMailUtil.sendMail(mailDetailObj);
		log.info("Just before leaving SendMailUtility.sendEmailForAssociateFinalConfirmationMail method:");
	}
	
	public Map<String, Object> createUserDetailsMapForAssociateFinalConfirmationMail(RMApprovalInputDto rmApprovalDtls,String wrkflwCode)
			throws ResourceManagementException{
		log.info("Entered into SendMailUtility.createUserDetailsMapForAssociateFinalConfirmationMail method:");
		//local variables
		Map<String, Object> userDtlsMap = new HashMap<>();
		List<Long> ccUsersList = new ArrayList<>(); 
		List<Long> toUsersList = new ArrayList<>(); 
		List<EmployeeDto> employeeDtlsList= new ArrayList<>(); 
		String projectCode = "";
		String projectName = "";
		String customerName = "";
		String staffName="";
		//toUsers logic
		employeeDtlsList = adminServiceClient.getAssociatesDetailsbyEmpIds(rmApprovalDtls.getEmployeeIdList());
		toUsersList=employeeDtlsList.stream().map(EmployeeDto::getEmployeeNumber).collect(Collectors.toList());
		
        staffName=employeeDtlsList.get(0).getEmployeeName();
		
		//ccUsers logic
        //ProjectDto targetProjectDto=bapServiceClient.getProjectDetail(rmApprovalDtls.getProjectId());
		if(rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE)) {
			Long primaryPMLookUpValueId = adminServiceClient.getLookuIdByTypeAndDescr(ResourceManagementConstant.ROLE_TYPE, ResourceManagementConstant.PROJECT_MANAGER);
			List<PrimaryUsersDto> primaryUserList = bapServiceClient.getRoleBasedPrimaryOwnersList(rmApprovalDtls.getProjectId(), List.of(primaryPMLookUpValueId));
			if(!CollectionUtils.isEmpty(primaryUserList)) {
				ccUsersList.addAll(primaryUserList.stream().map(PrimaryUsersDto::getUserId).collect(Collectors.toList()));
				projectName = primaryUserList.get(0).getProjectName();
				projectCode = primaryUserList.get(0).getProjectCode();
				customerName = primaryUserList.get(0).getCustomerCode();
				ccUsersList.add(rmApprovalDtls.getUserId());
			}
		}
		ccUsersList.removeAll(toUsersList);
		ccUsersList = ccUsersList.stream().distinct().collect(Collectors.toList());
		String projNameWithCode=projectName+"("+projectCode+")";
		
		
		//building userDtlsMap
		userDtlsMap.put(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY, projNameWithCode);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY, customerName);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_TO_USERS, toUsersList);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_CC_USERS, ccUsersList);
		userDtlsMap.put(ResourceManagementConstant.EMAIL_To_USER_NAME, staffName);
		
		
		
		log.info("Just before leaving SendMailUtility.createUserDetailsMapForAssociateFinalConfirmationMail method:");
		return userDtlsMap;
	}
	
	//overloaded function (roleName) 
	public MailDetail createMailDetailObject(MailTemplateDto mailTemplateDtls, Map<String, Object> projectDtlsMap,
			String staffName, RMApprovalInputDto rmApprovalDtls) throws ResourceManagementException {
		log.info("Entered into overloaded SendMailUtility.createMailDetailObject method:");
		MailDetail mailDetailObj = new MailDetail();
		mailDetailObj.setMailSubject((mailTemplateDtls.getSubject() != null) ? mailTemplateDtls.getSubject() : null);
		String msgHeader = (mailTemplateDtls.getMessageBodyHeader() != null)
				? mailTemplateDtls.getMessageBodyHeader().replace(ResourceManagementConstant.EMAIL_ASSOCIATE_NAME_KEY,
						staffName)
				: null;
		String msgContent = (mailTemplateDtls.getMessageBodyContent() != null)
				? mailTemplateDtls.getMessageBodyContent()
						.replace(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY,
								projectDtlsMap.get(ResourceManagementConstant.EMAIL_PROJECT_NAME_KEY).toString())
						.replace(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY,
								projectDtlsMap.get(ResourceManagementConstant.EMAIL_CUSTOMER_NAME_KEY).toString())
				: null;		
						
		String msgFooter = (mailTemplateDtls.getMessageBodyFooter() != null) ? mailTemplateDtls.getMessageBodyFooter()
								: null;
		mailDetailObj.setMailBody(msgHeader + msgContent  + msgFooter);

		log.info("Just before leaving overloaded SendMailUtility.createMailDetailObject method:");

		return mailDetailObj;
	}
	//ended
	
}