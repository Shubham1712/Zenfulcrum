package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class TransferResourceListDto implements Serializable {

	private static final long serialVersionUID = -6334086044387096538L;

	private Long requirementId;

	private String role;

	private Long roleId;

	private String location;

	private Long workLocationId;

	private String billingStatus;

	private String serviceName;

	private Integer serviceId;

	private List<Long> employeeIdList;

	private List<String> skills;

	private Long billingStatusId;

	private Double ftePercent;

	private Long sourceRequirementId;

	private List<RTResourceDto> rtResourceDtoList;
	
	//Added by Mrunal Marne for milestone selection while resource transfer
	private Long puchaseOrderId;
	
	private List<Long> poMilestoneIdList;
	
	//Added by Mrunal Marne for start and end dates while resource transfer within same project
	private Date transferStartDate;
	
	private Date transferEndDate;
	
	private Long billableStatusReasonId;

}
