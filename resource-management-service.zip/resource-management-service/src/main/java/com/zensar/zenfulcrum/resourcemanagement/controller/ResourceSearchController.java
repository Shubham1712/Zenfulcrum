package com.zensar.zenfulcrum.resourcemanagement.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateSearchDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PracticeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceSearchDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RoleDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SupervisorDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceSearchService;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementUtil;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Api(tags = "ResourceSearchController")
@RestController
@Slf4j
@Validated
@RequestMapping(path = "resourcesearch")
public class ResourceSearchController {

	@Autowired
	private ResourceSearchService resourceSearchService;
	
	/**get associate list by project
	 * @param project id
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path = "/resourcedetailsbyproject")   
	public ResponseEntity<RMResponseDto> getAssociateListByProjectId(@Valid @RequestParam(name = "projectId") long projectId,
			@Valid @RequestParam(name = "loggedInRoleId") Long loggedInRoleId, @Valid @RequestParam(name = "loggedInUserId") Long loggedInUserId) throws ResourceManagementException {
		log.info("Start getAssociateListByProjectId - projectId::{}");
		RMResponseDto rmResponseDto = new RMResponseDto();
		ResourceSearchDto resourceSearchDto= resourceSearchService.getAssociateListByProjectId(projectId, loggedInRoleId, loggedInUserId);
		if (null!=resourceSearchDto) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, resourceSearchDto);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getAssociateListByProjectId");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	 
	/**get associate list by practice name
	 * @param practice name
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path = "/resourcedetailsbypractice")
	public ResponseEntity<RMResponseDto> getResourceDtlsListByPractice(@Valid @RequestParam(name = "practiceId") Long practiceId) throws ResourceManagementException {
		log.info("Start getResourceDtlsListByPractice");
		RMResponseDto rmResponseDto = new RMResponseDto();
		ResourceSearchDto resourceSearchDto= resourceSearchService.getResourceDtlsListByPractice(practiceId);
		if (null!=resourceSearchDto) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, resourceSearchDto);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getResourceDtlsListByPractice");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path="/skills")
	public ResponseEntity<RMResponseDto> getListOfSkills() throws ResourceManagementException{
		log.info("Start getListOfSkills");
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<SkillDto> skillDtoList= resourceSearchService.getListOfSkills();
		if (null!=skillDtoList) {
			List<Object> objectList = new ArrayList<>(skillDtoList);
			ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, objectList);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getListOfSkills");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	
	
	@GetMapping(path = "/roleList")
	public ResponseEntity<RMResponseDto> getRoleList() throws ResourceManagementException {
		log.info("Start getRoleList");
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<RoleDto> roleDto= resourceSearchService.getRoleList();
		if (null!=roleDto) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, roleDto);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getRoleList");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * @param skillName
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path = "/resourceDetailsBySkill")
	public ResponseEntity<RMResponseDto> getResourceDtlsListBySkill(@Valid @RequestParam("skillId") Long skillId) throws ResourceManagementException{
		log.info("Start getResourceDtlsListBySkill");
		RMResponseDto rmResponseDto = new RMResponseDto();
		ResourceSearchDto resourceListBySkill= resourceSearchService.getResourceDtlsListBySkill(skillId);
		if (null!=resourceListBySkill) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, resourceListBySkill);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getResourceDtlsListBySkill");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**get practice names list
	 * @param 
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path="/practicelist")
	public ResponseEntity<RMResponseDto> getPracticeList() throws ResourceManagementException{
		log.info("Start getPracticeList");
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<PracticeDto> practiceList= resourceSearchService.getPracticeList();
		if (!CollectionUtils.isEmpty(practiceList)) {
			List<Object> objectList = new ArrayList<>(practiceList);
			ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, objectList);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getPracticeList");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	@GetMapping(path = "/getresourceprojectdtlsbyassociateID")
	public ResponseEntity<RMResponseDto> getResourceProjectDtlsByAssociateID(@Valid @RequestParam(name = "employeeIdOrName") String employeeIdOrName,@Valid @RequestParam(name = "requestType") String requestType,
			@Valid @RequestParam(name = "loggedInRoleId") Long loggedInRoleId, @Valid @RequestParam(name = "loggedInUserId") Long loggedInUserId) throws ResourceManagementException {
		log.info("Start getResourceDtlsListByPracticeName");
		RMResponseDto rmResponseDto = new RMResponseDto();
		AssociateSearchDto associateDetails = resourceSearchService.getResourceProjectDtlsByAssociateID(employeeIdOrName,requestType, loggedInRoleId, loggedInUserId);
		if (null!=associateDetails) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, associateDetails);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getResourceDtlsListByPracticeName");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**get Supervisor names list by project id
	 * @param  project id
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path = "/supervisorlistbyprojectid")
	public ResponseEntity<RMResponseDto> getSupervisorList(@Valid @RequestParam(name = "projectId") long projectId) throws ResourceManagementException {
		log.info("Start getSupervisorList - projectId::{}");
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<SupervisorDto> supervisorList = resourceSearchService.getSupervisorList(projectId);
		if (!CollectionUtils.isEmpty(supervisorList)) {
			List<Object> objectList = new ArrayList<>(supervisorList);
			ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, objectList);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getSupervisorList");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * update/edit forSearch By Associate and Project.
	 * @param employeeDto
	 * @return 201 created
	 * @throws ResourceManagementException
	 * @throws ParseException 
	 */
	@PostMapping(path="/updateProjectDtlsForSearch", produces= MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<RMResponseDto> updateProjectDtlsForSearch(@Valid @RequestBody ResourceSearchDto resourceSearchDto) throws ResourceManagementException, ParseException {
		log.info("Entered into ResourceManagementController.updateProjectDtlsForSearch method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		resourceSearchService.updateProjectDtlsForSearch(resourceSearchDto);
		log.info("Just before leaving ResourceManagementController.updateProjectDtlsForSearch method:");
		return new ResponseEntity<>(rmResponseDto,	HttpStatus.CREATED);
	}
	
	/**
	 * @param searchKey
	 * @param searchValueId
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path="/searchdetails")
	public ResponseEntity<RMResponseDto> getResourceDetails(@Valid @RequestParam("searchKey") String searchKey,@Valid @RequestParam("searchValueId") long searchValueId,
			@Valid @RequestParam("loggedInRoleId") Long loggedInRoleId, @Valid @RequestParam("loggedInUserId") Long loggedInUserId) throws ResourceManagementException {
		log.info("Entered into ResourceSearchController.getSearchDetailsForResource method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		ResourceSearchDto searchDetailsForResource = resourceSearchService.getResourceDetails(searchKey,searchValueId, loggedInRoleId, loggedInUserId);
		
		if (null!=searchDetailsForResource) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, searchDetailsForResource);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("Just before leaving ResourceSearchController.getSearchDetailsForResource method:");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path="/searchlist")
	public ResponseEntity<RMResponseDto> getSearchList() throws ResourceManagementException {
		log.info("Entered into ResourceSearchController.getSearchParameters method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<LookupValueDto> lookupValueDtoForSearch = resourceSearchService.getSearchList();
		if (null!=lookupValueDtoForSearch) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, lookupValueDtoForSearch);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("Just before leaving ResourceSearchController.getSearchParameters method:");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * Submits the request for extension.
	 * @param 
	 * @return
	 * @throws ResourceManagementException
	 */
	@PostMapping(path = "/resaveforsearch", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RMResponseDto> saveResourcesForExtension(@Valid @RequestBody ResourceSearchDto resourceSearchDto)
			throws ResourceManagementException {
		log.info("Entered into ResourceTransferController.saveResourcesForExtension method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		resourceSearchService.saveResourcesForExtension(resourceSearchDto);	
		log.info("Just before leaving ResourceTransferController.saveResourcesForExtension method:");
		return new ResponseEntity<>(rmResponseDto,	HttpStatus.CREATED);
		
	}	
	
	/**
	 * Updates supervisor details of associates
	 * @param supervisorDto
	 * @return
	 * @throws ResourceManagementException
	 * Created by Shubham
	 */
	@PostMapping(path = "/updatesupervisor", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RMResponseDto> updateSupervisorDetails(@Valid @RequestBody SupervisorDto supervisorDto)
			throws ResourceManagementException {
		log.info("Entered into ResourceSearchController.updateSupervisorDetails method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		resourceSearchService.updateSupervisorDetails(supervisorDto);	
		log.info("Just before leaving ResourceSearchController.updateSupervisorDetails method:");
		return new ResponseEntity<>(rmResponseDto,	HttpStatus.CREATED);
		
	}
	
	@GetMapping(path = "/reservedresourcedetailsbyproject")   
	public ResponseEntity<RMResponseDto> getReservedAssociateListByProjectId(@Valid @RequestParam(name = "projectId") long projectId) throws ResourceManagementException {
		log.info("Start getAssociateListByProjectId - projectId::{}", projectId);
		RMResponseDto rmResponseDto = new RMResponseDto();
		ResourceSearchDto resourceSearchDto= resourceSearchService.getReservedAssociateListByProjectId(projectId);
		if (null!=resourceSearchDto) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, resourceSearchDto);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getAssociateListByProjectId");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
}
