package com.zensar.zenfulcrum.resourcemanagement.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name ="T_ASSOCIATE_ALLOCATION_BUDGET")
@Data
public class TAssociateAllocationBudget {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ASSOCIATE_ALLOCATION_BUDGET_ID")
	private Long associateAllocationBudgetId;
	
	@Column(name="BUDGET_ALLOCATION_MONTH")	
	private String budgetAllocationMonth;
	
	@Column(name="BUDGET_ALLOCATED_MONTH")	
	private String budgetAllocatedMonth;
	
	@Column(name="MONTHLY_BUDGET")	
	private Double monthlyBudget;
	
	@Column(name="MONTHLY_AVAILABLE_BUDGET")	
	private Double monthlyAvailableBudget;
	
	@Column(name="MONTHLY_USED_BUDGET")	
	private Double monthlyUsedBudget;
	
	@Column(name="STATUS_ID")	
	private Long statusId;
	
	@Column(name="CREATED_BY")	
	private Long createdBy;
	
	@Column(name="LAST_UPDATED_BY")	
	private Long lastUpdatedBy;
	
	@Column(name="CREATED_DATE")	
	private Date createdDate;
	
	@Column(name="LAST_UPDATED_DATE")	
	private Date lastUpdatedDate;
	
	@Column(name="EFFECTIVE_START_DATE")	
	private Date effectiveStartDate;
	
	@Column(name="EFFECTIVE_END_DATE")	
	private Date effectiveEndDate;
	
	@ManyToOne
	@JoinColumn(name = "ASSOCIATE_ALLOCATION_ID")
	private TAssociateAllocation tAssociateAllocation;
}
