package com.zensar.zenfulcrum.resourcemanagement.controller;

import java.text.ParseException;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMErrorDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTWithinSamePhaseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceTransferService;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementUtil;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Api(tags = "ResourceTransferController")
@RestController
@Slf4j
@Validated
@RequestMapping(path = "transfermanagement/")
public class ResourceTransferController {

	@Autowired
	private ResourceTransferService resourceTransferService;

	/**
	 * Submits resource to transfer within project
	 * @param rtWithinSamePhaseDto
	 * @return
	 * @throws ResourceManagementException
	 * @throws ParseException 
	 */
	@PutMapping(path="/updateResTransferInSamePhase", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RMResponseDto> updateResTransferInSameProject(@Valid @RequestBody RTWithinSamePhaseDto rtWithinSamePhaseDto) throws ResourceManagementException, ParseException {
		log.info("Start updateResTransferInSamePhase");
		RMResponseDto rmResponseDto = new RMResponseDto();
		if(CollectionUtils.isNotEmpty(rtWithinSamePhaseDto.getRequirementList())) {
			resourceTransferService.updateResTransferInSameProject(rtWithinSamePhaseDto);
		} else {
			ResourceManagementUtil.createBadRequest(rmResponseDto, ResourceManagementConstant.PROVIDE_DATA,
					ResourceManagementConstant.VALUE_EMPTY);
			log.debug("Exiting saveResourceAllocations");
			return ResponseEntity.badRequest().body(rmResponseDto);
		}
		log.info("End updateResTransferInSamePhase");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.CREATED);
	}
	/**
	 * Submits the request for transfer withIn ODC and Project.
	 * @param RMApprovalInputDto
	 * @return
	 * @throws ResourceManagementException
	 * @throws ParseException 
	 */
	@PostMapping(path = "/rtsaveODCProjectBU", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RMResponseDto> saveRTWithinODCAndProjectAndBU(@Valid @RequestBody RMApprovalInputDto rtInputDto)
			throws ResourceManagementException, ParseException {
		log.info("Entered into ResourceTransferController.saveRTWithinODCAndProjectAndBU method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		if(null != rtInputDto) {
			resourceTransferService.saveRTWithinODCAndProjectAndBU(rtInputDto);	
		} else {
			ResourceManagementUtil.createBadRequest(rmResponseDto, ResourceManagementConstant.PROVIDE_DATA,
					ResourceManagementConstant.VALUE_EMPTY);
			log.info("End saveRTWithinODCAndProjectAndBU");
			return ResponseEntity.badRequest().body(rmResponseDto);
		}
				
		log.info("Just before leaving ResourceTransferController.saveRTWithinODCAndProjectAndBU method:");
		return new ResponseEntity<>(rmResponseDto,	HttpStatus.CREATED);
		
	}	
	/**
	 * Reject the request for transfer withIn ODC and Project.
	 * @param RMApprovalInputDto
	 * @return
	 * @throws ResourceManagementException
	 */
	@PostMapping(path = "/rtRejectODCProjectBU", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RMResponseDto> rejectRTWithinODCAndProjectAndBU(@Valid @RequestBody List<RMApprovalInputDto> rtInputDtoList)
			throws ResourceManagementException {
		log.info("Entered into ResourceTransferController.rejectRTWithinODCAndProjectAndBU method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		if(null != rtInputDtoList && !rtInputDtoList.isEmpty()) {
			resourceTransferService.rejectRTWithinODCAndProjectAndBU(rtInputDtoList);	
		} else {
			ResourceManagementUtil.createBadRequest(rmResponseDto, ResourceManagementConstant.PROVIDE_DATA,
					ResourceManagementConstant.VALUE_EMPTY);
			log.info("End rejectRTWithinODCAndProjectAndBU");
			return ResponseEntity.badRequest().body(rmResponseDto);
		}
				
		log.info("Just before leaving ResourceTransferController.rejectRTWithinODCAndProjectAndBU method:");
		return new ResponseEntity<>(rmResponseDto,	HttpStatus.OK);
		
	}	
	/**
	 * get allocated resource details for project.
	 * 
	 * @param transfertype
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path = "/allocatedresource")
	public ResponseEntity<RMResponseDto> getAllocatedResource(@Valid @RequestParam long projectId,
			@Valid @RequestParam String transferType) throws ResourceManagementException {
		log.info("Start getProjectList - projectId::{}", projectId);

		RMResponseDto rmResponseDto = new RMResponseDto();
		ResourceRequirementAndFteDto allocatedResourceAndProjectFte = resourceTransferService
				.getAllocatedResourceFTE(projectId, transferType);
		if (null != allocatedResourceAndProjectFte) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, allocatedResourceAndProjectFte);
		} else {
			log.info("Exit getgetResourceRequirementList method");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End allocatedResourceAndProjectFteList");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * get List of Project from same ODC.
	 * @param projectId
	 * @param userId
	 * @param roleId
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path = "/getprojectfromsameodc")
	public ResponseEntity<RMResponseDto> getProjectFromSameOdc(@Valid @RequestParam long projectId,
			@Valid @RequestParam long userId,@Valid @RequestParam long roleId) throws ResourceManagementException {
		log.info("Start getprojectfromsameodc - projectId::{}", projectId ," roleId :: {}",roleId,"ueseId ::{}",userId);

		RMResponseDto rmResponseDto = new RMResponseDto();
		List<ProjectDto> projectListWithinODC = resourceTransferService.getProjectfromSameOdc(userId,roleId,projectId);
		if (null != projectListWithinODC) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, projectListWithinODC);
		} else {
			log.info("Exit getprojectfromsameodc method");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getprojectfromsameodc");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * get allocated resource details for project.
	 * 
	 * @param transfertype
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path = "/getintransitprojectresource")
	public ResponseEntity<RMResponseDto> getResourceFromIntransitProject(@Valid @RequestParam long targetProjectId,@Valid @RequestParam String empIdOrName) throws ResourceManagementException {
		log.info("Start getProjec - projectId::{}", targetProjectId, " Employee Id - empId :: {}", empIdOrName);

		RMResponseDto rmResponseDto = new RMResponseDto();
		EmployeeDto allocatedEmployee = resourceTransferService.getResourceFromIntransitProject(targetProjectId, empIdOrName);
		if (null != allocatedEmployee) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, allocatedEmployee);
		} else {
			log.info("Exit getResourceFromIntransitProject method");
			RMErrorDto rmerrorDto = new RMErrorDto();
			rmerrorDto.setErrorMessage("Resource is in workflow");
			rmResponseDto.setError(rmerrorDto);
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getResourceFromIntransitProject");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * approve or rejects the RT request of respective workflow.
	 * @param RMApprovalInputDto List
	 * @return
	 * @throws ResourceManagementException
	 */
	@PostMapping(path ="/approveorrejectrtapproval", produces= MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE )
	public  ResponseEntity<RMResponseDto> approveOrRejectRTApproval(@Valid @RequestBody List<RMApprovalInputDto> rtApproveOrRejectDtls) throws ResourceManagementException {
		log.info("Entered into ResourceManagementController.approveOrRejectRTApproval method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		resourceTransferService.approveOrRejectRTApproval(rtApproveOrRejectDtls);			
		log.info("Just before leaving ResourceManagementController.approveOrRejectRTApproval method:");
		return new ResponseEntity<>(rmResponseDto,	HttpStatus.CREATED);
	}	
	

	
}
