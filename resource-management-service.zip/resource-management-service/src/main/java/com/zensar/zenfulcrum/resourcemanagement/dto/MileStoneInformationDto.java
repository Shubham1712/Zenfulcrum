package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;

import lombok.Data;
  
@Data 
public class MileStoneInformationDto {
	
	private Long purchaseOrderMileStoneId;
	private String mileStoneName;
	private Date mileStoneStartDate;
	private Date mileStoneEndDate;
	private Double estimatedEfforts;
	private Double remainingAmount;  
	private Double mileStoneAmount;
	private boolean deleteFlag;

}
