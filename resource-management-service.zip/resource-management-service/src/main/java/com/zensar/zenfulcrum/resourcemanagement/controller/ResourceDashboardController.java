package com.zensar.zenfulcrum.resourcemanagement.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceApprovalDashboardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TraceabilityDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceDashboardService;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementUtil;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Api(tags = "ResourceDashboardController")
@RestController
@Slf4j
@Validated
@RequestMapping(path = "resourcedashboard")
public class ResourceDashboardController {
	
	@Autowired
	private ResourceDashboardService resourceDashboardService;
	
	/**
	 * Fetch pending count of resources for Approval.
	 * @param userId
	 * @param roleId
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path="/resourcependingcount")
	public ResponseEntity<RMResponseDto> getResourcePendingCount(@Valid @RequestParam("userId") Long userId,@Valid @RequestParam("roleId") Long roleId) throws ResourceManagementException {
		log.info("Entered into ResourceDashboardController.getResourcePendingCount method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		
		ResourceApprovalDashboardDto resourceApprovalDashboardDto = resourceDashboardService.getResourcePendingCount(userId,roleId);
		
		if (null!=resourceApprovalDashboardDto) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, resourceApprovalDashboardDto);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("Just before leaving ResourceDashboardController.getResourcePendingCount method:");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * Get list of resources pending for approval/submission
	 * @param userId
	 * @param roleId
	 * @param requestType
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path="/approvalpendingresources")
	public ResponseEntity<RMResponseDto> getPendingResourceDetails(@Valid @RequestParam("userId") Long userId, @Valid @RequestParam("roleId") Long roleId) throws ResourceManagementException {
		log.info("Entered into ResourceDashboardController.getPendingResourceDetails method:");
		RMResponseDto rmResponseDto = new RMResponseDto();		
		ResourceApprovalDashboardDto resourceApprovalDashboardDto = resourceDashboardService.getPendingResourceDetails(userId, roleId);
		if (null != resourceApprovalDashboardDto) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, resourceApprovalDashboardDto);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("Just before leaving ResourceDashboardController.getPendingResourceDetails method:");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	
	
	/**
	 * @param userId
	 * @param roleId
	 * @param allocationId
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path="/traceability")
	public ResponseEntity<RMResponseDto> getRMPendingTraceability(@Valid @RequestParam("userId") Long userId,
			@Valid @RequestParam("roleId") Long roleId,@Valid @RequestParam("allocationId") Long allocationId,
			@Valid @RequestParam("requestType") String requestType) throws ResourceManagementException {
		log.info("Entered into ResourceDashboardController.getRMPendingTraceability method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		
		TraceabilityDto traceabilityDto = resourceDashboardService.getRMPendingTraceability(userId,roleId,allocationId,requestType);
		if (null!=traceabilityDto) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, traceabilityDto);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("Just before leaving ResourceDashboardController.getRMPendingTraceability method:");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * Get list of resources pending for approval/pending with others
	 * @param userId
	 * @param roleId
	 * @param requestType
	 * @return
	 * @throws ResourceManagementException
	 */
	//Added by Mrunal Marne for performance issue on dashboard
	@GetMapping(path="/resourcespendingforapprovalandothers")
	public ResponseEntity<RMResponseDto> getPendingForApprovalAndOthersResourceDetails(@Valid @RequestParam("userId") Long userId, @Valid @RequestParam("roleId") Long roleId) throws ResourceManagementException {
		log.info("Entered into ResourceDashboardController.getPendingResourceDetails method:");
		RMResponseDto rmResponseDto = new RMResponseDto();		
		ResourceApprovalDashboardDto resourceApprovalDashboardDto = resourceDashboardService.getPendingForApprovalAndOthersResourceDetails(userId, roleId);
		if (null != resourceApprovalDashboardDto) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, resourceApprovalDashboardDto);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("Just before leaving ResourceDashboardController.getPendingResourceDetails method:");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * Get list of resources pending for submission
	 * @param userId
	 * @param roleId
	 * @param requestType
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path="/resourcespendingforsubmission")
	public ResponseEntity<RMResponseDto> getPendingForSubmissionResourceDetails(@Valid @RequestParam("userId") Long userId, @Valid @RequestParam("roleId") Long roleId) throws ResourceManagementException {
		log.info("Entered into ResourceDashboardController.getPendingResourceDetails method:");
		RMResponseDto rmResponseDto = new RMResponseDto();		
		ResourceApprovalDashboardDto resourceApprovalDashboardDto = resourceDashboardService.getPendingForSubmissionResourceDetails(userId, roleId);
		if (null != resourceApprovalDashboardDto) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, resourceApprovalDashboardDto);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("Just before leaving ResourceDashboardController.getPendingResourceDetails method:");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	//End by Mrunal
}
