package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class EmployeeDetailsDTO {

	private Long projectId;
    private Long employeeId;
    private Long employeeNumber;
    private String firstName;
    private String middleName;
    private String lastName;
    private String employeeName;
    private String grade;
    private Long businessUnitId;
    private Long statusId;
    private Long payrollId;
    private String hiringSbu;
    private String payroll;
    private String projectManager;
    private String programManager;	
}
