package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class ProjectDto implements Comparable<ProjectDto> {

	private long projectId;
	private String projectName;
	private Long executionLocationId;
	private Long projectBillableTypeId;
	private String projectCode;
	private Long projectServiceTypeId;
	private boolean isIntransitproject;

	private Long projectEngId;

	private Long costCenterId;

	private Boolean allocationRequiredFlag;

	private Long executionCityId;

	private Long projectBillingHr;

	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	private Date estStartDate;

	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	private Date estEndDate;

	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="en_GB")
	private Date actualStartDate;

	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="en_GB")
	private Date actualEndDate;

	private Double totalFte;

	private Long statusId;

	private Long createdBy;

	private Long lastUpdatedBy;

	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	private Date createdDate;

	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	private Date lastUpdatedDate;

	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	private Date effectiveStartDate;

	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	private Date effectiveEndDate;

	private Double grossMargin;

	private Long projectStatusId;
	
	//Added by Mrunal Marne for milestone selection while resource allocation
	private String projectBillableTypeDesc;
	private String projectCommercialTypeDesc;
	

	//Added by dipannita for opportunity
	private String opportunityId;

	@Override
	public int compareTo(ProjectDto pd) {
		return this.projectName.compareTo(pd.projectName);
	}
}
