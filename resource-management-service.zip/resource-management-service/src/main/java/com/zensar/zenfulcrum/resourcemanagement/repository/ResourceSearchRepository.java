package com.zensar.zenfulcrum.resourcemanagement.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface ResourceSearchRepository {

}
