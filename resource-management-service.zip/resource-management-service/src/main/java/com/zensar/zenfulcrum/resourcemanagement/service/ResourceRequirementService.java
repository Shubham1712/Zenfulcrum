package com.zensar.zenfulcrum.resourcemanagement.service;

import java.util.List;

import javax.validation.Valid;

import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

public interface ResourceRequirementService {


    public ResourceRequirementAndFteDto getRRforAllocation(long projectId) throws ResourceManagementException;

    public List<ResourceRequirementDto> getRRforDeallocation(long projectId) throws ResourceManagementException;

    public ResourceRequirementAndFteDto getRRforTransfer(long projectId) throws ResourceManagementException;

	public ResourceRequirementAndFteDto getMargins(@Valid long projectId) throws ResourceManagementException;


}
