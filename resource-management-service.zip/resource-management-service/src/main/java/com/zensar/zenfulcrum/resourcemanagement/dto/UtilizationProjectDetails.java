package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;


import lombok.Data;
@Data
public class UtilizationProjectDetails {
	private String projectCode;
	private String projectName;
	private Long projectId;
	private Double projectUtilization;
	private Long billableStatusId;
	private String billability;
	private Date actualAllocationStartDate;
	private Date actualAllocationEndDate;
	private Date actualReleaseDate;
	private Date estAllocationEndDate;
	private Long workLocationId;
	private String location;
	private Long vbuId;
	private String vbu;
	private Long projectManagerId;
	private String projectManager;
	private Long associateAllocationId;
	
	private String workLocationName;
}
