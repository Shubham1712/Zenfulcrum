package com.zensar.zenfulcrum.resourcemanagement.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateProject;

@Mapper(componentModel = "spring")
@Component
public interface TAssociateProjectMapper {

	TAssociateProject tAssociateProjectDtoToTAssociateProject(TAssociateProjectDto valueDto);

	TAssociateProjectDto tAssociateProjectToTAssociateProjectDto(TAssociateProject value);

	List<TAssociateProject> tAssociateProjectDtoToTAssociateProject(List<TAssociateProjectDto> valueDto);

	List<TAssociateProjectDto> tAssociateProjectToTAssociateProjectDto(List<TAssociateProject> value);
	
}


