package com.zensar.zenfulcrum.resourcemanagement.rest.client;

import static java.util.Optional.ofNullable;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.zensar.zenfulcrum.resourcemanagement.dto.AllocationTypeStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CountryDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDetailsDTO;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LeaveDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueAndDescDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueNewDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.MLocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PracticeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PracticeProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PractiseDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBuDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApproversDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ReasonForDeallocation;
import com.zensar.zenfulcrum.resourcemanagement.dto.ReportLookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RoleDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ServiceLineDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SuperVisiorDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UserDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UtilizationDetailDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UtilizationProjectDetails;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.projection.MModuleProjection;
import com.zensar.zenfulcrum.resourcemanagement.util.HttpRequestUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AdminServiceClient {

	@Value("${RM.APPROVERS.LIST.REST.URL}")
	private String getRMApproversListRestURL;

	@Value("${RM.TRANSFER.APPROVERS.LIST.REST.URL}")
	private String getRMTransferApproversList;

	@Value("${ADMIN.SERVICE.URL}")
	private String adminBaseUrl;

	@Value("${EARMARKED.ASSOCIATES.REST.URL}")
	private String getEarmarkedAssociatesRestURL;

	@Value("${MODULE.STATUS.REST.URL}")
	private String getModuleStatusRestURL;

	@Value("${LOOKUP.VALUE.REST.URL}")
	private String getLookupValueRestURL;

	@Value("${ASSOCIATES.MAIL.REST.URL}")
	private String getEmailAddressURL;

	@Value("${REASONFORDEALLOCATION.REST.URL}")
	private String reasonForDeAllocationURL;

	@Value("${MODULE.REST.URL}")
	private String getModuleDetailsURL;

	@Value("${PRACTISEDETAILS.REST.URL}")
	private String getPractiseDetailsURL;

	@Value("${RESOURCEDTLBYPRACTICENAME.REST.URL}")
	private String getResourceDtlsListByPracticeName;

	@Value("${ALLOCATION.TYPE.STATUS.REST.URL}")
	private String getAllocationTypeStatus;

	@Value("${EMPLOYEEDETAILS.REST.URL}")
	private String getEmployeeDetailsURL;

	@Value("${SKILLLIST.REST.URL}")
	private String getListOfSkillsURL;

	@Value("${ROLELIST.REST.URL}")
	private String getListOfRolesURL;

	@Value("${RESOURCEDTLBYROLENAME.REST.URL}")
	private String getResourceDtlsListByRoleName;

	@Value("${RESOURCE.LISTBYSKILL.REST.URL}")
	private String getResourceDtlsListBySkill;

	@Value("${PRACTICELIST.REST.URL}")
	private String getListOfPracticeURL;

	@Value("${LOOKUP.ID.REST.URL}")
	private String getLookupByIdRestURL;

	@Value("${RESOURCE.PRACTICE.ALLOC.REST.URL}")
	private String getResourcePracticeAllocURL;

	@Value("${RESOURCE.PRACTICE.PROJECT.REST.URL}")
	private String getPracticeProjectURL;

	@Value("${SUPERVISIORLIST.REST.URL}")
	private String getSuperVisiorList;

	@Value("${LEAVEDETAILS.REST.URL}")
	private String leaveDetailsURL;

	@Value("${EMPIDSBYPRACTICENAME.REST.URL}")
	private String getEmpIdsByPractice;

	@Value("${ASSOCIATES.NAME.REST.URL}")
	private String getAssociateNames;

	@Value("${MODULE.STATUS.LIST.REST.URL}")
	private String getModuleStatusListRestURL;

	@Value("${MODULE.STATUS.BYNAME.REST.URL}")
	private String getModuleStatusByNameURL;

	@Value("${LOOKUPVALUE.LIST.REST.URL}")
	private String getListOfLookupValueURL;

	@Value("${RESOURCE.COUNTRY.REST.URL}")
	private String getCountryForResourceURL;

	@Value("${ROLEID.REST.URL}")
	private String getRoleId;

	@Value("${MODULE.LIST.REST.URL}")
	private String getModuleDetailsListURL;

	@Value("${ALLMODULE.LIST.REST.URL}")
	private String getAllModuleDetailsListURL;

	@Value("${ADMINPROJECTDEFINATION.SERVICE.BASE.URL}")
	private String getAdminPDBaseRestUrl;

	@Value("${SKILLFAMILY.BY.SKILLID.RESTURL}")
	private String getSkillFamilyBySkillId;

	@Value("${COSTCARD.RESTURL}")
	private String getCostCardRestUrl;

	@Value("${PROJECT.BILLID.REST.URL}")
	private String getProjectBillableIdURL;

	@Value("${COUNTRY.BY.LOCATIONID.REST.URL}")
	private String getCountryByLocationIdURL;

	@Value("${PROJECT.BY.PROJECTID.REST.URL}")
	private String getProjectByProjectIdURL;

	@Value("${RMADMIN.SERVICE.BASE.URL}")
	private String getRMAdminRestUrl;

	@Value("${PROJECTDEFINATION.SERVICE.URL}")
	private String projectDefinationBasetUrl;

	@Value("${LOOKUP.DESCRIPTION.REST.URL}")
	private String looUpDescriptionRestUrl;

	@Value("${PROJECT.ORG.DETAILS}")
	private String getProjectOrgDetails;

	@Value("${EMPLOYEE.BY.EMPID.URL}")
	private String getEmployeeDetailsByEmpIdURL;

	@Value("${CITY.COUNTRY.URL}")
	private String getCityCountryURL;

	@Value("${UTILIZATION.DLTS.REST.URL}")
	private String getUtilizationDetails;

	@Value("${RMADMIN.SERVICE.BASE.URL}")
	private String rmAdmingBaseUrl;

	@Value("${RMADMIN.SERVICE.BASE.REPORT.URL}")
	private String adminBaseURL;
	@Value("${RMADMIN.SERVICE.BASE.REPORT.LOOKUP.URL}")
	private String adminBaseLookUpDetails;

	@Value("${PROJECT.BUDGET.REST.URL}")
	private String getProjectBudgetStatus;

	@Value("${MODULE.STATUS.BY.ACTION}")
	private String getModuleStatusByAction;

	@Value("${LOOKUP.VALUE.BY.TYPEANDDESCR.REST.URL}")
	private String getLookUpbyTypeAndDescrUrl;

	@Value("${PRIMARY.PROJECT.OWNERS.BYPROJECTIDLIST.REST.URL}")
	private String getPrimaryOwnerUserIdListByProjectId;

	@Value("${ASSOCIATEBYEMPIDLIST.REST.URL}")
	private String associateByEmpIdRestUrl;

	@Value("${LVALUE.BY.TYPE.AND.DESCLIST.REST.URL}")
	private String getLookuIdByTypeAndDescrListUrl;

	@Value("${BU.REST.URL}")
	private String getBuForProjectRestUrl;

	@Value("${LVALUE.DATA.REST.URL}")
	private String getLookUpValueDetailsByIds;

	@Value("${ALL.EMPLOYEE.DETAILS.URL}")
	private String getAllEmployeeDetailsUrl;

	@Value("${SERVICE.LINE.REST.URL}")
	private String getServiceLineListRestURL;

	@Value("${LOOKUP.VALUE.BY.DESC.REST.URL}")
	private String getLookupValueListByLookupDesc;
	
	@Value("${RM.SUPERVISORS.LIST.REST.URL}")
	private String getRMSupervisorsListRestURL;
	
	@Value("${ADMIN.SERVICE.REPORT.URL}")
    private String adminReportBaseURL;
   
    @Value("${ADMIN.REPORT.EMP.ID.REST.URL}")
    private String getEmployeeDetailsByEmployeeNumber;
    
    @Value("${OWNER.ENTITY.COUNT}")
    private String getOwnerCount;
    
   //Dev by Ravi
    @Value("${GETLOCATION.REST.URL}")
    private String getLocationByLocationIdURL;
    
    //by Srinivvasulu
    @Value("${EMPLOYEE.NUMBER.REST.URL}")
    private String getEmployeeNumberURL;
    
    @Value("${CURRENCYIDBYNAME.SERVICE.URL}")
	private String getCurrencyIdByNameRestURL;
    
    @Value("${RM.APPROVERS.LIST.FOR.REJECTION.REST.URL}")
	private String getRMApproversListForRejectionRestURL;

    //Added by devAk
    @Value("${SASTAFFCHACK.REST.URL}")
  	private String saEmployeeCheckRestURL;
    
	// ADMINPROJECTDEFINATION.SERVICE.BASE.URL=http://ADMIN-SERVICE/admin-service/projectdefinition/
	// SKILLFAMILY.BY.ASSOCIATEID.RESTURL=skillfamily?skillIdList={0}
	@Autowired
	private RestTemplate restTemplate;

	// sandeep working
	public List<RMApproversDto> getRMApproversList(List<Long> roleId, List<Long> userId)
			throws ResourceManagementException {
		log.info("Entered into AdminServiceClient.getRMApproversList method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());

		String url = getRMAdminRestUrl + MessageFormat.format(getRMApproversListRestURL, StringUtils.join(roleId, ","),
				StringUtils.join(userId, ","));
		List<RMApproversDto> rmApproversListObj = null;
		try {
			ResponseEntity<List<RMApproversDto>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntityObj, new ParameterizedTypeReference<List<RMApproversDto>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<RMApproversDto>> rmApproversOptnlObj = ofNullable(responseEntityObj.getBody());
				if (rmApproversOptnlObj.isPresent()) {
					rmApproversListObj = rmApproversOptnlObj.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getRMApproversList|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getRMApproversList|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.getRMApproversList method:");
		return rmApproversListObj;
	}
	
	public List<RMApproversDto> getRMApproversListForRejection(List<Long> roleId, Long projectId)
			throws ResourceManagementException {
		log.info("Entered into AdminServiceClient.getRMApproversListForRejection method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());

		String url = getRMAdminRestUrl + MessageFormat.format(getRMApproversListForRejectionRestURL, StringUtils.join(roleId, ","), String.valueOf(projectId));
		List<RMApproversDto> rmApproversListObj = null;
		try {
			ResponseEntity<List<RMApproversDto>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntityObj, new ParameterizedTypeReference<List<RMApproversDto>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<RMApproversDto>> rmApproversOptnlObj = ofNullable(responseEntityObj.getBody());
				if (rmApproversOptnlObj.isPresent()) {
					rmApproversListObj = rmApproversOptnlObj.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getRMApproversList|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getRMApproversList|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.getRMApproversListForRejection method:");
		return rmApproversListObj;
	}

	// sandeep not called
	public List<UserDto> getEmailRMApproversList(long projectId, long roleId) throws ResourceManagementException {
		log.info("Entered into AdminServiceClient.getEmailRMApproversList method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String proId = Long.toString(projectId);
		String url = getRMAdminRestUrl + MessageFormat.format(getRMTransferApproversList, proId, roleId);
		List<UserDto> rmtApproversListObj = null;
		try {
			ResponseEntity<List<UserDto>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntityObj, new ParameterizedTypeReference<List<UserDto>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<UserDto>> rmtApproversOptnlObj = ofNullable(responseEntityObj.getBody());
				if (rmtApproversOptnlObj.isPresent()) {
					rmtApproversListObj = rmtApproversOptnlObj.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getEmailRMApproversList|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getEmailRMApproversList|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.getEmailRMApproversList method:");
		return rmtApproversListObj;
	}

	/**
	 * get associates details.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	// akshay working
	public List<EmployeeDto> getAssociatesDetails(List<Long> empIds) throws ResourceManagementException {
		log.info("Start getAssociatesDetails - projectId::{}", empIds);
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String employees = StringUtils.join(empIds, ",");
		String url = getRMAdminRestUrl + MessageFormat.format(getEarmarkedAssociatesRestURL, employees);
		List<EmployeeDto> associates = getAssociateListCommonMethod(requestEntity, url);
		return associates;
	}

	public List<EmployeeDto> getAssociatesDetailsbyEmpIds(List<Long> empIds) throws ResourceManagementException {
		log.info("Start getAssociatesDetails - projectId::{}", empIds);
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String employees = StringUtils.join(empIds, ",");
		String url = getRMAdminRestUrl + MessageFormat.format(associateByEmpIdRestUrl, employees);
		List<EmployeeDto> associates = getAssociateListCommonMethod(requestEntity, url);
		return associates;
	}

	private List<EmployeeDto> getAssociateListCommonMethod(HttpEntity<String> requestEntity, String url)
			throws ResourceManagementException {
		return setAssociateObject(requestEntity, url);
	}

	/**
	 * get Module status details.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	// sandeep working
	public ModuleStatusDto getModuleStatus(String parentModule, String subModule, String action)
			throws ResourceManagementException {
		log.info("Start getModuleStatus - parentModule::{}", parentModule);
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl + MessageFormat.format(getModuleStatusRestURL, parentModule, subModule, action);
		ModuleStatusDto moduleStatusDto = null;
		try {
			ResponseEntity<ModuleStatusDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					ModuleStatusDto.class);
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<ModuleStatusDto> moduleStatus = ofNullable(response.getBody());
				if (moduleStatus.isPresent()) {
					moduleStatusDto = moduleStatus.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getModuleStatus|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getModuleStatus|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Start getModuleStatus");
		return moduleStatusDto;
	}

	/**
	 * get looup value details.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	// working harshal
	public LookupValueDto getLookupValue(String lookUpType, String lookUpValueCode) throws ResourceManagementException {
		log.info("Start getLookupValue - lookUpType::{}", lookUpType);
		String url = getRMAdminRestUrl + MessageFormat.format(getLookupValueRestURL, lookUpType, lookUpValueCode);
		log.info("End getLookupValue");
		return getLookupValueDto(url);
	}

	/**
	 * get associates email address.
	 * 
	 * @param list of empIds
	 * @return list of EmailIds
	 * @throws ResourceManagementException
	 */
	// working sandeep
	public List<String> getAssociatesEmailAddress(List<Long> empIds) throws ResourceManagementException {
		log.info("Start getAssociatesEmailAddress - EmployeeIDs::{}", empIds);
		String employees = StringUtils.join(empIds, ",");
		String url = getRMAdminRestUrl + MessageFormat.format(getEmailAddressURL, employees);
		return getEmployeeDetails(url);
	}

	// not called
	public List<String> getAssociatesNames(List<Long> empIds) throws ResourceManagementException {
		log.info("Start getAssociatesEmailAddress - EmployeeIDs::{}", empIds);
		String employees = StringUtils.join(empIds, ",");
		String url = getRMAdminRestUrl + MessageFormat.format(getAssociateNames, employees);
		return getEmployeeDetails(url);
	}

	// working sandeep
	public List<String> getEmployeeDetails(String url) throws ResourceManagementException {
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		List<String> associates = null;
		try {
			ResponseEntity<List<String>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<String>>() {
					});

			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<String>> mailList = ofNullable(response.getBody());
				if (mailList.isPresent()) {
					associates = mailList.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getEmployeeDetails|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getEmployeeDetails|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getAssociatesEmailAddress- EmployeeEmailIDs::{}", associates);
		return associates;
	}

	/**
	 * get Reasons For Deallocation.
	 * 
	 * @return
	 * @throws ResourceManagementException
	 */
	// working akshay
	public List<ReasonForDeallocation> getReasonForDeallocation() throws ResourceManagementException {
		log.info("Start getReasons for Deallocation");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl + reasonForDeAllocationURL;
		List<ReasonForDeallocation> reasons = null;
		try {
			ResponseEntity<List<ReasonForDeallocation>> response = restTemplate.exchange(url, HttpMethod.GET,
					requestEntity, new ParameterizedTypeReference<List<ReasonForDeallocation>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<ReasonForDeallocation>> reasonList = ofNullable(response.getBody());
				if (reasonList.isPresent()) {
					reasons = reasonList.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getReasonForDeallocation|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getReasonForDeallocation|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("END reasonsforDeallocation");
		return reasons;
	}

	/**
	 * get Module details to get the workflowTypeId.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	// working
	public ModuleStatusDto getModuleDetails(String parentModule, String subModule) throws ResourceManagementException {
		log.info("Entered into AdminServiceClient.getModuleDetails method:");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl + MessageFormat.format(getModuleDetailsURL, parentModule, subModule);
		ModuleStatusDto moduleDtlsDto = null;
		try {
			ResponseEntity<ModuleStatusDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					ModuleStatusDto.class);
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<ModuleStatusDto> moduleDtlsDtoOptnObj = ofNullable(response.getBody());
				if (moduleDtlsDtoOptnObj.isPresent()) {
					moduleDtlsDto = moduleDtlsDtoOptnObj.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getModuleStatus|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getModuleStatus|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.getModuleDetails method:");
		return moduleDtlsDto;
	}

// this method
	/**
	 * Get Employee Practise Details from ADMINService
	 * 
	 * @param employeeId
	 * @return
	 * @throws ResourceManagementException
	 */
	// working akshay
	public EmployeeDto getEmployeeDetails(long employeeId) throws ResourceManagementException {
		log.info("Start getPractiseDetails");
		String url = getRMAdminRestUrl + MessageFormat.format(getPractiseDetailsURL, String.valueOf(employeeId));
		return getPractiseDetails(url);
	}

	/**
	 * get associates details by practice Name.
	 * 
	 * @param practiceName
	 * @return List of EmployeeDto
	 * @throws ResourceManagementException
	 */
	// working
	public List<EmployeeDto> getResourceDtlsListByPractice(Long practiceId) throws ResourceManagementException {
		log.info("Start getResourceDtlsListByPracticeName ");
		String url = getRMAdminRestUrl + MessageFormat.format(getResourceDtlsListByPracticeName, practiceId);

		List<EmployeeDto> employeeList = getEmployeeDtoClient(url);

		log.info("End getResourceDtlsListByPracticeName");
		return employeeList;
	}

	/**
	 * Get Allocation Type Status Details from ADMINService
	 * 
	 * @param allocationTypeValue
	 * @return
	 * @throws ResourceManagementException
	 */
	// working
	public AllocationTypeStatusDto getAllocationTypeStatus(String allocationTypeValue)
			throws ResourceManagementException {

		log.info("Start getAllocationTypeStatus");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl + MessageFormat.format(getAllocationTypeStatus, allocationTypeValue);
		AllocationTypeStatusDto allocationTypeStatusDto = null;
		try {
			ResponseEntity<AllocationTypeStatusDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<AllocationTypeStatusDto>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<AllocationTypeStatusDto> allocationTyperesponse = ofNullable(response.getBody());
				if (allocationTyperesponse.isPresent()) {
					allocationTypeStatusDto = allocationTyperesponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getAllocationTypeStatus|url:{}|exception:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getAllocationTypeStatus|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}

		log.info("End getAllocationTypeStatus");
		return allocationTypeStatusDto;
	}

	/**
	 * Get Employee Employee Details from ADMINService
	 * 
	 * @param employeeName
	 * @return
	 * @throws ResourceManagementException
	 */
	// working
	public EmployeeDto getEmployeeByNameOrId(String employeeName) throws ResourceManagementException {

		log.info("Start getEmployeeByName");
		String url = null;
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		if (Pattern.matches("[0-9]+", employeeName)) {
			long empid = Long.parseLong(employeeName);
			url = getRMAdminRestUrl + MessageFormat.format(getPractiseDetailsURL, String.valueOf(empid));
		} else {
			url = getRMAdminRestUrl + MessageFormat.format(getEmployeeDetailsURL, employeeName);
		}

		EmployeeDto associates = null;
		try {
			ResponseEntity<EmployeeDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<EmployeeDto>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<EmployeeDto> employeeList = ofNullable(response.getBody());
				if (employeeList.isPresent()) {
					associates = employeeList.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getAssociatesDetails|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getAssociatesDetails|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Start getAssociatesDetails");
		return associates;
	}

	// working
	public List<SkillDto> getListOfSkills() throws ResourceManagementException {
		log.info("Start getListOfSkills");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getAdminPDBaseRestUrl + getListOfSkillsURL;
		List<SkillDto> skillDto = null;

		try {
			ResponseEntity<List<SkillDto>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<SkillDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<SkillDto>> skillList = ofNullable(response.getBody());
				if (skillList.isPresent()) {
					skillDto = skillList.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getListOfSkills|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getListOfSkills|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}

		log.info("End getListOfSkills");
		return skillDto;
	}

	/**
	 * get associates details by practice Name.
	 * 
	 * @param practiceName
	 * @return List of EmployeeDto
	 * @throws ResourceManagementException
	 */
	// not called
	public List<EmployeeDto> getResourceDtlsListByRoleName(String roleName) throws ResourceManagementException {
		log.info("Start getResourceDtlsListByRoleName ");
		String url = getRMAdminRestUrl + MessageFormat.format(getResourceDtlsListByRoleName, roleName);

		List<EmployeeDto> employeeList = getEmployeeDtoClient(url);

		log.info("End getResourceDtlsListByRoleName");
		return employeeList;
	}

	/**
	 * get Role List.
	 * 
	 * @return List of RoleDto
	 * @throws ResourceManagementException
	 */
	// working
	public List<RoleDto> getListOfRoles() throws ResourceManagementException {
		log.info("Start getListOfRoles");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl + getListOfRolesURL;
		List<RoleDto> roleDto = null;

		try {
			ResponseEntity<List<RoleDto>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<RoleDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<RoleDto>> roleList = ofNullable(response.getBody());
				if (roleList.isPresent()) {
					roleDto = roleList.get();
				}
				roleDto.forEach(skill -> {
				});
			}
		} catch (ResourceAccessException rae) {
			log.error("getListOfRoles|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getListOfRoles|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}

		log.info("End getRoleList");
		return roleDto;
	}

	// not called
	public List<EmployeeDto> getResourceDtlsListBySkill(String skillName) throws ResourceManagementException {
		log.info("Start getResourceDtlsListBySkill ");

		String url = getRMAdminRestUrl + MessageFormat.format(getResourceDtlsListBySkill, skillName);

		List<EmployeeDto> employeeList = getEmployeeDtoClient(url);

		log.info("End getResourceDtlsListBySkill");
		return employeeList;
	}

	// WORKING
	public List<EmployeeDto> getEmployeeDtoClient(String url) throws ResourceManagementException {
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		List<EmployeeDto> employeeList = null;
		try {

			ResponseEntity<List<EmployeeDto>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<EmployeeDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<EmployeeDto>> employeeresponse = ofNullable(response.getBody());
				if (employeeresponse.isPresent()) {
					employeeList = employeeresponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getResourceDtlsListBySkill|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getResourceDtlsListBySkill|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		return employeeList;
	}

	/**
	 * get Practice List.
	 * 
	 * @return List of PracticeNames
	 * @throws ResourceManagementException
	 */
	// working
	public List<PracticeDto> getListOfPractice() throws ResourceManagementException {
		log.info("Start getListOfPracticeNames");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getAdminPDBaseRestUrl + getListOfPracticeURL;
		List<PracticeDto> practiceList = null;

		try {
			ResponseEntity<List<PracticeDto>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<PracticeDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<PracticeDto>> practice = ofNullable(response.getBody());
				if (practice.isPresent()) {
					practiceList = practice.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getListOfPracticeNames|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getListOfPracticeNames|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}

		log.info("End getListOfPracticeNames");
		return practiceList;
	}

	/**
	 * get lookup value details.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	// working
	public LookupValueDto getLookUpById(Long lookupValueId) throws ResourceManagementException {
		log.info("Start getLookUpById - lookUpType::{}", lookupValueId);
		String url = getRMAdminRestUrl + MessageFormat.format(getLookupByIdRestURL, lookupValueId.toString());
		log.info("End getLookUpById");

		return getLookupValueDto(url);
	}

	// working
	public LookupValueDto getLookupValueDto(String url) throws ResourceManagementException {
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		LookupValueDto lookupValueDto = null;
		try {
			ResponseEntity<LookupValueDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					LookupValueDto.class);
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<LookupValueDto> lookupValue = ofNullable(response.getBody());
				if (lookupValue.isPresent()) {
					lookupValueDto = lookupValue.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getLookUpById|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getLookUpById|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		return lookupValueDto;
	}

	// not needed replaced
	public PractiseDetailsDto getResourcePracticeAllocByEmpId(Long employeeId) throws ResourceManagementException {
		log.info("Start getResourcePracticeAllocByEmpId - resourcePractice::{}", employeeId);
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String empId = String.valueOf(employeeId);
		String url = getRMAdminRestUrl + MessageFormat.format(getResourcePracticeAllocURL, empId);
		PractiseDetailsDto practiceDetailDto = null;
		try {
			ResponseEntity<PractiseDetailsDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					PractiseDetailsDto.class);
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<PractiseDetailsDto> practiseDetail = ofNullable(response.getBody());
				if (practiseDetail.isPresent()) {
					practiceDetailDto = practiseDetail.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getResourcePracticeAllocByEmpId|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getResourcePracticeAllocByEmpId|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getResourcePracticeAllocByEmpId");
		return practiceDetailDto;
	}

	// working
	public PracticeProjectDto getPracticeProject(long practiceId) throws ResourceManagementException {
		log.info("Start getResourcePracticeProject - resourcePractice::{}", practiceId);
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl + MessageFormat.format(getPracticeProjectURL, practiceId);
		PracticeProjectDto practiceProjectDto = null;
		try {
			ResponseEntity<PracticeProjectDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					PracticeProjectDto.class);
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<PracticeProjectDto> practiceProject = ofNullable(response.getBody());
				if (practiceProject.isPresent()) {
					practiceProjectDto = practiceProject.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getResourcePracticeProject|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getResourcePracticeProject|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getResourcePracticeProject");
		return practiceProjectDto;
	}

	// working
	public List<SuperVisiorDetailsDto> getSuperVisiorList(List<Long> empIds) throws ResourceManagementException {

		log.info("Start getResourceRequirementList");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String employeeIds = StringUtils.join(empIds, ",");
		String url = getRMAdminRestUrl + MessageFormat.format(getSuperVisiorList, employeeIds);
		List<SuperVisiorDetailsDto> supervisiorList = null;
		try {
			ResponseEntity<List<SuperVisiorDetailsDto>> response = restTemplate.exchange(url, HttpMethod.GET,
					requestEntity, new ParameterizedTypeReference<List<SuperVisiorDetailsDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<SuperVisiorDetailsDto>> projectDtoResponse = ofNullable(response.getBody());
				if (projectDtoResponse.isPresent()) {
					supervisiorList = projectDtoResponse.get();
				}
			}
		} catch (Exception e) {
			log.error("geList|url:{}|exception:{}", url, e);
			throw new ResourceManagementException(e);
		}
		log.info("End getProjectList");
		return supervisiorList;

	}

	// working
	public LeaveDetailsDto getLeaveDetails(Long empIds) throws ResourceManagementException {

		log.info("Start LeaveDetails");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl + MessageFormat.format(leaveDetailsURL, String.valueOf(empIds));

		LeaveDetailsDto leaveDetails = null;
		try {
			ResponseEntity<LeaveDetailsDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<LeaveDetailsDto>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<LeaveDetailsDto> leaveDtoResponse = ofNullable(response.getBody());
				if (leaveDtoResponse.isPresent()) {
					leaveDetails = leaveDtoResponse.get();
				}
			}
		} catch (Exception e) {
			log.error("geList|url:{}|exception:{}", url, e);
			throw new ResourceManagementException(e);
		}
		log.info("End leaveDetails");
		return leaveDetails;

	}

	/**
	 * get lookup value details.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	// working
	public LookupValueDto getLookUpById(Integer lookupValueId) throws ResourceManagementException {
		log.info("Start getLookUpById - lookUpType::{}", lookupValueId);

		String url = getRMAdminRestUrl + MessageFormat.format(getLookupByIdRestURL, lookupValueId);

		log.info("End getLookUpById");
		return getLookupValueDto(url);
	}

	// working
	public EmployeeDto getPractiseDetails(String url) throws ResourceManagementException {
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		EmployeeDto employee = null;
		try {
			ResponseEntity<EmployeeDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<EmployeeDto>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<EmployeeDto> employeeresponse = ofNullable(response.getBody());
				if (employeeresponse.isPresent()) {
					employee = employeeresponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getEmployeeByName|url:{}|exception:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getEmployeeByName|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}

		log.info("End getEmployeeByName");
		return employee;

	}

	// not called
	public List<Long> getEmpIdListByPracticeName(String practiceName) throws ResourceManagementException {
		log.info("Start getEmpIdListByPracticeName ");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl + MessageFormat.format(getEmpIdsByPractice, practiceName);
		List<Long> associates = null;
		try {
			ResponseEntity<List<Long>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<Long>>() {
					});

			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<Long>> empId = ofNullable(response.getBody());
				if (empId.isPresent()) {
					associates = empId.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getEmpIdListByPracticeName|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getEmpIdListByPracticeName|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getEmpIdListByPracticeName- EmployeeEmailIDs::{}", associates);
		return associates;
	}

	/**
	 * get Module status List details.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	// working
	public List<ModuleStatusDto> getModuleStatusList(String parentModule, List<String> subModuleList,
			List<String> actionList) throws ResourceManagementException {
		log.info("Entered into AdminServiceClient.getModuleStatusList method:");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl + MessageFormat.format(getModuleStatusListRestURL, parentModule,
				String.join(",", subModuleList), String.join(",", actionList));
		List<ModuleStatusDto> moduleStatusDtoList = null;
		try {
			ResponseEntity<List<ModuleStatusDto>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<ModuleStatusDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<ModuleStatusDto>> moduleStatus = ofNullable(response.getBody());
				if (moduleStatus.isPresent()) {
					moduleStatusDtoList = moduleStatus.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getModuleStatusList|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getModuleStatusList|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.getModuleStatusList method:");
		return moduleStatusDtoList;
	}

	// working
	public List<LookupValueDto> getLookupValueByLookupType(String lookupType) throws ResourceManagementException {
		log.info("Start getLookupValueByLookupType");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl + MessageFormat.format(getListOfLookupValueURL, lookupType);
		List<LookupValueDto> lookupValueDto = null;

		try {
			ResponseEntity<List<LookupValueDto>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<LookupValueDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<LookupValueDto>> LookupValueList = ofNullable(response.getBody());
				if (LookupValueList.isPresent()) {
					lookupValueDto = LookupValueList.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getLookupValueByLookupType|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getLookupValueByLookupType|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getLookupValueByLookupType");
		return lookupValueDto;
	}

	// not called
	public String getCountryForResource(Long empId) throws ResourceManagementException {
		log.info("Start getCountryForResource");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String employeeId = String.valueOf(empId);

		String url = getRMAdminRestUrl + MessageFormat.format(getCountryForResourceURL, employeeId);
		String countryName = null;

		try {
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<String>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<String> countryResponse = ofNullable(response.getBody());
				if (countryResponse.isPresent()) {
					countryName = countryResponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getCountryForResource|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getCountryForResource|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getCountryForResource");
		return countryName;

	}

	// WORKING
	public List<Long> getRoleIds(List<String> roleName) throws ResourceManagementException {
		log.info("Entered into AdminServiceClient.getRoleId method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String roleNames = StringUtils.join(roleName, ",");
		String url = getRMAdminRestUrl + MessageFormat.format(getRoleId, roleNames);
		List<Long> roleIds = null;
		try {
			ResponseEntity<List<Long>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET, requestEntityObj,
					new ParameterizedTypeReference<List<Long>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<Long>> rmApproversOptnlObj = ofNullable(responseEntityObj.getBody());
				if (rmApproversOptnlObj.isPresent()) {
					roleIds = rmApproversOptnlObj.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getEmailRMApproversList|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getRMApproversList|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.getRoleId method:");
		return roleIds;
	}

	/**
	 * get Module details List to get the workflowTypeId List.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	public List<ModuleStatusDto> getModuleDetailsList(String parentModule, List<String> subModuleList)
			throws ResourceManagementException {
		log.info("Entered into AdminServiceClient.getModuleDetailsList method:");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl
				+ MessageFormat.format(getModuleDetailsListURL, parentModule, String.join(",", subModuleList));
		List<ModuleStatusDto> moduleDtlsList = null;
		try {
			ResponseEntity<List<ModuleStatusDto>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntity, new ParameterizedTypeReference<List<ModuleStatusDto>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<ModuleStatusDto>> moduleDtlsListOptnObj = ofNullable(responseEntityObj.getBody());
				if (moduleDtlsListOptnObj.isPresent()) {
					moduleDtlsList = moduleDtlsListOptnObj.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getModuleDetailsList|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getModuleDetailsList|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.getModuleDetailsList method:");
		return moduleDtlsList;
	}

	/**
	 * get Module details List to get the workflowTypeId List.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	// working
	public List<ModuleStatusDto> getAllModuleDetailsList(String parentModule) throws ResourceManagementException {
		log.info("Entered into AdminServiceClient.getModuleDetailsList method:");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl + MessageFormat.format(getAllModuleDetailsListURL, parentModule);
		List<ModuleStatusDto> allmoduleDtlsList = null;
		try {
			ResponseEntity<List<ModuleStatusDto>> newresponseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntity, new ParameterizedTypeReference<List<ModuleStatusDto>>() {
					});
			if (HttpStatus.Series.valueOf(newresponseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<ModuleStatusDto>> moduleDtlsListOptnObj = ofNullable(newresponseEntityObj.getBody());
				if (moduleDtlsListOptnObj.isPresent()) {
					allmoduleDtlsList = moduleDtlsListOptnObj.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getModuleDetailsList|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getModuleDetailsList|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.getModuleDetailsList method:");
		return allmoduleDtlsList;
	}

	/**
	 * Get SkillList from ProjectDefination service
	 * 
	 * @param reqIds
	 * @return
	 * @throws ResourceManagementException
	 */
	public List<SkillTaxonomyDto> getSkillFamilyByskillId(List<Long> skillIds) throws ResourceManagementException {

		log.info("Start getSkillFamilyByReqId");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String reqIdList = StringUtils.join(skillIds, ",");

		String url = getAdminPDBaseRestUrl + MessageFormat.format(getSkillFamilyBySkillId, reqIdList);
		List<SkillTaxonomyDto> skillFamilyList = null;
		try {
			ResponseEntity<List<SkillTaxonomyDto>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<SkillTaxonomyDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<SkillTaxonomyDto>> projectwithinodcresponse = ofNullable(response.getBody());
				if (projectwithinodcresponse.isPresent()) {
					skillFamilyList = projectwithinodcresponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getSkillFamilyByReqId|url:{}|exception:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getSkillFamilyByReqId|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}

		log.info("End getSkillFamilyByReqId");
		return skillFamilyList;
	}

	public CostCardDto getCostCard(CostCardInputDto costCardInputDto) throws ResourceManagementException {
		log.info("Entered into AdminServiceClient.getCostCard method:");
		String url = getAdminPDBaseRestUrl + getCostCardRestUrl;
		CostCardDto costCardDto = null;
		try {
			costCardDto = restTemplate.postForObject(url, costCardInputDto, CostCardDto.class);
		} catch (ResourceAccessException rae) {
			log.error("getCostCard|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getCostCard|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getCostCard method:");
		return costCardDto;
	}

	public Long getProjectBillableIdbyProjectId(Long projectId) throws ResourceManagementException {

		log.info("Start getProjectBillableIdbyProjectId");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String pid = String.valueOf(projectId);

		String url = projectDefinationBasetUrl + MessageFormat.format(getProjectBillableIdURL, pid);
		Long projectBillableId = null;

		try {
			ResponseEntity<Long> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<Long>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<Long> projBId = ofNullable(response.getBody());
				if (projBId.isPresent()) {
					projectBillableId = projBId.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getProjectBillableIdbyProjectId|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getProjectBillableIdbyProjectId|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getProjectBillableIdbyProjectId");
		return projectBillableId;
	}

	public CountryDto getCountryByLocationId(Long locationId) throws ResourceManagementException {
		log.info("Start getCountryIdByLocationId");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String lid = String.valueOf(locationId);

		String url = getRMAdminRestUrl + MessageFormat.format(getCountryByLocationIdURL, lid);
		CountryDto countryDto = null;

		try {
			ResponseEntity<CountryDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<CountryDto>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<CountryDto> country = ofNullable(response.getBody());
				if (country.isPresent()) {
					countryDto = country.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getCountryIdByLocationId|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getCountryIdByLocationId|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getCountryIdByLocationId");
		return countryDto;
	}

	// test
	public ProjectDto getProjectbyProjectId(Long projectId) throws ResourceManagementException {

		log.info("Start getProjectbyProjectId");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String pid = String.valueOf(projectId);

		String url = getRMAdminRestUrl + MessageFormat.format(getProjectByProjectIdURL, pid);
		ProjectDto projectDto = null;

		try {
			ResponseEntity<ProjectDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<ProjectDto>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<ProjectDto> projBId = ofNullable(response.getBody());
				if (projBId.isPresent()) {
					projectDto = projBId.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getProjectbyProjectId|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getProjectbyProjectId|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getProjectbyProjectId");
		return projectDto;
	}

	public EmployeeDto getEmployeeDetailsByEmpId(long employeeId) throws ResourceManagementException {
		log.info("Start getEmployeeDetailsByEmpId");
		String url = getRMAdminRestUrl + MessageFormat.format(getEmployeeDetailsByEmpIdURL, String.valueOf(employeeId));

		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		EmployeeDto employee = null;
		try {
			ResponseEntity<EmployeeDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<EmployeeDto>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<EmployeeDto> employeeresponse = ofNullable(response.getBody());
				if (employeeresponse.isPresent()) {
					employee = employeeresponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getEmployeeDetailsByEmpId|url:{}|exception:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getEmployeeDetailsByEmpId|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}

		log.info("End getEmployeeByName");
		return employee;
	}

	public UtilizationDetailDto getUtilizationDetails(List<UtilizationProjectDetails> utilizationProjectDetailsList)
			throws ResourceManagementException {
		String url = getRMAdminRestUrl + getUtilizationDetails;
		UtilizationDetailDto utilizationDetailDto = null;
		try {
			utilizationDetailDto = restTemplate.postForObject(url, utilizationProjectDetailsList,
					UtilizationDetailDto.class);
		} catch (ResourceAccessException rae) {
			log.error("getLookupValueDto|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getLookupValueDto|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		return utilizationDetailDto;
	}

	public LookupValueDto getLookupValueDescription(Long lookUpValueId) throws ResourceManagementException {
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		LookupValueDto lookupValueDto = null;
		String url = rmAdmingBaseUrl + MessageFormat.format(looUpDescriptionRestUrl, lookUpValueId.toString());

		try {
			ResponseEntity<LookupValueDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<LookupValueDto>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<LookupValueDto> lookupValue = ofNullable(response.getBody());
				if (lookupValue.isPresent()) {
					lookupValueDto = lookupValue.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getLookUpById|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getLookUpById|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		return lookupValueDto;
	}

	/**
	 * @param resourceAllocation
	 * @param activeAction
	 * @return
	 * @throws ResourceManagementException
	 */
	public List<ReportLookupValueDto> getAllocatedResourcesStatuses(String resourceAllocation, String activeAction)
			throws ResourceManagementException {
		log.info("Start getAllocatedResourcesStatuses");

		String url = adminBaseURL + MessageFormat.format(adminBaseLookUpDetails, resourceAllocation, activeAction);

		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		List<ReportLookupValueDto> lookUpValues = null;

		try {
			ResponseEntity<List<ReportLookupValueDto>> response = restTemplate.exchange(url, HttpMethod.GET,
					requestEntity, new ParameterizedTypeReference<List<ReportLookupValueDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<ReportLookupValueDto>> lookUpResponse = ofNullable(response.getBody());
				if (lookUpResponse.isPresent()) {
					lookUpValues = lookUpResponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getAllocatedResourcesStatuses|url:{}|exception:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getAllocatedResourcesStatuses|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}

		log.info("End getAllocatedResourcesStatuses");
		return lookUpValues;
	}

	public String getProjectBudgetStatus(Long projectId) throws ResourceManagementException {
		log.info("Entered into getProgramCode method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String url = getRMAdminRestUrl + MessageFormat.format(getProjectBudgetStatus, projectId.toString());
		String budgetStatus = null;
		try {
			ResponseEntity<String> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET, requestEntityObj,
					new ParameterizedTypeReference<String>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<String> response = ofNullable(responseEntityObj.getBody());
				if (response.isPresent()) {
					budgetStatus = response.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getProjectBudgetStatus|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getProjectBudgetStatus|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving getProjectBudgetStatus method:");
		return budgetStatus;
	}

	public Long getModuleStatusByAction(String moduleName, String action) throws ResourceManagementException {
		log.info("Entered into getModuleStatusByAction method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String url = getRMAdminRestUrl + MessageFormat.format(getModuleStatusByAction, moduleName, action);
		Long moduleStatus = getLookUpAndModuleId(requestEntityObj, url);
		log.info("Just before leaving getModuleStatusByAction method:");
		return moduleStatus;
	}

	private Long getLookUpAndModuleId(HttpEntity<String> requestEntityObj, String url)
			throws ResourceManagementException {
		Long moduleStatus = null;
		try {
			ResponseEntity<Long> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET, requestEntityObj,
					new ParameterizedTypeReference<Long>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<Long> response = ofNullable(responseEntityObj.getBody());
				if (response.isPresent()) {
					moduleStatus = response.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getModuleStatusByAction|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getModuleStatusByAction|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		return moduleStatus;
	}

	public Long getLookuIdByTypeAndDescr(String lookUpType, String LookupDescr) throws ResourceManagementException {
		log.info("Entered into getModuleStatusByAction method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String url = getRMAdminRestUrl + MessageFormat.format(getLookUpbyTypeAndDescrUrl, lookUpType, LookupDescr);
		Long moduleStatus = getLookUpAndModuleId(requestEntityObj, url);
		log.info("Just before leaving getModuleStatusByAction method:");
		return moduleStatus;
	}

	public List<MModuleProjection> getStatusByName(String resourceAllocationTypeStatus, String activateStatus)
			throws ResourceManagementException {
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = adminBaseURL
				+ MessageFormat.format(getModuleStatusByNameURL, resourceAllocationTypeStatus, activateStatus);
		List<MModuleProjection> moduleStatuses = new ArrayList<>();
		try {
			ResponseEntity<List<MModuleProjection>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntity, new ParameterizedTypeReference<List<MModuleProjection>>() {
					});

			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<MModuleProjection>> moduleResponse = ofNullable(responseEntityObj.getBody());
				if (moduleResponse.isPresent()) {
					moduleStatuses = moduleResponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getStatusByName|url:{}|exception:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getStatusByName|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}

		log.info("End getStatusByName");
		return moduleStatuses;
	}

	public List<Long> getPrimaryOwnerUserIdListByProjectId(Long projectId) throws ResourceManagementException {
		log.info("Entered into getPrimaryOwnerUserIdListByProjectId method: " + projectId);
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String projId = Long.toString(projectId);
		String url = getRMAdminRestUrl + MessageFormat.format(getPrimaryOwnerUserIdListByProjectId, projId);
		List<Long> userIdList = null;
		try {
			ResponseEntity<List<Long>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET, requestEntityObj,
					new ParameterizedTypeReference<List<Long>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<Long>> mEntityOwnersObject = ofNullable(responseEntityObj.getBody());
				if (mEntityOwnersObject.isPresent()) {
					userIdList = mEntityOwnersObject.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getPrimaryOwnerUserIdListByProjectId|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getPrimaryOwnerUserIdListByProjectId|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving getPrimaryOwnerUserIdListByProjectId method:");
		return userIdList;
	}

	public List<LookupValueAndDescDto> getLookuIdByTypeAndDescrList(String lookUpType, List<String> LookupDescrList)
			throws ResourceManagementException {
		log.info("Entered into getModuleStatusByAction method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String url = getRMAdminRestUrl + MessageFormat.format(getLookuIdByTypeAndDescrListUrl, lookUpType,
				StringUtils.join(LookupDescrList, ","));
		List<LookupValueAndDescDto> moduleStatus = new ArrayList<>();
		try {
			ResponseEntity<List<LookupValueAndDescDto>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntityObj, new ParameterizedTypeReference<List<LookupValueAndDescDto>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<LookupValueAndDescDto>> response = ofNullable(responseEntityObj.getBody());
				if (response.isPresent()) {
					moduleStatus = response.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getModuleStatusByAction|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getModuleStatusByAction|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving getModuleStatusByAction method:");
		return moduleStatus;
	}

	public ProjectBuDto getBuForProject(Long projectId) throws ResourceManagementException {
		log.info("Entered into getBuForProject method: " + projectId);
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String projId = Long.toString(projectId);
		String url = getRMAdminRestUrl + MessageFormat.format(getBuForProjectRestUrl, projId);
		ProjectBuDto projectBu = null;
		try {
			ResponseEntity<ProjectBuDto> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntityObj, new ParameterizedTypeReference<ProjectBuDto>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<ProjectBuDto> mEntityOwnersObject = ofNullable(responseEntityObj.getBody());
				if (mEntityOwnersObject.isPresent()) {
					projectBu = mEntityOwnersObject.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getBuForProject|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getBuForProject|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving getBuForProject method:");
		return projectBu;
	}

	public List<LookupValueDto> getLookUpValueDetailsByIds(List<Long> ids) throws ResourceManagementException {
		log.info("Entered into getLookUpValueDetailsByIds method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String url = adminBaseURL + MessageFormat.format(getLookUpValueDetailsByIds, StringUtils.join(ids, ","));
		List<LookupValueDto> dtosForLValues = new ArrayList<>();
		try {
			ResponseEntity<List<LookupValueDto>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntityObj, new ParameterizedTypeReference<List<LookupValueDto>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<LookupValueDto>> dtosForLValuesResponse = ofNullable(responseEntityObj.getBody());
				if (dtosForLValuesResponse.isPresent()) {
					dtosForLValues = dtosForLValuesResponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getLookUpValueDetailsByIds|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getLookUpValueDetailsByIds|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving getLookUpValueDetailsByIds method:");
		return dtosForLValues;
	}

	public List<EmployeeDto> getAllEmployeeDetails(String searchParameter) throws ResourceManagementException {
		log.info("inside getAllEmployeeDetails");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getAdminPDBaseRestUrl + MessageFormat.format(getAllEmployeeDetailsUrl, searchParameter);

		return setAssociateObject(requestEntity, url);
	}

	public List<EmployeeDto> setAssociateObject(HttpEntity<String> requestEntity, String url)
			throws ResourceManagementException {
		List<EmployeeDto> associates = null;
		try {
			ResponseEntity<List<EmployeeDto>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<EmployeeDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<EmployeeDto>> employeeList = ofNullable(response.getBody());
				if (employeeList.isPresent()) {
					associates = employeeList.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getAllEmployeeDetails|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getAllEmployeeDetails|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Start getAllEmployeeDetails");
		return associates;
	}

	public List<ServiceLineDto> getServiceLineList(List<Long> serviceLineIdList) throws ResourceManagementException {
		log.info("Entered into getServiceLineList method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String url = getAdminPDBaseRestUrl
				+ MessageFormat.format(getServiceLineListRestURL, StringUtils.join(serviceLineIdList, ","));
		List<ServiceLineDto> serviceLine = null;
		try {
			ResponseEntity<List<ServiceLineDto>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntityObj, new ParameterizedTypeReference<List<ServiceLineDto>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<ServiceLineDto>> serviceLineObject = ofNullable(responseEntityObj.getBody());
				if (serviceLineObject.isPresent()) {
					serviceLine = serviceLineObject.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getServiceLineList|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getServiceLineList|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving getServiceLineList method:");
		return serviceLine;
	}

	// Added by Mrunal Marne for milestone selection while resource allocation
	public List<LookupValueNewDto> getLookupValueListByLookupDesc(List<String> lookupValueDescList)
			throws ResourceManagementException {
		log.info("Entered into getLookupValueList method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String url = getAdminPDBaseRestUrl
				+ MessageFormat.format(getLookupValueListByLookupDesc, StringUtils.join(lookupValueDescList, ","));
		List<LookupValueNewDto> lookupValueDtoListByDesc = null;
		try {
			ResponseEntity<List<LookupValueNewDto>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntityObj, new ParameterizedTypeReference<List<LookupValueNewDto>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<LookupValueNewDto>> lookupValueDtlsObject = ofNullable(responseEntityObj.getBody());
				if (lookupValueDtlsObject.isPresent()) {
					lookupValueDtoListByDesc = lookupValueDtlsObject.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getLookupValueList|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getLookupValueList|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving getLookupValueListt method:");
		return lookupValueDtoListByDesc;
	}
	
	//Added by Mrunal Marne for getting project owners in supervisors list
	public List<Long> getRMSupervisorsList(Long projectId)
			throws ResourceManagementException {
		log.info("Entered into AdminServiceClient.getRMSupervisorsList method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());

		String url = getRMAdminRestUrl + MessageFormat.format(getRMSupervisorsListRestURL, Long.toString(projectId));
		List<Long> rmSupervisorsList = null;
		try {
			ResponseEntity<List<Long>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntityObj, new ParameterizedTypeReference<List<Long>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<Long>> rmApproversOptnlObj = ofNullable(responseEntityObj.getBody());
				if (rmApproversOptnlObj.isPresent()) {
					rmSupervisorsList = rmApproversOptnlObj.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getRMApproversList|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getRMApproversList|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.getRMSupervisorsList method:");
		return rmSupervisorsList;
	}
	
	public EmployeeDetailsDTO getEmployeeDetailsByEmployeeNumber(Long employeeNumber) throws ResourceManagementException {
        log.info("Start getEmployeeDetailsByEmployeeNumber");
        HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

 

        String url = adminReportBaseURL
                + MessageFormat.format(getEmployeeDetailsByEmployeeNumber, employeeNumber.toString());
        EmployeeDetailsDTO employeeIdData = null;

 

        try {
            ResponseEntity<EmployeeDetailsDTO> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
                    new ParameterizedTypeReference<EmployeeDetailsDTO>() {
                    });
            if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
                employeeIdData = response.getBody();
            }
        } catch (ResourceAccessException rae) {
            log.error("getEmployeeDetailsByEmployeeNumber|url:{}| ResourceAccessException:{}", url, rae);
            throw new ResourceManagementException(rae);
        } catch (HttpClientErrorException | HttpServerErrorException hcee) {
            log.error("getEmployeeDetailsByEmployeeNumber|url:{}| exception:{}", url, hcee);
            throw new ResourceManagementException(hcee);
        }

 

        log.info("End getEmployeeDetailsByEmployeeNumber");
        return employeeIdData;
    }
	// End by Mrunal Marne

	//Added by Shubham
	public int getOwnerCount(Long userId, Long projectId, Long loggedInRoleId) throws ResourceManagementException {
		log.info("Start AdminServiceClient.getOwnerCount");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl
				+ MessageFormat.format(getOwnerCount, userId.toString(), projectId.toString(), loggedInRoleId.toString());
		int result=0;
		try {
			ResponseEntity<Integer> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<Integer>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				result = response.getBody();
			}
		} catch (ResourceAccessException rae) {
			log.error("getOwnerCount|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getOwnerCount|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End AdminServiceClient.getOwnerCount");
		return result;
	}
	
	//Dev by Ravi

	public MLocationDto getlocationCodeBylocationId(Long locationId)
			throws ResourceManagementException {
		log.info("Start getModuleStatus - getlocationCodeBylocationId::{}", locationId);
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getAdminPDBaseRestUrl + MessageFormat.format(getLocationByLocationIdURL,locationId);
		MLocationDto mLocationDto = null;
		try {
			ResponseEntity<MLocationDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					MLocationDto.class);
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<MLocationDto> moduleStatus = ofNullable(response.getBody());
				if (moduleStatus.isPresent()) {
					mLocationDto = moduleStatus.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getModuleStatus|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getModuleStatus|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Start getModuleStatus");
		return mLocationDto;
	}
	
	//Dev by Ravi
	
	public Integer getCurrencyIdByName(String currencyName) throws ResourceManagementException {
		log.info("Start getCurrencyIdByName - currencyName::{}", currencyName);
		String url = getAdminPDBaseRestUrl + MessageFormat.format(getCurrencyIdByNameRestURL, currencyName);
		log.info("End getCurrencyIdByName");
		return getCurrencyIdValueDto(url);
	}
	
	public Integer getCurrencyIdValueDto(String url) throws ResourceManagementException {
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		Integer lookupValueid = null;
		try {
			ResponseEntity<Integer> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					Integer.class);
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<Integer> lookupValuIde = ofNullable(response.getBody());
				if (lookupValuIde.isPresent()) {
					lookupValueid = lookupValuIde.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getLookUpById|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getLookUpById|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		return lookupValueid;
	}
	//end ravi
	
	//Srinivasulu
	public List<Long> getEmployeeNumber(List<Long> empIds)
			throws ResourceManagementException {
		log.info("Start AdminServiceClient - getEmployeeNumber::{}", empIds);
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = getRMAdminRestUrl + MessageFormat.format(getEmployeeNumberURL,StringUtils.join(empIds, ","));
		List<Long> result = null;
		
		try {
			ResponseEntity<List<Long>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<Long>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				result = response.getBody();
			}
			
		} catch (ResourceAccessException rae) {
			log.error("getEmployeeNumber|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getEmployeeNumber|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End AdminServiceClient.getEmployeeNumber");
		return result;
	}
	//end by srinivasulu

	
	  //added by devAk
			public Boolean saStaffCheck(Long empIds)
					throws ResourceManagementException {
				log.info("Start AdminServiceClient - saStaffCheck::{}", empIds);
				HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
				HttpEntity<String> requestEntity = new HttpEntity<>(headers);
				String url = getRMAdminRestUrl + MessageFormat.format(saEmployeeCheckRestURL,empIds.toString());
				Boolean result = null;
					try {
					ResponseEntity<Boolean> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,Boolean.class);
					if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
						result = response.getBody();
					}
					
				} catch (ResourceAccessException rae) {
					log.error("saStaffCheck|url:{}| ResourceAccessException:{}", url, rae);
					throw new ResourceManagementException(rae);
				} catch (HttpClientErrorException | HttpServerErrorException hcee) {
					log.error("saStaffCheck|url:{}| exception:{}", url, hcee);
					throw new ResourceManagementException(hcee);
				}
				log.info("End AdminServiceClient.saStaffCheck");
				return result;
			}
			//end
}
