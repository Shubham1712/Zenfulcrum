package com.zensar.zenfulcrum.resourcemanagement.service;

import java.util.List;

import javax.validation.Valid;

import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDtlsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

public interface ResourceProjectDetailsService {

	 
	List<ProjectDto> getProjectIdsByUserId(long userId);

	 
	List<ProjectBudgetDto> getProjectMonthlyBudgetsDetails(Long projectId) throws ResourceManagementException;

	ProjectDtlsDto getAllocatedResources(long projectId);

 
}
