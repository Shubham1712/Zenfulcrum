package com.zensar.zenfulcrum.resourcemanagement.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

public class RMBudgetControlUtil {	
	
	private RMBudgetControlUtil() {
		super();
	}
	
	/**
	 * get month wise days.
	 */
	public static Map<String, Long> monthWiseNoOfDays(Date allocStartDate, Date allocEndDate) throws ResourceManagementException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		/*
		 * long monthsBetween = ChronoUnit.MONTHS.between(
		 * LocalDate.parse(dateFormat.format(allocStartDate)),
		 * LocalDate.parse(dateFormat.format(allocEndDate)));
		 */
		long monthsBetween =  ChronoUnit.MONTHS.between(
		        LocalDate.parse(dateFormat.format(allocStartDate)).withDayOfMonth(1),
		        LocalDate.parse(dateFormat.format(allocEndDate)).withDayOfMonth(1));
		 Date convertedDate;
		 String date;
		 Calendar c = new GregorianCalendar();
		 Date lastDayOfMonth;
		 Map<String, Long> monthWiseNoOfDays = new HashMap<>();
		 String sdate = dateFormat.format(allocStartDate);
		 for (int i = 0; i <= monthsBetween; i++) {
             try {
				convertedDate = dateFormat.parse(sdate);
			} catch (ParseException e) {
				throw new ResourceManagementException("Date Parse Exception", e);
			}
            c.setTime(convertedDate);
            String months = String.valueOf((c.get(Calendar.MONTH) + 1));
            String years = String.valueOf(c.get(Calendar.YEAR));
            
            if(Integer.valueOf(months) < 10) {
            	date = years.concat("-0").concat(months);
            } else {
            	date = years.concat("-").concat(months);
            }
            if(i == monthsBetween) {
            	lastDayOfMonth = allocEndDate;
            } else {
            	c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));
            	lastDayOfMonth = c.getTime();
            }
    
            long numberOfDays = calculateNumberofDays(convertedDate, lastDayOfMonth);
            monthWiseNoOfDays.put(date, numberOfDays);
            c.add(Calendar.DATE, 1);
            sdate = dateFormat.format(c.getTime());
        }
		 return monthWiseNoOfDays;
	}
	
	/**
	 * Calculate No.of days between given dates
	 */
	private static long calculateNumberofDays(Date convertedDate, Date lastDayOfMonth) {
        Calendar endCalendar = new GregorianCalendar();
        endCalendar.setTime(lastDayOfMonth);
        Calendar calendar1 =new GregorianCalendar();
        calendar1.setTime(convertedDate);
        Calendar calendar2 =new GregorianCalendar();
        calendar2.setTime(lastDayOfMonth);
        if(calendar2.before(endCalendar)){
            calendar2.setTime(lastDayOfMonth);
        }
        else{
            calendar2.setTime(lastDayOfMonth);
        }
        long numberOfDays = 0;
        List<Integer> notIn= Arrays.asList(Calendar.SUNDAY,Calendar.SATURDAY);
        while (calendar1.getTimeInMillis() <= calendar2.getTimeInMillis()) {
            if(!notIn.contains(calendar1.get(Calendar.DAY_OF_WEEK)))
                ++numberOfDays;
            calendar1.add(Calendar.DAY_OF_MONTH, 1);
        }
        return numberOfDays;
    }	
	
	/**
	 * return current year and month in specific format
	 */
	    public static String getCurrentYearAndMonth() {
		LocalDate localDate = LocalDate.now();
		return DateTimeFormatter.ofPattern("yyyy-MM").format(localDate);

	}
	

}
