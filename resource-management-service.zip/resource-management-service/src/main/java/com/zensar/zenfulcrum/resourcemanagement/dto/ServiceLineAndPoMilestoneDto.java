package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;
import lombok.Data;

@Data
public class ServiceLineAndPoMilestoneDto {

	public long requirementId;
	public String requirementband;
	public List<ServiceLineDto> serviceLineList;
	public List<PoMilestoneDto> poMilestoneList;

}
