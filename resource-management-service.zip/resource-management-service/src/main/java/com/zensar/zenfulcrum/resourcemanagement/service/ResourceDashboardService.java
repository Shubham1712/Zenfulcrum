package com.zensar.zenfulcrum.resourcemanagement.service;

import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceApprovalDashboardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TraceabilityDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

public interface ResourceDashboardService {
	
	public ResourceApprovalDashboardDto getResourcePendingCount(Long userId, Long roleId) throws ResourceManagementException;
	
	public ResourceApprovalDashboardDto getPendingResourceDetails(Long userId, Long roleId) throws ResourceManagementException;
	
	public TraceabilityDto getRMPendingTraceability(Long userId,Long roleId,Long allocationId,String requestType) throws ResourceManagementException;

	//Added by Mrunal Marne for performance issue on dashboard
	public ResourceApprovalDashboardDto getPendingForApprovalAndOthersResourceDetails(Long userId, Long roleId) throws ResourceManagementException;
	
	public ResourceApprovalDashboardDto getPendingForSubmissionResourceDetails(Long userId, Long roleId) throws ResourceManagementException;
	//End by Mrunal
}
