package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class ConfluenceAllocData {

	private Long empNum;
	private String empName;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd", timezone="IST")
	private Date praEstEndDate;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd", timezone="IST")
	private Date praActStartDate;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd", timezone="IST")
	private Date praActEndDate;
	private String projectName;
	private String projectCode;
	private Long projectId;
	 	
}
