package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;

import lombok.Data;


@Data
public class EmployeeSkillDto {
	
	private Long employeeId;
	private List<Long> l4SkillId;
	private List<SkillTaxonomyDto> skillFamilyList;

}
