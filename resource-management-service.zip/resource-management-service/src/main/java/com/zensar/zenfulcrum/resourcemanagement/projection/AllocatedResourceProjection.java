package com.zensar.zenfulcrum.resourcemanagement.projection;

import java.util.Date;

public interface AllocatedResourceProjection {
	
	public Long getAssociateAllocationId();
	public long getRequirementId();
	public long getEmployeeId();
	public Long getProjectId();
	public Boolean getIsPrimaryProject();
	public Double  getFtePercent();
	public Integer getBillableStatusId();
	public Date getActualStartDate();
	public Date getEstEndDate();
	public Date getDeallocationDate();
	public Date getActualAllocationEndDate();
	public Date getRequestReceivedOn();
	public Integer getallocatedProjectRole();
	public Integer getallocatedProjectLocation();
	public Double getemployeeCostRate();
	public Long getsrfId();
	public Long getsuperVisorId();
	public Long getcapHours();
	public String getcomments();
	public Integer getebrReason();
	public Long getdefaultSkillId();
	public void setAssociateAllocationId(long l);
	public void setEmployeeId(long l);
	public void setRequirementId(long l);
	public void setFtePercent(long l);
	public void setProjectId(long l);
	public void setBillableStatusId(Integer i);
	public Integer setebrReason(Integer i);
	public Long setsuperVisorId(Long l);
	public Long setsrfId(Long l);
	public void setRequestReceivedOn(Date d);
	public Date getExtEstEndDate();
	public void setExtEstEndDate(Date extEstEndDate);
	public void setEstEndDate(Date estEndDate);
	public void  setdefaultSkillId(Long l);
	public Long getAssociateProjectId();
	public Long getAllocationTypeId();
	public void setAssociateProjectId(Long associateProjectId);
	
	public Long getTransactionHistoryId();
	public void setTransactionHistoryId(long l);
	public Long getRoleId();
	public void setRoleId(long l);
	public Date getReleaseDate();
	public void setReleaseDate(Date d);
	public Date setActualStartDate(Date d);
	public void setemployeeCostRate(Double d);
	public Date setActualAllocationEndDate(Date d);
	
	public Long getReasonForDeallocationId();
	public void setReasonForDeallocationId(Long l);
	public Boolean setIsPrimaryProject(Boolean b);
	public Long getAssociateDeAllocationId();
	public void setAssociateDeAllocationId(long l);
	public Long getBandId();
	public void setBandId(Long b);

	public Long getServiceLineId();
	public void setServiceLineId(long serviceLineId);
	public String getServiceLineName();
	public void setServiceLineName(String serviceLineName);
	public void setcomments(String s);
	public void setAllocationTypeId(long l);
	public Long getWorkflowStatusId();
	public Long getStatusId();
	public void setWorkflowStatusId(long l);
	public void setStatusId(long l);

	public Integer getFlag();
	public void setFlag(Integer flag);
	public Long getWorklocationId();
	public void setWorklocationId(long l);
	public String getWorkLocation();
	public void setWorkLocation(String s);
	
	public Boolean getSkillChampionFlag();
	public void setSkillChampionFlag();
	
	//Added by Mrunal Marne
	public Integer getIsPrimaryProjectFlag();
	public Integer setIsPrimaryProjectFlag(Integer b);
	
	public Integer getSkillChampionFlagInt();
	public void setSkillChampionFlagInt();
	
}
