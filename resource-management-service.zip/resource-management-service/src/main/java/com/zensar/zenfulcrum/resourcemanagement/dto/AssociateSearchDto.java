package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class AssociateSearchDto implements Serializable{
	
	private static final long serialVersionUID = -2950497018653799994L;
    	
	private EmployeeDto associatePractiseDetails;
	private List<EmployeeDto> associateTravelAllocationDetails;
	private List<EmployeeDto> associateProjectDetails;
	private List<EmployeeDto> reservedForAllocation;
	private List<EmployeeDto> reservedForDeallocation;
	private List<EmployeeDto> deallocationApproved;
	private List<EmployeeDto> allocationApproved;


}
