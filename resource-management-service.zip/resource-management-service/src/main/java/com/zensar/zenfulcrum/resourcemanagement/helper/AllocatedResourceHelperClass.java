package com.zensar.zenfulcrum.resourcemanagement.helper;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.HashBasedTable;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;


@Component
public class AllocatedResourceHelperClass {
	
	@Autowired
	AdminServiceClient adminServiceClient;
	
	@Autowired
	TAssociateAllocationRepository allocationRepository;
	   


	public List<Long> getDeallocationList(HashBasedTable<String, String, Long> table,Long projectId, List<Long> requirementIds)
	{
		List<Long> wfStatusIdForSavedOrSubmittedForDeallocation = List.of(
				table.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.SAVED),
				table.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.SUBMITTED),
				table.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.APPROVED));
		Long statusIdForAllocationActive = table.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long wfStatusIdForAllocationApproved = table.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
	     return  allocationRepository.getDeallocationList(projectId, requirementIds, statusIdForAllocationActive, wfStatusIdForAllocationApproved, wfStatusIdForSavedOrSubmittedForDeallocation);
		
	}
	
	public List<Long> getTransferList(HashBasedTable<String, String, Long> table,Long projectId, List<Long> requirementIds)
	{
		Long statusIdForAllocationActive = table.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long wfStatusIdForAllocationApproved = table.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		
		List<Long> wfStatusIdForSavedOrSubmittedForTransfer = List.of(
				table.get(ResourceManagementConstant.RESOURCE_TRANSFER,
						ResourceManagementConstant.SAVED),
				table.get(ResourceManagementConstant.RESOURCE_TRANSFER,
						ResourceManagementConstant.SUBMITTED),57l);
		
      return  allocationRepository.getTransferList(projectId, requirementIds, statusIdForAllocationActive, wfStatusIdForAllocationApproved, wfStatusIdForSavedOrSubmittedForTransfer);
	}
	
	
	public List<Long> getExtensionList(HashBasedTable<String, String, Long> table,Long projectId, List<Long> requirementIds)
	{
		
		Long statusIdForAllocationActive = table.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long wfStatusIdForAllocationApproved = table.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long wfIdForSubmittedForExtension = table.get(ResourceManagementConstant.RESOURCE_EXTENSION,
				ResourceManagementConstant.SUBMITTED);
		return  allocationRepository.getExtensionList(projectId, requirementIds, statusIdForAllocationActive, wfStatusIdForAllocationApproved, wfIdForSubmittedForExtension);
		
	}
	
	public List<AllocatedResourceProjection> getNewAllocatedEmployeeList(Long projectId, List<Long> requirementIds,Boolean normalAllocId)
			throws ResourceManagementException {
		List<ModuleStatusDto> moduleList = adminServiceClient
				.getAllModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT);
		HashBasedTable<String, String, Long> table = HashBasedTable.create();
		for (ModuleStatusDto temp : moduleList) {
			table.put(temp.getSubModule(), temp.getAction(), temp.getModuleStatusId());
		}
		
		Long statusIdForAllocationActive = table.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long wfStatusIdForAllocationApproved = table.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long lookupIdForNorAlloc = adminServiceClient.getLookuIdByTypeAndDescr(
				ResourceManagementConstant.ALLOCATION_TYPE, ResourceManagementConstant.NORMAL);
		
		List<Long> allocationIDsInWorkflow = new ArrayList<>();
		List<Long> deallocationIds = getDeallocationList(table, projectId, requirementIds);
		List<Long> transferallocatinIds = getTransferList(table, projectId, requirementIds);
		List<Long>  extensionList = getExtensionList(table, projectId, requirementIds);
		allocationIDsInWorkflow.add(0l);
		allocationIDsInWorkflow.addAll(deallocationIds);
		allocationIDsInWorkflow.addAll(transferallocatinIds);
		allocationIDsInWorkflow.addAll(extensionList);
		 if(normalAllocId)
		   return allocationRepository.getNormalempList(projectId, requirementIds, statusIdForAllocationActive, wfStatusIdForAllocationApproved, allocationIDsInWorkflow,lookupIdForNorAlloc);
		 else
		  return allocationRepository.getempList(projectId, requirementIds, statusIdForAllocationActive, wfStatusIdForAllocationApproved, allocationIDsInWorkflow);
			
	}
	  
	public String getProjectCode(Long projectId)
	{
		return allocationRepository.getProjectCode(projectId);
	}
	  
	public HashBasedTable<String, String, Long> getallModuleData() throws ResourceManagementException {
		List<ModuleStatusDto> newmoduleListForFlows = adminServiceClient
				.getAllModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT);
		HashBasedTable<String, String, Long> newtable = HashBasedTable.create();
		for (ModuleStatusDto newtemp : newmoduleListForFlows) {
	    	newtable.put(newtemp.getSubModule(), newtemp.getAction(), newtemp.getModuleStatusId());
		}  
		return newtable;     
	}

	public double getRoundedOffValue(double actualValue) {
		DecimalFormat df = new DecimalFormat("#.##");
		double a = Double.parseDouble(df.format(actualValue));
		return a;
	}
  
}
