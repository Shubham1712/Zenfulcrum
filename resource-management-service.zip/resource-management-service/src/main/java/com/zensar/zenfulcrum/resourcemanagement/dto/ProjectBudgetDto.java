package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class ProjectBudgetDto implements Serializable {
	private static final long serialVersionUID = 4701283573927849788L;
	
	private Long id;
	private String projectId;
	private Date projectStartDate;
	private Date projectEndDate;
	private String month;
	private Double availableBudget;
	private Double consumedBudget;
	private Double budgetCurrency;
	
	// PD parameters
	
	  Double additionalAmmount;
//    Double availableBudget;
    Double budgetAdded;
    Double budgetDetailsId;
    Double budgetReduced;
    Double contingencyAmount;
    String monthName;
    String monthValue;
    Long monthlyBudgetId;
    String pricingMonth;
//     String projectId;
    Date rowAddStp;
    Long rowAddUser;
    Date rowUpdateStp;
    String rowUpdateUser;
    Double totalConsumption;
    Double totalMonthlyBudget;
    Double usedCumulative;
    String year;
	
	public ProjectBudgetDto() {
		
	}
	
}
