package com.zensar.zenfulcrum.resourcemanagement.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateAllocationRequestDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateAllocationResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateHistoryReportDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.BapReportDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ConfluenceAllocData;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectAndAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ReportServiceException;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.projection.TAssociateAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceReportService;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Api(tags = "ResourceProjectDetailsController")
@RestController
@Slf4j
@Validated
@RequestMapping(path = "report")
public class ResourceReportDetailsController {

	@Autowired
	private ResourceReportService resourceReportService;


	/**
	 * @return MCustomerGroupList
	 * @throws ReportServiceException
	 */
	@PostMapping(path = "/allocatedResource")
	public ResponseEntity<AssociateAllocationResponseDto> getAssociateAllocationIdByProjectId(
			@RequestBody AssociateAllocationRequestDto associateAllocationRequest) throws ReportServiceException {
		log.info("start getAssociateAllocationIdByProjectId");
		List<TAssociateAllocationProjection> associateAllocationList = resourceReportService
				.getAssociateAllocationIdByProjectId(associateAllocationRequest.getProjectIds());

		AssociateAllocationResponseDto response = new AssociateAllocationResponseDto();
		if (CollectionUtils.isEmpty(associateAllocationList)) {
			return new ResponseEntity<>(response, HttpStatus.NO_CONTENT);
		}
		log.info("end getAssociateAllocationIdByProjectId");
		response.setAssociateAllocated(associateAllocationList);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping(path = "associatehistory")
	public ResponseEntity<List<AssociateHistoryReportDto>> getAssociateHistory(@Valid @RequestParam long empId)
			throws ResourceManagementException {
		log.info("Start getAssociateHistory projectId::{}");

		List<AssociateHistoryReportDto> projectList = resourceReportService.resourceAllocationHistory(empId);
		if (projectList != null) {
			return new ResponseEntity<>(projectList, HttpStatus.OK);
		} else {
			log.info("Exit getProjectList method");
			return new ResponseEntity<>(projectList, HttpStatus.NO_CONTENT);
		}

	}

	@GetMapping(path = "getacualestdate")
	public ResponseEntity<TAssociateAllocationDto> getActualAndEstAllocationDate(@Valid long projectId,
			@Valid long empId) throws ResourceManagementException {
		log.info("Start getActualAndEstAllocationDate projectId::{}");

		TAssociateAllocationDto tAssociateAllocationDto = resourceReportService.getActualAndEstAllocationDate(projectId,
				empId);
		if (tAssociateAllocationDto != null) {
			return new ResponseEntity<>(tAssociateAllocationDto, HttpStatus.OK);
		} else {
			log.info("Exit getActualAndEstAllocationDate  method");
			return new ResponseEntity<>(tAssociateAllocationDto, HttpStatus.NO_CONTENT);
		}
	}
	
	@GetMapping(path="getrequirementids")
	public ResponseEntity<BapReportDto> getRequirementIds(@Valid long projectId ) throws ResourceManagementException {
		log.info("Start getActualAndEstAllocationDate projectId::{}");

 
		BapReportDto bapReportDto = resourceReportService.getRequirementIds(projectId);
		if (bapReportDto!=null) {
			return new ResponseEntity<>(bapReportDto, HttpStatus.OK);
		} else {
			log.info("Exit getActualAndEstAllocationDate  method");
			return new ResponseEntity<>(bapReportDto, HttpStatus.NO_CONTENT);
		}
	}
	@GetMapping(path = "/getAssociateDetailsByAssociateId")
	public ResponseEntity<List<TAssociateProjectAndAllocationDto>> getAssociateDetailsByAssociateId(
			@RequestParam("associateId") Long associateId) throws ResourceManagementException {
		log.info("Start - Getting getAssociateLocationDetailsReport ");
		List<TAssociateProjectAndAllocationDto> obj = resourceReportService
				.getAssociateDetailsByAssociateId(associateId);
		if (CollectionUtils.isNotEmpty(obj)) {
			log.info("End - Getting getAssociateLocationDetailsReport ");
			return new ResponseEntity<>(obj, HttpStatus.OK);
		} else {
			log.info("End getAssociateLocationDetailsReport failure");
			return new ResponseEntity<>(obj, HttpStatus.NO_CONTENT);
		}
	}

	@GetMapping(path = "/getAssociateDeallocationDetails")
	public ResponseEntity<List<TAssociateDeAllocationDto>> getAssociateDeallocationDetails()
			throws ResourceManagementException {
		log.info("Start - Getting getAssociateDeallocationDetails ");
		List<TAssociateDeAllocationDto> obj = resourceReportService.getAssociateDeallocationDetails();
		if (CollectionUtils.isNotEmpty(obj)) {
			log.info("End - Getting getAssociateDeallocationDetails ");
			return new ResponseEntity<>(obj, HttpStatus.OK);
		} else {
			log.info("End getAssociateDeallocationDetails failure");
			return new ResponseEntity<>(obj, HttpStatus.NO_CONTENT);
		}
	}
	
	@PostMapping(path = "/getAllocationWorkflowDetails")
	public ResponseEntity<List<TAssociateProjectAndAllocationDto>> getAllocationWorkflowDetails()
			throws ResourceManagementException {
		log.info("Start - Getting getAllocationWorkflowDetails resource-management-service");
		List<TAssociateProjectAndAllocationDto> obj = resourceReportService.getAllocationWorkflowDetails();
		if (CollectionUtils.isNotEmpty(obj)) {
			log.info("End - Getting getAllocationWorkflowDetails success ( resource-management-service )");
			return new ResponseEntity<>(obj, HttpStatus.OK);
		} else {
			log.info("End getAllocationWorkflowDetails failure ( resource-management-service )");
			return new ResponseEntity<>(obj, HttpStatus.NO_CONTENT);
		}
	}
	
	@GetMapping(path = "/getAllocatedCount")
	public ResponseEntity<Long> getAllocatedCount(@RequestParam Long projectId)
			throws ResourceManagementException {
		log.info("Start - Getting getAllocatedCount ");
		Long obj = resourceReportService.getAllocatedCount(projectId);
		if (obj != null) {
			log.info("End - Getting getAllocatedCount ");
			return new ResponseEntity<>(obj, HttpStatus.OK);
		} else {
			log.info("End getAllocatedCount failure");
			return new ResponseEntity<>(obj, HttpStatus.NO_CONTENT);
		}
	}
	
	//Added by Shubham- ZenConflence API
	@GetMapping(path = "/getallocdata")
	public ResponseEntity<List<ConfluenceAllocData>> getProjAllocationDetails(@Valid @RequestParam(name = "employeeNum") long employeeNum) throws ResourceManagementException {
		log.info("Entered getAllocData method:");
		List<ConfluenceAllocData> obj = resourceReportService.getProjAllocationDetails(employeeNum);
		if (CollectionUtils.isNotEmpty(obj)) {
			log.info("Exiting getAllocData method:");
			return new ResponseEntity<>(obj, HttpStatus.OK);
		} else {
			log.info("End getAllocData failure");
			return new ResponseEntity<>(obj, HttpStatus.NO_CONTENT);
		}
	}
 
}

 
