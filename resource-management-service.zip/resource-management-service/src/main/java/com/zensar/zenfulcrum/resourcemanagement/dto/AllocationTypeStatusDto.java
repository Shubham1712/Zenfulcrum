package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class AllocationTypeStatusDto {
	private Long allocationTypeId;
	private String allocationTypeValue;
}
