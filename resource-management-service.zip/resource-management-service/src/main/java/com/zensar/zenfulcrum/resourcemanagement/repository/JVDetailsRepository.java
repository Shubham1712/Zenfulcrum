package com.zensar.zenfulcrum.resourcemanagement.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.zensar.zenfulcrum.resourcemanagement.model.ZFJVDetails;

@Repository
public interface JVDetailsRepository extends JpaRepository<ZFJVDetails, Long> {

	@Query(value="SELECT WINDOW_END_DATE FROM zf_staging.ZF_JV_DETAILS ORDER BY WINDOW_END_DATE DESC LIMIT 1; ",nativeQuery=true)
    Date getWindowEndDate();
}
