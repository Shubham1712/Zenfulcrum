package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;


@Data
public class UserDto {	
	private long userId;
	private String userName;
}
