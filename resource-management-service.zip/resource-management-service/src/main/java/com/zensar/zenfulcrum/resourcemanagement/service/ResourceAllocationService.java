package com.zensar.zenfulcrum.resourcemanagement.service;

import java.text.ParseException;
import java.util.List;

import javax.validation.Valid;

import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

public interface ResourceAllocationService {

	public List<EmployeeDto> getEarmarkedAssociates(Long projectId, Long requirementId) throws ResourceManagementException;

	public void saveResourceAllocations(Long projectId, Long requirementId, List<TAssociateProjectDto> tAssociateProjectDto) throws ResourceManagementException,ParseException;
   
	public List<EmployeeDto> getAssociatesDetails(long projectId,long requirementId,List<EmployeeDto> employeelist) throws ResourceManagementException;

	public EmployeeDto getAssociatesForTravelByIdOrName(String empIdOrName, @Valid long projectId, @Valid Long reqId) throws ResourceManagementException ;

	public void saveResourceTravelAllocations(List<TAssociateProjectDto> tAssociateProjectDto) throws ResourceManagementException;	
	
	
	  public List<EmployeeDto> getpoolToIntransitAllocationDtls(String empIdOrName,
	  Long currIntransitProjectId, Long requirmentId) throws
	  ResourceManagementException;

	public List<SkillTaxonomyDto> getSkillListForResource(Long employeeId) throws ResourceManagementException;

	public List<EmployeeDto> getAlllocatedFteRsrcForReq(@Valid Long requirementId) throws ResourceManagementException;
	 
	
}
