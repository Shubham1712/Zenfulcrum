package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;

import lombok.Data;
@Data
public class RMErrorDto implements Serializable{
	private static final long serialVersionUID = -4166064560040839678L;
	private String errorMessage;
	private String errorCause;
}
