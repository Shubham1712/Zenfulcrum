package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class ReasonForDeallocation implements Serializable{

	private static final long serialVersionUID = -4307035173628414889L;
	private Long reasonId;
    private String Reason;

}
