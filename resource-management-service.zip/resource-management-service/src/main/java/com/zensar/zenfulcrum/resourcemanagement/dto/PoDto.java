package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class PoDto implements Serializable {
	private static final long serialVersionUID = 2413557633915322699L;
	private int poId;
	private String poName;
}
