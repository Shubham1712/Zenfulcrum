package com.zensar.zenfulcrum.resourcemanagement.controller;

import java.text.ParseException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeallocationInputDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceDeAllocationService;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementUtil;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Api(tags = "ResourcesDeAllocationController")
@RestController
@Slf4j
@Validated
@RequestMapping(path = "resourcedeallocation")
public class ResourcesDeAllocationController {

	@Autowired
	private ResourceDeAllocationService resourceDeallocationService;

	/**
	 * Save the Resource for Deallocation.
	 * 
	 * @param List<TAssociateDeAllocationDto>
	 * @return
	 * @throws ResourceManagementException
	 * @throws ParseException 
	 */
	@PostMapping
	public ResponseEntity<RMResponseDto> saveResourceDeallocations(
			@Valid @RequestBody TAssociateDeallocationInputDto tassociateDeallocationInputDto)
			throws ResourceManagementException, ParseException {
		log.info("Start saveResourceDeallocations");
		RMResponseDto rmResponseDto = new RMResponseDto();

		if (null != tassociateDeallocationInputDto) {
			resourceDeallocationService.saveALLResourceDeallocation(tassociateDeallocationInputDto);
		} else {
			ResourceManagementUtil.createBadRequest(rmResponseDto, ResourceManagementConstant.PROVIDE_DATA,
					ResourceManagementConstant.VALUE_EMPTY);
			log.debug("Exiting saveResourceDeallocations");
			return ResponseEntity.badRequest().body(rmResponseDto);
		}
		log.info("End saveResourceDeallocations");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.CREATED);
	}
	
	//code 140421 started
	@GetMapping(value = "/releaseBudget")
	public ResponseEntity<RMResponseDto> budgetReleaseAfterResourceDeallocationsExit(
			@Valid @RequestParam(name = "projectId") Long projectId, 
			@Valid @RequestParam(name = "employeeId") Long employeeId,
			@Valid @RequestParam(name = "requirementId") Long requirementId,
			@Valid @RequestParam(name = "statusId") Long statusId) //allocation statusId
			throws ResourceManagementException, ParseException {
		
		log.info("Start budgetReleaseResourceDeallocationsExit");
		RMResponseDto rmResponseDto = new RMResponseDto();

		if (null != projectId &&  null != employeeId && null !=requirementId && null !=statusId) {
			
			resourceDeallocationService.budgetReleaseAfterResourceDeallocationsExit(projectId,employeeId,requirementId,statusId);
		} else {
			ResourceManagementUtil.createBadRequest(rmResponseDto, ResourceManagementConstant.PROVIDE_DATA,
					ResourceManagementConstant.VALUE_EMPTY);
			log.debug("Exiting budgetReleaseResourceDeallocationsExit");
			return ResponseEntity.badRequest().body(rmResponseDto);
		}
		
		log.info("End budgetReleaseResourceDeallocationsExit");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.CREATED);
	}
	
	//code 140421 end
}
