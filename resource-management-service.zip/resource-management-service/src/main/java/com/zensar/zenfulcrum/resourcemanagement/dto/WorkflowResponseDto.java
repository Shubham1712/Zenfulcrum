package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Data;
@Data
public class WorkflowResponseDto implements Serializable {
	private static final long serialVersionUID = 3193995275938685005L;
	private WorkflowMessage message;
	private WorkflowError error;
	private WorkflowData workflowOutput;
	
	@Data
	public class WorkflowMessage implements Serializable{
		private static final long serialVersionUID = 8157578725114736064L;
		private String message;
	}
	
	@Data
	public class WorkflowError implements Serializable{
		private static final long serialVersionUID = -4166064560040839678L;
		private String errorMessage;
		private String errorCause;
	}
	
	@Data
	public  class WorkflowData implements Serializable {
		private static final long serialVersionUID = -6368517603511530638L;
		private transient Object dataObject;
		private transient List<Object> dataObjectList;
	}


}
