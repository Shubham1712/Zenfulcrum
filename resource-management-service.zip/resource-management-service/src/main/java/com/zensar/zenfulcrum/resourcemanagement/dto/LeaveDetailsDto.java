package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.sql.Date;



import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class LeaveDetailsDto {

		private Long leaveId;
		private Long employeeId;
	    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	    private Date leaveStartDate;
	    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	    private Date leaveEndtDate;
	    private String status;
	    private String leaveType;
}
