package com.zensar.zenfulcrum.resourcemanagement.service;

import java.util.List;

import javax.validation.Valid;

import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateHistoryReportDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.BapReportDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ConfluenceAllocData;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectAndAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ReportServiceException;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.projection.TAssociateAllocationProjection;

public interface ResourceReportService {

	List<AssociateHistoryReportDto> resourceAllocationHistory(long empId);

	TAssociateAllocationDto getActualAndEstAllocationDate(long projectId, long empId)
			throws ResourceManagementException;

	BapReportDto getRequirementIds(long projectId) throws ResourceManagementException;

	List<TAssociateProjectAndAllocationDto> getAssociateDetailsByAssociateId(Long associateId);

	List<TAssociateDeAllocationDto> getAssociateDeallocationDetails();

	public List<TAssociateAllocationProjection> getAssociateAllocationIdByProjectId(List<Long> associateProjectIdList)
			throws ReportServiceException;

	List<TAssociateProjectAndAllocationDto> getAllocationWorkflowDetails();

	Long getAllocatedCount(Long projectId);

	List<ConfluenceAllocData> getProjAllocationDetails(@Valid long employeeNum) throws ResourceManagementException;
}
