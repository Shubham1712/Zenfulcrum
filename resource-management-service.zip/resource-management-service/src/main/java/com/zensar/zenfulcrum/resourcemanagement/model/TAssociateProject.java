package com.zensar.zenfulcrum.resourcemanagement.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name ="T_ASSOCIATE_PROJECT")
@Data
public class TAssociateProject {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ASSOCIATE_PROJECT_ID")	
	private Long associateProjectId;
	
	@Column(name="EMPLOYEE_ID")	
	private Long employeeId;
	
	@Column(name="SRF_ID")	
	private Long srfId;
	
	@Column(name="PROJECT_ID")	
	private Long projectId;
	
	@Column(name="SUPERVISOR_ID")	
	private Long supervisorId;
	
	@Column(name="IS_PRIMARY_PROJECT")	
	private Long isPrimaryProject;
	
	@Column(name="STATUS_ID")	
	private Long statusId;
	
	@Column(name="CREATED_BY")	
	private Long createdBy;
	
	@Column(name="LAST_UPDATED_BY")	
	private Long lastUpdatedBy;
	
	@Column(name="CREATED_DATE")	
	private Date createdDate;
	
	@Column(name="LAST_UPDATED_DATE")	
	private Date lastUpdatedDate;
	
	@Column(name="EFFECTIVE_START_DATE")	
	private Date effectiveStartDate;
	
	@Column(name="EFFECTIVE_END_DATE")	
	private Date effectiveEndDate;
	
	@OneToOne(mappedBy = "tAssociateProject", fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
	@EqualsAndHashCode.Exclude
    private TAssociateAllocation tAssociateAllocation;
}
