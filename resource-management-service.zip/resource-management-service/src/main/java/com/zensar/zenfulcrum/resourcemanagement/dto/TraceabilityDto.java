package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;

import lombok.Data;

@Data
public class TraceabilityDto {
	
	private List<TraceabilityCurrentStatusDto> currentStatus;
	
	private List<TraceabilityApprSummaryDto> approvalSummary;

}
