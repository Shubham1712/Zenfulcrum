package com.zensar.zenfulcrum.resourcemanagement.projection;

import java.util.Date;

public interface EstimatedEndDateProjection {
	
	public Long getassociateAllocationId();
	public Date getapprovedEndDate();
	public void setassociateAllocationId(Long l);
	public void setapprovedEndDate(Date date);


}
