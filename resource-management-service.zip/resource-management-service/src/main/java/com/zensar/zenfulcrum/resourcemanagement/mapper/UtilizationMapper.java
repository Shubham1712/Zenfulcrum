package com.zensar.zenfulcrum.resourcemanagement.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.resourcemanagement.dto.UtilizationProjectDetails;
import com.zensar.zenfulcrum.resourcemanagement.projection.ProjectDetailsProjection;

@Mapper(componentModel = "spring")
@Component
public interface UtilizationMapper {

	List<UtilizationProjectDetails> projectDetailsProjectionListToUtilizationProjectDetails(List<ProjectDetailsProjection> allocatedResourceProjectionList);
}
