package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class SkillDto implements Serializable,Comparable<SkillDto>{

	private static final long serialVersionUID = 3561931494508023714L;

	private Long skillId;
	
	private String skillName;

	@Override
	public int compareTo(SkillDto sd) {
		return this.skillName.compareTo(sd.skillName);
	}
}
