package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

/**
 * @author MM54168
 *
 */
@Data
public class LookupValueNewDto {
	private Long lookupValueId;
	private MLookupTypeDto lookupType;
	private String lookupValueCode;
	private String lookupValueDescription;
	private String lookUpValueName;
}
