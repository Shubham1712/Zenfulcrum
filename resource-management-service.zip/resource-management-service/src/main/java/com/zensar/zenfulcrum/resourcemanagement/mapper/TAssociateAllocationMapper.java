package com.zensar.zenfulcrum.resourcemanagement.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;

@Mapper(componentModel = "spring")
@Component
public interface TAssociateAllocationMapper {

	TAssociateAllocation tAssociateAllocationDtoToTAssociateAllocation(TAssociateAllocationDto valueDto);

	TAssociateAllocationDto tAssociateAllocationToTAssociateAllocationDto(TAssociateAllocation value);

	List<TAssociateAllocationDto> tAssociateAllocationToTAssociateAllocationDto(List<TAssociateAllocation> value);

	List<TAssociateAllocation> tAssociateAllocationDtoToTAssociateAllocation(List<TAssociateAllocationDto> value);

}
