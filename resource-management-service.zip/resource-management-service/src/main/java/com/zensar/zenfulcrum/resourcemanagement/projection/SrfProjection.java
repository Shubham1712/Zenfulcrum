package com.zensar.zenfulcrum.resourcemanagement.projection;

public interface SrfProjection {
	
	public Long getSrfId();
	public String getSrfNumber();
	public Long getCandidateId();
	public void setSrfId(long l);
    public void setSrfNumber(long l);
    public void setCandidateId(long l);

}
