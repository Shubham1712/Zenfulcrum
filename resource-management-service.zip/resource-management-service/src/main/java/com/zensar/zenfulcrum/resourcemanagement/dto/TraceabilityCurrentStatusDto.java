package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;

import lombok.Data;

@Data
public class TraceabilityCurrentStatusDto {

	private String employeeName;
	
	private String action;
	
	private String roleName;
	
	private String approverName;
	
	private long approverEmpId;
	
	private String comments;
	
	private String actionDate;
}
