package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class RoleDto {
	private long roleId;
	private String roleName;
}
