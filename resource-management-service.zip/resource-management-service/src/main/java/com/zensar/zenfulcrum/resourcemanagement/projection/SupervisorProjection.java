package com.zensar.zenfulcrum.resourcemanagement.projection;

public interface SupervisorProjection {
	
	public Long getEmpId();
	public String getEmpName();
	public Long getEmpNumber(); 
	
	public void setEmpId(Long empId);
	public void setEmpName(String empName); 
	public void setEmpNumber(Long empNumber); 
}
