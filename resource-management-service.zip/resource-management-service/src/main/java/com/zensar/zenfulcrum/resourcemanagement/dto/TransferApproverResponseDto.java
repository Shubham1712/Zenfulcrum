package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;

import lombok.Data;

@Data
public class TransferApproverResponseDto {
	List<RMApproversDto> rmSourceApproversListObj;
	FYIapproverDto fyiApproverDto;

	
	
}
