package com.zensar.zenfulcrum.resourcemanagement.projection;

import java.util.Date;

public interface AssociateDeAllocationProjection {
	
	public  Date getActualAllocationStartDate();
	
	public Date getActualAllocationEndDate();
	
	public Long getAssociateAllocationId();
	
	public Long getAssociateDeAllocationId();
	
	public Date getEstAllocationEndDate();
	
	public Date getDeallocationDate();
	
	public Double getFtePercent();	
	
	public Double getemployeeCostRate();

	
	public void setActualAllocationStartDate(Date startDate);
	
	public void setActualAllocationEndDate(Date endDate);
	
    public void setAssociateAllocationId(long associateAllocationId);
	
	public void setAssociateDeAllocationId(long associateDeAlocationId);
	
	public void setDeallocationDate(Date deAllocationDate);
	
	public Double setFtePercent(double ftePercent);	
	
	public Date setEstAllocationEndDate(Date estEndDate);
	
	
	public void setemployeeCostRate(Double d);


}
