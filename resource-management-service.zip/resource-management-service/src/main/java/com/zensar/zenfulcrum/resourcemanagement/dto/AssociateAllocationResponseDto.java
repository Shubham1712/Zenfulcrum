package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;

import com.zensar.zenfulcrum.resourcemanagement.projection.TAssociateAllocationProjection;

import lombok.Data;

@Data
public class AssociateAllocationResponseDto {

	public List<TAssociateAllocationProjection> associateAllocated;

}
