package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class ResourceSearchDto {

	Long totalCount;
	Double totalResourceAllocated;
	Double totalBillableResource;
	Double totalNonBillableResource;
	Double totalEBRResource;
	Double totalPoolResources;
	
	List<EmployeeDto> employeeList;
	
	private Long userId;
	private Long roleId;
	private Long projectId;
	private Long supervisorId;
	private Date estEndDate;
	private String roleName;
	private String userName;
	
	List<EmployeeDto> resourceAllocatedList;
	List<EmployeeDto> resourceReadyForAllocationList;
}
