package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zensar.zenfulcrum.resourcemanagement.projection.SrfProjection;

import lombok.Data;

@Data
public class EmployeeDto implements Serializable {
	
	
	public EmployeeDto() {
		super();
	}
	public EmployeeDto(Long associateAllocationId, Long employeeNumber, Long employeeId, String employeeName,
			int employeePracticeId, String practiceName, int employeeRoleId, String role, String band,
			int employeeLocationId, String employeeLocation, Date practiceAllocationStartDate,
			Date practiceAllocationEndDate,String emailId) {
		super();
		this.associateAllocationId = associateAllocationId;
		this.employeeNumber = employeeNumber;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeePracticeId = employeePracticeId;
		this.practiceName = practiceName;
		this.employeeRoleId = employeeRoleId;
		this.role = role;
		this.band = band;
		this.employeeLocationId = employeeLocationId;
		this.employeeLocation = employeeLocation;
		this.practiceAllocationStartDate = practiceAllocationStartDate;
		this.practiceAllocationEndDate = practiceAllocationEndDate;
		this.emailId=emailId;
	}

	private static final long serialVersionUID = 280223491417034148L;
	private Long associateAllocationId;
	private Long employeeNumber;
	private Long employeeId;
	private String employeeName;
	private int employeePracticeId;  
	private String practiceName;
	private int employeeRoleId;
	private String projectName;
	private String role;
	private String band;  
	private int matchFactor; 
	private Long availibility;
	private Long employeeProjectId;
	private List<SrfProjection> srfList;
	private long serviceLineId;
	private String serviceLineName; 
	private double fte_percent;
	//@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	private Date actualAllocationDate;
	//@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	private Date estimatedEndDate;
	private boolean isBillable;
	private int employeeLocationId;
	public String employeeLocation;
	private long resourceRequirementLocationId;
	private String resourceRequirementLocation;
	private String locationType;
    private long requirementRoleId;
	private String requirementRole;
	private List<ReasonForDeallocation> reasonForDeallocationList;
	private long requirementId;
	public String skills;
	private double billingRateInUSD;
    private String billingStatus;
    private Boolean primaryProjectStatusId;
    private String srfNo;
    private double billableUtilization;
    private double nonBillableUtilization;
   // @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
    private Date practiceAllocationStartDate;
    //@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
    private Date practiceAllocationEndDate;
    private long allocationTypeId;
    private String allocationType;
    private Long ProjectId;

    private double billingRatePerHour;
    private String ebrReason;
    private double projectUtilization;
    private String remarks;
    private String version;
    private String phaseName;
    private Boolean skillChampion;
    private Boolean isAllocated;
    private Boolean isReservedAllocation;
    private Boolean isAllocationApproved;
    private Boolean isReservedForDeallocation;
    private Boolean isDeallocationApproved;
    private String superVisiorName;
    private LeaveDetailsDto leaveDetails;
    
    private double availability;
    private double ebrUtilization;
    private String coe;
    private String coreNonBillable;
    
    private String poolProjectCode;
    private String poolProjectName;
    
    private double capHours;
    //@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	private Date effectiveStartDate;
	private String comments;
	private String supervisorName;
	private Long supervisorId;
	
    private Long associateProjectId;
   // @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
    private Date requestReceivedOn;
    //@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
    private Date estimatedProjectEndDate;
    //@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
    private Date estimatedExtendedEndDate;
    //@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
    private Date approvedReleaseDate;
	private List<SkillTaxonomyDto> skilltaxanomyList = new ArrayList<>();
	private Double employeeCostRate;
	private Long defaultL4SkillId;
	private String defaultL4SkillName;
	private SkillTaxonomyDto defaultSkillFamilyDto;
	private Long locationTypeId;
    private Boolean ifPrimaryProjectExists;
    private Boolean budgetAndCostCheck;
    private Double resourceRequirementCost;
	
	private Long srfId;
	 // @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	  @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	    private Date dateOfDeallocation;
	  
	 private String reasonForDeallocation;
	 private String primaryProjectStatusField;
	 private String projectCode;
	 private Long billiableEffortsHours;
	 private String skillType;
	 private Long associateDeAllocationId;
	  //@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	  @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	 private Date toBeAllocatedFrom;
	  
	 private String billableType;

	 private SuperVisiorDetailsDto supervisorDto;
	 private String hiveFlag;
	 private List<ServiceLineDto> serviceLineDto; 
	 private String approvedStatus;
	 
	 private String requestType;
	 private Integer billableStatusId;
	 
	 private String serviceName;
	 private String emailId;
	 private Boolean isAllowedToEdit;
	 
	 private String countryName;
	 
	//Added by Mrunal Marne for adding requirement est. end date
	 @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	 private Date estimatedRequirementEndDate;
	 
}
