package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Data;
@Data
public  class ResourceManagementDto implements Serializable {
	private static final long serialVersionUID = -6368517603511530638L;
	private transient Object dataObject;
	private transient List<Object> dataObjects;
}
