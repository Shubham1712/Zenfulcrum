package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class ResourceDashboardTransferDto {

	private EmployeeDto sourceProjectEmployeeDto;
	private EmployeeDto targetProjectEmployeeDto;
}
