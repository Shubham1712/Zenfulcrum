package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class TAssociateAllocationDto implements Serializable {
	private static final long serialVersionUID = 3305162587864873714L;

	private Long employeeId;

	private Long associateAllocationId;

	private Long associateProjectId;

	private Long roleId;

	private Long requirementId;

	private Long workLocationId;

	private Long billableStatusId;

	private Long billableStatusReasonId;

	private Long workflowReasonId;

	private Date estAllocationEndDate;

	private Date actualAllocationStartDate;

	private Date actualAllocationEndDate;

	private Double baseHours;

	private Double ftePercent;

	private String remarks;

	private Long workflowStatusId;

	private Long statusId;

	private Long createdBy;

	private Long lastUpdatedBy;

	private Date createdDate;

	private Date lastUpdatedDate;

	private Date effectiveStartDate;

	private Date effectiveEndDate;

	private Long allocationTypeId;
	
	private Long transactionHistoryId;

	private Long supervisorId;

	private Long skillId;

	private String srReference;

	private Double stdCost;
	
	private Long serviceLineId;

	private List<TAssociateAllocationBudgetDto> tAssociateAllocationBudget;

	private TAssociateProjectDto tAssociateProjectDto;
	
	//Added by Mrunal Marne for milestone selection while resource allocation
	private Long puchaseOrderId;
	
	private List<Long> poMilestoneIdList;
	
}
