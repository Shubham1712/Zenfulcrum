package com.zensar.zenfulcrum.resourcemanagement.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name ="T_ASSOCIATE_SKILL")
@Data
public class TAssociateSkill {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ASSOCIATE_SKILL_ID")	
	private Long associateSkillId;
	
	@Column(name="ASSOCIATE_ID")	
	private Long associateId;
	
	@Column(name="SKILL_COMPETANCY_ID")	
	private Long skillCompetancyId;
	
	@Column(name="SKILL_ID")	
	private Long skillId;
	
	@Column(name="EXPERIENCE_IN_MONTH")	
	private Long experienceInMonth;
	
	@Column(name="LAST_USED_MONTH")	
	private Integer lastUsedMonth;
	
	@Column(name="LAST_USED_YEAR")	
	private Integer lastUsedYear;
	
	@Column(name="STATUS_ID")
	private Integer statusId;
	
	@Column(name="CREATED_BY")
	private Integer createdBy;
	
	@Column(name="LAST_UPDATED_BY")	
	private Integer updatedBy;
	
	@Column(name="CREATED_DATE")	
	private Date createdDate;
	
	@Column(name="LAST_UPDATED_DATE")	
	private Date lastUpdatedDate;
}
