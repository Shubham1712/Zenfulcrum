package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;

import lombok.Data;

@Data
public class BapReportDto {
 	private String estimatedEfforts; 
	private String resourceDuration;
	private Long allocatedFte; 
	private String onshoreCount; 
	private String offshoreCount;
	
	private List<Long> requirementIds;
}
