package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class ResourceRequirementDto {

	private long reqId;
	private long requirementRoleId;
	private String requirementRole;
    private long projectId;
    private String projectCode;
	private String Skills;
	private String serviceName;
	private long resourceRequirementLocationId;
	private String resourceRequirementLocation;
	private double totalResourceQty;
	private double allocateResourceQty;
	private double billable;
	private String band;
	private double billingEffortsPerHrs;
	private double billingRateInUSD;
	private String billingStatus;
	private List<EmployeeDto> employeeList;
    private Integer noOfWorkingDays;
	private String shore;
	private long serviceLineId;
	private String  serviceLineName;
	private Long billableStatusId;
	//@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
   private Date requirementStartDate;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss", timezone="IST")
	//@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date requirementEndDate;
	private Date projectStartDate;
	private Date projectEndDate;
	private Double zenAccurateCurrency;
	private Double budgetCurrency;
	private Integer reservedQtyForAllocation;
	private Integer reservedQtyForDeallocation;
	private Integer requirementBillingStatusId;
	private List<Long> employeeIdList;
	private String version;
	private String role;
	public ResourceRequirementDto() {
       super();
	}
	private SkillTaxonomyDto skillfamily;
	private Double requirmentCostRate;
	private Double requirmentEffortsHours;
	private Long reqlocationTypeId;
	private String projectName;
	private List<NewLookUpDto> ebrReasonList;
	private Long payrollArrangementId;
    private String payrollArrangement;
    private Long resourceBillingStatusId;
    private Boolean budgetAndCostCheck; 
    private boolean isIntransitproject;
    private String buForProject;
    private double projectBillingHours;
    private String currencyName;
    private List<ServiceLineDto> serviceLineDto; 
    private String countryName;


}
