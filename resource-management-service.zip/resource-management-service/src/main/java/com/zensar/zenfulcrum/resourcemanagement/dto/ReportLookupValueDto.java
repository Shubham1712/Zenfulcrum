package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class ReportLookupValueDto {
	
	private Long lookupValueId;
	private MLookupTypeDto lookupType;
	private String lookupValueCode;
	private String lookupValueDescription;
}
