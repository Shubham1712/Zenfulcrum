package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class TAssociateAllocationBudgetDto implements Serializable {
	private static final long serialVersionUID = 3305162587864873714L;
	
	private Long associateAllocationBudgetId;
	
	private Long associateAllocationId;
	
	private String budgetAllocationMonth;
	
	private String budgetAllocatedMonth;
	
	private Double monthlyBudget;
	
	private Double monthlyAvailableBudget;
	
	private Double monthlyUsedBudget;
	
	private Long statusId;
	
	private Long createdBy;
	
	private Long lastUpdatedBy;
	
	private Date createdDate;
	
	private Date lastUpdatedDate;
	
	private Date effectiveStartDate;
	
	private Date effectiveEndDate;
}
