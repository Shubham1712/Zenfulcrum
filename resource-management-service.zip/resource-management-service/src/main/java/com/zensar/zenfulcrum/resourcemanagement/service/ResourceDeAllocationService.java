package com.zensar.zenfulcrum.resourcemanagement.service;


import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeallocationInputDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import java.text.ParseException;

public interface ResourceDeAllocationService {

	public void saveALLResourceDeallocation(TAssociateDeallocationInputDto tassociateDeallocationInputDto)
			throws ResourceManagementException,ParseException;

	//start code requirement 140421 
	public void budgetReleaseAfterResourceDeallocationsExit(Long projectId,Long employeeId, Long requirementId,Long statusId) throws ResourceManagementException;
	//end code requirement 140421 
}
