package com.zensar.zenfulcrum.resourcemanagement.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.zensar.zenfulcrum.resourcemanagement.dto.RMErrorDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceManagementDto;

@Component
public class ResourceManagementUtil {
	private ResourceManagementUtil() {
		super();
	}

	/**
	 * This method check uniqueness of list
	 * 
	 * @param collections
	 * @return
	 */
	public static boolean checkUnique(List<String> collections) {
		if (!CollectionUtils.isEmpty(collections)) {
			return collections.size() == collections.stream().distinct().count();
		}
		return true;
	}

	/**
	 * This method will create error response
	 * 
	 * @param APIResponse
	 * @param message
	 * @param cause
	 */
	public static void createBadRequest(RMResponseDto rmResponseDto, String message, String cause) {
		RMErrorDto rmErrorDto = new RMErrorDto();
		rmErrorDto.setErrorMessage(message);
		rmErrorDto.setErrorCause(cause);
		rmResponseDto.setError(rmErrorDto);
	}

	/**
	 * This method set API data to response
	 * 
	 * @param APIResponse
	 * @param object
	 */
	public static void setResourceManagementDto(RMResponseDto rmResponseDto, Object object) {
		ResourceManagementDto rResourceManagementDto = new ResourceManagementDto();
		rResourceManagementDto.setDataObject(object);
		rmResponseDto.setResourceManagementDto(rResourceManagementDto);
	}
	
	/**
	 * This method set API data to response
	 * 
	 * @param APIResponse
	 * @param object
	 */
	public static void setResourceManagementDtoList(RMResponseDto rmResponseDto, List<Object> object) {
		ResourceManagementDto rResourceManagementDto = new ResourceManagementDto();
		rResourceManagementDto.setDataObjects(object);
		rmResponseDto.setResourceManagementDto(rResourceManagementDto);
	}
	
	/**
	 * This method checks if input is EmployeeName or String
	 * 
	 * @param APIResponse
	 * @param object
	 */
	
	public static boolean isNumeric(String search) {
	    try {
	         Long.parseLong(search);
	    } catch (NumberFormatException nfe) {
	        return false;
	    }
	    return true;
	}
	
	/**
	 * Prepares a list object with possible submodule names or request types
	 * @return
    */
	public List<String> getListOfRequestTypes(){
		List<String> requestTypeList = new ArrayList<>(); 
		requestTypeList.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		requestTypeList.add(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		requestTypeList.add(ResourceManagementConstant.RESOURCE_TRANSFER);
		requestTypeList.add(ResourceManagementConstant.RESOURCE_EXTENSION);
		return requestTypeList;
	}	


	
}
