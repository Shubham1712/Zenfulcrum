package com.zensar.zenfulcrum.resourcemanagement.service;


import java.text.ParseException;
import java.util.List;

import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PoAndMilestoneDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApproversDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TransferApproverResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

public interface ResourceManagementService {
	public  List<ProjectDto> getProjectList(long userId,long roleId) throws ResourceManagementException;

	public List<RMApproversDto> getRMApproversList(long projectId, long userId, long roleId, String requestType, Boolean isRequiredDuringRejection) throws ResourceManagementException;
		
	public void submitRMApproval(List<RMApprovalInputDto> rmApprovalDtlsList) throws ResourceManagementException;
    
    public void approveOrRejectRMApproval(List<RMApprovalInputDto> rmApproveOrRejectDtls) throws ResourceManagementException, ParseException;

    public void rejectRMSavedResources(List<RMApprovalInputDto> rejectResourceDtlsList) throws ResourceManagementException;

    public TransferApproverResponseDto getRMTransferApproversList(long sourceProjectId,long targetProjectId, long userId, long roleIds,String requestType) throws ResourceManagementException;

    public void approveOrRejectRMApprovalForExtension(List<RMApprovalInputDto> rmApproveOrRejectDtls) throws ResourceManagementException;

	public CostCardDto getCostCard(CostCardInputDto costCardInputDto) throws ResourceManagementException;

	List<EmployeeDto> getAllEmployeeDetails(String searchParameter) throws ResourceManagementException;
	
	//Added by Mrunal Marne for milestone selection while resource allocation
	public List<PoAndMilestoneDetailsDto> getPoAndMilestoneDetailsByProjectId(Long projectId, String allocStartDate, String allocEndDate) throws ResourceManagementException;
	
	//Added by Mrunal Marne for RMG Tagging
	/*public List<LookupValueDto> getRMGTypeDetailsDtos() throws ResourceManagementException;
	
	public TAssociateRmgTagDto saveRmgTagging(TAssociateRmgTagDto rmgTaggingDto) throws ResourceManagementException, ParseException;
	
	public TAssociateRmgTagDto getRmgTagging(Long employeeNumber) throws ResourceManagementException;*/
}
