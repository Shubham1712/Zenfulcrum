package com.zensar.zenfulcrum.resourcemanagement.service;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import com.zensar.zenfulcrum.resourcemanagement.dto.QuarterDetailDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceUtilizationSummaryDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UtilizationDetailDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

public interface ResourceUtilizationService {

	public List<QuarterDetailDto> getQuarterDetailsForYear()throws ResourceManagementException,ParseException;
	public UtilizationDetailDto getResourceUtilization(Long empId, String startDate, String endDate)throws ResourceManagementException,ParseException;
	ResourceUtilizationSummaryDto getResourceUtilizationSummaryDetails(Long projectId) throws ResourceManagementException;


}
