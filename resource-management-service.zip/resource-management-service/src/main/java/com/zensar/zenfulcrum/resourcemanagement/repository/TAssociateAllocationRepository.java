package com.zensar.zenfulcrum.resourcemanagement.repository;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zensar.zenfulcrum.resourcemanagement.dto.ConfluenceAllocData;
import com.zensar.zenfulcrum.resourcemanagement.dto.SupervisorDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocDataProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AssociateDeAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AvaibalityProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.GetResourceReqProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.ModuleProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.ProjectDetailsProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.ReservedAssociateProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.SupervisorProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.TAssociateAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.TAssociateProjectAndAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

@Repository
public interface TAssociateAllocationRepository extends JpaRepository<TAssociateAllocation, Long> {
	
	@Query(value = "SELECT requirement_id AS RequirementId ,SUM(TA.fte_percent/100)  AS AllocatedFte\r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT TP  \r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id \r\n"
			+ "WHERE TA.requirement_id IN :requirementIds AND  TP.project_id = :projectId AND TA.status_id = :statsuIdforActivate AND TA.workflow_status_id IN (:workflowIds) AND (TA.`actual_allocation_end_date` IS NULL OR TA.`actual_allocation_end_date`='1111-11-11 00:00:00') GROUP BY 1", nativeQuery = true)
	List<GetResourceReqProjection> getAllAllocatedResourceByRequirementId(
			@Param("requirementIds") List<Long> requirementIds, @Param("projectId") Long projectId,
			@Param("statsuIdforActivate") Long statsuIdforActivate,List<Long> workflowIds);


	@Query(value = "SELECT requirement_id AS RequirementId ,SUM(TA.fte_percent/100)  AS AllocatedFte\r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT TP  \r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id \r\n"
			+ "WHERE TA.requirement_id IN :requirementIds AND  TP.project_id = :projectId AND TA.status_id = :statsuIdforActivate AND (TA.`actual_allocation_end_date` IS NULL OR TA.`actual_allocation_end_date`='1111-11-11 00:00:00') GROUP BY 1", nativeQuery = true)
	List<GetResourceReqProjection> getAllocatedResourceByRequirementId(
			@Param("requirementIds") List<Long> requirementIds, @Param("projectId") Long projectId,
			@Param("statsuIdforActivate") Long statsuIdforActivate);

	@Query(value = "SELECT  employee_id AS EmployeeId ,SUM(fte_percent)  AS AllocatedFte FROM  T_ASSOCIATE_ALLOCATION JOIN T_ASSOCIATE_PROJECT\r\n"
			+ "ON  T_ASSOCIATE_ALLOCATION.associate_project_id =  T_ASSOCIATE_PROJECT.associate_project_id\r\n"
			+ "WHERE T_ASSOCIATE_PROJECT.employee_id IN :employeeIds AND T_ASSOCIATE_ALLOCATION.status_id = :statusIdForActivate AND T_ASSOCIATE_ALLOCATION.`billable_status_id` != :statusIdForPool  GROUP BY 1;", nativeQuery = true)
	List<AvaibalityProjection> getAllocatedResourceAvaibality(@Param("employeeIds") List<Long> employeeIds,
			@Param("statusIdForActivate") Long statusIdForActivate, @Param("statusIdForPool") Long statusIdForPool);
	
	@Query(value = "SELECT  employee_id AS EmployeeId ,SUM(fte_percent)  AS AllocatedFte \r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION JOIN T_ASSOCIATE_PROJECT\r\n"
			+ "ON  T_ASSOCIATE_ALLOCATION.associate_project_id =  T_ASSOCIATE_PROJECT.associate_project_id\r\n"
			+ "WHERE T_ASSOCIATE_PROJECT.employee_id IN :employeeIds \r\n"
			+ "AND T_ASSOCIATE_ALLOCATION.status_id = :statusIdForActivate \r\n"
			+ "AND T_ASSOCIATE_ALLOCATION.`billable_status_id` = :statusIdForPool  \r\n"
			+ "AND T_ASSOCIATE_ALLOCATION.workflow_status_id= :statusIdForallocApproved\r\n"
			+ "GROUP BY 1", nativeQuery = true)
	List<AvaibalityProjection> getAllocatedResourceAvailabilityForPractice(@Param("employeeIds") List<Long> employeeIds,
			@Param("statusIdForActivate") Long statusIdForActivate, @Param("statusIdForPool") Long statusIdForPool, @Param("statusIdForallocApproved") Long statusIdForallocApproved);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate ,TA.`std_cost` AS employeeCostRate,TA.`skill_id` AS defaultSkillId \r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT  TP\r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id\r\n"
			+ "WHERE TA.requirement_id IN :requirementIds AND  TP.project_id= :projectId AND TA.status_id = :wfStatusIdForActivate AND TA.workflow_status_id = :wfStatisIdForApproved", nativeQuery = true)
	List<AllocatedResourceProjection> getAssociatesByRequirementId(@Param("requirementIds") List<Long> requirementIds,
			@Param("projectId") Long projectId, @Param("wfStatusIdForActivate") Long wfStatusIdForActivate,
			@Param("wfStatisIdForApproved") Long wfStatisIdForApproved);

	@Query(value = "SELECT IFNULL(SUM(TA.fte_percent/100), 0)  \r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT TP  \r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id \r\n"
			+ "WHERE TA.requirement_id IN :requirmentIdList AND  TP.project_id= :projectId AND TA.status_id = :wfStatusIdForActivate AND  TA.billable_status_id IN :billableStatusID  AND TA.workflow_status_id=:wfStatusIdForApproved AND (TA.`actual_allocation_end_date` IS NULL OR TA.`actual_allocation_end_date`='1111-11-11 00:00:00')", nativeQuery = true)
	Double getTotalAllocatedBillbleFteForProject(@Param("requirmentIdList") List<Long> requirmentIdList,
			@Param("projectId") Long projectId, @Param("wfStatusIdForActivate") Long wfStatusIdForActivate,
			@Param("billableStatusID") List<Long> billableStatusID, @Param("wfStatusIdForApproved") Long wfStatusIdForApproved);

	@Query(value = "SELECT IFNULL(SUM(TA.fte_percent/100), 0) \r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT TP  \r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id \r\n"
			+ "WHERE TA.requirement_id IN :requirmentIdList AND  TP.project_id= :projectId AND TA.status_id = :wfStatusIdForActivate AND  TA.billable_status_id = :ebrStatusId AND TA.workflow_status_id=:wfStatusIdForApproved", nativeQuery = true)
	Double getTotalAllocatedEBRFteForProject(@Param("requirmentIdList") List<Long> requirmentIdList,
			@Param("projectId") Long projectId, @Param("wfStatusIdForActivate") Long wfStatusIdForActivate,
			@Param("ebrStatusId") Long ebrStatusId, @Param("wfStatusIdForApproved") Long wfStatusIdForApproved);

	@Query(value = "SELECT SUM(TA.fte_percent/100) \r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT TP  \r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id \r\n"
			+ "WHERE TA.requirement_id IN :requirementIds AND  TP.project_id= :projectId AND TA.status_id = :wfStatusIdForActivate AND  TA.billable_status_id = :billableStatusID", nativeQuery = true)
	Double getTotalAllocatedFteForProject(@Param("requirementIds") List<Long> requirementIds,
			@Param("projectId") Long projectId, @Param("wfStatusIdForActivate") Long wfStatusIdForActivate,
			@Param("billableStatusID") Long billableStatusID);

	@Query(value = "SELECT talloc.* FROM (T_ASSOCIATE_ALLOCATION talloc INNER JOIN T_ASSOCIATE_PROJECT tpro ON tpro.associate_project_id=talloc.associate_project_id) WHERE tpro.project_id=:projectId  AND talloc.status_id=:statusId AND tpro.employee_id IN (:empIdList) AND talloc.requirement_id=:requirementId AND talloc.workflow_status_id = :workflowStatusId", nativeQuery = true)
	List<TAssociateAllocation> getRAllocationDetails(@Param("projectId") long projectId,
			@Param("statusId") long statusId, @Param("empIdList") List<Long> empIdList,
			@Param("requirementId") long requirementId,@Param("workflowStatusId") Long workflowStatusId) throws ResourceManagementException;
  
	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_ALLOCATION SET  `workflow_status_id` = :deAllocApprovedStatusId , status_id=:statusId, `actual_allocation_end_date` = :deallocationDate, last_updated_by=:userId, last_updated_date= NOW(), effective_end_date= NOW() WHERE associate_allocation_id IN (:rmAllocTranscIdList)", nativeQuery = true)
	void updateStatusAndEffectiveEndDate(@Param("deAllocApprovedStatusId") long deAllocApprovedStatusId,
			@Param("rmAllocTranscIdList") List<Long> rmAllocTranscIdList,
			@Param("deallocationDate") Date deallocationDate, @Param("statusId") Long statusId, @Param("userId") Long userId) throws ResourceManagementException;

	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_ALLOCATION SET status_id=:statusId, effective_start_date=:effectiveEndDate, last_updated_date = NOW() WHERE associate_allocation_id IN (:rmAllocTranscIdList)", nativeQuery = true)
	void deactivateAllocTransaction(@Param("statusId") long statusId,
			@Param("rmAllocTranscIdList") List<Long> rmAllocTranscIdList,
			@Param("effectiveEndDate") Date effectiveEndDate) throws ResourceManagementException;

	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_ALLOCATION SET status_id = :statusId, workflow_status_id = :statusId  WHERE ASSOCIATE_PROJECT_ID IN\r\n"
			+ "	(SELECT ASSOCIATE_PROJECT_ID FROM T_ASSOCIATE_PROJECT WHERE EMPLOYEE_ID IN :resourceIdList AND PROJECT_ID =:projectId)\r\n"
			+ "	AND REQUIREMENT_ID = :reqId", nativeQuery = true)
	void rejectRMSavedResources(@Param("statusId") long statusId, @Param("resourceIdList") List<Long> resourceIdList,
			@Param("reqId") long requirementId, @Param("projectId") long projectId) throws ResourceManagementException;
	
	//Added by Mrunal Marne for removing records for RM Allocation saved on rejection by Project Manager
	@Modifying
	@Transactional
	@Query(value = "DELETE FROM T_ASSOCIATE_ALLOCATION \r\n"
			+ "WHERE ASSOCIATE_PROJECT_ID IN (SELECT ASSOCIATE_PROJECT_ID FROM T_ASSOCIATE_PROJECT WHERE EMPLOYEE_ID IN (:resourceIdList) AND PROJECT_ID =:projectId) \r\n"
			+ "AND REQUIREMENT_ID = :reqId", nativeQuery = true)
	void removeRMSavedResources(@Param("resourceIdList") List<Long> resourceIdList, @Param("reqId") long requirementId, 
			@Param("projectId") long projectId) throws ResourceManagementException;
	//End by Mrunal Marne

	@Query(value = "SELECT COUNT(*) FROM (T_ASSOCIATE_ALLOCATION talloc\r\n"
			+ "INNER JOIN T_ASSOCIATE_PROJECT tpro ON tpro.associate_project_id=talloc.associate_project_id)\r\n"
			+ "WHERE tpro.project_id= :projectId  AND talloc.status_id= :statusId", nativeQuery = true)
	Integer getActiveStatusCount(@Param("projectId") long projectId, @Param("statusId") long statusId);

	@Query(value = "SELECT requirement_id AS RequirementId ,SUM(TA.fte_percent/100)  AS AllocatedFte\r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT TP  \r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id \r\n"
			+ "WHERE TA.requirement_id IN :requirementIds AND  TP.project_id = :projectId AND TA.billable_status_id = :billableStatusID AND TA.status_id = :statsuIdforActivate GROUP BY 1", nativeQuery = true)
	List<GetResourceReqProjection> getBillableFTEForRequirementId(@Param("requirementIds") List<Long> requirementIds,
			@Param("projectId") Long projectId, @Param("statsuIdforActivate") Long statsuIdforActivate,@Param("billableStatusID") Long billableStatusID);

	/*
	 * @Modifying
	 * 
	 * @Transactional
	 * 
	 * @Query(value =
	 * "UPDATE T_ASSOCIATE_ALLOCATION SET status_id = :statusId , LAST_UPDATED_DATE = NOW() , LAST_UPDATED_BY = :userId WHERE REQUIREMENT_ID =:reqId AND ASSOCIATE_PROJECT_ID IN (SELECT ASSOCIATE_PROJECT_ID FROM T_ASSOCIATE_PROJECT WHERE PROJECT_ID =:projectId AND EMPLOYEE_ID IN :employeeIdList)"
	 * , nativeQuery = true) void deactivateResourceAllocation(@Param("projectId")
	 * Long projectId,@Param("reqId") Long reqId,@Param("employeeIdList") List<Long>
	 * employeeIdList,
	 * 
	 * @Param("statusId") long statusId,@Param("userId") Long userId);
	 */

	@Query(value = "SELECT a.* FROM T_ASSOCIATE_ALLOCATION a INNER JOIN T_ASSOCIATE_PROJECT b ON a.associate_project_id= b.associate_project_id WHERE employee_id IN :employeeIdList", nativeQuery = true)
	List<TAssociateAllocation> getAllocationListByEmployeeId(@Param("employeeIdList") List<Long> employeeIdList);

	@Modifying
	@Transactional
	@Query(value = "UPDATE `T_ASSOCIATE_ALLOCATION` SET STATUS_ID = :statusId , LAST_UPDATED_DATE = NOW() , LAST_UPDATED_BY = :userId\r\n"
			+ "WHERE ASSOCIATE_PROJECT_ID IN (SELECT ASSOCIATE_PROJECT_ID FROM `T_ASSOCIATE_PROJECT` WHERE EMPLOYEE_ID IN :employeeIdList AND PROJECT_ID = :projectId)", nativeQuery = true)
	void deactiveCurrEmpAlloStatus(@Param("employeeIdList") List<Long> employeeIdList, @Param("statusId") long statusId,
			@Param("projectId") long projectId, @Param("userId") long userId) throws ResourceManagementException;

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TA.`std_cost` AS employeeCostRate,TA.`skill_id` AS defaultSkillId \r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT  TP\r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id\r\n"
			+ "WHERE TP.project_id= :projectId", nativeQuery = true)
	List<AllocatedResourceProjection> getAllocatedResourceToTransfer(@Param("projectId") Long projectId);

	@Query(value = "SELECT SUM(TA.fte_percent/100) \r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT TP  \r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id \r\n"
			+ "WHERE  TP.project_id= :projectId AND TA.billable_status_id = 42;", nativeQuery = true)
	Double getTotalAllocatedBillbleFteForTransfer(@Param("projectId") Long projectId);

	@Query(value = "SELECT SUM(TA.fte_percent/100) \r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT TP  \r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id \r\n"
			+ "WHERE  TP.project_id= :projectId AND TA.billable_status_id = 2;", nativeQuery = true)
	Double getTotalAllocatedEBRFteForTransfer(@Param("projectId") Long projectId);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,\r\n"
			+ "TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,\r\n"
			+ "TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,\r\n"
			+ "TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TA.role_id AS allocatedProjectRole,TA.work_location_id AS allocatedProjectLocation,TA.`std_cost` AS employeeCostRate,TA.`skill_id` AS defaultSkillId\r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA INNER JOIN T_ASSOCIATE_PROJECT  TP\r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id\r\n"
			+ "WHERE TP.project_id= :projectId And TP.employee_id= :employeeId AND TA.status_id= :statusIdForActivate AND TA.workflow_status_id = :statusIdForApproved", nativeQuery = true)
	AllocatedResourceProjection getIntrnsitProjectResource(@Param("projectId") Long projectId,
			@Param("employeeId") Long employeeId,@Param("statusIdForActivate") Long statusIdForActivate,@Param("statusIdForApproved") Long statusIdForApproved);

	@Query(value = "SELECT requirement_id AS requirementId ,COUNT(`requirement_id`) AS reservedAssociateCount FROM `T_ASSOCIATE_ALLOCATION` WHERE `workflow_status_id` IN :workflowStausIds AND `status_id` = :wfStatusIdForActivate AND requirement_id IN :requirmentIdList  GROUP BY 1;", nativeQuery = true)
	List<ReservedAssociateProjection> getReservedAssociateForAllocation(
			@Param("workflowStausIds") List<Long> workflowStausIds,
			@Param("wfStatusIdForActivate") Long wfStatusIdForActivate,
			@Param("requirmentIdList") List<Long> requirmentId);

	@Query(value = "SELECT  employee_id AS EmployeeId ,SUM(fte_percent)  AS AllocatedFte FROM  T_ASSOCIATE_ALLOCATION JOIN T_ASSOCIATE_PROJECT\r\n"
			+ "ON  T_ASSOCIATE_ALLOCATION.associate_project_id =  T_ASSOCIATE_PROJECT.associate_project_id\r\n"
			+ "WHERE T_ASSOCIATE_PROJECT.employee_id= :empId AND T_ASSOCIATE_ALLOCATION.status_id= :statusId AND T_ASSOCIATE_ALLOCATION.workflow_status_id= :workflowId GROUP BY 1", nativeQuery = true)
	AvaibalityProjection getAllocatedResourceAvail(@Param("empId") Long empId, @Param("statusId") long statusId,
			@Param("workflowId") long workflowId);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,\r\n"
			+ "TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,\r\n"
			+ "TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,\r\n"
			+ "TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TA.role_id AS allocatedProjectRole,TA.work_location_id AS allocatedProjectLocation, TA.skill_champion_flag AS Flag\r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA INNER JOIN T_ASSOCIATE_PROJECT  TP\r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id\r\n"
			+ "WHERE TP.employee_id= :employeeId AND  TA.fte_percent > 0 AND TA.status_id= :statusId AND TP.is_primary_project= 1 AND TA.workflow_status_id = :statusForAllocApproved AND TA.billable_status_id != :lookupIdForPool", nativeQuery = true)
	AllocatedResourceProjection getAllocatedResourceToTravel(@Param("employeeId") Long employeeId,
			@Param("statusId") long statusId, @Param("statusForAllocApproved") Long statusForAllocApproved, @Param("lookupIdForPool") Long lookupIdForPool);

	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_ALLOCATION SET workflow_status_id=:statusId WHERE associate_allocation_id IN (:rmAllocTranscIdList)", nativeQuery = true)
	void updateWorkflowStatus(@Param("rmAllocTranscIdList") List<Long> rmAllocTranscIdList,
			@Param("statusId") long statusId) throws ResourceManagementException;
	
	@Modifying
	@Transactional
	@Query(value = " UPDATE T_ASSOCIATE_ALLOCATION SET `effective_start_date` = CURRENT_TIMESTAMP() WHERE associate_allocation_id IN (:rmAllocTranscIdList) AND DATE(`actual_allocation_start_date`) =  CURDATE()", nativeQuery = true)
	void updateffectiveDate(@Param("rmAllocTranscIdList") List<Long> rmAllocTranscIdList) throws ResourceManagementException;


	@Query(value = "SELECT * FROM `T_ASSOCIATE_ALLOCATION` WHERE requirement_id = :requirementID AND \r\n"
			+ "	status_id = :statusId AND workflow_status_id IN (:workflowStatusId) AND associate_project_id IN \r\n"
			+ "	(SELECT associate_project_id FROM `T_ASSOCIATE_PROJECT` WHERE employee_id = :empId AND project_id = :projectId )", nativeQuery = true)
	TAssociateAllocation getCurrentProjectAllocationId(@Param("empId") long empId,
			@Param("requirementID") long requirementId, @Param("projectId") long projectId,
			@Param("statusId") long statusId, @Param("workflowStatusId") List<Long> workflowStatusId);

	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_ALLOCATION SET status_id = :statusIdtoBeUpdated , WORKFLOW_STATUS_ID = :wrkflwStatusId WHERE ASSOCIATE_PROJECT_ID IN (SELECT ASSOCIATE_PROJECT_ID FROM T_ASSOCIATE_PROJECT WHERE EMPLOYEE_ID IN (:resourceIdList) AND project_id IN (:projectIdList)) AND STATUS_ID = :statusIdPresent AND transaction_history_Id IN (:transactionHistoryIdList)", nativeQuery = true)
	void rejectRMSavedResourcesForTransfer(@Param("statusIdtoBeUpdated") long statusIdtoBeUpdated,
			@Param("resourceIdList") List<Long> resourceIdList, @Param("projectIdList") List<Long> projectIdList,
			@Param("transactionHistoryIdList") List<Long> transactionHistoryIdList,
			@Param("statusIdPresent") long statusIdPresent, @Param("wrkflwStatusId") long wrkflwStatusId)
			throws ResourceManagementException;
	
	//Added by Mrunal Marne for removing records for RM transfer saved on rejection by Project Manager
	@Modifying
	@Transactional
	@Query(value = "DELETE FROM T_ASSOCIATE_ALLOCATION\r\n"
			+ "WHERE ASSOCIATE_PROJECT_ID IN (SELECT ASSOCIATE_PROJECT_ID FROM T_ASSOCIATE_PROJECT WHERE EMPLOYEE_ID IN (:resourceIdList) AND project_id IN (:projectIdList)) \r\n"
			+ "AND workflow_status_id = :workflowStatusId AND status_id = :statusId AND requirement_id IN (:requirementIdList) ", nativeQuery = true)
	void removeRMSavedResourcesForTransfer(@Param("resourceIdList") List<Long> resourceIdList, @Param("projectIdList") List<Long> projectIdList, 
			@Param("workflowStatusId") Long workflowStatusId, @Param("statusId") long statusId, @Param("requirementIdList") List<Long> requirementIdList) 
					throws ResourceManagementException;
	//End by Mrunal

	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_ALLOCATION SET status_id = :statusId ,workflow_status_id=:workflowStatusId, LAST_UPDATED_DATE = NOW() ,EFFECTIVE_END_DATE =:allocationEndDate, EST_ALLOCATION_END_DATE = :allocationEndDate, ACTUAL_ALLOCATION_END_DATE = :allocationEndDate,LAST_UPDATED_BY = :userId WHERE REQUIREMENT_ID = :requirementId AND ASSOCIATE_ALLOCATION_ID IN :transactionHistoryIdList", nativeQuery = true)
	void deactivateResourceAllocation(@Param("transactionHistoryIdList") List<Long> transactionHistoryIdList,
			@Param("statusId") long statusId, @Param("userId") Long userId, @Param("requirementId") Long requirementId,
			@Param("allocationEndDate") Date allocationEndDate, @Param("workflowStatusId") Long workflowStatusId);
	
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_ALLOCATION SET workflow_status_id=:workflowStatusId, LAST_UPDATED_DATE = NOW() ,EFFECTIVE_END_DATE =:allocationEndDate, ACTUAL_ALLOCATION_END_DATE = :allocationEndDate,LAST_UPDATED_BY = :userId WHERE  ASSOCIATE_ALLOCATION_ID = :transactionHistoryIdList", nativeQuery = true)
	void deactivateResourceAllocationForSourceRec(@Param("transactionHistoryIdList") Long transactionHistoryIdList,
			@Param("userId") Long userId,@Param("allocationEndDate") LocalDateTime allocationEndDate, @Param("workflowStatusId") Long workflowStatusId);

	@Query(value = "SELECT * FROM T_ASSOCIATE_ALLOCATION WHERE TRANSACTION_HISTORY_ID IN :transactionHistoryIdList", nativeQuery = true)
	List<TAssociateAllocation> getPreviousDataByTransactionHistoryId(
			@Param("transactionHistoryIdList") List<Long> transactionHistoryIdList);


	@Query(value = "SELECT * FROM T_ASSOCIATE_ALLOCATION allo INNER JOIN T_ASSOCIATE_PROJECT pro ON allo.associate_project_id = pro.associate_project_id\r\n"
			+ " WHERE  pro.project_id = :projectId AND allo.status_id = :statusId AND workflow_status_id= :approvedWorkFlowId AND pro.status_id = :statusId", nativeQuery = true)
	List<TAssociateAllocation> getAssociateListByProjectId(@Param("projectId") long projectId,
			@Param("statusId") long statusId, Long approvedWorkFlowId) throws ResourceManagementException;

	@Query(value = "SELECT * FROM T_ASSOCIATE_ALLOCATION WHERE REQUIREMENT_ID =:requirementId AND ASSOCIATE_PROJECT_ID = (SELECT ASSOCIATE_PROJECT_ID FROM T_ASSOCIATE_PROJECT WHERE EMPLOYEE_ID =:empId AND PROJECT_ID =:currentProjectId) ", nativeQuery = true)
	TAssociateAllocation getCurrentProjectData(Long requirementId, long currentProjectId, long empId);

	@Query(value = "SELECT COUNT(DISTINCT pro.employee_id) FROM T_ASSOCIATE_ALLOCATION allo INNER  JOIN T_ASSOCIATE_PROJECT pro ON allo.associate_project_id = pro.associate_project_id WHERE allo.status_id = :statusId", nativeQuery = true)
	Long getTotalResourceAllocatedCount(@Param("statusId") long statusId);

	@Query(value = "SELECT SUM(taa.fte_percent/100) FROM T_ASSOCIATE_PROJECT tap INNER JOIN T_ASSOCIATE_ALLOCATION taa ON taa.associate_project_id = tap.associate_project_id WHERE tap.employee_id IN (:empIdList) AND taa.billable_status_id IN (:billableStatusId) AND taa.status_id=:statusId AND tap.status_id =:statusId AND taa.workflow_status_id=:wrkflwStatusId", nativeQuery = true)
	Double getBillabilityCount(@Param("billableStatusId") List<Long> billableStatusId, @Param("statusId") long statusId,
			@Param("empIdList") List<Long> empIdList,@Param("wrkflwStatusId") long wrkflwStatusId);

	@Query(value = "SELECT pro.employee_id FROM T_ASSOCIATE_ALLOCATION allo INNER  JOIN T_ASSOCIATE_PROJECT pro ON \r\n"
			+ "allo.associate_project_id = pro.associate_project_id WHERE pro.employee_id IN\r\n"
			+ "(SELECT DISTINCT pro.employee_id FROM `T_ASSOCIATE_ALLOCATION` allo INNER  JOIN T_ASSOCIATE_PROJECT pro ON \r\n"
			+ "allo.associate_project_id = pro.associate_project_id WHERE pro.project_id = :projectId) \r\n"
			+ "AND allo.workflow_status_id IN (:workflowStatusIdList) AND allo.STATUS_ID = :statusId", nativeQuery = true)
	List<Long> getEmpIdListBasedOnWorkflowStatus(@Param("projectId") long projectId,
			@Param("workflowStatusIdList") List<Long> workflowStatusIdList, @Param("statusId") long statusId);

	/*@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.status_id AS StatusId,TA.workflow_status_id AS WorkflowStatusId,TA.allocation_type_id AS AllocationTypeId,TA.actual_allocation_end_date AS ActualAllocationEndDate,TA.service_line_id AS ServiceLineId,TA.associate_project_id AS AssociateProjectId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TP.`srf_id` AS srfId,TP.`supervisor_id` AS superVisorId ,TA.`cap_hr` AS capHours,TA.`remarks` AS comments,TA.`billable_status_reason_id` AS ebrReason,TA.`std_cost` AS employeeCostRate,TA.`skill_id` AS defaultSkillId, TA.skill_champion_flag AS skillChampionFlag  \r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "WHERE TP.`employee_id`= :employeeId AND TA.`status_id` = :statusId AND TA.`workflow_status_id` IN :workflowStatusId  AND `actual_allocation_start_date` <= NOW() AND TA.billable_status_id != :lookupIdForPool AND TA.requirement_id IS NOT NULL AND TA.allocation_type_id != :allocationTypeId", nativeQuery = true)
	List<AllocatedResourceProjection> searchAllocatedToProject(@Param("employeeId") Long employeeId,
			@Param("statusId") Long statusId, @Param("workflowStatusId") List<Long> workflowStatusId,@Param("lookupIdForPool") Long lookupIdForPool, @Param("allocationTypeId") Long allocationTypeId);*/
	
	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.status_id AS StatusId,TA.workflow_status_id AS \r\n"
			+ "WorkflowStatusId,TA.allocation_type_id AS AllocationTypeId,TA.actual_allocation_end_date AS ActualAllocationEndDate,TA.service_line_id AS \r\n"
			+ "ServiceLineId,TA.associate_project_id AS AssociateProjectId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS \r\n"
			+ "ProjectId,TP.is_primary_project AS IsPrimaryProjectFlag ,TA.fte_percent AS FtePercent,TA.billable_status_id AS \r\n"
			+ "BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TP.`srf_id` AS \r\n"
			+ "srfId,TA.`supervisor_id` AS superVisorId ,TA.`cap_hr` AS capHours,TA.`remarks` AS comments,TA.`billable_status_reason_id` AS \r\n"
			+ "ebrReason,TA.`std_cost` AS employeeCostRate,TA.`skill_id` AS defaultSkillId, TA.skill_champion_flag AS SkillChampionFlagInt\r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "WHERE TP.`employee_id`= :employeeId AND TA.`status_id` = :statusId AND TA.`workflow_status_id` IN :workflowStatusId  \r\n"
			+ "AND DATE(`actual_allocation_start_date`) <= CURDATE() AND TA.billable_status_id != :lookupIdForPool \r\n"
			+ "AND TA.requirement_id IS NOT NULL AND TA.allocation_type_id != :allocationTypeId\r\n"
			+ "UNION\r\n"
			+ "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.status_id AS StatusId,TA.workflow_status_id AS WorkflowStatusId,\r\n"
			+ "TA.allocation_type_id AS AllocationTypeId,TA.actual_allocation_end_date AS ActualAllocationEndDate,TA.service_line_id AS ServiceLineId,\r\n"
			+ "TA.associate_project_id AS AssociateProjectId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,\r\n"
			+ "TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProjectFlag ,\r\n"
			+ "(SELECT IF((TA1.fte_percent !=TA.fte_percent),(TA1.fte_percent+TA.fte_percent),IF((TA1.fte_percent+TA.fte_percent)=100,(TA1.fte_percent+TA.fte_percent),TA.fte_percent)) \r\n"
			+ "FROM T_ASSOCIATE_ALLOCATION TA1 \r\n"
			+ "WHERE TA1.`transaction_history_id`=TA.associate_allocation_id) AS FtePercent,\r\n"
			+ "TA.billable_status_id AS BillableStatusId,\r\n"
			+ "TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TP.`srf_id` AS srfId,\r\n"
			+ "TA.`supervisor_id` AS superVisorId ,TA.`cap_hr` AS capHours,TA.`remarks` AS comments,TA.`billable_status_reason_id` AS ebrReason,\r\n"
			+ "TA.`std_cost` AS employeeCostRate,TA.`skill_id` AS defaultSkillId, TA.skill_champion_flag AS SkillChampionFlagInt\r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA\r\n"
			+ "JOIN `T_ASSOCIATE_PROJECT` TP ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "WHERE TP.`employee_id`= :employeeId AND TA.`status_id` IN :statusIdList\r\n"
			+ "AND TA.billable_status_id != :lookupIdForPool AND TA.requirement_id IS NOT NULL AND TA.allocation_type_id != :allocationTypeId\r\n"
			+ "AND TA.actual_allocation_end_date IS NOT NULL AND DATE(TA.actual_allocation_end_date) >= CURDATE()", nativeQuery = true)
	List<AllocatedResourceProjection> searchAllocatedToProject(@Param("employeeId") Long employeeId,
			@Param("statusId") Long statusId, @Param("workflowStatusId") List<Long> workflowStatusId,@Param("lookupIdForPool") Long lookupIdForPool, @Param("allocationTypeId") Long allocationTypeId, @Param("statusIdList") List<Long> statusIdList);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.actual_allocation_end_date AS ActualAllocationEndDate,TA.service_line_id AS ServiceLineId,TA.std_cost AS employeeCostRate,TA.associate_project_id AS AssociateProjectId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TP.`srf_id` AS srfId,TP.`supervisor_id` AS superVisorId ,TA.`cap_hr` AS capHours,TA.`remarks` AS comments,TA.`billable_status_reason_id` AS ebrReason, TA.allocation_type_id AS AllocationTypeId, \r\n"
			+ "TA.workflow_status_id AS WorkflowStatusId, TA.skill_champion_flag AS skillChampionFlag FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "WHERE  TP.`employee_id`= :employeeId AND TA.`status_id` = :statusId AND TA.`workflow_status_id` IN :workflowStatusId", nativeQuery = true)
	List<AllocatedResourceProjection> searchReservedForAllocation(@Param("employeeId") Long employeeId,
			@Param("statusId") Long statusId, @Param("workflowStatusId") List<Long> workflowStatusId);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.actual_allocation_end_date AS ActualAllocationEndDate,TA.service_line_id AS ServiceLineId,TA.std_cost AS employeeCostRate,TA.associate_project_id AS AssociateProjectId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TP.`srf_id` AS srfId,TP.`supervisor_id` AS superVisorId ,TA.`cap_hr` AS capHours,TA.`remarks` AS comments,TA.`billable_status_reason_id` AS ebrReason, TA.allocation_type_id AS AllocationTypeId, TA.skill_champion_flag AS skillChampionFlag \r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "WHERE TP.`employee_id`= :employeeId AND TA.`status_id` = :statusId AND TA.`workflow_status_id` IN :workflowStatusId AND  DATE(`actual_allocation_start_date`) > CURDATE();\r\n", nativeQuery = true)
	List<AllocatedResourceProjection> searchAllocationApproved(@Param("employeeId") Long employeeId,
			@Param("statusId") Long statusId, @Param("workflowStatusId") List<Long> workflowStatusId);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.associate_project_id AS AssociateProjectId,TA.requirement_id AS RequirementId,TD.employee_id AS EmployeeId,TD.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TD.`deallocation_date` AS DeallocationDate\r\n"
			+ "	,TP.`srf_id` AS srfId,TP.`supervisor_id` AS superVisorId,TA.`cap_hr` AS capHours,TD.`remarks` AS comments \r\n"
			+ "	FROM `T_ASSOCIATE_ALLOCATION` AS TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "	ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "	LEFT OUTER JOIN `T_ASSOCIATE_DEALLOCATION` TD \r\n"
			+ "	ON TA.`associate_allocation_id` = TD.`associate_allocation_id`\r\n"
			+ "	WHERE (TD.`employee_id` = :employeeId AND (TA.`status_id` = :statusIdActiveAllocation AND TA.`workflow_status_id` IN :workflowStatusIdAllocation  AND  TD.`status_id` = :statusIdDeactiveDeallocation AND TD.`workflow_status_id` IN :workflowStatusIdDeallocation))\r\n"
			+ "  OR (TP.`employee_id`= :employeeId AND TA.`associate_allocation_id` IN (SELECT IFNULL(`transaction_history_Id`,'XXXXX') FROM `T_ASSOCIATE_ALLOCATION` WHERE `status_id` = :statusIdActiveAllocation AND `workflow_status_id` IN :workflowStatusIdTransfer))", nativeQuery = true)
	List<AllocatedResourceProjection> searchReservedForDeallocation(@Param("employeeId") Long employeeId,
			@Param("workflowStatusIdAllocation") List<Long> workflowStatusIdAllocation,
			@Param("workflowStatusIdDeallocation") List<Long> workflowStatusIdDeallocation,
			@Param("workflowStatusIdTransfer") List<Long> workflowStatusIdTransfer,
			@Param("statusIdActiveAllocation") Long statusIdActiveAllocation,
			@Param("statusIdDeactiveDeallocation") Long statusIdDeactiveDeallocation);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.actual_allocation_end_date AS ActualAllocationEndDate,TA.service_line_id AS ServiceLineId,TA.std_cost AS employeeCostRate,TA.associate_project_id AS AssociateProjectId,TA.requirement_id AS RequirementId,TD.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate ,TP.`srf_id` AS srfId,TP.`supervisor_id` AS superVisorId,TA.`cap_hr` AS capHours,TD.`remarks` AS comments ,TA.`billable_status_reason_id` AS ebrReason,TD.`deallocation_date` AS DeallocationDate,  \r\n"
			+ "TA.allocation_type_id AS AllocationTypeId, TA.skill_champion_flag AS skillChampionFlag FROM `T_ASSOCIATE_ALLOCATION` AS TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "LEFT OUTER JOIN `T_ASSOCIATE_DEALLOCATION` TD \r\n"
			+ "ON TA.`associate_allocation_id` = TD.`associate_allocation_id`\r\n"
			+ "WHERE TD.`employee_id` = :employeeId AND TA.`status_id` = :statusIdForActive AND TA.`workflow_status_id` IN :wfStatusIdfortransferAndDeallocationApproved  AND  TD.`status_id` = :statusIdDeactiveDeallocation AND TD.`workflow_status_id` IN :wfStatusIdfortransferAndDeallocationApproved AND DATE(TD.`deallocation_date`) >=  CURDATE() AND TA.allocation_type_id != :allocationTypeId \r\n", nativeQuery = true)
	List<AllocatedResourceProjection> searchDeallocationApproved(@Param("employeeId") Long employeeId,
			@Param("statusIdForActive") Long statusIdActiveAllocation,
			@Param("statusIdDeactiveDeallocation") Long statusIdDeactiveDeallocation,
			@Param("wfStatusIdfortransferAndDeallocationApproved") List<Long> wfStatusIdfortransferAndDeallocationApproved, @Param("allocationTypeId") Long allocationTypeId);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.actual_allocation_end_date AS ActualAllocationEndDate,TA.service_line_id AS ServiceLineId,TA.std_cost AS employeeCostRate,TA.associate_project_id AS AssociateProjectId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TP.`srf_id` AS srfId,TP.`supervisor_id` AS superVisorId ,TA.`cap_hr` AS capHours,TA.`remarks` AS comments ,TA.`billable_status_reason_id` AS ebrReason,  \r\n"
			+ "TA.allocation_type_id AS AllocationTypeId, TA.skill_champion_flag AS skillChampionFlag FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "WHERE TP.`employee_id`= :employeeId AND TA.`status_id` = :statusIdForActive AND TA.`workflow_status_id` = :statusIdForallocApproved AND TA.allocation_type_id = :allocationTypeId", nativeQuery = true)	//AND `actual_allocation_start_date` <= CURDATE()
	List<AllocatedResourceProjection> searchTravelAllocationToProject(@Param("employeeId") Long employeeId,@Param("statusIdForActive") Long statusIdForActive,@Param("statusIdForallocApproved") Long statusIdForallocApproved, @Param("allocationTypeId") Long allocationTypeId);

	@Query(value = "SELECT SUM(TA.`fte_percent`)\r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "WHERE TP.`employee_id`= :employeeId AND TA.`status_id` = :statusIdForActive AND TA.`workflow_status_id` = :statusIdForallocApproved AND TA.`billable_status_id` = :lookupIdForBillable AND `actual_allocation_start_date` <= NOW();", nativeQuery = true)
	Double searchEmployeeBillableUtilization(@Param("employeeId") Long employeeId,@Param("statusIdForActive") Long statusIdForActive,@Param("statusIdForallocApproved") Long statusIdForallocApproved,@Param("lookupIdForBillable") Long lookupIdForBillable);

	@Query(value = "SELECT SUM(TA.`fte_percent`)\r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "WHERE TP.`employee_id`= :employeeId AND TA.`status_id` = :statusIdForActive AND TA.`workflow_status_id` = :statusIdForallocApproved AND (TA.`billable_status_id` = :lookupIdForNonBillable OR TA.`billable_status_id` = :lookupIdForIntransit) AND `actual_allocation_start_date` <= NOW();", nativeQuery = true)
	Double searchEmployeeNonBillableUtilization(@Param("employeeId") Long employeeId,@Param("statusIdForActive") Long statusIdForActive, @Param("statusIdForallocApproved") Long statusIdForallocApproved,@Param("lookupIdForNonBillable") Long lookupIdForNonBillable, @Param("lookupIdForIntransit") Long lookupIdForIntransit);

	@Query(value = "SELECT SUM(TA.`fte_percent`)\r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "WHERE TP.`employee_id`= 52330 AND TA.`status_id` = 42 AND TA.`workflow_status_id` = 44 AND TA.`billable_status_id` = 3 AND `actual_allocation_start_date` <= CURDATE();", nativeQuery = true)
	Double searchEmployeeEBRUtilization(@Param("employeeId") Long employeeId);

	@Query(value = "SELECT * FROM `T_ASSOCIATE_ALLOCATION` allo INNER  JOIN T_ASSOCIATE_PROJECT pro ON \r\n"
			+ "allo.associate_project_id = pro.associate_project_id WHERE pro.employee_id IN (:empIdList) AND allo.status_id =:statusId AND workflow_status_id = :wfStausIdForApproved AND pro.status_id =:statusId", nativeQuery = true)
	List<TAssociateAllocation> getResourceDetailsByEmpId(@Param("empIdList") List<Long> empIdList,
			@Param("statusId") Long statusId, @Param("wfStausIdForApproved") Long wfStausIdForApproved);

	@Query(value = "SELECT DISTINCT pro.employee_id FROM `T_ASSOCIATE_ALLOCATION` allo INNER  JOIN T_ASSOCIATE_PROJECT pro ON \r\n"
			+ "allo.associate_project_id = pro.associate_project_id WHERE allo.status_id =:statusId AND pro.status_id =:statusId ", nativeQuery = true)
	List<Long> getAllEmpIds(@Param("statusId") Long statusId);

	@Query(value = "SELECT taa.* FROM T_ASSOCIATE_ALLOCATION taa INNER JOIN T_ASSOCIATE_PROJECT tap ON taa.associate_project_id = tap.associate_project_id WHERE tap.employee_id IN :empIdList AND taa.workflow_status_id=:workflowStatusId AND taa.status_id =:statusId AND tap.status_id=:statusId", nativeQuery = true)
	List<TAssociateAllocation> getAssociateAllocationByWorkflowStatusAndStatusId(
			@Param("workflowStatusId") Long workflowStatusId, @Param("statusId") Long statusId,
			@Param("empIdList") List<Long> empIdList);

	@Query(value = "SELECT SUM(taa.fte_percent/100) FROM T_ASSOCIATE_PROJECT tap INNER JOIN T_ASSOCIATE_ALLOCATION taa ON taa.associate_project_id = tap.associate_project_id WHERE tap.employee_id IN (:empIdList) AND taa.billable_status_id IN (:billableId) AND taa.status_id=:statusId AND tap.status_id =:statusId AND taa.workflow_status_id=:wrkflwStatusId" , nativeQuery = true)
	Double getTotalBillablesBySkill(@Param("empIdList") List<Long> empIdList, @Param("billableId") List<Long> billableId,@Param("statusId") Long statusId,@Param("wrkflwStatusId") Long wrkflwStatusId);
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE  T_ASSOCIATE_ALLOCATION  SET  est_allocation_end_date  = :endDate, last_updated_by=:userId, last_updated_date = NOW() WHERE associate_allocation_id = :associateAllocationId  AND status_id = :statusIdforActive AND workflow_status_id = :wfStausIdForApproved", nativeQuery = true)
	void updateEstimatedEndDateforExtension(@Param("endDate") Date endDate,
			@Param("associateAllocationId") Long associateAllocationId,
			@Param("statusIdforActive") Long statusIdforActive,
			@Param("wfStausIdForApproved") Long wfStausIdForApproved, @Param("userId") long userId) throws ResourceManagementException;

	@Query(value = "SELECT * FROM `T_ASSOCIATE_ALLOCATION` WHERE associate_allocation_id IN (:associateAllocationId) ", nativeQuery = true)
	List<TAssociateAllocation> getAssociateAllocationById(
			@Param("associateAllocationId") List<Long> associateAllocationId);

	@Modifying
	@Transactional
	@Query(value = "UPDATE `T_ASSOCIATE_ALLOCATION` SET STATUS_ID = :statusId WHERE associate_allocation_id IN (:associateAllocationId)", nativeQuery = true)
	void updateStatusIdDeactive(@Param("statusId") Long statusId,
			@Param("associateAllocationId") List<Long> associateAllocationId) throws ResourceManagementException;

	@Modifying
	@Transactional
	@Query(value = " UPDATE `T_ASSOCIATE_ALLOCATION` SET est_allocation_end_date = :effectiveEndDate, last_updated_by=:userId, last_updated_date=SYSDATE()  WHERE associate_allocation_id IN (:associateAllocationIdList) AND status_id = :statusId", nativeQuery = true)
	void updateEstEndDate(@Param("effectiveEndDate") Date effectiveEndDate,
			@Param("associateAllocationIdList") List<Long> associateAllocationIdList, @Param("statusId") Long statusId, @Param("userId") Long userId)
			throws ResourceManagementException;

	@Query(value = "SELECT * FROM `T_ASSOCIATE_ALLOCATION` WHERE associate_project_id IN(:associateProjectIdList) AND status_id = :statusId", nativeQuery = true)
	List<TAssociateAllocation> getAssociateAllocationIdByProjectId(
			@Param("associateProjectIdList") List<Long> associateProjectIdList, @Param("statusId") Long statusId);

	@Query(value = "SELECT tap.project_id AS associateProjectId, taa.billable_status_id AS billableStatusId,taa.fte_percent AS ftePercent  FROM T_ASSOCIATE_ALLOCATION taa,"
			+ " T_ASSOCIATE_PROJECT tap WHERE taa.associate_project_id = tap.associate_project_id AND "
			+ "tap.project_id IN(:associateProjectIdList) AND taa.billable_status_id IN(:billableStatusId) AND taa.status_id =:statusId", nativeQuery = true)
	List<TAssociateAllocationProjection> getAssociateAllocationIdByProjectIdAndStatusId(
			@Param("associateProjectIdList") List<Long> associateProjectIdList,
			@Param("billableStatusId") List<Long> billableStatusId, @Param("statusId") Long statusId);
	
	@Query(value = "SELECT tap.project_id AS associateProjectId, taa.billable_status_id AS billableStatusId,taa.fte_percent AS ftePercent  FROM T_ASSOCIATE_ALLOCATION taa,"
			+ " T_ASSOCIATE_PROJECT tap WHERE taa.associate_project_id = tap.associate_project_id AND "
			+ "tap.project_id IN(:associateProjectIdList) AND taa.billable_status_id IN(:billableStatusId)", nativeQuery = true)
	List<TAssociateAllocationProjection> getAssociateAllocationIdByProjectIdAndStatusId(
			@Param("associateProjectIdList") List<Long> associateProjectIdList,
			@Param("billableStatusId") List<Long> billableStatusId);

	@Query(value = "SELECT * FROM `T_ASSOCIATE_ALLOCATION` WHERE associate_allocation_id = :associateAllocationId ", nativeQuery = true)
	TAssociateAllocation getAssociateAllocationByAssociateAlloId(
			@Param("associateAllocationId") Long associateAllocationId);

	@Query(value = "SELECT COUNT(*) FROM T_ASSOCIATE_ALLOCATION taa INNER JOIN T_RESOURCE_WORKFLOW trw ON taa.associate_allocation_id = trw.transaction_id WHERE taa.workflow_status_id IN :submitStatusIdList AND trw.current_user_id=:userId AND trw.current_role_id=:roleId AND trw.status_id=0", nativeQuery = true)
	Integer getApprovalPendingResourceCount(@Param("userId") Long userId, @Param("roleId") Long roleId,
			@Param("submitStatusIdList") List<Long> submitStatusIdList);

	@Query(value = "SELECT COUNT(*) FROM T_ASSOCIATE_ALLOCATION WHERE last_updated_by=:userId AND workflow_status_id IN :savedStatusIdList", nativeQuery = true)
	Integer getSubmissionPendingResourceCount(@Param("userId") Long userId,
			@Param("savedStatusIdList") List<Long> savedStatusIdList);

	@Query(value = "SELECT COUNT(*) FROM T_ASSOCIATE_ALLOCATION taa INNER JOIN T_RESOURCE_WORKFLOW trw ON taa.associate_allocation_id = trw.transaction_id WHERE taa.workflow_status_id IN :submitStatusIdList AND trw.current_user_id=:userId AND trw.current_role_id=:roleId AND trw.status_id <> 0 AND trw.next_user_id IS NOT NULL AND trw.next_user_id <>0", nativeQuery = true)
	Integer getPendingOthersResourceCount(@Param("userId") Long userId, @Param("roleId") Long roleId,
			@Param("submitStatusIdList") List<Long> submitStatusIdList);

	@Query(value = "SELECT DISTINCT talloc.ASSOCIATE_ALLOCATION_ID FROM T_ASSOCIATE_ALLOCATION talloc INNER JOIN T_RESOURCE_WORKFLOW trscwrklw ON talloc.ASSOCIATE_ALLOCATION_ID = trscwrklw.TRANSACTION_ID\r\n"
			+ "WHERE talloc.STATUS_ID = :activeStatusId AND talloc.WORKFLOW_STATUS_ID = :submittedStatusId AND trscwrklw.WORKFLOW_TYPE_ID = :workflowTypeId\r\n"
			+ "AND trscwrklw.CURRENT_USER_ID = :userId AND trscwrklw.CURRENT_ROLE_ID = :roleId", nativeQuery = true)
	List<Long> getActiveUserTransactions(@Param("userId") Long userId, @Param("roleId") Long roleId,
			@Param("workflowTypeId") Long workflowTypeId, @Param("activeStatusId") Long activeStatusId,
			@Param("submittedStatusId") Long submittedStatusId);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.remarks AS comments, TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate \r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT  TP\r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id\r\n"
			+ "WHERE TA.associate_allocation_id IN :allocationIds", nativeQuery = true)
	List<AllocatedResourceProjection> getAssociatesByAllocationId(@Param("allocationIds") List<Long> allocationIds);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId, TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TP.`srf_id` AS srfId,TP.`supervisor_id` AS superVisorId ,TA.`cap_hr` AS capHours,TA.`remarks` AS comments ,TA.`billable_status_reason_id` AS ebrReason \r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "WHERE TA.`workflow_status_id`= :workflowId AND TA.`created_by` = :userId AND TA.`status_id` = :statusId ", nativeQuery = true)
	List<AllocatedResourceProjection> getPendingResourceSubmit(@Param("workflowId") long workflowId,
			@Param("userId") long userId, @Param("statusId") long statusId);

	@Query(value = "SELECT * FROM T_ASSOCIATE_ALLOCATION WHERE associate_allocation_id =:associateAllocationId", nativeQuery = true)
	TAssociateAllocation getAllocationByAllocationId(@Param("associateAllocationId") Long associateAllocationId);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate \r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT  TP\r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id\r\n"
			+ "WHERE TA.associate_allocation_id = :allocationId", nativeQuery = true)
	AllocatedResourceProjection getAssociateByAllocationId(@Param("allocationId") Long allocationId);

	@Query(value = "SELECT * FROM `T_ASSOCIATE_ALLOCATION` WHERE workflow_status_id = :workflowStatusId AND status_id = :statusId AND last_updated_by = :userId AND `transaction_history_id` IS NOT NULL", nativeQuery = true)
	List<TAssociateAllocation> getListOfRMPendingTransferSubmission(@Param("workflowStatusId") Long workflowStatusId,
			@Param("statusId") Long statusId, @Param("userId") Long userId);

	/*@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.remarks AS comments,TA.actual_allocation_end_date AS ReleaseDate,TA.role_id AS roleId,TA.`billable_status_reason_id` AS ebrReason,TA.created_date AS RequestReceivedOn,TA.transaction_history_Id AS TransactionHistoryId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT  TP ON  TA.associate_project_id =  TP.associate_project_id\r\n"
			+ " WHERE associate_allocation_id IN (SELECT transaction_history_Id FROM T_ASSOCIATE_ALLOCATION WHERE associate_allocation_id IN (:allocationIds)) OR associate_allocation_id IN (:allocationIds)", nativeQuery = true)*/
	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.remarks AS comments,IF(ISNULL(TA.actual_allocation_end_date),TA.est_allocation_end_date,\r\n"
			+ "IF(DATE(TA.actual_allocation_end_date) = DATE('1111-11-11 00:00:00'),TA.est_allocation_end_date,TA.actual_allocation_end_date)) AS ReleaseDate,TA.role_id AS roleId,TA.`billable_status_reason_id` AS ebrReason,TA.created_date AS RequestReceivedOn,TA.transaction_history_Id AS TransactionHistoryId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT  TP ON  TA.associate_project_id =  TP.associate_project_id\r\n"
			+ " WHERE associate_allocation_id IN (SELECT transaction_history_Id FROM T_ASSOCIATE_ALLOCATION WHERE associate_allocation_id IN (:allocationIds)) OR associate_allocation_id IN (:allocationIds)", nativeQuery = true)
	List<AllocatedResourceProjection> getSourceAndTargetOfAssociateByAllocationIdList(
			@Param("allocationIds") List<Long> allocationIds);

	@Query(value = "SELECT talloc.* FROM (T_ASSOCIATE_ALLOCATION talloc INNER JOIN T_ASSOCIATE_PROJECT tpro ON tpro.associate_project_id=talloc.associate_project_id) WHERE tpro.project_id=:projectId  AND talloc.status_id=:statusId AND tpro.employee_id IN (:empIdList) AND talloc.requirement_id=:requirementId AND talloc.workflow_status_id=:workflowStatusId", nativeQuery = true)
	List<TAssociateAllocation> getRAllocationDetailsForFte(@Param("projectId") long projectId,
			@Param("statusId") long statusId, @Param("empIdList") List<Long> empIdList,
			@Param("requirementId") long requirementId, @Param("workflowStatusId") long workflowStatusId)
			throws ResourceManagementException;

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TP.`srf_id` AS srfId ,TA.`std_cost` AS employeeCostRate,TA.`skill_id` AS defaultSkillId FROM `T_ASSOCIATE_ALLOCATION` TA INNER JOIN `T_ASSOCIATE_PROJECT` TP  \r\n"
			+ "ON TA.`associate_project_id` = TP.`associate_project_id` \r\n"
			+ "WHERE TP.`project_id` = :projectId  AND TA.`workflow_status_id` IN :wfStatusIdForAllocationOrTransferApproved AND TA.`status_id` = :statusIdForAllocationActive AND `requirement_id` IN :requirementIds\r\n"
			+ "AND TA.`associate_allocation_id` NOT IN (SELECT IFNULL(`associate_allocation_id`,'XXXXX') FROM `T_ASSOCIATE_DEALLOCATION` WHERE `project_id` = :projectId AND `status_id` = :statusIdForDeAllocationDeActive AND `workflow_status_id` IN :wfStatusIdForSavedOrSubmittedForDeallocation\r\n"
			+ " )  AND TA.`associate_allocation_id` NOT IN (SELECT TA.`associate_allocation_id` \r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA LEFT OUTER JOIN `T_ASSOCIATE_ALLOCATION` TAC\r\n"
			+ "ON TA.`associate_allocation_id` = TAC.`transaction_history_Id` \r\n"
			+ "INNER JOIN `T_ASSOCIATE_PROJECT` TP ON TA.`associate_project_id` = TP.`associate_project_id`\r\n"
			+ "WHERE TAC.`transaction_history_Id` IS NOT NULL AND TAC.`status_id` = :statusIdForAllocationActive AND TAC.`workflow_status_id` IN :wfStatusIdForSavedOrSubmittedForTransfer \r\n"
			+ "AND TP.`project_id` = :projectId) AND TA.`associate_allocation_id` NOT IN (SELECT IFNULL(`transaction_history_Id`,'XXXX') FROM `T_ASSOCIATE_EXTENSION` TE INNER JOIN `T_ASSOCIATE_PROJECT` TP \r\n"
			+ "ON TE.`associate_project_id` = TP.`associate_project_id`\r\n"
			+ "WHERE TP.`project_id` =:projectId AND TE.`status_id` = :statusIdForAllocationActive AND TE.`workflow_status_id` = :wfIdForSubmittedForExtension);", nativeQuery = true)
	List<AllocatedResourceProjection> getAllocatedResourceList(@Param("projectId") Long projectId,
			@Param("wfStatusIdForAllocationOrTransferApproved") List<Long> wfStatusIdForAllocationOrTransferApproved,
			@Param("statusIdForAllocationActive") Long statusIdForAllocationActive,
			@Param("requirementIds") List<Long> requirementIds,
			@Param("statusIdForDeAllocationDeActive") Long statusIdForDeAllocationDeActive,
			@Param("wfStatusIdForSavedOrSubmittedForDeallocation") List<Long> wfStatusIdForSavedOrSubmittedForDeallocation,
			@Param("wfStatusIdForSavedOrSubmittedForTransfer") List<Long> wfStatusIdForSavedOrSubmittedForTransfer,
			@Param("wfIdForSubmittedForExtension") Long wfIdForSubmittedForExtension);

	@Modifying
	@Transactional
	@Query(value = "UPDATE `T_SRF` \r\n" + "SET `resource_status` =  'CLOSED'\r\n"
			+ "WHERE `candidate_id` IN :empIds AND `project_id` = :projectId", nativeQuery = true)
	void deactivateSrfStatus(List<Long> empIds, Long projectId);

	@Modifying
	@Transactional
	@Query(value = "UPDATE `T_SRF` \r\n" + "SET `resource_status` = 'CLOSED'\r\n"
			+ "WHERE `srf_id` IN (SELECT `srf_id` FROM `T_ASSOCIATE_PROJECT` WHERE `associate_project_id` IN (SELECT `associate_project_id` FROM `T_ASSOCIATE_ALLOCATION` WHERE `associate_allocation_id` IN :allocationIds) )\r\n", nativeQuery = true)
	void deactivateSrfStatusBySrfId(List<Long> allocationIds);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TP.`srf_id` AS srfId ,TA.`std_cost` AS employeeCostRate,TA.`skill_id` AS defaultSkillId FROM `T_ASSOCIATE_ALLOCATION` TA INNER JOIN `T_ASSOCIATE_PROJECT` TP  \r\n"
			+ "ON TA.`associate_project_id` = TP.`associate_project_id` \r\n"
			+ "WHERE TP.`project_id` = :projectId  AND TA.`workflow_status_id` IN :wfStatusIdForAllocationOrTransferApproved AND TA.`status_id` = :statusIdForAllocationActive \r\n"
			+ "AND TA.`associate_allocation_id` NOT IN (SELECT IFNULL(`associate_allocation_id`,'XXXXX') FROM `T_ASSOCIATE_DEALLOCATION` WHERE `project_id` = :projectId AND `status_id` = :statusIdForDeAllocationDeActive AND `workflow_status_id` IN :wfStatusIdForSavedOrSubmittedForDeallocation\r\n"
			+ " )  AND TA.`associate_allocation_id` NOT IN (SELECT TA.`associate_allocation_id` \r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA LEFT OUTER JOIN `T_ASSOCIATE_ALLOCATION` TAC\r\n"
			+ "ON TA.`associate_allocation_id` = TAC.`transaction_history_Id` \r\n"
			+ "INNER JOIN `T_ASSOCIATE_PROJECT` TP ON TA.`associate_project_id` = TP.`associate_project_id`\r\n"
			+ "WHERE TAC.`transaction_history_Id` IS NOT NULL AND TAC.`status_id` = :statusIdForAllocationActive AND TAC.`workflow_status_id` IN :wfStatusIdForSavedOrSubmittedForTransfer \r\n"
			+ "AND TP.`project_id` = :projectId) AND TA.`associate_allocation_id` NOT IN (SELECT IFNULL(`transaction_history_Id`,'XXXX') FROM `T_ASSOCIATE_EXTENSION` TE INNER JOIN `T_ASSOCIATE_PROJECT` TP \r\n"
			+ "ON TE.`associate_project_id` = TP.`associate_project_id`\r\n"
			+ "WHERE TP.`project_id` =:projectId AND TE.`status_id` = :statusIdForAllocationActive AND TE.`workflow_status_id` = :wfIdForSubmittedForExtension);", nativeQuery = true)
	List<AllocatedResourceProjection> getAllocatedResourceListForTransfer(@Param("projectId") Long projectId,
			@Param("wfStatusIdForAllocationOrTransferApproved") List<Long> wfStatusIdForAllocationOrTransferApproved,
			@Param("statusIdForAllocationActive") Long statusIdForAllocationActive,
			@Param("statusIdForDeAllocationDeActive") Long statusIdForDeAllocationDeActive,
			@Param("wfStatusIdForSavedOrSubmittedForDeallocation") List<Long> wfStatusIdForSavedOrSubmittedForDeallocation,
			@Param("wfStatusIdForSavedOrSubmittedForTransfer") List<Long> wfStatusIdForSavedOrSubmittedForTransfer,
			@Param("wfIdForSubmittedForExtension") Long wfIdForSubmittedForExtension);

	@Query(value = "SELECT DISTINCT `employee_id` FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON   TA.associate_project_id = TP.associate_project_id\r\n"
			+ "WHERE  TP.`employee_id` IN :employeeIds AND TA.STATUS_ID = :statusIdForActivate AND TA.`billable_status_id` != :statusIdForPool  AND TP.`is_primary_project` =  1", nativeQuery = true)
	List<Long> getPrimaryProjectCheck(@Param("employeeIds") List<Long> employeeIds,
			@Param("statusIdForActivate") Long statusIdForActivate, @Param("statusIdForPool") Long statusIdForPool);

	@Query(value = "SELECT allo.associate_allocation_id AS associateAllocationId ,pro.employee_id AS employeeId FROM `T_ASSOCIATE_ALLOCATION` allo INNER JOIN T_ASSOCIATE_PROJECT pro"
			+ " ON allo.associate_project_id = pro.associate_project_id WHERE pro.employee_id IN (:empIdList) "
			+ "AND pro.project_id IN (:projectId) AND allo.status_id = :statusId AND (allo.workflow_status_id = :wfStausIdForApproved OR allo.workflow_status_id = :wfStausIdForSaved)  AND"
			+ " allo.requirement_id IN (:requirementIds)", nativeQuery = true)
	List<AllocatedResourceProjection> getAllocatedResource(@Param("empIdList") List<Long> empIdList,
			@Param("statusId") Long statusId, @Param("wfStausIdForApproved") Long wfStausIdForApproved,
			@Param("wfStausIdForSaved") Long wfStausIdForSaved, @Param("projectId") List<Long> projectId,
			@Param("requirementIds") List<Long> requirementIds);

	@Query(value = "SELECT employee_id FROM `T_ASSOCIATE_ALLOCATION` allo INNER  JOIN T_ASSOCIATE_PROJECT pro ON \r\n"
			+ "allo.associate_project_id = pro.associate_project_id WHERE pro.employee_id= :empId AND"
			+ " actual_allocation_start_date >= :allocationStartDate AND :allocationStartDate <= allo.actual_allocation_end_date AND allo.status_id =:statusId AND"
			+ " allo.fte_percent=0", nativeQuery = true)
	List<Long> getTravelAllocatedResource(@Param("statusId") Long statusId,
			@Param("allocationStartDate") Date allocationStartDate, @Param("empId") Long empId);

	@Query(value = "SELECT talloc.* FROM (T_ASSOCIATE_ALLOCATION talloc INNER JOIN T_ASSOCIATE_PROJECT tpro ON tpro.associate_project_id=talloc.associate_project_id) WHERE tpro.project_id=:projectId  AND talloc.status_id=:statusId AND tpro.employee_id IN (:empIdList) AND talloc.requirement_id IN (:requirementId) AND talloc.workflow_status_id IN (:workflowStatusIdforSaved)", nativeQuery = true)
	List<TAssociateAllocation> getRAllocationDetailsList(@Param("projectId") long projectId,
			@Param("statusId") long statusId, @Param("empIdList") List<Long> empIdList,
			@Param("requirementId") List<Long> requirementId,@Param("workflowStatusIdforSaved") List<Long> workflowStatusIdforSaved) throws ResourceManagementException;

	@Query(value = "SELECT TA.`associate_allocation_id`\r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id` =  TP.`associate_project_id`\r\n"
			+ "LEFT OUTER JOIN `T_ASSOCIATE_DEALLOCATION` TD\r\n"
			+ "ON TA.associate_allocation_id = TD.`associate_allocation_id`\r\n"
			+ "WHERE TP.`project_id` = :projectId AND TA.`workflow_status_id` = :wfStatusIdForAllocationApproved AND TA.`status_id` = :statusIdForAllocationActive\r\n"
			+ "AND TA.`requirement_id` IN :requirementId AND TD.`workflow_status_id` IN :wfStatusIdForSavedOrSubmittedForDeallocation", nativeQuery = true)
	List<Long> getDeallocationList(@Param("projectId") long projectId, @Param("requirementId") List<Long> requirementId,
			@Param("statusIdForAllocationActive") Long statusIdForAllocationActive,
			@Param("wfStatusIdForAllocationApproved") Long wfStatusIdForAllocationApproved,
			@Param("wfStatusIdForSavedOrSubmittedForDeallocation") List<Long> wfStatusIdForSavedOrSubmittedForDeallocation);

	@Query(value = "SELECT DISTINCT TA.`associate_allocation_id` FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id` =  TP.`associate_project_id`\r\n" + "JOIN `T_ASSOCIATE_ALLOCATION` TAA\r\n"
			+ "ON TA.`associate_allocation_id` = TAA.`transaction_history_Id` \r\n"
			+ "WHERE  TP.`project_id` = :projectId AND TA.`requirement_id` IN :requirementId AND TA.`workflow_status_id` = :wfStatusIdForAllocationApproved AND TA.`status_id` = :statusIdForAllocationActive AND TAA.workflow_status_id IN :wfStatusIdForSavedOrSubmittedForTransfer", nativeQuery = true)
	List<Long> getTransferList(@Param("projectId") long projectId, @Param("requirementId") List<Long> requirementId,
			@Param("statusIdForAllocationActive") Long statusIdForAllocationActive,
			@Param("wfStatusIdForAllocationApproved") Long wfStatusIdForAllocationApproved,
			@Param("wfStatusIdForSavedOrSubmittedForTransfer") List<Long> wfStatusIdForSavedOrSubmittedForTransfer);

	@Query(value = "SELECT TA.`associate_allocation_id`\r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id` =  TP.`associate_project_id`\r\n"
			+ "LEFT OUTER JOIN `T_ASSOCIATE_EXTENSION` TE\r\n"
			+ "ON TA.associate_allocation_id = TE.`transaction_history_Id`\r\n"
			+ "WHERE TP.`project_id` = :projectId AND TA.`workflow_status_id` = :wfStatusIdForAllocationApproved AND TA.`status_id` = :statusIdForAllocationActive\r\n"
			+ "AND  TA.`requirement_id` IN :requirementId AND TE.`workflow_status_id` =  :wfStatusIdForSavedOrSubmittedForExtension", nativeQuery = true)
	List<Long> getExtensionList(@Param("projectId") long projectId, @Param("requirementId") List<Long> requirementId,
			@Param("statusIdForAllocationActive") Long statusIdForAllocationActive,
			@Param("wfStatusIdForAllocationApproved") Long wfStatusIdForAllocationApproved,
			@Param("wfStatusIdForSavedOrSubmittedForExtension") Long wfStatusIdForSavedOrSubmittedForExtension);

	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TP.`srf_id` AS srfId ,TA.`std_cost` AS employeeCostRate,TA.`skill_id` AS defaultSkillId,TA.`service_line_id` AS ServiceLineId,MS.`service_line` AS ServiceLineName  \r\n"
			+ " FROM `T_ASSOCIATE_ALLOCATION` TA  JOIN `T_ASSOCIATE_PROJECT` TP ON TA.`associate_project_id` =  TP.`associate_project_id` JOIN `zf_admin`.`M_SERVICE_LINE` MS ON TA.service_line_id=MS.service_line_id\r\n"
			+ "WHERE TP.`project_id` = :projectId AND  TA.`requirement_id` IN :requirementId AND TA.`allocation_type_id` = :normalAllocId AND TA.`workflow_status_id` = :wfStatusIdForAllocationApproved AND TA.`status_id` = :statusIdForAllocationActive AND TP.`status_id` = :statusIdForAllocationActive AND TA.associate_allocation_id NOT IN :allocationIds AND TA.actual_allocation_start_date <= NOW() " , nativeQuery = true)
	List<AllocatedResourceProjection> getNormalempList(@Param("projectId") long projectId,
			@Param("requirementId") List<Long> requirementId,
			@Param("statusIdForAllocationActive") Long statusIdForAllocationActive,
			@Param("wfStatusIdForAllocationApproved") Long wfStatusIdForAllocationApproved,
			@Param("allocationIds") List<Long> allocationIds,
			@Param("normalAllocId") Long normalAllocId);
	
	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TP.`srf_id` AS srfId ,TA.`std_cost` AS employeeCostRate,TA.`skill_id` AS defaultSkillId,TA.`service_line_id` AS ServiceLineId,MS.`service_line` AS ServiceLineName  \r\n"
			+ " FROM `T_ASSOCIATE_ALLOCATION` TA  JOIN `T_ASSOCIATE_PROJECT` TP ON TA.`associate_project_id` =  TP.`associate_project_id` JOIN `zf_admin`.`M_SERVICE_LINE` MS ON TA.service_line_id=MS.service_line_id\r\n"
			+ "WHERE TP.`project_id` = :projectId AND  TA.`requirement_id` IN :requirementId  AND TA.`workflow_status_id` = :wfStatusIdForAllocationApproved AND TA.`status_id` = :statusIdForAllocationActive AND TP.`status_id` = :statusIdForAllocationActive AND TA.associate_allocation_id NOT IN :allocationIds AND TA.actual_allocation_start_date <= NOW() " , nativeQuery = true)
	List<AllocatedResourceProjection> getempList(@Param("projectId") long projectId,
			@Param("requirementId") List<Long> requirementId,
			@Param("statusIdForAllocationActive") Long statusIdForAllocationActive,
			@Param("wfStatusIdForAllocationApproved") Long wfStatusIdForAllocationApproved,
			@Param("allocationIds") List<Long> allocationIds);

	@Query(value = "SELECT * FROM T_ASSOCIATE_ALLOCATION WHERE REQUIREMENT_ID =:requirementId AND ASSOCIATE_PROJECT_ID = (SELECT ASSOCIATE_PROJECT_ID FROM T_ASSOCIATE_PROJECT WHERE EMPLOYEE_ID =:empId AND PROJECT_ID =:currentProjectId) ", nativeQuery = true)
	List<TAssociateAllocation> getCurrentProjectDetail(Long requirementId, long currentProjectId, long empId);

	@Query(value = "SELECT * FROM T_ASSOCIATE_ALLOCATION WHERE REQUIREMENT_ID =:requirementId AND ASSOCIATE_PROJECT_ID = (SELECT ASSOCIATE_PROJECT_ID FROM T_ASSOCIATE_PROJECT WHERE EMPLOYEE_ID =:empId AND PROJECT_ID =:currentProjectId AND status_id=:activeStatusIdForProject) AND workflow_status_id IN (:workflowStatusId) AND `associate_allocation_id` IN :transactionHistoryIds ", nativeQuery = true)
	TAssociateAllocation getCurrentProjectDataForTransfer(Long requirementId, long currentProjectId, long empId,
			List<Long> workflowStatusId, Long activeStatusIdForProject,List<Long> transactionHistoryIds);

	@Query(value = "SELECT `project_code` FROM  `zf_projectdefinition`.`M_PROJECT` WHERE `project_id` = :projectId ", nativeQuery = true)
	String getProjectCode(@Param("projectId") Long projectId);

	@Query(value = "SELECT `module_id` AS ModuleId,`module_code` AS ModuleCode,`module_name` AS ModuleName FROM `zf_admin`.`M_MODULE` WHERE `parent_module_id` = (SELECT `module_id` FROM `zf_admin`.`M_MODULE` WHERE `module_name` = 'RESOURCE_MANAGEMENT' )", nativeQuery = true)
	List<ModuleProjection> getModuleId();

	@Query(value = "SELECT `employee_number` FROM `zf_admin`.`M_EMPLOYEE` WHERE `employee_id` IN :empIds", nativeQuery = true)
	List<Long> getEmpNumbers(@Param("empIds") List<Long> empIds);

	@Query(value = "SELECT\r\n"
			+ "pro.project_id AS projectId,\r\n"
			+ "allo.fte_percent AS projectUtilization,\r\n"
			+ "allo.billable_status_id AS billableStatusId,\r\n"
			+ "allo.actual_allocation_start_date AS actualAllocationStartDate,\r\n"
			+ "allo.actual_allocation_end_date AS actualAllocationEndDate,\r\n"
			+ "allo.est_allocation_end_date AS estAllocationEndDate,\r\n"
			+ "allo.work_location_id AS workLocationId,\r\n"
			+ "location_name AS workLocationName,\r\n"
			+ "allo.associate_allocation_id AS associateAllocationId\r\n"
			+ "FROM `zf_resourcemanagement`.T_ASSOCIATE_ALLOCATION allo\r\n"
			+ "INNER JOIN `zf_resourcemanagement`.T_ASSOCIATE_PROJECT pro\r\n"
			+ "ON allo.associate_project_id = pro.associate_project_id\r\n"
			+ "JOIN `zf_admin`.`M_LOCATION` mLoc\r\n"
			+ "ON mLoc.`location_id`=allo.work_location_id\r\n"
			+ "WHERE pro.employee_id = :empId\r\n"
			+ "AND allo.actual_allocation_start_date <= :endDate\r\n"
			+ "AND IF(allo.actual_allocation_end_date='1111-11-11',:startDate,allo.actual_allocation_end_date) >= :startDate\r\n"
			+ "UNION\r\n"
			+ "SELECT\r\n"
			+ "pro.project_id AS projectId,\r\n"
			+ "allo.fte_percent AS projectUtilization,\r\n"
			+ "allo.billable_status_id AS billableStatusId,\r\n"
			+ "allo.actual_allocation_start_date AS actualAllocationStartDate,\r\n"
			+ "allo.actual_allocation_end_date AS actualAllocationEndDate,\r\n"
			+ "allo.est_allocation_end_date AS estAllocationEndDate,\r\n"
			+ "allo.work_location_id AS workLocationId,\r\n"
			+ "location_name AS workLocationName,\r\n"
			+ "allo.associate_allocation_id AS associateAllocationId\r\n"
			+ "FROM `zf_resourcemanagement`.T_ASSOCIATE_ALLOCATION allo\r\n"
			+ "INNER JOIN `zf_resourcemanagement`.T_ASSOCIATE_PROJECT pro\r\n"
			+ "ON allo.associate_project_id = pro.associate_project_id\r\n"
			+ "JOIN `zf_admin`.`M_LOCATION` mLoc\r\n"
			+ "ON mLoc.`location_id`=allo.work_location_id\r\n"
			+ "WHERE pro.employee_id = :empId\r\n"
			+ "AND allo.actual_allocation_start_date <= :endDate\r\n"
			+ "AND allo.actual_allocation_end_date >= :startDate", nativeQuery = true)
	List<ProjectDetailsProjection> findByAllocationDateAndEmpId(Long empId, Date startDate, Date endDate);


	@Query(value = " SELECT ta.* " + " FROM `T_ASSOCIATE_ALLOCATION` ta,`T_ASSOCIATE_PROJECT` tp "
			+ " WHERE ta.`associate_project_id` = tp.`associate_project_id` AND   tp.`project_id` = :projectId AND tp.status_id= :statusId AND tp.`employee_id` = :empId ", nativeQuery = true)
	TAssociateAllocation getActualAndEstAllocationDate(long projectId, long empId, long statusId);

	@Query(value = "SELECT  DISTINCT `requirement_id` FROM `T_ASSOCIATE_ALLOCATION` WHERE `associate_project_id` IN ( SELECT `associate_project_id` FROM `T_ASSOCIATE_PROJECT` WHERE `project_id` =:projectId AND `status_id`= :statusId )", nativeQuery = true)
	List<Long> getRequirementIds(long projectId, long statusId);

	@Query(value = "SELECT lookup_value_id FROM `zf_admin`.`M_LOOKUP_VALUE` WHERE `lookup_value_description` = 'TAG TEAM'", nativeQuery = true)
	Long getLookupValueForTag();

	@Query(value = "SELECT b.`lookup_value_id` FROM `zf_admin`.M_LOOKUP_TYPE a INNER JOIN `zf_admin`.M_LOOKUP_VALUE b ON (a.lookup_type_id=b.lookup_type_id) WHERE a.`lookup_type` = :lookupType AND b.lookup_value_description= :lookupValue ", nativeQuery = true)
	Long getLookupValueIdByTypeAndDescr(@Param("lookupType") String lookupType,
			@Param("lookupValue") String lookupValue);

	@Query(value = " SELECT `employee_number` FROM `zf_admin`.`M_EMPLOYEE` WHERE `employee_id` IN  ( SELECT TP.`employee_id` FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.ASSOCIATE_PROJECT_ID = TP.ASSOCIATE_PROJECT_ID\r\n"
			+ "WHERE TP.PROJECT_ID = :projectId AND TA.`workflow_status_id` IN :workflowStatusIds AND TA.`status_id` = :statusId )", nativeQuery = true)
	List<Long> getResourceInAllocWfForProject(@Param("projectId") Long projectId,
			@Param("workflowStatusIds") List<Long> workflowStatusIds, @Param("statusId") Long statusId);

	@Query(value = "SELECT IFNULL(SUM(TA.fte_percent/100), 0)  \r\n"
			+ "FROM  T_ASSOCIATE_ALLOCATION  TA JOIN T_ASSOCIATE_PROJECT TP  \r\n"
			+ "ON  TA.associate_project_id =  TP.associate_project_id \r\n"
			+ "WHERE TA.requirement_id IN :requirmentIdList AND  TP.project_id= :projectId AND TA.status_id = :wfStatusIdForActivate AND  TA.workflow_status_id=:wfStatisIdForApproved", nativeQuery = true)
	Double getTotalAllocatedBillableOrNonBillableFteForProject(List<Long> requirmentIdList, long projectId,
			Long wfStatusIdForActivate, Long wfStatisIdForApproved);

	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_ALLOCATION SET status_id = :statusId ,workflow_status_id=:workflowStatusId, LAST_UPDATED_DATE = NOW() ,EFFECTIVE_END_DATE =:allocationEndDate, EST_ALLOCATION_END_DATE = :allocationEndDate, ACTUAL_ALLOCATION_END_DATE = :allocationEndDate,LAST_UPDATED_BY = :userId WHERE ASSOCIATE_ALLOCATION_ID IN :transactionHistoryIdList", nativeQuery = true)
	void deactivateNBTransferResourceAllocation(@Param("transactionHistoryIdList") List<Long> transactionHistoryIdList,
			@Param("statusId") long statusId, @Param("userId") Long userId,
			@Param("allocationEndDate") Date allocationEndDate, @Param("workflowStatusId") Long workflowStatusId);

	@Query(value = "SELECT `employee_number` FROM `zf_admin`.`M_EMPLOYEE` WHERE `employee_id` IN :employeeIds ", nativeQuery = true)
	List<Long> getEmployeeNumbers(@Param("employeeIds") List<Long> employeeIds);

	@Query(value = "SELECT tp.employee_id AS employeeId, tp.project_id AS projectId, ta.std_cost AS stdCost,ta.actual_allocation_start_date AS actualAllocationStartDate, ta.actual_allocation_end_date AS actualAllocationEndDate, ta.fte_percent AS ftePercent, ta.remarks,ta.workflow_status_id AS workflowStatusId, ta.status_id AS statusId  FROM T_ASSOCIATE_ALLOCATION ta INNER JOIN T_ASSOCIATE_PROJECT tp ON ta.associate_project_id = tp.associate_project_id WHERE workflow_status_id<> 62", nativeQuery = true)
	List<TAssociateProjectAndAllocationProjection> getAllocationWorkflowDetails();
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE `T_ASSOCIATE_ALLOCATION` SET `workflow_status_id` = :workflowStatusId ,`actual_allocation_end_date` = :deAllocationDate, last_updated_by=:userId, last_updated_date= NOW(), effective_end_date= NOW()  WHERE `associate_allocation_id` = :associateAllocationId", nativeQuery = true)
	void updateDataForDeaalloc( @Param("workflowStatusId") Long workflowStatusId,@Param("deAllocationDate") Date deAllocationDate,@Param("associateAllocationId") Long associateAllocationId, @Param("userId") long userId);
	
	@Query(value = "SELECT * FROM T_ASSOCIATE_ALLOCATION WHERE `associate_allocation_id` :associateAllocidList", nativeQuery = true)
	List<TAssociateAllocation> getTargetProjByAssociateAllocIdId(
			@Param("associateAllocidList") List<Long> associateAllocidList);
	
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_ALLOCATION TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n" + 
			"	ON TA.`associate_project_id` = TP.`associate_project_id`\r\n" + 
			"	SET TA.`workflow_status_id` = :workflowStatusId WHERE \r\n" + 
			"	TP.`project_id` = :sourceProjectId AND TP.`employee_id` = :employeeId AND TA.`requirement_id` = :sourceRequirementId AND TA.`workflow_status_id` = :workflowStatusIdForTransferSaved\r\n" + 
			"", nativeQuery = true)
	void updatepartialRecordForSourceProj( @Param("workflowStatusId") Long workflowStatusId, @Param("sourceProjectId") Long sourceProjectId,@Param("employeeId") Long employeeId,@Param("sourceRequirementId") Long sourceRequirementId,@Param("workflowStatusIdForTransferSaved") Long workflowStatusIdForTransferSaved);

	@Modifying
	@Transactional
	@Query(value = "UPDATE `T_ASSOCIATE_ALLOCATION` SET supervisor_id=:#{#supervisorDto.supervisorId}  WHERE associate_project_id = (SELECT associate_project_id FROM `T_ASSOCIATE_PROJECT` WHERE project_id=:#{#supervisorDto.projectId} AND employee_id=:empId AND status_id= :statusIdForActive)", nativeQuery = true)
	void updateSupervisorDetails(@Valid SupervisorDto supervisorDto, @Param("empId") Long empId, @Param("statusIdForActive") Long statusIdForActive);
	
	@Query(value = "SELECT * FROM `T_ASSOCIATE_ALLOCATION` WHERE requirement_id = :requirementId AND \r\n"
			+ "	status_id = :statusIdForActive AND workflow_status_id IN (:savedWrkflwStatusId) AND associate_project_id IN \r\n"
			+ "	(SELECT associate_project_id FROM `T_ASSOCIATE_PROJECT` WHERE employee_id = :empId AND project_id = :projectId )", nativeQuery = true)
	TAssociateAllocation getTargetProjectAllocationId(@Param("empId")long empId, @Param("requirementId")long requirementId, @Param("projectId")long projectId,
			@Param("statusIdForActive")Long statusIdForActive,@Param("savedWrkflwStatusId") List<Long> savedWrkflwStatusId);
	
	
	@Query(value = "SELECT `project_id` FROM `zf_projectdefinition`.`M_PROJECT` WHERE `project_code` = :projectCode", nativeQuery = true)
	Long getProjectIdByCode(@Param("projectCode") String projectCode);

	@Query(value = "SELECT pro.employee_id  FROM `T_ASSOCIATE_ALLOCATION` allo INNER JOIN T_ASSOCIATE_PROJECT pro"
			+ " ON allo.associate_project_id = pro.associate_project_id WHERE pro.employee_id IN (:employeeIdList) "
			+ "AND pro.project_id = :targetprojectId AND allo.status_id = :statusId AND allo.workflow_status_id IN :listOfWorkFlowIds  AND"
			+ " allo.requirement_id = :targetRequirmentId", nativeQuery = true)
	List<Long> getAllocatedResOnSameReqForTransfer(@Param("employeeIdList") List<Long> employeeIdList,
			@Param("statusId") Long statusId, @Param("listOfWorkFlowIds") List<Long> listOfWorkFlowIds, @Param("targetprojectId") Long targetprojectId,
			@Param("targetRequirmentId") Long targetRequirmentId);
	
	@Query(value = "SELECT * FROM `T_ASSOCIATE_ALLOCATION` WHERE `associate_project_id` = :associateProjectId AND `status_id` = :statusId AND `workflow_status_id` = :workflowStausId ", nativeQuery = true)
	TAssociateAllocation getAllocationByassociateProjId(@Param("associateProjectId") Long associateProjectId,@Param("statusId") Long statusId,@Param("workflowStausId") Long workflowStausId);

	
	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.actual_allocation_end_date AS ActualAllocationEndDate,TA.service_line_id AS ServiceLineId,TA.std_cost AS employeeCostRate,TA.associate_project_id AS AssociateProjectId,TA.requirement_id AS RequirementId,TD.employee_id AS EmployeeId,TD.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TD.`deallocation_date` AS DeallocationDate \r\n"
			+ "	,TP.`srf_id` AS srfId,TP.`supervisor_id` AS superVisorId,TA.`cap_hr` AS capHours,TD.`remarks` AS comments, TA.allocation_type_id AS AllocationTypeId, TD.workflow_status_id AS WorkflowStatusId, TA.skill_champion_flag AS skillChampionFlag \r\n"
			+ "	FROM `T_ASSOCIATE_ALLOCATION` AS TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "	ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "	LEFT OUTER JOIN `T_ASSOCIATE_DEALLOCATION` TD \r\n"
			+ "	ON TA.`associate_allocation_id` = TD.`associate_allocation_id`\r\n"
			+ "	WHERE (TD.`employee_id` = :employeeId AND (TA.`status_id` = :statusIdActiveAllocation AND TA.`workflow_status_id` IN :workflowStatusIdAllocation  AND  TD.`status_id` = :statusIdDeactiveDeallocation AND TD.`workflow_status_id` IN :workflowStatusIdDeallocation))", nativeQuery = true)
	List<AllocatedResourceProjection>  resourceResvrForDealloc(@Param("employeeId") Long employeeId,
			@Param("workflowStatusIdAllocation") List<Long> workflowStatusIdAllocation,
			@Param("workflowStatusIdDeallocation") List<Long> workflowStatusIdDeallocation,
			@Param("statusIdActiveAllocation") Long statusIdActiveAllocation,
			@Param("statusIdDeactiveDeallocation") Long statusIdDeactiveDeallocation);

	@Query(value = "SELECT count(TA.associate_allocation_id) "
			+ "FROM T_ASSOCIATE_ALLOCATION TA INNER JOIN T_ASSOCIATE_PROJECT TP \r\n"
			+ "ON TA.associate_project_id = TP.associate_project_id \r\n"
			+ "WHERE TP.employee_id= :employeeId AND TA.status_id= :statusId AND TA.workflow_status_id = :statusForAllocApproved AND TA.billable_status_id != :lookupIdForPool && TP.project_id =:projectId", nativeQuery = true)
	Long checkIfexist(@Param("employeeId") Long employeeId,
			@Param("statusId") long statusId, @Param("statusForAllocApproved") Long statusForAllocApproved, @Param("lookupIdForPool") Long lookupIdForPool, @Param("projectId") long projectId);

	
	@Query(value = "SELECT TP. FROM `T_ASSOCIATE_PROJECT` TP JOIN `T_ASSOCIATE_ALLOCATION` TA\r\n" +
            "ON TP.`associate_project_id` = TA.`associate_project_id`\r\n" +
            "WHERE TP.`employee_id` IN :employeeId AND TP.`status_id` = :allocActivestatusId AND TA.`status_id` = :allocActivestatusId AND TA.`billable_status_id` = :billableStatusIdforPool\r\n" +
            "AND TA.`workflow_status_id` = :workflowStatusIdForAllocApproved", nativeQuery = true)
            List<TAssociateProjectDto> getPoolAllocationForResource(
            @Param("employeeId") List<Long> employeeId,@Param("allocActivestatusId") Long allocActiveStatusId,
            @Param("billableStatusIdforPool") Long billableStatusId,@Param("workflowStatusIdForAllocApproved") Long workflowStatusIdForAllocApproved);


	@Query(value = "SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.associate_project_id AS AssociateProjectId,TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TP.`srf_id` AS srfId,TP.`supervisor_id` AS superVisorId ,TA.`cap_hr` AS capHours,TA.`remarks` AS comments,TA.`billable_status_reason_id` AS ebrReason,TA.`std_cost` AS employeeCostRate,TA.`skill_id` AS defaultSkillId \r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA JOIN `T_ASSOCIATE_PROJECT` TP\r\n"
			+ "ON TA.`associate_project_id`= TP.`associate_project_id`\r\n"
			+ "WHERE TP.`employee_id`IN :employeeId AND TA.`status_id` = :statusId AND TA.`workflow_status_id` = :workflowStatusId  AND TA.billable_status_id = :lookupIdForPool AND TA.requirement_id IS NOT NULL;", nativeQuery = true)
	List<AllocatedResourceProjection> getProjectionForPool(@Param("employeeId") List<Long> employeeId,
			@Param("statusId") Long statusId, @Param("workflowStatusId") Long workflowStatusId,@Param("lookupIdForPool") Long lookupIdForPool);

	@Modifying
	@Transactional
	@Query(value = "UPDATE `T_ASSOCIATE_ALLOCATION` SET `status_id` = :statusId ,`effective_end_date` = :poolEndDate ,`actual_allocation_end_date` = :poolEndDate,`last_updated_date` = NOW(),`last_updated_by` = :userId WHERE `associate_allocation_id` = :associateAllocId AND `associate_project_id` = :associateProjectId\r\n", nativeQuery = true)
	 public void deactivateFullRecordForPool(@Param("statusId") Long statusId,@Param("associateAllocId") Long associateAllocId,@Param("associateProjectId") Long associateProjectId,@Param("poolEndDate") LocalDateTime poolEndDate,@Param("userId") Long userId);
	
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE `T_ASSOCIATE_PROJECT` SET  status_id = :statusId,`effective_end_date` = :poolEndDate  WHERE  `associate_project_id` = :associateProjectId ", nativeQuery = true)
	public void deactivateFullRecordForPoolInTassProj(@Param("statusId") Long statusId,@Param("associateProjectId") Long associateProjectId,@Param("poolEndDate") LocalDateTime poolEndDate);
	
	@Query(value = "SELECT * FROM `T_ASSOCIATE_ALLOCATION` WHERE associate_allocation_id = :associateAllocId ", nativeQuery = true)
	TAssociateAllocation getAssAllocById(@Param("associateAllocId") long associateAllocId);
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE `T_ASSOCIATE_ALLOCATION` SET `workflow_status_id` = :statusId,`effective_end_date` = :poolEndDate ,`actual_allocation_end_date` = :poolEndDate ,`last_updated_date` = NOW(),`last_updated_by` = :userId WHERE `associate_allocation_id` = :associateAllocId AND `associate_project_id` = :associateProjectId \r\n", nativeQuery = true)
	 public void deactivatePoolRecordForTAssocAlloc(@Param("statusId") Long statusId,@Param("associateAllocId") Long associateAllocId,@Param("associateProjectId") Long associateProjectId,@Param("poolEndDate") LocalDateTime poolEndDate,@Param("userId") Long userId);

	@Query(value="SELECT service_line FROM zf_admin.M_SERVICE_LINE WHERE service_line_id =:serviceLineId",nativeQuery=true)
	String getServiceLineByServiceLineId(Long serviceLineId);
	
	@Query(value = "SELECT tap.employee_id FROM T_ASSOCIATE_PROJECT tap INNER JOIN T_ASSOCIATE_ALLOCATION taa ON taa.associate_project_id = tap.associate_project_id WHERE tap.employee_id IN (:empIdList) AND taa.billable_status_id IN (:billableStatusId) AND taa.status_id=:statusId AND tap.status_id =:statusId AND taa.workflow_status_id=:wrkflwStatusId", nativeQuery = true)
	List<Long> getEmployeeIdForSearch(@Param("billableStatusId") List<Long> billableStatusId, @Param("statusId") long statusId,
			@Param("empIdList") List<Long> empIdList,@Param("wrkflwStatusId") long wrkflwStatusId);

	@Query(value = "SELECT associate_allocation_id FROM `T_ASSOCIATE_ALLOCATION` WHERE workflow_status_id IN (:wfStatusId) AND status_id=:statusIdForActive \r\n"
			+ "AND associate_allocation_id IN (:associateAllocationIds)", nativeQuery = true)
	List<Long> getAllocationApprovedList(List<Long> associateAllocationIds, List<Long> wfStatusId,
			Long statusIdForActive);

	@Query(value = "SELECT associate_allocation_id FROM T_ASSOCIATE_ALLOCATION allo INNER JOIN T_ASSOCIATE_PROJECT pro ON allo.associate_project_id = pro.associate_project_id\r\n"
			+ " WHERE  pro.project_id = :projectId AND allo.status_id = :statusIdForActive AND workflow_status_id IN :wfStatusId AND pro.status_id = :statusIdForActive", nativeQuery = true)
	List<Long> getReservedAllocationList(Long projectId, List<Long> wfStatusId,
			Long statusIdForActive);

	@Query(value = "SELECT * FROM T_ASSOCIATE_ALLOCATION allo INNER JOIN T_ASSOCIATE_PROJECT pro ON allo.associate_project_id = pro.associate_project_id\r\n"
			+ " WHERE  pro.project_id = :projectId AND allo.status_id = :statusIdForActive AND workflow_status_id IN (:wfStatusIdList) AND pro.status_id = :statusIdForActive", nativeQuery = true)
	List<TAssociateAllocation> getReservedAssociateAllocationList(Long projectId, Long statusIdForActive,
			List<Long> wfStatusIdList);

	@Query(value="SELECT DISTINCT service_line_id FROM `T_ASSOCIATE_ALLOCATION` allo INNER JOIN T_ASSOCIATE_PROJECT pro ON allo.associate_project_id = pro.associate_project_id \r\n" + 
			"WHERE  pro.project_id = :projectId ",nativeQuery=true)
	List<Long> getServiceLineForRequirement(long projectId);
	
	@Query(value="SELECT service_line_id FROM zf_projectdefinition.B_PROJECT_SERVICE_LINE WHERE project_id =:projectId",nativeQuery=true)
	List<Long> getProjectServiceLineIdbyProjectId(Long projectId);
	
	@Query(value="SELECT lookup_value_description FROM `zf_admin`.`M_LOOKUP_VALUE` WHERE lookup_value_id =:allocationTypeId",nativeQuery = true)
	String getAllocationTypeByAllocationTypeId(Long allocationTypeId);
	
	@Query(value="SELECT ta.fte_percent FROM T_ASSOCIATE_ALLOCATION ta INNER JOIN T_ASSOCIATE_PROJECT tp ON ta.associate_project_id = tp.associate_project_id WHERE ta.workflow_status_id = 74 AND ta.status_id=65 AND tp.status_id = 65 AND tp.employee_id=12650",nativeQuery = true)
	List<Long> getTotalFteForEmployee(Long workflowStatusId,Long statusId,Long employeeId);

	@Query(value="SELECT TA.associate_allocation_id AS AssociateAllocationId,TA.associate_project_id AS AssociateProjectId, TA.requirement_id AS RequirementId,TP.employee_id AS EmployeeId,TP.project_id AS ProjectId, TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,TA.work_location_id AS WorklocationId,ML.location_name AS WorkLocation,TA.`workflow_status_id` AS WorkflowStatusId FROM zf_resourcemanagement.T_ASSOCIATE_ALLOCATION TA INNER JOIN zf_resourcemanagement.T_ASSOCIATE_PROJECT TP ON TA.associate_project_id = TP.associate_project_id INNER JOIN zf_admin. M_LOCATION ML ON ML.location_id = TA.work_location_id WHERE TA.requirement_id=:requirementId AND TA.workflow_status_id IN (:workflowStatusIds) AND TA.status_id=:statusId AND TP.status_id =:statusId AND (TA.`actual_allocation_end_date` IS NULL OR TA.`actual_allocation_end_date`='1111-11-11 00:00:00')",nativeQuery=true)
//	List<AllocatedResourceProjection> getAlllocatedFteRsrcForReq(Long requirementId,Long workflowStatusId,Long statusId);
	List<AllocatedResourceProjection> getAlllocatedFteRsrcForReq(Long requirementId,List<Long> workflowStatusIds,Long statusId);
	
	@Query(value = "SELECT `employee_id` FROM `zf_admin`.`M_EMPLOYEE` WHERE `employee_number` IN :employeeNumber ", nativeQuery = true)
	List<Long> getEmployeeIds(@Param("employeeNumber") List<Long> employeeNumber);

	@Query(value = "SELECT count(TA.associate_allocation_id) "
			+ "FROM T_ASSOCIATE_ALLOCATION TA INNER JOIN T_ASSOCIATE_PROJECT TP \r\n"
			+ "ON TA.associate_project_id = TP.associate_project_id \r\n"
			+ "WHERE TP.employee_id= :employeeId AND TA.status_id= :statusId AND TA.workflow_status_id = :statusForAllocApproved AND TA.billable_status_id = :lookupIdForPool AND TA.fte_percent = 100", nativeQuery = true)
	Long checkIfPoolResource(@Param("employeeId") Long employeeId,
			@Param("statusId") long statusId, @Param("statusForAllocApproved") Long statusForAllocApproved, @Param("lookupIdForPool") Long lookupIdForPool);

	@Query(value = "SELECT `employee_id` FROM `zf_admin`.`M_EMPLOYEE` WHERE `employee_number` = :employeeNumber ", nativeQuery = true)
	Long getEmployeeId(@Param("employeeNumber") Long employeeNumber);

	@Query(value = "SELECT employee_id AS empId, employee_number AS empNumber, employee_name AS empName FROM zf_admin.M_EMPLOYEE WHERE employee_number IN  \r\n" + 
			"(SELECT employee_number FROM zf_admin.`V_M_PROJECT_OWNER_DETAIL` WHERE project_id IN (:projectId) AND role_code=8506 AND owner_status='" + ResourceManagementConstant.ACTIVATE_STATUS +"' AND \r\n" + 
			"additional_owner='false') LIMIT 1", nativeQuery = true)
	SupervisorProjection getSupervisorsList(Long projectId);
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_ALLOCATION SET workflow_status_id=:workflowStatusId,status_id=:allocDeactiveStatusId ,LAST_UPDATED_DATE = NOW() ,EFFECTIVE_END_DATE =:allocationEndDate, ACTUAL_ALLOCATION_END_DATE = :allocationEndDate,LAST_UPDATED_BY = :userId WHERE  ASSOCIATE_ALLOCATION_ID = :transactionHistoryIdList", nativeQuery = true)
	void deactivateResourceAllocationForSourceRecSWithStatusId(@Param("transactionHistoryIdList") Long transactionHistoryIdList,
			@Param("userId") Long userId,@Param("allocationEndDate") LocalDateTime allocationEndDate, @Param("workflowStatusId") Long workflowStatusId,@Param("allocDeactiveStatusId") Long allocDeactiveStatusId);


	//query code 140421 start
	@Query(value="SELECT talloc.associate_allocation_id as AssociateAllocationId, talloc.actual_allocation_start_date as ActualAllocationStartDate,talloc.actual_allocation_end_date as ActualAllocationEndDate,talloc.std_cost AS employeeCostRate,\r\n" + 
			"talloc.fte_percent as FtePercent, talloc.est_allocation_end_date as estAllocationEndDate FROM (T_ASSOCIATE_ALLOCATION talloc INNER JOIN T_ASSOCIATE_PROJECT tpro ON tpro.associate_project_id=talloc.associate_project_id)\r\n" + 
			"WHERE tpro.project_id=:projectId AND talloc.status_id=:allocStatusId AND tpro.employee_id IN (:empIdList) AND talloc.requirement_id=:requirementId", nativeQuery = true)
	public List<AssociateDeAllocationProjection> getResourceExitRemainingBudget(Long projectId, List<Long> empIdList,
			Long requirementId, Long allocStatusId);
	//query code 140421 end

	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_ALLOCATION SET  `workflow_status_id` = :deAllocApprovedStatusId , `actual_allocation_end_date` = :deallocationDate, last_updated_by=:userId, last_updated_date= NOW(), effective_end_date= NOW() WHERE associate_allocation_id IN (:rmAllocTranscIdList)", nativeQuery = true)
	void updateStatusAndEffectiveEndDateForDealloc(@Param("deAllocApprovedStatusId") long deAllocApprovedStatusId,
			@Param("rmAllocTranscIdList") List<Long> rmAllocTranscIdList,
			@Param("deallocationDate") Date deallocationDate, @Param("userId") Long userId) throws ResourceManagementException;
	
	@Query(value = "SELECT fte_percent FROM T_ASSOCIATE_ALLOCATION WHERE REQUIREMENT_ID =:requirementId AND ASSOCIATE_PROJECT_ID = (SELECT ASSOCIATE_PROJECT_ID FROM T_ASSOCIATE_PROJECT WHERE EMPLOYEE_ID =:empId AND PROJECT_ID =:currentProjectId AND status_id =:activeStatusIdForProject) AND `associate_allocation_id` IN :transactionHistoryIds ", nativeQuery = true)
	Double getCurrentProjectUtilizatioonForTransfer(Long requirementId, long currentProjectId, long empId,
			List<Long> transactionHistoryIds, Long activeStatusIdForProject);


	@Query(value = "SELECT * FROM T_ASSOCIATE_ALLOCATION allo INNER JOIN T_ASSOCIATE_PROJECT pro ON allo.associate_project_id = pro.associate_project_id\r\n"
			+ " WHERE  pro.project_id = :projectId", nativeQuery = true)
	List<TAssociateAllocation> getAssociateList(@Param("projectId") long projectId) throws ResourceManagementException;

	@Query(value = "SELECT role_type_desc FROM zf_admin.V_M_ROLE_TYPE WHERE role_type_id=:roleId", nativeQuery = true)
	String getRoleName(long roleId);
	
	@Query(value = "SELECT employee_number FROM zf_admin.M_EMPLOYEE WHERE employee_id = :employeeId ", nativeQuery = true)
	Long getEmployeeNumber(@Param("employeeId") Long employeeId);

	@Query(value = " SELECT est_allocation_end_date AS praEstEndDate, actual_allocation_start_date AS praActStartDate, actual_allocation_end_date \r\n" + 
			" AS praActEndDate, project_id AS projectId FROM  T_ASSOCIATE_ALLOCATION TA,T_ASSOCIATE_PROJECT TP \r\n" + 
			" WHERE TA.associate_project_id=TP.associate_project_id AND employee_id=:employeeId AND TA.status_id=:statusIdForActive", nativeQuery = true)
	List<AllocDataProjection> getProjAllocationDetails(Long employeeId, Long statusIdForActive);

	@Query(value = "SELECT service_line_id FROM zf_projectdefinition.M_PROJECT_REQUIREMENT WHERE project_requirement_id=:reqId", nativeQuery = true)
	Long getReqServiceLineId(Long reqId);

	@Query(value = "SELECT * FROM T_ASSOCIATE_ALLOCATION allo INNER JOIN T_ASSOCIATE_PROJECT pro ON allo.associate_project_id = pro.associate_project_id\r\n"
			+ " WHERE  pro.project_id = :projectId AND allo.status_id = :statusIdForActive AND workflow_status_id IN (:workflowIds)  AND pro.status_id = :statusIdForActive", nativeQuery = true)
	List<TAssociateAllocation> getAssociateListByProjectId(Long projectId, Long statusIdForActive, List<Long> workflowIds);
	
}



