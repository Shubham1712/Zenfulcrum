package com.zensar.zenfulcrum.resourcemanagement.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateExtension;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AssociateExtensionProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.EstimatedEndDateProjection;

@Repository
public interface TAssociateExtensionRepository extends JpaRepository<TAssociateExtension, Long> {
	
	 @Query(value ="SELECT `transaction_history_Id` AS associateAllocationId,`est_allocation_end_date` AS approvedEndDate FROM `T_ASSOCIATE_EXTENSION` WHERE `transaction_history_Id` IN :associteAllocatioId AND `status_id` = :statusId AND `workflow_status_id` = :workflowStatusId" , nativeQuery = true) 
     List<EstimatedEndDateProjection> getApprovedEndDateofResource(List<Long> associteAllocatioId,Long statusId,Long workflowStatusId);

	 
		@Modifying
		@Transactional
		@Query( value ="UPDATE T_ASSOCIATE_EXTENSION  SET workflow_status_id = :wfstatusIdForApproved , status_id = :statusIdForDeactive WHERE workflow_status_id = :wfstatusIdForSubmit AND  status_id = :statusIdForActive AND transaction_history_Id IN :allocationTranscIdList", nativeQuery = true)
		void updateWorkflowStatusforExtension( @Param("wfstatusIdForApproved") long wfstatusIdForApproved,
                @Param("statusIdForDeactive") long statusIdForDeactive,
				@Param("wfstatusIdForSubmit") long wfstatusIdForSubmit,
				@Param("statusIdForActive") long statusIdForActive,
				@Param("allocationTranscIdList") List<Long> allocationTranscIdList) throws ResourceManagementException;

		
		@Query(value="SELECT DISTINCT tallocext.ASSOCIATE_EXTENSION_ID AS AssociateAllocationId, tallocext.est_allocation_end_date AS ExtEstEndDate, talloc.est_allocation_end_date AS EstEndDate, tallocext.requirement_id RequirementId, tproject.project_id ProjectId, tproject.employee_id AS EmployeeId \r\n" + 
				"FROM T_ASSOCIATE_EXTENSION tallocext  \r\n" + 
				"INNER JOIN T_ASSOCIATE_ALLOCATION talloc ON tallocext.TRANSACTION_HISTORY_ID = talloc.ASSOCIATE_ALLOCATION_ID\r\n" + 
				"INNER JOIN T_RESOURCE_WORKFLOW trscwrklw ON tallocext.ASSOCIATE_EXTENSION_ID = trscwrklw.TRANSACTION_ID \r\n" + 
				"INNER JOIN T_ASSOCIATE_PROJECT tproject ON tproject.ASSOCIATE_PROJECT_ID = talloc.ASSOCIATE_PROJECT_ID  \r\n"+
				"WHERE talloc.STATUS_ID =:activeStatusId AND talloc.WORKFLOW_STATUS_ID =:approvedStatusId AND tallocext.STATUS_ID =:activeStatusId AND tallocext.WORKFLOW_STATUS_ID =:submittedStatusId\r\n" + 
				"AND trscwrklw.WORKFLOW_TYPE_ID =:workflowTypeId AND trscwrklw.CURRENT_USER_ID =:userId AND trscwrklw.CURRENT_ROLE_ID =:roleId", nativeQuery = true)
		List<AllocatedResourceProjection> getActiveAllocationExtensionDetails(@Param("userId") Long userId, @Param("roleId") Long roleId, @Param("workflowTypeId") Long workflowTypeId,
				@Param("activeStatusId") Long activeStatusId, @Param("submittedStatusId") Long submittedStatusId, @Param("approvedStatusId") Long approvedStatusId);

		
		@Query(value ="SELECT * FROM `T_ASSOCIATE_EXTENSION` WHERE transaction_history_Id IN (:associteTransactionIds) AND \r\n" + 
			 		"workflow_status_id = :workflowStatusId AND status_id = :statusId" , nativeQuery = true) 
		 List<TAssociateExtension> getExtensionByTransactionId(List<Long> associteTransactionIds,Long statusId,Long workflowStatusId);
		 
		 
			@Query(value = "SELECT TA.`associate_allocation_id` AS allocationId ,TA.`requirement_id` AS requirmentId ,TE.`associate_extension_id` AS extensionId ,TE.`est_allocation_end_date` AS extendedDate\r\n" + 
					"FROM `T_ASSOCIATE_ALLOCATION` TA INNER JOIN `T_ASSOCIATE_PROJECT` TP \r\n" + 
					"ON TA.`associate_project_id` = TP.`associate_project_id`\r\n" + 
					"INNER  JOIN `T_ASSOCIATE_EXTENSION` TE\r\n" + 
					"ON TA.`associate_allocation_id` = TE.`transaction_history_Id`\r\n" + 
					"WHERE TP.`project_id` = :projectId AND TP.`employee_id` IN :empIds AND TE.`workflow_status_id` = :wfStatusforSubmittedforExtension AND TE.`status_id` = :statusIdforActive ",nativeQuery = true)
	        List<AssociateExtensionProjection> getExtensionResourceList(@Param("empIds") List<Long> empIds,@Param("projectId") Long projectId,@Param("wfStatusforSubmittedforExtension") Long wfStatusforSubmittedforExtension,@Param("statusIdforActive") Long statusIdforActive);
}
