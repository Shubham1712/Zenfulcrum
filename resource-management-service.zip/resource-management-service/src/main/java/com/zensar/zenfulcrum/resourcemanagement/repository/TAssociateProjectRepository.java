package com.zensar.zenfulcrum.resourcemanagement.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

import com.zensar.zenfulcrum.resourcemanagement.dto.SupervisorDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectAndAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateProject;
import com.zensar.zenfulcrum.resourcemanagement.projection.AssociateHistoryProjecation;
import com.zensar.zenfulcrum.resourcemanagement.projection.TAssociateProjectAndAllocationProjection;

@Repository
public interface TAssociateProjectRepository extends JpaRepository<TAssociateProject, Long> {

	public TAssociateProject findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Long employeeId, Long srfId,
			Long projectId, Long statusId);

	@Query(value = " SELECT DISTINCT employee_id FROM `T_ASSOCIATE_PROJECT` pro INNER JOIN T_ASSOCIATE_ALLOCATION allo ON allo.associate_project_id = pro.associate_project_id\r\n"
			+ " WHERE project_id = :projectId AND allo.status_id = :statusId", nativeQuery = true)
	List<Long> getEmpIdByProjectId(@Param("projectId") Long projectId, @Param("statusId") Long statusId);

	@Query(value = "SELECT * FROM T_ASSOCIATE_PROJECT WHERE employee_id =:employeeId AND project_id =:projectId ", nativeQuery = true)
	List<TAssociateProject> findByEmployeeIdAndProjectId(@Param("employeeId") Long employeeId,
			@Param("projectId") Long projectId);

	@Query(value = "SELECT tap.* FROM T_ASSOCIATE_ALLOCATION taa  JOIN  T_ASSOCIATE_PROJECT tap ON taa.associate_project_id = tap.associate_project_id WHERE taa.status_id = :statusId AND taa.workflow_status_id = :workflowStatusId AND tap.employee_id IN :employeeIdList AND tap.project_id = :projectId AND tap.status_id =:statusId", nativeQuery = true)
	List<TAssociateProject> getAssociateProjectByEmployeeIdAndStatusId(
			@Param("employeeIdList") List<Long> employeeIdList, @Param("statusId") Long statusId,
			@Param("workflowStatusId") Long workflowStatusId,@Param("projectId") Long projectId);

	@Query(value = "SELECT * FROM T_ASSOCIATE_PROJECT tap INNER JOIN T_ASSOCIATE_ALLOCATION taa ON tap.associate_project_id = taa.associate_project_id WHERE tap.employee_id = :employeeId AND tap.project_id = :projectId AND tap.status_id =:statusId AND taa.workflow_status_id =:wrkflwStatusId", nativeQuery = true)
	TAssociateProject getByEmpIdAndProjId(@Param("projectId") Long projectId, @Param("employeeId") Long employeeId,@Param("statusId")Long statusId, @Param("wrkflwStatusId")Long wrkflwStatusId);

	TAssociateProject findByAssociateProjectId(Long associateProjectId);

	@Query(value = "SELECT `project_id` FROM `T_ASSOCIATE_PROJECT` WHERE `employee_id`=:empId", nativeQuery = true)
    List<Long> getProjectIds(@Param("empId") Long empId);

	@Query(value = "SELECT count(distinct(employee_id)) FROM `T_ASSOCIATE_PROJECT`\r\n"
			+ "	WHERE `project_id` =:projectId\r\n"
			+ "	AND status_id= (SELECT module_status_id\r\n"
			+ "	FROM zf_admin.V_M_MODULE_STATUS\r\n"
			+ "	WHERE module_name='"+ResourceManagementConstant.RESOURCE_ALLOCATION+"' "
			+ "AND module_status='"+ResourceManagementConstant.ACTIVATE+"')", nativeQuery = true)
	long getAllocatedResource(long projectId);

	@Query(value = "SELECT tp.project_id AS projectId,ta.`actual_allocation_start_date` AS actualAllocationStartDate,ta.`actual_allocation_end_date` AS actualAllocationEndDate, ta.created_date AS createdDate,\r\n"
			+ "ta.`est_allocation_end_date` AS estimatedReleaseDate,ta.`fte_percent` AS utilization ,srf.srf_number AS srfNo,ta.status_id as statusId ,ta.`service_line_id` as serviceLineId\r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` ta LEFT JOIN `T_ASSOCIATE_PROJECT` tp\r\n"
			+ "ON ta.`associate_project_id` = tp.associate_project_id LEFT JOIN `T_SRF` srf\r\n"
			+ "ON srf.srf_id=tp.srf_id WHERE tp.employee_id = :empId AND ta.`billable_status_id` NOT IN ( SELECT  `a`.`lookup_value_id`  FROM (zf_admin.`M_LOOKUP_VALUE` `a` JOIN zf_admin.`M_LOOKUP_TYPE` `b` ON ((`a`.`lookup_type_id` = `b`.`lookup_type_id`))) WHERE a.lookup_value_code = '" +ResourceManagementConstant.POOL+"')", nativeQuery = true)

	List<AssociateHistoryProjecation> getAssociateHistory(@Param("empId") long empId);

	@Query(value = "SELECT  tap.employee_id AS employeeId,tap.project_id AS projectId, taa.work_location_id AS workLocationId ,  taa.billable_status_id AS billableStatusId , taa.status_id AS statusId, taa.actual_allocation_start_date AS actualAllocationStartDate, taa.actual_allocation_end_date AS actualAllocationEndDate, taa.est_allocation_end_date AS estAllocationEndDate, taa.created_date AS createdDate, tsrf.srf_number AS srfNo, taa.fte_percent AS ftePercent, taa.service_line_id AS serviceLineId FROM T_ASSOCIATE_PROJECT tap INNER JOIN T_ASSOCIATE_ALLOCATION taa\r\n"
			+ "ON tap.associate_project_id = taa.associate_project_id LEFT JOIN T_SRF tsrf ON tsrf.srf_id = tap.srf_id WHERE tap.employee_id = :associateId", nativeQuery = true)
	List<TAssociateProjectAndAllocationProjection> findByEmployeeId(@Param("associateId") Long associateId);

	@Modifying
	@Transactional
	@Query(value = "UPDATE `T_ASSOCIATE_PROJECT` SET supervisor_id = :#{#supervisorDto.supervisorId}  WHERE project_id=:#{#supervisorDto.projectId} AND status_id= :statusIdForActive AND employee_id IN :#{#supervisorDto.employeeIds}", nativeQuery = true)
	public void updateSupervisorDetails(@Param("supervisorDto") SupervisorDto supervisorDto, @Param("statusIdForActive") Long statusIdForActive);

	@Query(value = "SELECT tp.project_id AS projectId, ta.fte_percent AS ftePercent, ta.billable_status_id AS billableStatusId FROM  T_ASSOCIATE_ALLOCATION ta JOIN T_ASSOCIATE_PROJECT tp ON ta.associate_project_id = tp.associate_project_id \r\n"
			+ "WHERE tp.project_id = :projectId", nativeQuery = true)
	List<TAssociateProjectAndAllocationProjection> getResourceUtilizationSummaryDetails(@Param("projectId") Long projectId);

	@Query(value = "SELECT * FROM `T_ASSOCIATE_PROJECT` TP JOIN `T_ASSOCIATE_ALLOCATION` TA\r\n" +
	"ON TP.`associate_project_id` = TA.`associate_project_id`\r\n" +
	"WHERE TP.`employee_id` IN :employeeId AND TP.`status_id` = :allocActiveStatusId AND TA.`status_id` = :allocActiveStatusId AND TA.`billable_status_id` = :billableStatusIdforPool\r\n" +
	"AND TA.`workflow_status_id` = :workflowStatusIdForAllocApproved", nativeQuery = true)
	List<TAssociateProject> getPoolProjectDetailsForResource(@Param("employeeId") List<Long> employeeId,@Param("allocActiveStatusId") Long allocActiveStatusId,
            @Param("billableStatusIdforPool") Long billableStatusId,@Param("workflowStatusIdForAllocApproved") Long workflowStatusIdForAllocApproved);
	
}
