package com.zensar.zenfulcrum.resourcemanagement.projection;

import lombok.Data;

@Data
public class MModuleProjection {

	public Long moduleStatusId;
	public Long moduleId;
	public String moduleCode;
	public String moduleName;
	public String remarks;
	
	
}
