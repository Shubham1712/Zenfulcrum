package com.zensar.zenfulcrum.resourcemanagement.dto;


import java.math.BigDecimal;

import lombok.Data;

@Data
public class CostCardDto {
	private Long hourlyCostCardId;
	private Long currencyId;
	private String currencyName;
	private BigDecimal eightHrsCostRate;
	private BigDecimal nineHrsCostRate;
}
