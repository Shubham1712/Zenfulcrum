package com.zensar.zenfulcrum.resourcemanagement.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.model.ResourceWorkflow;
import com.zensar.zenfulcrum.resourcemanagement.projection.ApprovalTraceabilityProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.ResourceWorkflowProjection;

@Repository
public interface ResourceWorkflowRepository extends JpaRepository<ResourceWorkflow, Long>{
	 
	 @Query( value ="SELECT * FROM T_RESOURCE_WORKFLOW WHERE transaction_id=:wrkflwTrnsctnId  AND status_id IN(:statusIdList) AND current_user_id=:currentUserId AND current_role_id=:currentRoleId", nativeQuery = true)
	 ResourceWorkflow getRowDataOfDefaultStatus(@Param("wrkflwTrnsctnId") long wrkflwTrnsctnId,@Param("statusIdList") List<Long> statusIdList ,@Param("currentUserId") long currentUserId, @Param("currentRoleId") long currentRoleId)throws ResourceManagementException;
	 
	 @Query( value ="SELECT * FROM T_RESOURCE_WORKFLOW WHERE transaction_id=:wrkflwTrnsctnId  AND current_user_id=:currentUserId AND current_role_id=:currentRoleId LIMIT 1", nativeQuery = true)
	 ResourceWorkflow getRowData(@Param("wrkflwTrnsctnId") long wrkflwTrnsctnId, @Param("currentUserId") long currentUserId, @Param("currentRoleId") long currentRoleId)throws ResourceManagementException;

	 @Query( value ="SELECT * FROM T_RESOURCE_WORKFLOW WHERE transaction_id=:wrkflwTrnsctnId AND next_user_id=:currentUserId AND next_role_id=:currentRoleId ORDER BY resource_workflow_id DESC LIMIT 1", nativeQuery = true)
	 ResourceWorkflow getPreviousRowData(@Param("wrkflwTrnsctnId") long wrkflwTrnsctnId, @Param("currentUserId") long currentUserId, @Param("currentRoleId") long currentRoleId)throws ResourceManagementException;
	 		 
	 @Query(value ="SELECT DISTINCT current_user_id as CurrentUserId, next_user_id as NextUserId, current_role_id as CurrentRoleId, next_role_id as NextRoleId FROM T_RESOURCE_WORKFLOW WHERE transaction_id=:transcId" , nativeQuery = true) 
	 List<ResourceWorkflowProjection> getAllApproversIdList(@Param("transcId") Long transcId)throws ResourceManagementException;
	 
	 @Query( value ="SELECT * FROM T_RESOURCE_WORKFLOW WHERE next_role_id =:roleId AND next_user_id =:userId AND status_id IN (:statusIdList) AND workflow_type_id=:workflowTypeId AND transaction_id=:wrkflwTrnsctnId ORDER BY last_updated_date DESC LIMIT 1", nativeQuery = true)
	 ResourceWorkflow getRecentPreviousRowData(@Param("wrkflwTrnsctnId") long wrkflwTrnsctnId, @Param("workflowTypeId") long workflowTypeId, @Param("userId") long userId, @Param("roleId") long roleId, @Param("statusIdList") List<Long> statusIdList)throws ResourceManagementException;
	 
	 @Query( value ="SELECT * FROM T_RESOURCE_WORKFLOW WHERE current_role_id =:roleId AND current_user_id =:userId AND workflow_type_id=:workflowTypeId AND transaction_id=:wrkflwTrnsctnId ORDER BY last_updated_date DESC LIMIT 1", nativeQuery = true)
	 ResourceWorkflow getRecentRowData(@Param("wrkflwTrnsctnId") long wrkflwTrnsctnId, @Param("workflowTypeId") long workflowTypeId, @Param("userId") long userId, @Param("roleId") long roleId)throws ResourceManagementException;
	 
	 @Query( value ="SELECT * FROM T_RESOURCE_WORKFLOW WHERE current_role_id =:roleId AND current_user_id =:userId AND status_id IN (:statusIdList) AND workflow_type_id=:workflowTypeId AND transaction_id=:wrkflwTrnsctnId ORDER BY last_updated_date DESC LIMIT 1", nativeQuery = true)
	 ResourceWorkflow getRecentNextRowData(@Param("wrkflwTrnsctnId") long wrkflwTrnsctnId, @Param("workflowTypeId") long workflowTypeId, @Param("userId") long userId, @Param("roleId") long roleId, @Param("statusIdList") List<Long> statusIdList)throws ResourceManagementException;
	
	 @Query(value ="SELECT * FROM T_RESOURCE_WORKFLOW WHERE transaction_id=:wrkflwTrnsctnId" , nativeQuery = true) 
	 List<ResourceWorkflow> findByWrkflwTrnsctnId(Long wrkflwTrnsctnId);
	 
	 @Query(value="SELECT tap.employee_id AS EmployeeId, trw.transaction_id AS TransactionId, trw.current_user_id AS CurrentUserId, taa.last_updated_date AS AllocLastUpdatedDate, taa.workflow_status_id AS WkflowStatusId, trw.current_role_id AS CurrentRoleId, trw.status_id AS StatusId, trw.last_updated_date AS WrkflwLastUpdatedDate, trw.comment AS Comments FROM T_RESOURCE_WORKFLOW trw INNER JOIN T_ASSOCIATE_ALLOCATION taa ON trw.transaction_id = taa.associate_allocation_id  INNER JOIN T_ASSOCIATE_PROJECT tap ON taa.associate_project_id = tap.associate_project_id WHERE taa.associate_allocation_id = :allocationId", nativeQuery=true)
	 List<ApprovalTraceabilityProjection> getAllocationTraceAbilityDetails(@Param("allocationId")Long allocationId);

	 @Query(value="SELECT tad.employee_id AS EmployeeId, trw.transaction_id AS TransactionId, trw.current_user_id AS CurrentUserId, tad.last_updated_date AS DeAllocLastUpdatedDate,tad.workflow_status_id AS WkflowStatusId, trw.current_role_id AS CurrentRoleId, trw.status_id AS StatusId, trw.last_updated_date AS WrkflwLastUpdatedDate, trw.comment AS Comments FROM T_RESOURCE_WORKFLOW trw INNER JOIN T_ASSOCIATE_DEALLOCATION tad ON trw.transaction_id = tad.associate_deallocation_id WHERE tad.associate_allocation_id=:deallocationId", nativeQuery=true)
	 List<ApprovalTraceabilityProjection> getDeAllocationTraceAbilityDetails(@Param("deallocationId")Long deallocationId);
	 
	 @Query(value="SELECT tap.employee_id AS EmployeeId, trw.transaction_id AS TransactionId, trw.current_user_id AS CurrentUserId, tae.last_updated_date AS DeAllocLastUpdatedDate,tae.workflow_status_id AS WkflowStatusId, trw.current_role_id AS CurrentRoleId, trw.status_id AS StatusId, trw.last_updated_date AS WrkflwLastUpdatedDate, trw.comment AS Comments FROM T_RESOURCE_WORKFLOW trw INNER JOIN T_ASSOCIATE_EXTENSION tae ON trw.transaction_id = tae.associate_extension_id INNER JOIN T_ASSOCIATE_PROJECT tap ON tae.associate_project_id = tap.associate_project_id WHERE tae.associate_extension_id=:extensionId", nativeQuery=true)
	 List<ApprovalTraceabilityProjection> getExtensionTraceAbilityDetails(@Param("extensionId")Long extensionId);
	 
	 @Query(value="SELECT module_name FROM zf_admin.`M_MODULE` WHERE module_id = (SELECT module_id FROM zf_admin.`B_MODULE_STATUS` WHERE module_status_id=:workflowStatusId)", nativeQuery=true)
	 String getModuleName(Long workflowStatusId);

	//Added by Mrunal Marne for RM transfer approval/rejection
	 @Query(value ="SELECT * FROM T_RESOURCE_WORKFLOW WHERE transaction_id=:wrkflwTrnsctnId AND current_user_id=:currentUserId AND current_role_id=:currentRoleId LIMIT 2", nativeQuery = true)
	 List<ResourceWorkflow> getRowDataForPMRole(@Param("wrkflwTrnsctnId") long wrkflwTrnsctnId, @Param("currentUserId") long currentUserId, @Param("currentRoleId") long currentRoleId)throws ResourceManagementException;
	 
	 @Query(value ="SELECT * FROM T_RESOURCE_WORKFLOW WHERE transaction_id=:wrkflwTrnsctnId AND current_user_id=:currentUserId AND current_role_id=:currentRoleId AND next_role_id != :currentRoleId LIMIT 1", nativeQuery = true)
	 ResourceWorkflow getRowDataForTagRole(@Param("wrkflwTrnsctnId") long wrkflwTrnsctnId, @Param("currentUserId") long currentUserId, @Param("currentRoleId") long currentRoleId)throws ResourceManagementException;
	 
	 @Query(value ="SELECT current_user_id FROM T_RESOURCE_WORKFLOW WHERE transaction_id=:wrkflwTrnsctnId AND current_role_id=:currentRoleId AND next_role_id != :currentRoleId LIMIT 1", nativeQuery = true)
	 Long getUserIdForPMApproved(@Param("wrkflwTrnsctnId") long wrkflwTrnsctnId, @Param("currentRoleId") long currentRoleId)throws ResourceManagementException;
	 
	 @Modifying
	 @Transactional
	 @Query(value ="DELETE FROM T_RESOURCE_WORKFLOW WHERE transaction_id IN(:wrkflwTrnsctnId) AND status_id IN(:statusIdList)", nativeQuery = true)
	 void deleteRowsOfDefaultStatus(@Param("wrkflwTrnsctnId") List<Long> wrkflwTrnsctnId,@Param("statusIdList") List<Long> statusIdList) throws ResourceManagementException;
	 
	 @Modifying
	 @Transactional
	 @Query(value ="DELETE FROM T_RESOURCE_WORKFLOW WHERE transaction_id IN(:wrkflwTrnsctnId)", nativeQuery = true)
	 void deleteWorkflowRecords(@Param("wrkflwTrnsctnId") List<Long> wrkflwTrnsctnId) throws ResourceManagementException;
}
