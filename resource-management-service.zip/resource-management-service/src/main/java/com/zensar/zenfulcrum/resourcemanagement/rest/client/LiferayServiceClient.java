package com.zensar.zenfulcrum.resourcemanagement.rest.client;

import static java.util.Optional.ofNullable;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.zensar.zenfulcrum.resourcemanagement.dto.MailTemplateDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.util.HttpRequestUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class LiferayServiceClient {

	@Value("${LIFERAY.SERVICE.URL}")
	private String liferayBaseUrl; 
	
	@Autowired
	private RestTemplate restTemplate;
	
	public MailTemplateDto getEmailTemplate(String filePath) throws ResourceManagementException {
		log.info("Entered into LiferayServiceClient.getEmailTemplate method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		String url = liferayBaseUrl + filePath ;
		MailTemplateDto mailTemplateDtls = null;
		try {
			ResponseEntity<MailTemplateDto> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET, requestEntityObj,
					new ParameterizedTypeReference<MailTemplateDto>() {});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<MailTemplateDto>  mailTemplateOptnlObj = ofNullable(responseEntityObj.getBody());
				if(mailTemplateOptnlObj.isPresent())
					mailTemplateDtls = mailTemplateOptnlObj.get();
			}
		}catch (ResourceAccessException rae) {
			log.error("getEmailTemplate|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
        } catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getEmailTemplate|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
        }	
		log.info("Just before leaving LiferayServiceClient.getEmailTemplate method:");
		return mailTemplateDtls ;
	}
	
}
