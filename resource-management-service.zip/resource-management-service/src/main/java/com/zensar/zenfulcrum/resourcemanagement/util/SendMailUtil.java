package com.zensar.zenfulcrum.resourcemanagement.util;

import java.io.File;
import javax.mail.internet.MimeMessage;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.resourcemanagement.dto.MailDetail;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

import lombok.extern.slf4j.Slf4j;


@Component
@Slf4j
public class SendMailUtil {

	@Autowired
	private JavaMailSender javaMailSender;

	public void sendMail(final MailDetail mailDetails)throws ResourceManagementException{
		log.info("Entered into SendMailUtil.sendMail method:");
		try {		
			if(CollectionUtils.isEmpty(mailDetails.getMailToAddress()) || mailDetails.getMailSubject() == null) {
				throw new ResourceManagementException(ResourceManagementConstant.INSUFFICIENT_EMAIL_PARAMS);
			}else {
				MimeMessage mimeMessage = javaMailSender.createMimeMessage();
				MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage,true);
				mimeMessageHelper.setSubject(mailDetails.getMailSubject());
				mimeMessageHelper.setFrom(ResourceManagementConstant.FROM_EMAIL_ADDRESS);
				String[] toEmailAddresses = mailDetails.getMailToAddress().stream().toArray(String[]::new);
				mimeMessageHelper.setTo(toEmailAddresses);
				if(CollectionUtils.isNotEmpty(mailDetails.getMailCcAddress())) {
					String[] ccEmailAddresses = mailDetails.getMailCcAddress().stream().toArray(String[]::new);
					mimeMessageHelper.setCc(ccEmailAddresses);
				}
				if(CollectionUtils.isNotEmpty(mailDetails.getMailBccAddress())) {
					String[] bccEmailAddresses = mailDetails.getMailBccAddress().stream().toArray(String[]::new);
					mimeMessageHelper.setBcc(bccEmailAddresses);
				}
				mimeMessageHelper.setText(mailDetails.getMailBody(), true);
				javaMailSender.send(mimeMessage);
			}
		}catch(Exception exp) {
			log.error("sendMail|exception:{}", exp);
			throw new ResourceManagementException(exp);
		}
//		log.info("Just before leaving SendMailUtil.sendMail method:");		
	}

	public void sendMultipartMail(final MailDetail mailDetails, String filePath, String fileName)throws ResourceManagementException{
		log.info("Entered into SendMailUtil.sendMultipartMail method:");
		try {		
			if(CollectionUtils.isEmpty(mailDetails.getMailToAddress()) || mailDetails.getMailSubject() == null) {
				throw new ResourceManagementException(ResourceManagementConstant.INSUFFICIENT_EMAIL_PARAMS);
			}else {
				MimeMessage mimeMessage = javaMailSender.createMimeMessage();
				MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage,true);
				mimeMessageHelper.setSubject(mailDetails.getMailSubject());
				mimeMessageHelper.setFrom(ResourceManagementConstant.FROM_EMAIL_ADDRESS);
				String[] toEmailAddresses = mailDetails.getMailToAddress().stream().toArray(String[]::new);
				mimeMessageHelper.setTo(toEmailAddresses);
				if(CollectionUtils.isNotEmpty(mailDetails.getMailCcAddress())) {
					String[] ccEmailAddresses = mailDetails.getMailCcAddress().stream().toArray(String[]::new);
					mimeMessageHelper.setCc(ccEmailAddresses);
				}
				if(CollectionUtils.isNotEmpty(mailDetails.getMailBccAddress())) {
					String[] bccEmailAddresses = mailDetails.getMailBccAddress().stream().toArray(String[]::new);
					mimeMessageHelper.setBcc(bccEmailAddresses);
				}
				mimeMessageHelper.setText(mailDetails.getMailBody(), true);
				mimeMessageHelper.addAttachment(fileName, new FileSystemResource(new File(filePath)));			 
				javaMailSender.send(mimeMessage);
			}
		}catch(Exception exp) {
			log.error("sendMail|exception:{}", exp);
			throw new ResourceManagementException(exp);
		}		
		log.info("Just before leaving SendMailUtil.sendMultipartMail method:");		
	}
}
