package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class MLookupTypeDto {
	
	private Long lookupTypeId;
	private String lookupType;
	private String lookupTypeDescription;

}
