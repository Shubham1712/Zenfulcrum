package com.zensar.zenfulcrum.resourcemanagement.dto;


import lombok.Data;

@Data
public class PracticeProjectDto {

	private int practiceProjectId;
	private int practiceId;
	private int projectId;
	private String projectCode;
	private String practiceProjectName;
}
