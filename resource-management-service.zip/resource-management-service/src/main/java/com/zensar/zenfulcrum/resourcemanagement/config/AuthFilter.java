package com.zensar.zenfulcrum.resourcemanagement.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AuthServiceClient;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@Order(value=1)
public class AuthFilter implements Filter {
	
	@Autowired
	AuthServiceClient authServiceClient;
	
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
	   try {
		   HttpServletRequest request = (HttpServletRequest)req;
		   log.info("Entered inside the AuthFilter.doFilter:"+request.getRequestURI());
		   if(isAuthenticationRequired(request)) {
			   String tokenValue = request.getHeader("Authorization");
			    String userCode = request.getHeader("AuthUserCode");
			    String userSessionId = request.getHeader("AuthUserSessionId");
			    if(tokenValue != null) {
			    	log.info("Recieved valid form of access token:"+tokenValue+userCode+userSessionId); 
			    	boolean validationResult = authServiceClient.validateAccessToken(tokenValue, userCode, userSessionId);
			    	if(validationResult) {
			    		log.info("Token validation is success:");
			    		chain.doFilter(req, res);
			    	}else {
			    		log.info("Token validation is not success:");
			    		throw new ResourceManagementException("INVALID_ACCESS_TOKEN");
			    	}
			    }else {
			    	log.info("Access token not exits in request header:");
			    	throw new ResourceManagementException("INVALID_ACCESS_TOKEN");
			    }
		   }else {
			   chain.doFilter(request, res);
		   }		  
	   }catch(ResourceManagementException rme) {
			rme.printStackTrace();
		   throw new ServletException("INVALID_ACCESS_TOKEN");
	   }	   
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void init(FilterConfig filterConfig) {
		log.debug("Inside init of AuthFilter");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void destroy() {
		log.debug("Inside destroy of AuthFilter");
	}
	
	
	public boolean isAuthenticationRequired( HttpServletRequest request) {
		  log.info("Entered inside the AuthFilter.isAuthenticationRequired:"+request.getRequestURI());
		  List<String> requestPathList = new ArrayList<String>();
		  /*requestPathList.add("/resourceallocation/");
		  requestPathList.add("/resourcedashboard/");
		  requestPathList.add("/resourcemanagement/");
		  requestPathList.add("/rmprojectDetails/");
		  requestPathList.add("/resourcerequirement/");
		  requestPathList.add("/report/");
		  requestPathList.add("/resourcedeallocation/");
		  requestPathList.add("/resourcesearch/");
		  requestPathList.add("/transfermanagement/");
		  requestPathList.add("/resourceutilization/");*/
		  requestPathList.add("/test/");
		  for (String requestPath : requestPathList) {
			  if(request.getRequestURI().contains(requestPath))
				  return true;		  
		  }		  
		  return false;
	}
	
	
}
