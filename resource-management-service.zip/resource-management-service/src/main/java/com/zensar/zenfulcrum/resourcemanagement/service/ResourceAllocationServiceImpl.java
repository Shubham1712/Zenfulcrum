package com.zensar.zenfulcrum.resourcemanagement.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.HashBasedTable;
import com.zensar.zenfulcrum.resourcemanagement.dto.AllocationTypeStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.BAllocationMilestoneDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeSkillDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueNewDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PrimaryUsersDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ReasonForDeallocation;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ServiceLineDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.AllocatedResourceHelperClass;
import com.zensar.zenfulcrum.resourcemanagement.helper.JVCheckHelperService;
import com.zensar.zenfulcrum.resourcemanagement.helper.SendMailHelperService;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateProjectMapper;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocationBudget;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateProject;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateSkill;
import com.zensar.zenfulcrum.resourcemanagement.model.TSrf;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AvaibalityProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.SrfProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.JVDetailsRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateSkillRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TSrfRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.RMBudgetControlUtil;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class ResourceAllocationServiceImpl implements ResourceAllocationService {
    
	@Autowired
	private BudgetControlServiceClient budgetControlServiceClient;

	@Autowired
	private BAPServiceClient bapServiceClient;

	@Autowired
	private TAssociateProjectRepository associateProjectRepository;

	@Autowired
	private AdminServiceClient adminServiceClient;

	@Autowired
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Autowired
	private TAssociateProjectMapper asssociateProjectMapper;

	@Autowired
	private TSrfRepository tSrfRepository;

	@Autowired
	private SendMailHelperService sendMailHelperService;

	@Autowired
	private TAssociateSkillRepository skillRepository;

	@Autowired
	private JVDetailsRepository jvDetailsRepository;

	@Autowired
	JVCheckHelperService jvCheckHelperService;
	
	@Autowired
	AllocatedResourceHelperClass allocatedResourceHelper;
	
	@Autowired
    private ResourceRequirementServiceImpl resourceRequirementServiceImpl;
	
	@Autowired
    private ResourceManagementServiceImpl resourceManagementServiceImpl;

	DateFormat formater = new SimpleDateFormat("yyyy-MM");

	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

	@Override
	public List<EmployeeDto> getEarmarkedAssociates(Long projectId, Long requirementId)
			throws ResourceManagementException {
		log.info("Start get getEarmarkedAssociates|projectId{}", projectId);
		List<EmployeeDto> employees = null;
		String projectCode = tAssociateAllocationRepository.getProjectCode(projectId);
		Long statusIdForPool = tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(
				ResourceManagementConstant.RESOURCE_BILLABLE_TYPE, ResourceManagementConstant.POOL);
		HashBasedTable<String, String, Long> wfTable = allocatedResourceHelper.getallModuleData();
		Long statusId = wfTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		List<Long> workflowStatusIds = List.of( 
				wfTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.SUBMITTED),
				wfTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.SAVED));
		List<Long> empIdsinWf = tAssociateAllocationRepository.getResourceInAllocWfForProject(projectId,
				workflowStatusIds, statusId);
		Long statusIdForSrfActive = tSrfRepository.getModuleIdForSrf(ResourceManagementConstant.SRF,
				ResourceManagementConstant.ACTIVATE);
		List<Long> tSrfs = tSrfRepository.getCandidateIds(projectCode, ResourceManagementConstant.EARMARKED_STATUS,
				statusId, true, statusIdForSrfActive, statusIdForPool);
		if (null != empIdsinWf) {
			tSrfs.removeAll(empIdsinWf);
		}
        if (null != tSrfs && CollectionUtils.isNotEmpty(tSrfs)) {
			employees = adminServiceClient.getAssociatesDetails(tSrfs);
		}
        log.info("Start get getEarmarkedAssociates|projectId{}", projectId);
		return employees;
	}

	@Override 
	@Transactional(readOnly = false)
	public void saveResourceAllocations(Long projectId, Long requirementId,
			List<TAssociateProjectDto> tAssociateProjectDto) throws ResourceManagementException, ParseException {
		long startTime = System.currentTimeMillis();
		log.info("Start saveResourceAllocations-Allocation Start-{}", sdf.format(startTime));
		Date jvDate = jvDetailsRepository.getWindowEndDate();
		boolean budgetCheck = getBudgetAndCostCheck(projectId);
		if (null != jvCheckHelperService.isJvCheck(jvDate) && jvCheckHelperService.isJvCheck(jvDate)) {
			throw new ResourceManagementException(ResourceManagementConstant.ALLOCATION_NOT_POSSIBLE);
		} else {
			if (tAssociateProjectDto.get(0).getRoleName().equalsIgnoreCase(ResourceManagementConstant.ADMIN_ROLE_NAME)
					|| tAssociateProjectDto.get(0).getRoleName()
							.equalsIgnoreCase(ResourceManagementConstant.TAG_ROLE_NAME)) {
				saveResourceAllocationByAdminOrTag(projectId, requirementId, tAssociateProjectDto,budgetCheck);
			} else if(budgetCheck) {
				if (performBudgetControlCheckAndUpdate(projectId, requirementId, tAssociateProjectDto)) {
					saveAllocation(tAssociateProjectDto);
				} else {
					throw new ResourceManagementException(ResourceManagementConstant.INSUFFICIENT_BUDGET);
				}
				
			}  else {
				List<ResourceRequirementDto> resourceRequirementList = bapServiceClient.getResourceRequiremetList(List.of(requirementId));
				ModuleStatusDto module = adminServiceClient.getModuleStatus(
						ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_ALLOCATION,
						ResourceManagementConstant.ACTIVATE);
				/*
				 * double shoreWorkHour =
				 * ResourceManagementConstant.ONSHORE.equalsIgnoreCase(resourceRequirementList.
				 * get(0).getShore()) ? 8 : 9;
				 */
				 double shoreWorkHour = 0.00;
					if (resourceRequirementList.get(0).getShore().equalsIgnoreCase(ResourceManagementConstant.ONSHORE))
						shoreWorkHour = 8;
					else
						shoreWorkHour = resourceRequirementList.get(0).getProjectBillingHours();
				 for(TAssociateProjectDto projectDto:tAssociateProjectDto)
				 {
				 preparepTAssociateAllocationDto(resourceRequirementList.get(0), module, projectDto.getTAssociateAllocation(), shoreWorkHour);
				 preparepAssociateProject(module, projectDto);
				 } 
				 saveAllocation(tAssociateProjectDto);
	     	  }
		}
        long totalTimeTaken = System.currentTimeMillis() - startTime;
		log.info("End saveResourceAllocations-Allocation Ends-Total Time Taken in Millis -{}, End Time -{}",
				totalTimeTaken, sdf.format(new Date()));
}

	private void saveAllocation(List<TAssociateProjectDto> tAssociateProjectDto) throws ResourceManagementException {
		
		List<Long> employeeIds = tAssociateAllocationRepository.getEmployeeIds(List.of(tAssociateProjectDto.get(0).getCreatedBy()));

		ModuleStatusDto moduleStatus = adminServiceClient.getModuleStatus(
				ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.SAVED);
         long workflowStatusIdSaved = moduleStatus.getModuleStatusId().intValue();
        boolean budgetCheck = tAssociateProjectDto.get(0).getBudgetAndCostCheck();
        
        List<Long> fixedPriceStatusIdList = new ArrayList<>();
        Long projectCommercialTypeId = 0L;
               
        Map<Long, TAssociateProjectDto> tAssociateProjectDtoMap = tAssociateProjectDto.stream().
        		collect(HashMap::new, (m, v) -> m.put(v.getEmployeeId(), v), HashMap::putAll);
        List<BAllocationMilestoneDto> bAllocationMilestoneList= new ArrayList<>();
        
		List<TAssociateProject> associateProjectAllocation = asssociateProjectMapper
				.tAssociateProjectDtoToTAssociateProject(tAssociateProjectDto);
		List<Long> roleId = new ArrayList<>();
		roleId.add(tAssociateProjectDto.get(0).getRoleId());
		List<PrimaryUsersDto> primaryUserList = bapServiceClient
				.getRoleBasedPrimaryOwnersList(tAssociateProjectDto.get(0).getProjectId(), roleId);

		List<AllocatedResourceProjection> allocatedResource = alllocatedResourceCheck(tAssociateProjectDto);

		if (!CollectionUtils.isEmpty(allocatedResource)) {
			List<Long> empIds = allocatedResource.stream().map(AllocatedResourceProjection::getEmployeeId)
					.collect(Collectors.toList());
			 List<Long> empNumber=adminServiceClient.getEmployeeNumber(empIds);
			throw new ResourceManagementException(empNumber + "" + ResourceManagementConstant.SAME_ALLOCATION_REQUIREMENT);

		} else {
			if (null != primaryUserList) {
				//Added by Mrunal Marne for milestone selection while resource allocation
				projectCommercialTypeId = bapServiceClient.getSalesOrderDetailByProjectId(associateProjectAllocation.get(0).getProjectId());
				List<String> lookupValueDescList = List.of(ResourceManagementConstant.COMMERCIAL_MODEL_FIXED_PRICE, ResourceManagementConstant.COMMERCIAL_MODEL_FIXED_PRICE_AMC);
				List<LookupValueNewDto> lookupValueListByLookupDesc = adminServiceClient.getLookupValueListByLookupDesc(lookupValueDescList);
				fixedPriceStatusIdList = lookupValueListByLookupDesc.stream().map(LookupValueNewDto::getLookupValueId).collect(Collectors.toList());
				Long lookupIdForNb = adminServiceClient.getLookuIdByTypeAndDescr(
						ResourceManagementConstant.PROJECT_BILLABLE_TYPE, ResourceManagementConstant.Non_Billable);
				Long projectBillableIdbyProjectId = adminServiceClient
						.getProjectBillableIdbyProjectId(associateProjectAllocation.get(0).getProjectId());
				//End by Mrunal Marne
				
				for (TAssociateProject tAssociateProject : associateProjectAllocation) {
					tAssociateProject.setCreatedBy(employeeIds.get(0));
					tAssociateProject.setLastUpdatedBy(employeeIds.get(0));
					tAssociateProject.getTAssociateAllocation().setCreatedBy(employeeIds.get(0));
					tAssociateProject.getTAssociateAllocation().setLastUpdatedBy(employeeIds.get(0));
					tAssociateProject.setSupervisorId(primaryUserList.get(0).getEmpId());
					tAssociateProject.getTAssociateAllocation().setSupervisorId(primaryUserList.get(0).getEmpId());
					tAssociateProject.getTAssociateAllocation().setTAssociateProject(tAssociateProject);
					tAssociateProject.getTAssociateAllocation().setWorkflowStatusId(workflowStatusIdSaved);
					if (budgetCheck) {
						for (TAssociateAllocationBudget tAssociateAllocationBudget : tAssociateProject
								.getTAssociateAllocation().getTAssociateAllocationBudget()) {
							tAssociateAllocationBudget
									.setTAssociateAllocation(tAssociateProject.getTAssociateAllocation());
							tAssociateAllocationBudget.setCreatedBy(tAssociateProject.getCreatedBy());
							tAssociateAllocationBudget.setLastUpdatedBy(tAssociateProject.getCreatedBy());
						}
					}
					TAssociateProject tAssociateProjectReference = associateProjectRepository.save(tAssociateProject);
					//Added by Mrunal Marne for milestone selection while resource allocation
					bAllocationMilestoneList.addAll(prepareMilestoneDetailsForSave(tAssociateProjectReference, tAssociateProjectDtoMap, projectCommercialTypeId, fixedPriceStatusIdList, projectBillableIdbyProjectId, lookupIdForNb));
				}
				if(!bAllocationMilestoneList.isEmpty()) {
					bapServiceClient.savePoAndMilestoneDetailsDuringAllocation(bAllocationMilestoneList);
				}
				//End by Mrunal Marne
			}
		}
	}
	
	//Added by Mrunal Marne for milestone selection while resource allocation
	public List<BAllocationMilestoneDto> prepareMilestoneDetailsForSave(TAssociateProject tAssociateProjectReference, Map<Long, TAssociateProjectDto> tAssociateProjectDtoMap, 
			Long projectCommercialTypeId, List<Long> fixedPriceStatusIdList, Long projectBillableIdbyProjectId, Long lookupIdForNb) {
		log.info("Entered ResourceAllocationServiceImpl.prepareMilestoneDetailsForSave method:");
		List<BAllocationMilestoneDto> bAllocationMilestoneList = new ArrayList<>();
		Long size = 0L;
		if(!projectBillableIdbyProjectId.equals(lookupIdForNb)) {
			if(Objects.nonNull(projectCommercialTypeId) && fixedPriceStatusIdList.contains(projectCommercialTypeId)) {
				try {
					size = tAssociateProjectDtoMap.containsKey(tAssociateProjectReference.getEmployeeId()) ? 
							tAssociateProjectDtoMap.get(tAssociateProjectReference.getEmployeeId()).getTAssociateAllocation().getPoMilestoneIdList().size() : 0L;
				} catch (Exception e) {
					size = 0L;
				}
			}else
				size = 1L;
		}
		for (int i = 0; i < size; i++) {
			BAllocationMilestoneDto bAllocationMilestone = new BAllocationMilestoneDto();
			bAllocationMilestone.setAssociateAllocationId(tAssociateProjectReference.
					getTAssociateAllocation().getAssociateAllocationId());	
			bAllocationMilestone.setEmployeeId(tAssociateProjectReference.getEmployeeId());
			bAllocationMilestone.setProjectId(tAssociateProjectReference.getProjectId());
			bAllocationMilestone.setBapPaymentScheduleKey(tAssociateProjectDtoMap.containsKey(tAssociateProjectReference.getEmployeeId()) ? 
					tAssociateProjectDtoMap.get(tAssociateProjectReference.getEmployeeId()).getTAssociateAllocation().getPoMilestoneIdList().isEmpty() ? null : 
					tAssociateProjectDtoMap.get(tAssociateProjectReference.getEmployeeId()).getTAssociateAllocation().getPoMilestoneIdList().get(i) : null);	//milestone id
			bAllocationMilestone.setPoInvoiceKey(tAssociateProjectDtoMap.containsKey(tAssociateProjectReference.getEmployeeId()) ? 
					tAssociateProjectDtoMap.get(tAssociateProjectReference.getEmployeeId()).getTAssociateAllocation().getPuchaseOrderId(): null);		//po id
			bAllocationMilestone.setCreatedBy(tAssociateProjectReference.getTAssociateAllocation().getCreatedBy());
			bAllocationMilestone.setLastUpdatedBy(tAssociateProjectReference.getTAssociateAllocation().getLastUpdatedBy());
			bAllocationMilestoneList.add(bAllocationMilestone);
		}
		log.info("Leaving ResourceAllocationServiceImpl.prepareMilestoneDetailsForSave method:");
		return bAllocationMilestoneList;
	}
	//End by Mrunal Marne

	public boolean performBudgetControlCheckAndUpdate(Long projectId, Long requirementId,
			List<TAssociateProjectDto> tAssociateProjectDto) throws ResourceManagementException {
		boolean isBudgetCheck = false;
		List<ProjectBudgetDto> projectBudgetDto = budgetControlServiceClient.getProjectMonthlyBudgetsDetails(projectId);
		List<ResourceRequirementDto> resourceRequirementList = bapServiceClient.getResourceRequiremetList(List.of(requirementId));
        ResourceRequirementDto resourceRequirementDto=resourceRequirementList.get(0);
        if (CollectionUtils.isNotEmpty(projectBudgetDto) && null != resourceRequirementDto) {
			if (ResourceManagementConstant.VALUE_NON_BILLABLE_STATUS
					.equalsIgnoreCase(resourceRequirementDto.getBillingStatus())) {
				return true;
			}
			Map<String, ProjectBudgetDto> projectBudgets = projectBudgetDto.stream().collect(HashMap::new,
					(m, v) -> m.put(v.getMonth(), v), HashMap::putAll);
			isBudgetCheck = performBudgetControlCheck(resourceRequirementDto, tAssociateProjectDto, projectBudgets);
			if (isBudgetCheck) {
				updateBudget(projectBudgets);
			}
		}
		return isBudgetCheck;
	}

	/**
	 * do budget check.
	 * 
	 * @param projectId
	 * @param reqId
	 * @param tAssociateAllocationDto
	 * @return
	 * @throws ResourceManagementException
	 */
	public boolean performBudgetControlCheck(ResourceRequirementDto resourceRequirementDto,
			List<TAssociateProjectDto> tAssociateProjectDto, Map<String, ProjectBudgetDto> projectBudgets)
			throws ResourceManagementException {
		log.info("Start performBudgetControlCheck");  
		boolean isBudgetCheck = false;
		ModuleStatusDto moduleStatusDto = adminServiceClient.getModuleStatus(
				ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);

		for (TAssociateProjectDto associateProject : tAssociateProjectDto) {
			if (null != associateProject.getTAssociateAllocation()) {
				preparepAssociateProject(moduleStatusDto, associateProject);

				isBudgetCheck = monthWieseBudgetControlCheckForResource(resourceRequirementDto, projectBudgets,
						moduleStatusDto, associateProject.getTAssociateAllocation());

			}
		}  
		log.info("End performBudgetControlCheck");
		return isBudgetCheck;
	}

	private void preparepAssociateProject(ModuleStatusDto moduleStatusDto, TAssociateProjectDto associateProject) {
		associateProject.getTAssociateAllocation().setEmployeeId(associateProject.getEmployeeId());
	//	associateProject.setStatusId(moduleStatusDto.getModuleStatusId());  
		associateProject.setStatusId(moduleStatusDto.getModuleStatusId());  

		TAssociateProject tAssociateProject = associateProjectRepository
				.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(associateProject.getEmployeeId(),
						associateProject.getSrfId(), associateProject.getProjectId(), moduleStatusDto.getModuleStatusId());

		if (null != tAssociateProject) {
			TAssociateProjectDto tap = asssociateProjectMapper
					.tAssociateProjectToTAssociateProjectDto(tAssociateProject);
			associateProject.setAssociateProjectId(tap.getAssociateProjectId());
			associateProject.setLastUpdatedDate(new Date());
			associateProject.setLastUpdatedBy(associateProject.getLastUpdatedBy());
		}
		associateProject.setCreatedDate(new Date());
		associateProject
				.setEffectiveStartDate(associateProject.getTAssociateAllocation().getActualAllocationStartDate());
		associateProject.setEffectiveEndDate(associateProject.getTAssociateAllocation().getEstAllocationEndDate());
		associateProject.setLastUpdatedDate(new Date());
	}

	private boolean monthWieseBudgetControlCheckForResource(ResourceRequirementDto resourceRequirementDto,
			Map<String, ProjectBudgetDto> projectBudgets, ModuleStatusDto moduleStatusDto,
			TAssociateAllocationDto allocation) throws ResourceManagementException {
		boolean isBudgetCheck = false;
		Map<String, Long> monthlyResourceAllocationDetail = RMBudgetControlUtil
				.monthWiseNoOfDays(allocation.getActualAllocationStartDate(), allocation.getEstAllocationEndDate());
		double shoreWorkHour = 0.00;
        if(resourceRequirementDto.getShore().equalsIgnoreCase( ResourceManagementConstant.ONSHORE))
	        shoreWorkHour = 8;
		else
			 shoreWorkHour =  resourceRequirementDto.getProjectBillingHours();
		/*double shoreWorkHour = ResourceManagementConstant.ONSHORE.equalsIgnoreCase(resourceRequirementDto.getShore())
				? 8
				: 9;*/
		List<String> months = monthlyResourceAllocationDetail.keySet().stream().collect(Collectors.toList());
		preparepTAssociateAllocationDto(resourceRequirementDto, moduleStatusDto, allocation, shoreWorkHour);
		List<TAssociateAllocationBudgetDto> monthlybudget = new LinkedList<>();
		for (String month : months) {
			ProjectBudgetDto projectBudgetDto = projectBudgets.get(month);
			double monthlyAllocationCost = calculateMonthlyAllocationCost(resourceRequirementDto, allocation,
					monthlyResourceAllocationDetail, shoreWorkHour, month, projectBudgetDto);
			if (null != projectBudgetDto && monthlyAllocationCost <= projectBudgetDto.getAvailableBudget()) {
				prepareAssociateAllocationBudget(moduleStatusDto.getModuleStatusId(), month, monthlybudget,
						monthlyAllocationCost, projectBudgetDto);
				setAvailableAndConsumedBudget(projectBudgets, month, monthlyAllocationCost, projectBudgetDto);
				isBudgetCheck = true;
			} else {
				if (null != projectBudgetDto) {
					projectBudgetDto.setProjectStartDate(resourceRequirementDto.getRequirementStartDate());
					projectBudgetDto.setProjectEndDate(resourceRequirementDto.getRequirementEndDate());
                    Map<String, String> parameter = prepareBudgetDetailsParameter(
							projectBudgetDto.getProjectStartDate(), month, monthlyAllocationCost,
							moduleStatusDto.getModuleStatusId());
					isBudgetCheck = insufficientBudgetCheckForMonth(projectBudgets, projectBudgetDto, parameter,
							monthlybudget);
				}
				if (!isBudgetCheck) {
					throw new ResourceManagementException(
							ResourceManagementConstant.INSUFFICIENT_BUDGET_FOR_EMPLOYEE + tAssociateAllocationRepository.getEmployeeNumber(allocation.getEmployeeId()));
				}
			}
		}
		allocation.setTAssociateAllocationBudget(monthlybudget);
		return isBudgetCheck;
	}

	private double calculateMonthlyAllocationCost(ResourceRequirementDto resourceRequirementDto,
			TAssociateAllocationDto allocation, Map<String, Long> monthlyResourceAllocationDetail, double shoreWorkHour,
			String month, ProjectBudgetDto projectBudgetDto) {
		double monthlyAllocationCost = 0;
		double noOfWorkingdaysInMonth = monthlyResourceAllocationDetail.get(month);
		if (null != projectBudgetDto && null != projectBudgetDto.getBudgetCurrency()
				&& projectBudgetDto.getBudgetCurrency() > 0)
			monthlyAllocationCost = noOfWorkingdaysInMonth * (( allocation.getStdCost()
					* shoreWorkHour * (allocation.getFtePercent() / 100)));
		//			* resourceRequirementDto.getZenAccurateCurrency() / projectBudgetDto.getBudgetCurrency());
		return monthlyAllocationCost;
	}

	private void preparepTAssociateAllocationDto(ResourceRequirementDto resourceRequirementDto,
			ModuleStatusDto moduleStatusDto, TAssociateAllocationDto allocation, double shoreWorkHour)
			throws ResourceManagementException {
		AllocationTypeStatusDto allocationTypeStatus = adminServiceClient
				.getAllocationTypeStatus(ResourceManagementConstant.RESOURCE_ALLOCATION_TYPE_STATUS);
		//allocation.setStatusId(moduleStatusDto.getModuleStatusId());
		allocation.setStatusId(moduleStatusDto.getModuleStatusId());

		allocation.setBaseHours(shoreWorkHour);
		allocation.setBillableStatusId(resourceRequirementDto.getResourceBillingStatusId());
		allocation.setWorkLocationId(resourceRequirementDto.getResourceRequirementLocationId());
		allocation.setCreatedDate(new Date());
		allocation.setEffectiveStartDate(allocation.getActualAllocationStartDate());
		allocation.setEffectiveEndDate(allocation.getEstAllocationEndDate());
		allocation.setLastUpdatedDate(new Date());
		allocation.setAllocationTypeId(allocationTypeStatus.getAllocationTypeId());
	}

	private void setAvailableAndConsumedBudget(Map<String, ProjectBudgetDto> projectBudgets, String month,
			double monthlyAllocationCost, ProjectBudgetDto projectBudgetDto) {
		projectBudgetDto.setAvailableBudget(projectBudgetDto.getAvailableBudget() - monthlyAllocationCost);
		if (null != projectBudgetDto.getConsumedBudget()) {
			projectBudgetDto.setConsumedBudget(projectBudgetDto.getConsumedBudget() + monthlyAllocationCost);
			projectBudgetDto.setTotalConsumption(projectBudgetDto.getConsumedBudget());
		} else {
			projectBudgetDto.setConsumedBudget(monthlyAllocationCost);
			projectBudgetDto.setTotalConsumption(monthlyAllocationCost);
		}			
		//projectBudgetDto.setTotalConsumption(projectBudgetDto.getConsumedBudget() + monthlyAllocationCost);

		projectBudgets.put(month, projectBudgetDto);
	}

	private Map<String, String> prepareBudgetDetailsParameter(Date projectStartDate, String month,
			double monthlyAllocationCost, Long moduleId) {
		Map<String, String> parameter = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    parameter.put(ResourceManagementConstant.PARAMETER_PROJECTSTARTDATE, dateFormat.format(projectStartDate));
		parameter.put(ResourceManagementConstant.PARAMETER_ALLOCATION_MONTH, month);
		parameter.put(ResourceManagementConstant.PARAMETER_MONTHLY_ALLOCATION_COST,
				String.valueOf(monthlyAllocationCost));
		parameter.put(ResourceManagementConstant.PARAMETER_MODULESTATUSID, String.valueOf(moduleId));

		return parameter;
	}
  
	private void prepareAssociateAllocationBudget(Long moduleId, String allocationMonth,
			List<TAssociateAllocationBudgetDto> monthlyBudget, double monthlyAllocationCost,
			ProjectBudgetDto projectBudgetDto) {
		TAssociateAllocationBudgetDto tAssociateAllocationBudget = new TAssociateAllocationBudgetDto();
		tAssociateAllocationBudget.setBudgetAllocatedMonth(projectBudgetDto.getMonth());
		tAssociateAllocationBudget.setBudgetAllocationMonth(allocationMonth);
		tAssociateAllocationBudget.setMonthlyAvailableBudget(projectBudgetDto.getAvailableBudget());
		tAssociateAllocationBudget.setMonthlyBudget(monthlyAllocationCost);

		if (projectBudgetDto.getAvailableBudget() > monthlyAllocationCost) {
			tAssociateAllocationBudget.setMonthlyUsedBudget(monthlyAllocationCost);
		} else {
			tAssociateAllocationBudget.setMonthlyUsedBudget(projectBudgetDto.getAvailableBudget());
		}
		tAssociateAllocationBudget.setStatusId(moduleId);
		tAssociateAllocationBudget.setCreatedDate(new Date());
		tAssociateAllocationBudget.setLastUpdatedDate(new Date());
		tAssociateAllocationBudget.setEffectiveStartDate(new Date());
		tAssociateAllocationBudget.setEffectiveEndDate(new Date());
		monthlyBudget.add(tAssociateAllocationBudget);
	}

	private boolean insufficientBudgetCheckForMonth(Map<String, ProjectBudgetDto> projectBudgets,
			ProjectBudgetDto projectBudgetDto, Map<String, String> parameter,
			List<TAssociateAllocationBudgetDto> tAAbudget) throws ResourceManagementException {
		boolean isBudgetCheck = false;
		double remainingBudegtNeeded = Double
				.parseDouble(parameter.get(ResourceManagementConstant.PARAMETER_MONTHLY_ALLOCATION_COST));
		if (null != projectBudgetDto && projectBudgetDto.getAvailableBudget() > 0) {
			remainingBudegtNeeded = setAvailableAndConsumedBudget(projectBudgets, projectBudgetDto, parameter,
					tAAbudget, remainingBudegtNeeded);
		}
		remainingBudegtNeeded = reIterateBudgetCheck(projectBudgets, remainingBudegtNeeded, parameter, tAAbudget);
		if (remainingBudegtNeeded > 0) {
			isBudgetCheck = false;
		} else {
			isBudgetCheck = true;
		}
		return isBudgetCheck;
	}

	private Double reIterateBudgetCheck(Map<String, ProjectBudgetDto> projectBudgets, double remainingBudegtNeeded,
			Map<String, String> parameter, List<TAssociateAllocationBudgetDto> tAAbudget)
			throws ResourceManagementException {
		Calendar beginCalendar = Calendar.getInstance();
		Calendar finishCalendar = Calendar.getInstance();
		try {
			beginCalendar.setTime(formater.parse(parameter.get(ResourceManagementConstant.PARAMETER_PROJECTSTARTDATE)));
			finishCalendar
					.setTime(formater.parse(parameter.get(ResourceManagementConstant.PARAMETER_ALLOCATION_MONTH)));
		} catch (ParseException e) {
			throw new ResourceManagementException(ResourceManagementConstant.DATE_PARSE_EXCEPTION, e);
		}
		remainingBudegtNeeded = monthWiseReIteratebudget(projectBudgets, remainingBudegtNeeded, parameter, tAAbudget,
				beginCalendar, finishCalendar);
		return remainingBudegtNeeded;
	}

	private double monthWiseReIteratebudget(Map<String, ProjectBudgetDto> projectBudgets, double remainingBudegtNeeded,
			Map<String, String> parameter, List<TAssociateAllocationBudgetDto> tAAbudget, Calendar beginCalendar,
			Calendar finishCalendar) {
		while (beginCalendar.before(finishCalendar)) {
			// add one month to date per loop
			String date = formater.format(beginCalendar.getTime()).toUpperCase();
			ProjectBudgetDto projectBudgetDto = projectBudgets.get(date);
			if (null != projectBudgetDto && remainingBudegtNeeded <= projectBudgetDto.getAvailableBudget()) {
				prepareAssociateAllocationBudget(
						Long.valueOf(parameter.get(ResourceManagementConstant.PARAMETER_MODULESTATUSID)),
						parameter.get(ResourceManagementConstant.PARAMETER_ALLOCATION_MONTH), tAAbudget,
						remainingBudegtNeeded, projectBudgetDto);
				setAvailableAndConsumedBudget(projectBudgets, date, remainingBudegtNeeded, projectBudgetDto);
				remainingBudegtNeeded = 0.0;
			} else {
				if (null != projectBudgetDto && projectBudgetDto.getAvailableBudget() > 0) {
					parameter.put(ResourceManagementConstant.PARAMETER_MONTH, date);
					remainingBudegtNeeded = setAvailableAndConsumedBudget(projectBudgets, projectBudgetDto, parameter,
							tAAbudget, remainingBudegtNeeded);
				}
			}
			if (remainingBudegtNeeded > 0) {
				beginCalendar.add(Calendar.MONTH, 1);
			} else {
				break;
			}
		}
		return remainingBudegtNeeded;
	}

	private double setAvailableAndConsumedBudget(Map<String, ProjectBudgetDto> projectBudgets,
			ProjectBudgetDto projectBudgetDto, Map<String, String> parameter,
			List<TAssociateAllocationBudgetDto> tAABudget, double remainingBudegtNeeded) {
		if (null != projectBudgetDto.getConsumedBudget()) {
			projectBudgetDto
					.setConsumedBudget(projectBudgetDto.getConsumedBudget() + projectBudgetDto.getAvailableBudget());
			projectBudgetDto.setTotalConsumption(projectBudgetDto.getConsumedBudget());
		} else {
			projectBudgetDto.setConsumedBudget(projectBudgetDto.getAvailableBudget());
			projectBudgetDto.setTotalConsumption(projectBudgetDto.getAvailableBudget());
		}
		prepareAssociateAllocationBudget(
				Long.valueOf(parameter.get(ResourceManagementConstant.PARAMETER_MODULESTATUSID)),
				parameter.get(ResourceManagementConstant.PARAMETER_ALLOCATION_MONTH), tAABudget, remainingBudegtNeeded,
				projectBudgetDto);
		remainingBudegtNeeded = remainingBudegtNeeded - projectBudgetDto.getAvailableBudget();
		projectBudgetDto.setAvailableBudget(0.0);
		projectBudgets.put(parameter.get(ResourceManagementConstant.PARAMETER_ALLOCATION_MONTH), projectBudgetDto);
		return remainingBudegtNeeded;
	}

	public void updateBudget(Map<String, ProjectBudgetDto> projectBudgetDto) throws ResourceManagementException {
		log.info("Start updateBudget");
		List<ProjectBudgetDto> projectBudgetList = projectBudgetDto.values().stream().collect(Collectors.toList());
		budgetControlServiceClient.updateBudget(projectBudgetList);
		log.info("End updateBudget");
	}

	@Override
	public List<EmployeeDto> getAssociatesDetails(long projectId, long requirementId, List<EmployeeDto> employeelist)
			throws ResourceManagementException {

		ResourceRequirementDto requirementDetailList = bapServiceClient.getRequirementDetailByReqId(requirementId);
		if (null != requirementDetailList) {
			boolean budgetAndCostCheck = getBudgetAndCostCheck(projectId);
			setAssociateDetails(employeelist, requirementDetailList, projectId,budgetAndCostCheck);
		}
		return employeelist;
	}

	public boolean getBudgetAndCostCheck(long projectId) throws ResourceManagementException {
		boolean budgetAndCostCheck = false;
		String budgetCheck = adminServiceClient.getProjectBudgetStatus(projectId);
		if(budgetCheck.equalsIgnoreCase("YES"))
		{
			 budgetAndCostCheck = true;
		}else if(budgetCheck.equalsIgnoreCase("NO"))
		{
			 budgetAndCostCheck = false;
		}
		return budgetAndCostCheck;
	}
   
	private void setAssociateDetails(List<EmployeeDto> employeelist, ResourceRequirementDto requirementDetailList,
			long projectId,boolean budgetAndCostCheck) throws ResourceManagementException {
		String requirementBandValue = requirementDetailList.getBand();    
		List<ServiceLineDto> serviceLineList = adminServiceClient.getServiceLineList(tAssociateAllocationRepository.getProjectServiceLineIdbyProjectId(projectId));
		if (null != employeelist) {
			List<Long> empNumber = employeelist.stream().map(EmployeeDto::getEmployeeNumber).collect(Collectors.toList());
			List<Long> empIds= employeelist.stream().map(EmployeeDto::getEmployeeId).collect(Collectors.toList());
			 Long statusIdForPool = tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(ResourceManagementConstant.RESOURCE_BILLABLE_TYPE, ResourceManagementConstant.POOL);
				ModuleStatusDto moduleStatusDto = adminServiceClient.getModuleStatus(
						ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_ALLOCATION,
						ResourceManagementConstant.ACTIVATE);

			List<Long> primaryProjectEmpIdList = tAssociateAllocationRepository.getPrimaryProjectCheck(empIds,moduleStatusDto.getModuleStatusId(),statusIdForPool);
			String projectCode = tAssociateAllocationRepository.getProjectCode(projectId);
		    Long statusIdForSrfActive = tSrfRepository.getModuleIdForSrf(ResourceManagementConstant.SRF,ResourceManagementConstant.ACTIVATE);
	         List<SrfProjection> newsrfList = tSrfRepository.getsrfdetails(projectCode,
					ResourceManagementConstant.EARMARKED_STATUS, statusIdForSrfActive, true);
			Map<Long, EmployeeDto> employeeMap = getPractiseDetails(empNumber);
			Map<Long, EmployeeSkillDto> skillFamilyMap = getSkillFamilyForAssociate(empIds);
			 
			List<AvaibalityProjection> employeeAvaibility = tAssociateAllocationRepository
					.getAllocatedResourceAvaibality(empIds,moduleStatusDto.getModuleStatusId(),statusIdForPool);
			Map<Long, Long> employeeAvaibilityList = employeeAvaibility.stream().collect(HashMap::new,
					(m, v) -> m.put(v.getEmployeeId(), v.getAllocatedFte()), HashMap::putAll);
			employeelist.forEach(employeeDto -> {
				Long empId = employeeDto.getEmployeeId();
				if (null != employeeMap.get(empId)) {
					EmployeeDto newemployeeDto = employeeMap.get(employeeDto.getEmployeeId());
					setPractiseDetails(employeeDto, newemployeeDto);
				}
				if (null != skillFamilyMap) {
					EmployeeSkillDto empSkillDto = skillFamilyMap.get(employeeDto.getEmployeeId());
					List<SkillTaxonomyDto> skillFamilyList = empSkillDto.getSkillFamilyList();
					employeeDto.setSkilltaxanomyList(skillFamilyList);
				}
				getSrfList(newsrfList, employeeDto);
				if(requirementBandValue!=null) {
				getRequirementBand(employeeDto, requirementBandValue);}
				employeeDto.setServiceLineId(requirementDetailList.getServiceLineId());
				employeeDto.setServiceLineName(requirementDetailList.getServiceLineName());
				employeeDto.setRequirementRoleId(requirementDetailList.getRequirementRoleId());
				employeeDto.setRequirementRole(requirementDetailList.getRequirementRole());
				employeeDto.setResourceRequirementLocationId(requirementDetailList.getResourceRequirementLocationId());
				employeeDto.setResourceRequirementLocation(requirementDetailList.getResourceRequirementLocation());
				employeeDto.setLocationTypeId(requirementDetailList.getResourceRequirementLocationId());
				employeeDto.setAvailibility((long) 100);
				employeeDto.setServiceLineDto(serviceLineList);
				employeeDto.setBudgetAndCostCheck(budgetAndCostCheck);
				employeeDto.setResourceRequirementCost(requirementDetailList.getRequirmentCostRate());
				setPrimaryProjectFlag(primaryProjectEmpIdList, employeeDto, empId);
				if (!employeeAvaibilityList.isEmpty()) {
					Long availableFte = employeeAvaibilityList.get(employeeDto.getEmployeeId());
					if (null != availableFte) {
						Long availibility = 100 - availableFte;
						employeeDto.setAvailibility(availibility);
					}
				}
			});
		}
	}

	private void setPrimaryProjectFlag(List<Long> primaryProjectEmpIdList, EmployeeDto employeeDto, Long empId) {
		if (!primaryProjectEmpIdList.isEmpty()) {
			employeeDto.setIfPrimaryProjectExists(primaryProjectEmpIdList.contains(empId));
		} else {
			employeeDto.setIfPrimaryProjectExists(false);

		}
	}

	private Map<Long, EmployeeDto> getPractiseDetails(List<Long> empIds) throws ResourceManagementException {
		List<EmployeeDto> practiseDetails = adminServiceClient.getAssociatesDetails(empIds);
		return practiseDetails.stream()
				.collect(Collectors.toMap(EmployeeDto::getEmployeeId, employeemap -> employeemap));
	}

	private void setPractiseDetails(EmployeeDto employeeDto, EmployeeDto newemployeeDto) {
		if (null != newemployeeDto) {
			employeeDto.setEmployeeRoleId(newemployeeDto.getEmployeeRoleId());
			employeeDto.setEmployeePracticeId(newemployeeDto.getEmployeePracticeId());
			employeeDto.setPracticeName(newemployeeDto.getPracticeName());
			employeeDto.setRole(newemployeeDto.getRole());
		}
	}

	private Integer getRequirementBand(EmployeeDto employeeDto, String requirementBandValue) {
		Integer requirementBandValue1 = ResourceManagementConstant.COMPARE.indexOf(requirementBandValue.charAt(0));
		Integer resourceBandValue1 = ResourceManagementConstant.COMPARE.indexOf(employeeDto.getBand().charAt(0));
		if (null != requirementBandValue1 && null != resourceBandValue1) {
			if (requirementBandValue1 < resourceBandValue1) {
				employeeDto.setMatchFactor(2);
			} else if (requirementBandValue1.equals(resourceBandValue1)) {
				int requirementBandValue2 = requirementBandValue.charAt(1);
				int resourceBandValue2 = employeeDto.getBand().charAt(1);

				if (requirementBandValue2 == resourceBandValue2) {
					employeeDto.setMatchFactor(0);
				} else if (requirementBandValue2 < resourceBandValue2) {
					employeeDto.setMatchFactor(2);
				} else {
					employeeDto.setMatchFactor(1);
				}
			} else {
				employeeDto.setMatchFactor(1);
			}
		}

		return resourceBandValue1;

	}

	public void getSrfList(List<SrfProjection> newsrfList, EmployeeDto employeeDto) {
		newsrfList.forEach(srfProjection -> {
			if (employeeDto.getEmployeeNumber().equals(srfProjection.getCandidateId())) {
				employeeDto.setSrfNo(srfProjection.getSrfNumber());
				employeeDto.setSrfId(srfProjection.getSrfId());
			}

		});
	}

	@Override
	public EmployeeDto getAssociatesForTravelByIdOrName(String empIdOrName, long projectId, Long reqId) throws ResourceManagementException {
		log.info("Start getAssociatesForTravelById-Allocation");
		ModuleStatusDto moduleStatusDto = adminServiceClient.getModuleStatus(
				ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long statusForAllocApproved = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,	ResourceManagementConstant.APPROVED_ACTION);
		List<LookupValueDto> lookuTypes = adminServiceClient.getLookupValueByLookupType("RESOURCE_BILLABLE_TYPE");
		Map<String, Long> lookupDescrpMap = lookuTypes.stream()
				.collect(Collectors.toMap(LookupValueDto::getLookupType, LookupValueDto::getLookUpId));
		Long lookupIdForPool = lookupDescrpMap.get("POOL");
		
		EmployeeDto employee = adminServiceClient.getEmployeeByNameOrId(empIdOrName);
		if (null != employee) {
			Long poolCount = tAssociateAllocationRepository.checkIfPoolResource(employee.getEmployeeId(), moduleStatusDto.getModuleStatusId(), statusForAllocApproved, lookupIdForPool);
			if(poolCount<1){
				Long count = tAssociateAllocationRepository.checkIfexist(employee.getEmployeeId(), moduleStatusDto.getModuleStatusId(), statusForAllocApproved, lookupIdForPool, projectId);
				if(count<1) {
					AllocatedResourceProjection allocatedResourceProjection = tAssociateAllocationRepository
							.getAllocatedResourceToTravel(employee.getEmployeeId(), moduleStatusDto.getModuleStatusId(), statusForAllocApproved, lookupIdForPool);
					if (null != allocatedResourceProjection) {
						employee = createEmployeeRecord(employee, allocatedResourceProjection, employee.getEmployeeId(), moduleStatusDto);
						String srfNo = tSrfRepository.getSrfNoFromCandidateId(employee.getEmployeeNumber(), tAssociateAllocationRepository.getProjectCode(allocatedResourceProjection.getProjectId()));
						if(srfNo!=null)
							employee.setSrfNo(srfNo);
						else
							employee.setSrfNo(ResourceManagementConstant.NA);
						Long servicelineId = tAssociateAllocationRepository.getReqServiceLineId(reqId);
						if(servicelineId!=null) {
							List<ServiceLineDto> serviceLineName = adminServiceClient.getServiceLineList(List.of(servicelineId));
							employee.setServiceLineId(serviceLineName.get(0).getServiceLineId());
							employee.setServiceLineName(serviceLineName.get(0).getServiceLine());
						}else 
							employee.setServiceLineName(ResourceManagementConstant.NOT_AVAILABLE);
							
						List<Long> serviceLineIds = tAssociateAllocationRepository.getProjectServiceLineIdbyProjectId(projectId);
						if (!StreamSupport.stream(serviceLineIds.spliterator(), true).allMatch(o -> o == null)) {
								List<ServiceLineDto> serviceLineDtos = adminServiceClient.getServiceLineList(serviceLineIds);
								employee.setServiceLineDto(serviceLineDtos);
							}
						}else
							throw new ResourceManagementException(ResourceManagementConstant.NO_DATA_FOUND);
					}else
						throw new ResourceManagementException(ResourceManagementConstant.NO_TRAVEL_RESOURCE);
			}else
				throw new ResourceManagementException(ResourceManagementConstant.POOL_RESOURCE);
			}
		log.info("Start getAssociatesForTravelById-Allocation");

		return employee;
		
	}

	public EmployeeDto createEmployeeRecord(EmployeeDto employee,
			AllocatedResourceProjection allocatedResourceProjection, Long empployeeID, ModuleStatusDto moduleStatusDto)
			throws ResourceManagementException {

		EmployeeDto empDto = new EmployeeDto();
		if (null != employee) {
			empDto.setEmployeeId(allocatedResourceProjection.getEmployeeId());
			empDto.setEmployeeName(employee.getEmployeeName());
			empDto.setPracticeName(employee.getPracticeName());
			empDto.setProjectId(allocatedResourceProjection.getProjectId());
			empDto.setRole(employee.getRole());
			empDto.setBand(employee.getBand());
			empDto.setFte_percent(0.0);
			empDto.setEmployeeNumber(employee.getEmployeeNumber());
			empDto.setBillableStatusId(allocatedResourceProjection.getBillableStatusId());
			//empDto.setSkillChampion(allocatedResourceProjection.getFlag());
			AllocationTypeStatusDto allocationTypeStatus = adminServiceClient
					.getAllocationTypeStatus(ResourceManagementConstant.TRAVEL_ALLOCATION_TYPE_STATUS);
			empDto.setAllocationTypeId(allocationTypeStatus.getAllocationTypeId());
			empDto.setPrimaryProjectStatusId(false);
			Integer matchFactor = getRequirementBand(empDto, empDto.getBand());
			empDto.setMatchFactor(matchFactor);

			ModuleStatusDto workflowStatusId = adminServiceClient.getModuleStatus(
					ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_ALLOCATION,
					ResourceManagementConstant.APPROVED_ACTION);

			AvaibalityProjection employeeAvaibility = tAssociateAllocationRepository.getAllocatedResourceAvail(
					empployeeID, moduleStatusDto.getModuleStatusId(), workflowStatusId.getModuleStatusId());
			if (null != employeeAvaibility) {
				Long availableFte = employeeAvaibility.getAllocatedFte();

				if (null != availableFte) {
					Long availibility = 100 - availableFte;
					empDto.setAvailibility(availibility);
				}
			}
		}
		return empDto;
	}

	@Override
	@Transactional(readOnly = false)
	public void saveResourceTravelAllocations(List<TAssociateProjectDto> tAssociateProjectDto)
			throws ResourceManagementException {
		log.info("Start saveResourceTravelAllocations-Allocation");
		ModuleStatusDto moduleStatusDto = adminServiceClient.getModuleStatus(
				ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		List<TAssociateProject> associateProjectAllocation = asssociateProjectMapper
				.tAssociateProjectDtoToTAssociateProject(tAssociateProjectDto);
		boolean flag = false;
		List<Long> alreadyAllocatedResource = new ArrayList<>();

		for (TAssociateProject tAssociateProject1 : associateProjectAllocation) {
			List<Long> empdId = tAssociateAllocationRepository.getTravelAllocatedResource(moduleStatusDto.getModuleStatusId(),
					tAssociateProject1.getTAssociateAllocation().getActualAllocationStartDate(),
					tAssociateProject1.getEmployeeId());
			if (CollectionUtils.isNotEmpty(empdId)) {
				alreadyAllocatedResource.add(tAssociateProject1.getEmployeeId());
			}
		}
		if (CollectionUtils.isNotEmpty(alreadyAllocatedResource)) {
			throw new ResourceManagementException(
					ResourceManagementConstant.SAME_TRAVEL_ALLOCATION + alreadyAllocatedResource);
		} else {
			List<Long> roleId = new ArrayList<>();
			roleId.add(tAssociateProjectDto.get(0).getRoleId());
			List<PrimaryUsersDto> primaryUserList = bapServiceClient
					.getRoleBasedPrimaryOwnersList(tAssociateProjectDto.get(0).getProjectId(), roleId);
			for (TAssociateProject tAssociateProject : associateProjectAllocation) {
				if (null != primaryUserList) {
					setAssociateDetailsTravel(tAssociateProject, primaryUserList);
					associateProjectRepository.save(tAssociateProject);
					flag = true;
				}
			}
			if (flag) {
				sendMailHelperService.sendEmailForTravelSubmissionConfirmation(tAssociateProjectDto);

			}
		}
		log.info("End saveResourceTravelAllocations-Allocation Ends");
	}

	private void setAssociateDetailsTravel(TAssociateProject tAssociateProject, List<PrimaryUsersDto> primaryUserList)
			throws ResourceManagementException {
		ModuleStatusDto moduleStatusDto = adminServiceClient.getModuleStatus(
				ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long statusForAllocApproved = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED_ACTION);
		AllocationTypeStatusDto allocationTypeStatus = adminServiceClient
				.getAllocationTypeStatus(ResourceManagementConstant.TRAVEL_ALLOCATION_TYPE_STATUS);
		if (null != tAssociateProject) {
			ResourceRequirementDto requirementDetailList = bapServiceClient
					.getRequirementDetailByReqId(tAssociateProject.getTAssociateAllocation().getRequirementId());
			if (null != requirementDetailList) {
				double shoreWorkHour = ResourceManagementConstant.ONSHORE
						.equalsIgnoreCase(requirementDetailList.getShore()) ? 8 : 9;
				tAssociateProject.setEffectiveStartDate(
						tAssociateProject.getTAssociateAllocation().getActualAllocationStartDate());
				tAssociateProject
						.setEffectiveEndDate(tAssociateProject.getTAssociateAllocation().getActualAllocationEndDate());
				tAssociateProject.getTAssociateAllocation()
						.setWorkLocationId(requirementDetailList.getResourceRequirementLocationId());
				tAssociateProject.getTAssociateAllocation().setBaseHours(shoreWorkHour);
				tAssociateProject.getTAssociateAllocation()
						.setBillableStatusId(requirementDetailList.getBillableStatusId());
				tAssociateProject.getTAssociateAllocation()
						.setEstAllocationEndDate(requirementDetailList.getProjectEndDate());
				tAssociateProject.getTAssociateAllocation().setStatusId(moduleStatusDto.getModuleStatusId());
				tAssociateProject.getTAssociateAllocation()
						.setAllocationTypeId(allocationTypeStatus.getAllocationTypeId());
				tAssociateProject.getTAssociateAllocation().setCreatedDate(new Date());
				tAssociateProject.getTAssociateAllocation().setLastUpdatedDate(new Date());
				tAssociateProject.getTAssociateAllocation().setEffectiveStartDate(
						tAssociateProject.getTAssociateAllocation().getActualAllocationStartDate());
				tAssociateProject.getTAssociateAllocation()
						.setEffectiveEndDate(tAssociateProject.getTAssociateAllocation().getActualAllocationEndDate());
				tAssociateProject.getTAssociateAllocation().setEstAllocationEndDate(
						tAssociateProject.getTAssociateAllocation().getActualAllocationEndDate());
				tAssociateProject.setCreatedDate(new Date());
				tAssociateProject.setLastUpdatedDate(new Date());
				tAssociateProject.getTAssociateAllocation().setSupervisorId(primaryUserList.get(0).getEmpId());
				tAssociateProject.setSupervisorId(primaryUserList.get(0).getEmpId());
				tAssociateProject.setStatusId(moduleStatusDto.getModuleStatusId());
				tAssociateProject.getTAssociateAllocation().setWorkflowStatusId(statusForAllocApproved);
				Long createdBy = tAssociateAllocationRepository.getEmployeeId(tAssociateProject.getCreatedBy());
				Long lastUpdatedBy = tAssociateAllocationRepository.getEmployeeId(tAssociateProject.getLastUpdatedBy());
				tAssociateProject.setCreatedBy(createdBy);
				tAssociateProject.setLastUpdatedBy(lastUpdatedBy);
				tAssociateProject.getTAssociateAllocation().setCreatedBy(createdBy);
				tAssociateProject.getTAssociateAllocation().setLastUpdatedBy(lastUpdatedBy);
				tAssociateProject.getTAssociateAllocation().setStdCost(0d);
				tAssociateProject.getTAssociateAllocation().setSkillChampionFlag(false);
				tAssociateProject.getTAssociateAllocation().setRoleId(requirementDetailList.getRequirementRoleId());
				tAssociateProject.getTAssociateAllocation().setTAssociateProject(tAssociateProject);
			}
		}

	}   

	public Map<Long, EmployeeSkillDto> getSkillFamilyForAssociate(List<Long> employeeIds)
			throws ResourceManagementException {
		    
		Long statusIdForSkillActive = adminServiceClient.getModuleStatusByAction(ResourceManagementConstant.SKILL, ResourceManagementConstant.ACTIVATE);
		Long primarySkillFlag = adminServiceClient.getLookuIdByTypeAndDescr(ResourceManagementConstant.SKILL_COMPETANCY, ResourceManagementConstant.PRIMARY);
        List<TAssociateSkill> skillList = skillRepository.getPrimarySkillForAssociate(employeeIds, primarySkillFlag, statusIdForSkillActive);		
        Map<Long, EmployeeSkillDto> empSkillMap = null;
		List<EmployeeSkillDto> newemployeeSkillList = null;
		if (CollectionUtils.isNotEmpty(skillList)) {
			List<Long> skillIdList = skillList.stream().map(TAssociateSkill::getSkillId).distinct()
					.collect(Collectors.toList());
			List<SkillTaxonomyDto> associateSkillList = adminServiceClient.getSkillFamilyByskillId(skillIdList);
			Map<Long, SkillTaxonomyDto> skillFamilyMap = associateSkillList.stream()
					.collect(Collectors.toMap(SkillTaxonomyDto::getL4SkillId, newskillFamilyMap -> newskillFamilyMap));
			newemployeeSkillList = new ArrayList<>();
			for (Long employeeId : employeeIds) {
				EmployeeSkillDto empSkillDto = new EmployeeSkillDto();
				List<Long> skillIds = skillRepository.getSkillListForEmployee(employeeId,primarySkillFlag, statusIdForSkillActive);
				empSkillDto.setEmployeeId(employeeId);
				empSkillDto.setL4SkillId(skillIds);
				List<SkillTaxonomyDto> newSkillFamilList = new ArrayList<SkillTaxonomyDto>();
				for (Long skill : skillIds) {
					SkillTaxonomyDto skillFamily = skillFamilyMap.get(skill);
					if(skillFamily!=null) {
						newSkillFamilList.add(skillFamily);}
				}

				empSkillDto.setSkillFamilyList(newSkillFamilList);
				newemployeeSkillList.add(empSkillDto);

			}
			empSkillMap = newemployeeSkillList.stream()
					.collect(Collectors.toMap(EmployeeSkillDto::getEmployeeId, newempSkillMap -> newempSkillMap));

		}
		return empSkillMap;
	}

	public long getModuleStatusId(String subModuleName, String actionName) throws ResourceManagementException {
		ModuleStatusDto moduleStatusDto = adminServiceClient
				.getModuleStatus(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModuleName, actionName);
		if (moduleStatusDto != null)
			return moduleStatusDto.getModuleStatusId();
		else
			return 0;
	}

	public void saveResourceAllocationByAdminOrTag(Long projectId, Long requirementId,
			List<TAssociateProjectDto> tAssociateProjectDto,boolean budgetCheck) throws ResourceManagementException {
		long startTime = System.currentTimeMillis();
		log.info("Start saveResourceAllocationByAdmin-Allocation Start-{}", sdf.format(startTime));
		long allocApprovedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED_ACTION);
		List<AllocatedResourceProjection> allocatedResource = alllocatedResourceCheck(tAssociateProjectDto);

		if (!CollectionUtils.isEmpty(allocatedResource)) {
			List<Long> empIds = allocatedResource.stream().map(AllocatedResourceProjection::getEmployeeId)
					.collect(Collectors.toList());
	        List<Long> empNumber=adminServiceClient.getEmployeeNumber(empIds);
			throw new ResourceManagementException(empNumber + " " + ResourceManagementConstant.SAME_ALLOCATION_REQUIREMENT);
		} else {   
			if (budgetCheck) {
				if (performBudgetControlCheckAndUpdate(projectId, requirementId, tAssociateProjectDto)) {
					saverrForAdminOrTag(tAssociateProjectDto, allocApprovedStatusId);
				} else {
					throw new ResourceManagementException(ResourceManagementConstant.INSUFFICIENT_BUDGET);
				}
			} else {
				saverrForAdminOrTag(tAssociateProjectDto, allocApprovedStatusId);
			}
		}
	}

	private void saverrForAdminOrTag(List<TAssociateProjectDto> tAssociateProjectDto, long allocApprovedStatusId)
			throws ResourceManagementException {
		List<Long> employeeIds = tAssociateAllocationRepository.getEmployeeIds(List.of(tAssociateProjectDto.get(0).getCreatedBy()));

		Map<Long, TAssociateProjectDto> tAssociateProjectDtoMap = tAssociateProjectDto.stream().
        		collect(HashMap::new, (m, v) -> m.put(v.getEmployeeId(), v), HashMap::putAll);
        List<BAllocationMilestoneDto> bAllocationMilestoneList= new ArrayList<>();
		List<TAssociateProject> associateProjectAllocation = asssociateProjectMapper
				.tAssociateProjectDtoToTAssociateProject(tAssociateProjectDto);
		List<Long> roleId = new ArrayList<>();
		List<Long> fixedPriceStatusIdList = new ArrayList<>();
        Long projectCommercialTypeId = 0L;
		List<TAssociateProject> tAssociateProjectsList = new ArrayList<>();
		Long newroleId = adminServiceClient.getLookuIdByTypeAndDescr("ROLE_TYPE", "PROJECT MANAGER");
		roleId.add(newroleId); 
		List<PrimaryUsersDto> primaryUserList = bapServiceClient
				.getRoleBasedPrimaryOwnersList(tAssociateProjectDto.get(0).getProjectId(), roleId);
		List<ResourceRequirementDto> resourceRequirementList = bapServiceClient.getResourceRequiremetList(
				List.of(tAssociateProjectDto.get(0).getTAssociateAllocation().getRequirementId()));
		ModuleStatusDto module = adminServiceClient.getModuleStatus(ResourceManagementConstant.RESOURCE_MANAGEMENT,
				ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
		double shoreWorkHour = ResourceManagementConstant.ONSHORE
				.equalsIgnoreCase(resourceRequirementList.get(0).getShore()) ? 8 : 9;
		Long workLocationId = resourceRequirementList.get(0).getResourceRequirementLocationId();
		if (null != primaryUserList) {
			//Added by Mrunal Marne for milestone selection while resource allocation
			projectCommercialTypeId = bapServiceClient.getSalesOrderDetailByProjectId(associateProjectAllocation.get(0).getProjectId());
			List<String> lookupValueDescList = List.of(ResourceManagementConstant.COMMERCIAL_MODEL_FIXED_PRICE, ResourceManagementConstant.COMMERCIAL_MODEL_FIXED_PRICE_AMC);
			List<LookupValueNewDto> lookupValueListByLookupDesc = adminServiceClient.getLookupValueListByLookupDesc(lookupValueDescList);
			fixedPriceStatusIdList = lookupValueListByLookupDesc.stream().map(LookupValueNewDto::getLookupValueId).collect(Collectors.toList());
			Long lookupIdForNb = adminServiceClient.getLookuIdByTypeAndDescr(
					ResourceManagementConstant.PROJECT_BILLABLE_TYPE, ResourceManagementConstant.Non_Billable);
			Long projectBillableIdbyProjectId = adminServiceClient
					.getProjectBillableIdbyProjectId(associateProjectAllocation.get(0).getProjectId());
			//End by Mrunal Marne
			//Added By Shubham
			AllocationTypeStatusDto allocationTypeStatus = adminServiceClient
					.getAllocationTypeStatus(ResourceManagementConstant.RESOURCE_ALLOCATION_TYPE_STATUS);
			//End
			for (TAssociateProject tAssociateProject : associateProjectAllocation) {  
				tAssociateProject.setCreatedBy(employeeIds.get(0));
				tAssociateProject.setLastUpdatedBy(employeeIds.get(0));
				tAssociateProject.setCreatedDate(new Date());
				tAssociateProject.setLastUpdatedDate(new Date());
				tAssociateProject.getTAssociateAllocation().setCreatedBy(employeeIds.get(0));
				tAssociateProject.getTAssociateAllocation().setLastUpdatedBy(employeeIds.get(0));
				tAssociateProject.setSupervisorId(primaryUserList.get(0).getEmpId());
				tAssociateProject.getTAssociateAllocation().setSupervisorId(primaryUserList.get(0).getEmpId());
				tAssociateProject.getTAssociateAllocation().setTAssociateProject(tAssociateProject);
				tAssociateProject.getTAssociateAllocation().setWorkflowStatusId(allocApprovedStatusId);
				tAssociateProject.getTAssociateAllocation().setCreatedDate(new Date());
				tAssociateProject.getTAssociateAllocation().setLastUpdatedDate(new Date());
				tAssociateProject.getTAssociateAllocation().setEffectiveStartDate(
						tAssociateProject.getTAssociateAllocation().getActualAllocationStartDate());
				tAssociateProject.setStatusId(module.getModuleStatusId());
				tAssociateProject.getTAssociateAllocation().setBaseHours(shoreWorkHour);
				tAssociateProject.getTAssociateAllocation().setWorkLocationId(workLocationId);
				tAssociateProject.getTAssociateAllocation().setStatusId(module.getModuleStatusId());
				tAssociateProject.getTAssociateAllocation().setAllocationTypeId(allocationTypeStatus.getAllocationTypeId());
				if (tAssociateProjectDto.get(0).getBudgetAndCostCheck() == true
						&& tAssociateProject.getTAssociateAllocation().getTAssociateAllocationBudget() != null) {
					for (TAssociateAllocationBudget tAssociateAllocationBudget : tAssociateProject
							.getTAssociateAllocation().getTAssociateAllocationBudget()) {
						tAssociateAllocationBudget.setTAssociateAllocation(tAssociateProject.getTAssociateAllocation());
					}
				}
				TAssociateProject tAssociateProjectReference = associateProjectRepository.save(tAssociateProject);
				tAssociateProjectsList.add(tAssociateProject);
				//Added by Mrunal Marne for milestone selection while resource allocation
				bAllocationMilestoneList.addAll(prepareMilestoneDetailsForSave(tAssociateProjectReference, tAssociateProjectDtoMap, projectCommercialTypeId, fixedPriceStatusIdList, projectBillableIdbyProjectId, lookupIdForNb));
			}
			if(!bAllocationMilestoneList.isEmpty()) {
				bapServiceClient.savePoAndMilestoneDetailsDuringAllocation(bAllocationMilestoneList);
			}
			//Added by Mrunal Marne for updating pool availability by Tag Team
			log.info("POOL ALLOC STARTED");
			List<Long> empIdsList = tAssociateProjectsList.stream()
					.map(TAssociateProject::getEmployeeId).collect(Collectors.toList());
			Map<String, Long> lookupMap = resourceRequirementServiceImpl.getLookupValue();
			Long billableStatusID = lookupMap.get(ResourceManagementConstant.Billable_Pool);
			long allocActivateStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
			List<AllocatedResourceProjection> poolProjectionList = tAssociateAllocationRepository
					.getProjectionForPool(empIdsList, allocActivateStatusId, allocApprovedStatusId,
							billableStatusID);
			Long userId = tAssociateProjectDto.get(0).getCreatedBy();
			try {
				resourceManagementServiceImpl.updatenewPoolrecord(tAssociateProjectsList, poolProjectionList, allocApprovedStatusId,
						allocActivateStatusId,userId);
			} catch (Exception e) {
				throw new ResourceManagementException(ResourceManagementConstant.ALLOCATION_NOT_POSSIBLE, e);
			} 
			log.info("POOL ALLOC ENDS");
			//End by Mrunal
		}
	}

	@Override
	public List<EmployeeDto> getpoolToIntransitAllocationDtls(String empIdOrName, Long currIntransitProjectId,
			Long requirmentId) throws ResourceManagementException {
		EmployeeDto employeeDto = adminServiceClient.getEmployeeByNameOrId(empIdOrName);
		List<EmployeeDto> newEmployeeList = new ArrayList<>();
		//srinivasulu s
		List<ServiceLineDto> serviceLineDto = getServiceLineDto(currIntransitProjectId);
		//end srinivasulu s
		if (null != employeeDto) {
			Long empId = employeeDto.getEmployeeId();
			Long empNumber = employeeDto.getEmployeeNumber();
			ModuleStatusDto moduleStatusDto = adminServiceClient.getModuleStatus(
					ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_ALLOCATION,
					ResourceManagementConstant.ACTIVATE);
			Long statusIdForPool = tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(ResourceManagementConstant.RESOURCE_BILLABLE_TYPE, ResourceManagementConstant.POOL);
			//Added by Mrunal Marne
			Long statusIdForIntransit = tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(ResourceManagementConstant.RESOURCE_BILLABLE_TYPE, ResourceManagementConstant.InTransit);
			Long statusIdForSrfActive = tSrfRepository.getModuleIdForSrf(ResourceManagementConstant.SRF,
						ResourceManagementConstant.ACTIVATE);
			List<TSrf> srfList = tSrfRepository.getIntransitEarmarkedResource(empNumber,
					ResourceManagementConstant.EARMARKED_STATUS, statusIdForSrfActive, true);
			if (null != srfList) {
				List<Long> empIds = new ArrayList<>();
				empIds.add(empId);  
				ResourceRequirementDto requirementDetailList = bapServiceClient
						.getRequirementDetailByReqId(requirmentId);
				List<AvaibalityProjection> employeeAvaibility = tAssociateAllocationRepository
						.getAllocatedResourceAvaibality(empIds,moduleStatusDto.getModuleStatusId(),statusIdForPool);
				boolean budgetControlcheck = getBudgetAndCostCheck(currIntransitProjectId);
				employeeDto.setServiceLineId(requirementDetailList.getServiceLineId());
				employeeDto.setServiceLineName(requirementDetailList.getServiceLineName());
				employeeDto.setRequirementRoleId(requirementDetailList.getRequirementRoleId());
				employeeDto.setRequirementRole(requirementDetailList.getRequirementRole());
				employeeDto.setResourceRequirementLocationId(requirementDetailList.getResourceRequirementLocationId());
				employeeDto.setResourceRequirementLocation(requirementDetailList.getResourceRequirementLocation());
				employeeDto.setLocationTypeId(requirementDetailList.getResourceRequirementLocationId());
				employeeDto.setReasonForDeallocationList(getReasonForAllocationList());
				employeeDto.setBudgetAndCostCheck(budgetControlcheck);
				//Added by Mrunal Marne
				employeeDto.setBillableStatusId(statusIdForIntransit.intValue());
		    	setAvaibality(employeeDto, employeeAvaibility);
		    	employeeDto.setAvailibility((long)employeeDto.getAvailability());
				List<TSrf> newsrfList = getSrfWithinBu(currIntransitProjectId, srfList);
				setSrfNumber(employeeDto, newEmployeeList, newsrfList);
				//srinivasulu 
				if(employeeDto.getServiceLineName()==null||employeeDto.getServiceLineName().equalsIgnoreCase("NOT AVAILABLE")) {
					employeeDto.setServiceLineDto(serviceLineDto);
			}
				//srinivasulu s
			}
		}
		return newEmployeeList;
	}   

	private void setAvaibality(EmployeeDto employeeDto, List<AvaibalityProjection> employeeAvaibility) {
		if (CollectionUtils.isNotEmpty(employeeAvaibility)) {
			employeeDto.setAvailability(employeeAvaibility.get(0).getAllocatedFte());
		} else {
			employeeDto.setAvailability(100.00);
		}
	}


private List<ServiceLineDto> getServiceLineDto(long projectId) throws ResourceManagementException {
		List<Long> serviceLineIds = tAssociateAllocationRepository.getProjectServiceLineIdbyProjectId(projectId);
		if (!serviceLineIds.stream().allMatch(o -> o == null)) {
			return adminServiceClient.getServiceLineList(serviceLineIds);
		}
		return Collections.emptyList();
	}
	
	private List<TSrf> getSrfWithinBu(Long currIntransitProjectId, List<TSrf> srfList)
			throws ResourceManagementException {
		List<TSrf> newsrfList = new ArrayList<>();
		for (TSrf srf : srfList) {
			srf.getProjectId();
			// Long projectId = Long.parseLong(srf.getProjectId());
			Long projectId = tAssociateAllocationRepository.getProjectIdByCode(srf.getProjectId());
			if (projectId.equals(currIntransitProjectId)) {
				newsrfList.add(srf);

			} else {
				Long intransitProjectId = bapServiceClient.getIntransitProjectId(projectId).getProjectId();
				if (currIntransitProjectId.equals(intransitProjectId)) {
					newsrfList.add(srf);
				}
			}

		}
		return newsrfList;
	}

	private void setSrfNumber(EmployeeDto employeeDto, List<EmployeeDto> newEmployeeList, List<TSrf> newsrfList) {
		for (TSrf newSrf : newsrfList) {
			employeeDto.setSrfId(newSrf.getSrfId());
			employeeDto.setSrfNo(newSrf.getSrfNumber());
			newEmployeeList.add(employeeDto);
		}
	}

	private List<AllocatedResourceProjection> alllocatedResourceCheck(List<TAssociateProjectDto> tAssociateProjectDto)
			throws ResourceManagementException {
		long allocApprovedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED_ACTION);
		long allocActiveStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		ModuleStatusDto moduleStatus = adminServiceClient.getModuleStatus(
				ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ALLOCATION_ACTION_SAVED);
		long workflowStatusIdSaved = moduleStatus.getModuleStatusId().intValue();

		List<Long> empIdList = tAssociateProjectDto.stream().map(TAssociateProjectDto::getEmployeeId)
				.collect(Collectors.toList());
		List<Long> reqIdList = tAssociateProjectDto.stream().map(TAssociateProjectDto::getTAssociateAllocation)
				.map(TAssociateAllocationDto::getRequirementId).collect(Collectors.toList());
		List<Long> projrctIdList = tAssociateProjectDto.stream().map(TAssociateProjectDto::getProjectId)
				.collect(Collectors.toList());
		List<AllocatedResourceProjection> resourceList = tAssociateAllocationRepository.getAllocatedResource(empIdList,
				allocActiveStatusId, allocApprovedStatusId, workflowStatusIdSaved, projrctIdList, reqIdList);

		List<AllocatedResourceProjection> allocatedResource = new ArrayList<>();
		if (!CollectionUtils.isEmpty(resourceList)) {
			for (AllocatedResourceProjection allocatedResourceProjection : resourceList) {
				for (TAssociateProjectDto requestedResourceProjection : tAssociateProjectDto) {
					if (allocatedResourceProjection.getEmployeeId() == requestedResourceProjection.getEmployeeId()) {
						allocatedResource.add(allocatedResourceProjection);
					}
				}
			}
		}
		return allocatedResource;
	}
	
	public List<ReasonForDeallocation> getReasonForAllocationList()
	{
		 	 
     	List<ReasonForDeallocation> allocReasonList =  new ArrayList<>();
		ReasonForDeallocation allocReason = new ReasonForDeallocation();
		
		allocReason.setReason("PD ALLOCATION PENDING");
		allocReasonList.add(allocReason);
		allocReason.setReasonId(1l);
		
		ReasonForDeallocation allocReason1 = new ReasonForDeallocation();
		allocReason1.setReasonId(2l);
		allocReason1.setReason("VISA APPLIED");
		
		ReasonForDeallocation allocReason2 = new ReasonForDeallocation();
		allocReason2.setReasonId(3l);
		allocReason2.setReason("PROJECT CANCELLED/DELAYED");

		allocReasonList.add(allocReason2);
		allocReasonList.add(allocReason1);
		allocReasonList.add(allocReason);
		return allocReasonList;
		
	}

	@Override
	public List<SkillTaxonomyDto> getSkillListForResource(Long employeeId) throws ResourceManagementException {
		log.info("Entered in getSkillListForResource method");
		Map<Long, EmployeeSkillDto> skillFamilyForAssociate = getSkillFamilyForAssociate(List.of(employeeId));
		
		return skillFamilyForAssociate.get(employeeId).getSkillFamilyList();
	}

	@Override
	public List<EmployeeDto> getAlllocatedFteRsrcForReq(@Valid Long requirementId) throws ResourceManagementException {
		
		List<Long> workFlowStatusIds=new ArrayList<>();
		Map<Long, String> moduleMap=new HashMap<>();
		long allocApprovedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED_ACTION);
		long allocSumitedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.SUBMITTED);
		long allocSavedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.SAVED);
		long transferSubmittedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.SUBMITTED);
		long transferSavedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.SAVED);
		long allocActiveStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
	
		
		workFlowStatusIds.add(allocApprovedStatusId);
		workFlowStatusIds.add(allocSumitedStatusId);
		workFlowStatusIds.add(allocSavedStatusId);
		workFlowStatusIds.add(transferSubmittedStatusId);
		workFlowStatusIds.add(transferSavedStatusId);
		moduleMap.put(allocApprovedStatusId, ResourceManagementConstant.APPROVED_ACTION);
		moduleMap.put(allocSumitedStatusId, ResourceManagementConstant.SUBMITTED);
		moduleMap.put(allocSavedStatusId, ResourceManagementConstant.SAVED);
		moduleMap.put(transferSubmittedStatusId, ResourceManagementConstant.SUBMITTED);
		moduleMap.put(transferSavedStatusId,ResourceManagementConstant.SAVED);
		//List<AllocatedResourceProjection> associateProjectionList = tAssociateAllocationRepository.getAlllocatedFteRsrcForReq(requirementId,allocApprovedStatusId,allocActiveStatusId);			
		List<AllocatedResourceProjection> associateProjectionList = tAssociateAllocationRepository.getAlllocatedFteRsrcForReq(requirementId,workFlowStatusIds,allocActiveStatusId);
		List<Long> billableIdList = associateProjectionList.stream().map(AllocatedResourceProjection::getBillableStatusId).distinct().mapToLong(Integer::longValue).boxed().collect(Collectors.toList());
		List<Long> empIdList = associateProjectionList.stream().map(AllocatedResourceProjection::getEmployeeId).distinct()
				.collect(Collectors.toList());
		List<LookupValueDto> lookUpValueDetailsByIds = adminServiceClient.getLookUpValueDetailsByIds(billableIdList);
		Map<Long, String> lookupDescToIdMap = lookUpValueDetailsByIds.stream().collect(Collectors
				.toMap(LookupValueDto::getLookUpId, LookupValueDto::getLookupValueCode));
		List<EmployeeDto> associatesDetailsbyEmpIds = adminServiceClient.getAssociatesDetailsbyEmpIds(empIdList);
		Map<Long, EmployeeDto> employeeMap = associatesDetailsbyEmpIds.stream().collect(Collectors
				.toMap(EmployeeDto::getEmployeeId, x -> x));
		List<EmployeeDto> employeeList = new ArrayList<>();
		
		Map<Long, AllocatedResourceProjection> projectionMap=associateProjectionList.stream().collect(Collectors
				.toMap(AllocatedResourceProjection::getAssociateAllocationId, x -> x));
		projectionMap.entrySet().stream().forEach(Map.Entry::getKey);
		EmployeeDto employeeDto=null;
		for(AllocatedResourceProjection projection: associateProjectionList) {
			employeeDto=new EmployeeDto();
			employeeDto=mapToEmployeeDto(employeeMap.get(projection.getEmployeeId()),employeeDto);
			employeeDto.setBillableType(lookupDescToIdMap.get((long)projection.getBillableStatusId()));
			employeeDto.setEmployeeLocation(projection.getWorkLocation());
			employeeDto.setAssociateAllocationId(projection.getAssociateAllocationId());
			employeeDto.setProjectUtilization(projection.getFtePercent());
			employeeDto.setApprovedStatus(moduleMap.get(projection.getWorkflowStatusId()));

			if(null != projection.getBillableStatusId())
				employeeDto.setBillingStatus(lookupDescToIdMap.get(Long.valueOf(projection.getBillableStatusId())));
			employeeList.add(employeeDto);
		}
		return employeeList;
	}
	

	private EmployeeDto mapToEmployeeDto(EmployeeDto source,EmployeeDto target) {
		 
	return	target = new EmployeeDto( source.getAssociateAllocationId(),  source.getEmployeeNumber(),  source.getEmployeeId(),  source.getEmployeeName(),
				source.getEmployeePracticeId(),  source.getPracticeName(),  source.getEmployeeRoleId(),  source.getRole(),  source.getBand(),
				source.getEmployeeLocationId(),  source.getEmployeeLocation(),  source.getPracticeAllocationStartDate(),
				source.getPracticeAllocationEndDate(), source.getEmailId());
	}
}
