package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class CostCardInputDto {
	
	private long locationId;
	private long payrolld;
	private long practiceId; // l2
	private long skillFamilyId; // l3
	private long bandId;
	private String locationType;
	private long locationTypeId;
	private String band;
	private Double projectBillingHours;
	private String shore;
	private String currencyName;
	private Long projectRequirementId;
	

}
