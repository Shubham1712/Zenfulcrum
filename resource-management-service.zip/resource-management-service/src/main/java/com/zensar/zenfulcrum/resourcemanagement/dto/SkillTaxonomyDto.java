package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class SkillTaxonomyDto {
	
	     private Long employeeId;
	    private long requirmentId;
	    private Long l1PracticeId;
	    private String l1PracticeName;
	    private Long l2SubPracticeId;
	    private String l2SubPracticeName;
	    private Long l3SkillFamilyId;
	    private String l3SkillFamilyName;
	    private Long l4SkillId;
	    private String l4skillName;
	    private Long payrollArrangementId;
	    private String payrollArrangement;
		private Boolean nicheSkillFlag;

}
