package com.zensar.zenfulcrum.resourcemanagement.config;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;

@Component
@FeignClient(value = "authenticateUser", url = "https://projectdirectorstage.zensar.com/ZenFulcrumAPI/")
public interface ZenWalletConfig {
	
	@GetMapping("GetMonthlyBudgetOfProject/{projectId}")
	List<ProjectBudgetDto> getBudget(@PathVariable(value = "projectId") String projectId);
	

	@Transactional
	@RequestMapping(method = RequestMethod.POST, value = "/updateMonthlyBudget", consumes = "application/json")
	void update(List<ProjectBudgetDto> projectBudget);
}
