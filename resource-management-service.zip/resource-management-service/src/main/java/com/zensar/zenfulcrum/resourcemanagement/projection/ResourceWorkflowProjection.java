package com.zensar.zenfulcrum.resourcemanagement.projection;

public interface ResourceWorkflowProjection {
	
	public Long getCurrentUserId();	
	
	public Long getNextUserId();
	
	public Long getCurrentRoleId();
	
	public Long getNextRoleId();
	
	public void setCurrentUserId(long currenUserId);
	
	public void setNextUserId(long nextUserId);
	
	public void setCurrentRoleId(long currenRoleId);
	
	public void setNextRoleId(long nextRoleId);

}
