package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;

import lombok.Data;

@Data
public class ProjectDtlsDto {

	long projectId;
	long projectCode;
	double projectActualCost;
	double projectAtculaRevenue;
	double estimetedMargin;
	double projectedMargin;
	double currentMarginOractualMargin;
	String projectName;
	String enagementModel;
	String status;
	String excutionOfficeLocation;
	String onsiteOfficeLocation;
	String onsiteCountry;
	String costCenter;
	String typeOfService;
	String qmsTag;
	String qualityManager;
	String reason;
	String qualityReasonRemarks;
	String projectLifeCyle;
	String bu;
	String accountVertical;
	String rbu;
	Date estStartDate;
	Date estEndDate;
	Date actualStartDate;
	Date actualEndDate;
	long estEfforts;
	String actualBillableEfforts;
	String totalRequiredResource;
	long allocatedResources;
	String projectCompletionPercenatage;
	long projectCapping;
	String comments;
	String typeOfLean;
	String leanInitMonth;
	String remarks;
	Double totalConsumption;
	Double totalMonthlyBudget;
	private String projectStatus;
	private Double availableBudget;
	
}
