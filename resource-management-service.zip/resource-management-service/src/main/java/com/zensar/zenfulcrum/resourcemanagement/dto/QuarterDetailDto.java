package com.zensar.zenfulcrum.resourcemanagement.dto;


import java.util.Date;

import lombok.Data;

@Data
public class QuarterDetailDto {

	private Long quarterId;
	private String quarterName;
	private Date startDate;
	private Date endDate;
}
