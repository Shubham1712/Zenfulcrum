package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class LookupValueDto {
	
	public Long lookUpId;
	private String lookupType;
	private String lookupValueCode;
	private String lookupValueDescription;
	private String lookupValueName;
	private long moduleStatusId;

}
