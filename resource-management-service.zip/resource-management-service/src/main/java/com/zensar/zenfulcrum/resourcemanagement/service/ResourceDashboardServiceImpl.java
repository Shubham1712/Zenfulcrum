package com.zensar.zenfulcrum.resourcemanagement.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Multimap;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueAndDescDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ReasonForDeallocation;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceApprovalDashboardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceDashboardTransferDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TraceabilityApprSummaryDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TraceabilityCurrentStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TraceabilityDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.model.ResourceWorkflow;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.ApprovalTraceabilityProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceWorkflowRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateExtensionRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class ResourceDashboardServiceImpl implements ResourceDashboardService {

	@Autowired   
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Autowired
	private ResourceManagementServiceImpl resourceManagementServiceImpl;

	@Autowired
	ResourceWorkflowRepository resourceWorkflowRepository;

	@Autowired
	private TAssociateExtensionRepository tAssociateExtensionRepository;

	@Autowired
	private TAssociateDeAllocationRepository tAssociateDeAllocationRepository;

	@Autowired
	private BAPServiceClient bapServiceClient;

	@Autowired
	private AdminServiceClient adminServiceClient;

	@Autowired
	private ResourceManagementUtil resourceManagementUtil;

	/**
	 * Fetches resource pending count.
	 * 
	 * @param userId
	 * @param roleId
	 * @return
	 * @throws ResourceManagementException
	 */
	@Override
	@Transactional(readOnly = true)
	public ResourceApprovalDashboardDto getResourcePendingCount(Long userId, Long roleId)
			throws ResourceManagementException {
		log.info("Entered into ResourceSearchServiceImpl.getResourcePendingCount method:");
		ResourceApprovalDashboardDto resourceApprovalDashboardDto = new ResourceApprovalDashboardDto();
		Map<String, Integer> resourcePendingCountMap = new HashMap<>();
		Integer approvalPendingResourceCount = getApprovalPendingResourceCount(userId, roleId);
		Integer submissionPendingResourceCount = getSubmissionPendingResourceCount(userId);
		Integer pendingWithOthersResourceCount = getPendingWithOthersResourceCount(userId, roleId);
		Integer allocApprovalPendingCount = getAllocApprovalPendingCount(userId, roleId);
		Integer deallocApprovalPendingCount = getDeallocApprovalPendingCount(userId, roleId);
		Integer transferApprovalPendingCount = getTransferApprovalPendingCount(userId, roleId);
		Integer extApprovalPendingCount = getExtApprovalPendingCount(userId, roleId);
		Integer allocSubPendingCount = getAllocSubPendingCount(userId);
		Integer deallocSubPendingCount = getDeallocSubPendingCount(userId);
		Integer transferSubPendingCount = getTransferSubPendingCount(userId);
		Integer allocOtherPendingCount = getAllocOtherPendingCount(userId, roleId);
		Integer deallocOtherPendingCount = getDeallocOtherPendingCount(userId, roleId);
		Integer transferOtherPendingCount = getTransferOtherPendingCount(userId, roleId);
		Integer extOtherPendingCount = getExtOtherPendingCount(userId, roleId);

		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_FOR_APPROVAL, approvalPendingResourceCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_FOR_SUBMISSION, submissionPendingResourceCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_WITH_OTHERS, pendingWithOthersResourceCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_ALLOCATION_APPROVAL, allocApprovalPendingCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_DEALLOCATION_APPROVAL,
				deallocApprovalPendingCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_TRANSFER_APPROVAL, transferApprovalPendingCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_EXTENSION_APPROVAL, extApprovalPendingCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_ALLOCATION_SUBMISSION, allocSubPendingCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_DEALLOCATION_SUBMISSION, deallocSubPendingCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_TRANSFER_SUBMISSION, transferSubPendingCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_ALLOCATION_OTHERS, allocOtherPendingCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_DEALLOCATION_OTHERS, deallocOtherPendingCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_TRANSFER_OTHERS, transferOtherPendingCount);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_EXTENSION_OTHERS, extOtherPendingCount);

		resourceApprovalDashboardDto.setResourcePendingCountMap(resourcePendingCountMap);
		log.info("Exited into ResourceSearchServiceImpl.getResourcePendingCount method:");
		return resourceApprovalDashboardDto;
	}

	public Integer getApprovalPendingResourceCount(Long userId, Long roleId) throws ResourceManagementException {
		// pending for approval
		List<Long> submitStatusIdList = new ArrayList<>();
		submitStatusIdList
				.add(resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.SUBMITTED));
		submitStatusIdList
				.add(resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
						ResourceManagementConstant.SUBMITTED));
		submitStatusIdList.add(resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_EXTENSION, ResourceManagementConstant.SUBMITTED));
		submitStatusIdList.add(resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SUBMITTED));

		return tAssociateAllocationRepository.getApprovalPendingResourceCount(userId, roleId, submitStatusIdList);
	}

	public Integer getSubmissionPendingResourceCount(Long userId) throws ResourceManagementException {
		// Pending for submission
		List<Long> savedStatusIdList = new ArrayList<>();
		savedStatusIdList
				.add(resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.SAVED));
		savedStatusIdList.add(resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.SAVED));
		savedStatusIdList.add(resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SAVED));

		return tAssociateAllocationRepository.getSubmissionPendingResourceCount(userId, savedStatusIdList);
	}

	public Integer getPendingWithOthersResourceCount(Long userId, Long roleId) throws ResourceManagementException {
		// Pending with Others
		List<Long> pendingWithOtherList = new ArrayList<>();
		pendingWithOtherList
				.add(resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
						ResourceManagementConstant.SUBMITTED));

		return tAssociateAllocationRepository.getPendingOthersResourceCount(userId, roleId, pendingWithOtherList);
	}

	public Integer getAllocApprovalPendingCount(Long userId, Long roleId) throws ResourceManagementException {
		// Pending for Approval Allocation
		List<Long> pendingApprovalAllocList = new ArrayList<>();
		pendingApprovalAllocList
				.add(resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
						ResourceManagementConstant.SUBMITTED));
		return tAssociateAllocationRepository.getApprovalPendingResourceCount(userId, roleId, pendingApprovalAllocList);
	}

	public Integer getDeallocApprovalPendingCount(Long userId, Long roleId) throws ResourceManagementException {
		// Pending for Approval Deallocation
		List<Long> pendingApprovalDeAllocList = new ArrayList<>();
		pendingApprovalDeAllocList
				.add(resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.SUBMITTED));
		return tAssociateAllocationRepository.getApprovalPendingResourceCount(userId, roleId,
				pendingApprovalDeAllocList);
	}

	public Integer getTransferApprovalPendingCount(Long userId, Long roleId) throws ResourceManagementException {
		// Pending for Approval Transfer
		List<Long> pendingApprovalTransferList = new ArrayList<>();
		pendingApprovalTransferList.add(resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SUBMITTED));
		return tAssociateAllocationRepository.getApprovalPendingResourceCount(userId, roleId,
				pendingApprovalTransferList);
	}

	public Integer getExtApprovalPendingCount(Long userId, Long roleId) throws ResourceManagementException {
		// Pending for Approval Extension
		List<Long> pendingApprovalExtendList = new ArrayList<>();
		pendingApprovalExtendList.add(resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_EXTENSION, ResourceManagementConstant.SUBMITTED));
		return tAssociateAllocationRepository.getApprovalPendingResourceCount(userId, roleId,
				pendingApprovalExtendList);
	}

	public Integer getAllocSubPendingCount(Long userId) throws ResourceManagementException {
		// Pending for Submission Allocation
		List<Long> pendingSubAllocList = new ArrayList<>();
		pendingSubAllocList.add(resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.SAVED));
		return tAssociateAllocationRepository.getSubmissionPendingResourceCount(userId, pendingSubAllocList);
	}

	public Integer getDeallocSubPendingCount(Long userId) throws ResourceManagementException {
		// Pending for Submission Deallocation
		List<Long> pendingSubDeAllocList = new ArrayList<>();
		pendingSubDeAllocList
				.add(resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.SAVED));
		return tAssociateAllocationRepository.getSubmissionPendingResourceCount(userId, pendingSubDeAllocList);
	}

	public Integer getTransferSubPendingCount(Long userId) throws ResourceManagementException {
		// Pending for submission Transfer
		List<Long> pendingSubTransferList = new ArrayList<>();
		pendingSubTransferList.add(resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SUBMITTED));
		return tAssociateAllocationRepository.getSubmissionPendingResourceCount(userId, pendingSubTransferList);
	}

	public Integer getAllocOtherPendingCount(Long userId, Long roleId) throws ResourceManagementException {
		// Pending with Others Allocation
		List<Long> pendingApprovalAllocList = new ArrayList<>();
		pendingApprovalAllocList
				.add(resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
						ResourceManagementConstant.SUBMITTED));
		return tAssociateAllocationRepository.getPendingOthersResourceCount(userId, roleId, pendingApprovalAllocList);
	}

	public Integer getDeallocOtherPendingCount(Long userId, Long roleId) throws ResourceManagementException {
		// Pending with Others Deallocation
		List<Long> pendingApprovalDeAllocList = new ArrayList<>();
		pendingApprovalDeAllocList
				.add(resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.SUBMITTED));
		return tAssociateAllocationRepository.getPendingOthersResourceCount(userId, roleId, pendingApprovalDeAllocList);
	}

	public Integer getTransferOtherPendingCount(Long userId, Long roleId) throws ResourceManagementException {
		// Pending with others Transfer
		List<Long> pendingApprovalTransferList = new ArrayList<>();
		pendingApprovalTransferList.add(resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SUBMITTED));
		return tAssociateAllocationRepository.getPendingOthersResourceCount(userId, roleId,
				pendingApprovalTransferList);
	}

	public Integer getExtOtherPendingCount(Long userId, Long roleId) throws ResourceManagementException {
		// Pending with others Extension
		List<Long> pendingApprovalExtendList = new ArrayList<>();
		pendingApprovalExtendList.add(resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_EXTENSION, ResourceManagementConstant.SUBMITTED));
		return tAssociateAllocationRepository.getPendingOthersResourceCount(userId, roleId, pendingApprovalExtendList);
	}

	/**
	 * Get list of resources pending for approval/submission
	 * 
	 * @param userId
	 * @param roleId
	 * @return
	 * @throws ResourceManagementException
	 */
	@Override
	public ResourceApprovalDashboardDto getPendingResourceDetails(Long userId, Long roleId)
			throws ResourceManagementException {
		log.info("Entered into ResourceDashboardServiceImpl.getPendingResourceDetails method:");
		HashBasedTable<String, String, Long> moduletable = getModuleDta();
		List<String> requestTypeList = resourceManagementUtil.getListOfRequestTypes();
		List<ModuleStatusDto> moduleDtlsList = null;
		moduleDtlsList = adminServiceClient.getModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT,
				requestTypeList);
		Map<String, ModuleStatusDto> workflowTypeIdsMap = null;
		ResourceApprovalDashboardDto pendingResourceDtls = null;
		ResourceApprovalDashboardDto pendingResourceDtlsForSubmission = null;
		ResourceApprovalDashboardDto pendingResourceDtlsForApproval = null;
		if (CollectionUtils.isNotEmpty(moduleDtlsList))
			workflowTypeIdsMap = moduleDtlsList.stream().collect(HashMap::new, (m, v) -> m.put(v.getSubModule(), v),
					HashMap::putAll);
		pendingResourceDtlsForApproval = getResourcesPendingForApproval(userId, roleId, requestTypeList,
				workflowTypeIdsMap, moduletable);
		if (pendingResourceDtlsForApproval != null) {
			pendingResourceDtls = pendingResourceDtlsForApproval;
		}
		pendingResourceDtlsForSubmission = getResourcesPendingForSubmission(userId, roleId, requestTypeList,moduletable);
		if (pendingResourceDtlsForSubmission != null) {
			pendingResourceDtls.setResPendingAllocationSubmission(
					pendingResourceDtlsForSubmission.getResPendingAllocationSubmission());
			pendingResourceDtls.setResPendingDeallocationSubmission(
					pendingResourceDtlsForSubmission.getResPendingDeallocationSubmission());
			pendingResourceDtls.setResPendingTransferSubmission(
					pendingResourceDtlsForSubmission.getResPendingTransferSubmission());
		}
		log.info("Just before leaving ResourceDashboardServiceImpl.getPendingResourceDetails method:");
		return pendingResourceDtls;
	}
	
	//Added by Mrunal Marne for performance issue on dashboard
	public ResourceApprovalDashboardDto getPendingForApprovalAndOthersResourceDetails(Long userId, Long roleId)
			throws ResourceManagementException {
		log.info("Entered into ResourceDashboardServiceImpl.getApprovalPendingResourceDetails method:");
		HashBasedTable<String, String, Long> moduletable = getModuleDta();
		List<String> requestTypeList = resourceManagementUtil.getListOfRequestTypes();
		List<ModuleStatusDto> moduleDtlsList = null;
		moduleDtlsList = adminServiceClient.getModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT,
				requestTypeList);
		Map<String, ModuleStatusDto> workflowTypeIdsMap = null;
		ResourceApprovalDashboardDto pendingResourceDtls = null;
		ResourceApprovalDashboardDto pendingResourceDtlsForApproval = null;
		if (CollectionUtils.isNotEmpty(moduleDtlsList))
			workflowTypeIdsMap = moduleDtlsList.stream().collect(HashMap::new, (m, v) -> m.put(v.getSubModule(), v),
					HashMap::putAll);
		pendingResourceDtlsForApproval = getResourcesPendingForApproval(userId, roleId, requestTypeList,
				workflowTypeIdsMap, moduletable);
		if (pendingResourceDtlsForApproval != null) {
			pendingResourceDtls = pendingResourceDtlsForApproval;
		}
		log.info("Just before leaving ResourceDashboardServiceImpl.getApprovalPendingResourceDetails method:");
		return pendingResourceDtls;
	}
	
	public ResourceApprovalDashboardDto getPendingForSubmissionResourceDetails(Long userId, Long roleId)
			throws ResourceManagementException {
		log.info("Entered into ResourceDashboardServiceImpl.getSubmissionPendingResourceDetails method:");
		HashBasedTable<String, String, Long> moduletable = getModuleDta();
		List<String> requestTypeList = resourceManagementUtil.getListOfRequestTypes();
		ResourceApprovalDashboardDto pendingResourceDtls = new ResourceApprovalDashboardDto();
		ResourceApprovalDashboardDto pendingResourceDtlsForSubmission = null;
		pendingResourceDtlsForSubmission = getResourcesPendingForSubmission(userId, roleId, requestTypeList,moduletable);
		if (pendingResourceDtlsForSubmission != null) {
			pendingResourceDtls.setResPendingAllocationSubmission(
					pendingResourceDtlsForSubmission.getResPendingAllocationSubmission());
			pendingResourceDtls.setResPendingDeallocationSubmission(
					pendingResourceDtlsForSubmission.getResPendingDeallocationSubmission());
			pendingResourceDtls.setResPendingTransferSubmission(
					pendingResourceDtlsForSubmission.getResPendingTransferSubmission());
		}
		log.info("Just before leaving ResourceDashboardServiceImpl.getSubmissionPendingResourceDetails method:");
		return pendingResourceDtls;
	}
	//End by Mrunal

	/**
	 * Get list of resources pending for approval and pending with others
	 * 
	 * @param userId
	 * @param roleId
	 * @param requestType
	 * @return
	 * @throws ResourceManagementException
	 */
	public ResourceApprovalDashboardDto getResourcesPendingForApproval(Long userId, Long roleId,
			List<String> requestTypeList, Map<String, ModuleStatusDto> workflowTypeIdsMap,
			HashBasedTable<String, String, Long> moduletable) throws ResourceManagementException {
		log.info("Entered into ResourceDashboardServiceImpl.getResourcesPendingForApproval method:");
		ResourceApprovalDashboardDto approvalPendingResourceDtls = new ResourceApprovalDashboardDto();
		ResourceApprovalDashboardDto approvalPendingResourceDtlsForAlloc = null;
		ResourceApprovalDashboardDto approvalPendingResourceDtlsForDeAlloc = null;
		ResourceApprovalDashboardDto approvalPendingResourceDtlsForAllocExt = null;
		ResourceApprovalDashboardDto approvalPendingResourceDtlsForTransfer = null;
		long workflowTypeId = 0;
		for (String requestType : requestTypeList) {
			workflowTypeId = workflowTypeIdsMap.get(requestType).getModuleId();
			if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_ALLOCATION)) {
				approvalPendingResourceDtlsForAlloc = getPendingResourceDetailsForAlloc(userId, roleId, requestType,
						workflowTypeId, moduletable);
				createResourceApprovalDashboardDtoObject(approvalPendingResourceDtls, requestType,
						approvalPendingResourceDtlsForAlloc);
			} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_DEALLOCATION)) {
				approvalPendingResourceDtlsForDeAlloc = getPendingResourceDetailsForDeAlloc(userId, roleId, requestType,
						workflowTypeId,moduletable);
				createResourceApprovalDashboardDtoObject(approvalPendingResourceDtls, requestType,
						approvalPendingResourceDtlsForDeAlloc);
			} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_EXTENSION)) {
				approvalPendingResourceDtlsForAllocExt = getPendingResourceDetailsForAllocExt(userId, roleId,
						requestType, workflowTypeId);
				createResourceApprovalDashboardDtoObject(approvalPendingResourceDtls, requestType,
						approvalPendingResourceDtlsForAllocExt);
			} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_TRANSFER)) {
				approvalPendingResourceDtlsForTransfer = getPendingResourceDetailsForTransfer(userId, roleId,
						requestType, workflowTypeId);
				createResourceApprovalDashboardDtoObject(approvalPendingResourceDtls, requestType,
						approvalPendingResourceDtlsForTransfer);
			}
		}
		log.info("Just before leaving ResourceDashboardServiceImpl.getResourcesPendingForApproval method:");
		return approvalPendingResourceDtls;
	}

	/**
	 * Prepares final ResourceApprovalDashboardDto object
	 * 
	 * @param final       dto object reference
	 * @param current     dto object like for alloc/dealloc/extension/transfer
	 * @param requestType
	 */
	public void createResourceApprovalDashboardDtoObject(ResourceApprovalDashboardDto approvalPendingResourceDtls,
			String requestType, ResourceApprovalDashboardDto currentApprovalResourceDtls) {
		if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_ALLOCATION)
				&& currentApprovalResourceDtls != null) {
			approvalPendingResourceDtls
					.setResPendingAllocationApproval(currentApprovalResourceDtls.getResPendingAllocationApproval());
			approvalPendingResourceDtls
					.setResPendingOtherAllocation(currentApprovalResourceDtls.getResPendingOtherAllocation());
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_DEALLOCATION)
				&& currentApprovalResourceDtls != null) {
			approvalPendingResourceDtls
					.setResPendingDeallocationApproval(currentApprovalResourceDtls.getResPendingDeallocationApproval());
			approvalPendingResourceDtls
					.setResPendingOtherDeallocation(currentApprovalResourceDtls.getResPendingOtherDeallocation());
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_EXTENSION)
				&& currentApprovalResourceDtls != null) {
			approvalPendingResourceDtls
					.setResPendingExtensionApproval(currentApprovalResourceDtls.getResPendingExtensionApproval());
			approvalPendingResourceDtls
					.setResPendingOtherExtension(currentApprovalResourceDtls.getResPendingOtherExtension());
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_TRANSFER)
				&& currentApprovalResourceDtls != null) {
			approvalPendingResourceDtls
					.setResPendingTransferApproval(currentApprovalResourceDtls.getResPendingTransferApproval());
			approvalPendingResourceDtls
					.setResPendingOtherTransfer(currentApprovalResourceDtls.getResPendingOtherTransfer());
		}
	}

	/**
	 * Get list of resources pending for submission
	 * 
	 * @param userId
	 * @param roleId
	 * @param requestType
	 * @return
	 * @throws ResourceManagementException
	 */
	public ResourceApprovalDashboardDto getResourcesPendingForSubmission(Long userId, Long roleId,
			List<String> requestTypeList,HashBasedTable<String, String, Long> moduletable) throws ResourceManagementException {
		log.info("Entered into ResourceDashboardServiceImpl.getResourcesPendingForSubmission method:");
		ResourceApprovalDashboardDto submissionPendingResourceDtls = new ResourceApprovalDashboardDto();
		List<EmployeeDto> resPendingAllocationSubmission = null;
		List<EmployeeDto> resPendingDeallocationSubmission = null;
		for (String requestType : requestTypeList) {
			if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_ALLOCATION)) {
				resPendingAllocationSubmission = getListOfRMPendingAllocationSubmission(userId);
				submissionPendingResourceDtls.setResPendingAllocationSubmission(resPendingAllocationSubmission);
			}
			if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_DEALLOCATION)) {
				resPendingDeallocationSubmission = getpendingForDeallocationSubmission(userId,moduletable);
				submissionPendingResourceDtls.setResPendingDeallocationSubmission(resPendingDeallocationSubmission);
			} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_TRANSFER)) {
				submissionPendingResourceDtls
						.setResPendingTransferSubmission(getListOfRMPendingTransferSubmission(userId));
			}
		}  
		log.info("Just before leaving ResourceDashboardServiceImpl.getResourcesPendingForSubmission method:");
		return submissionPendingResourceDtls;
	}

	/**
	 * Get list of resources pending for allocation approval
	 * 
	 * @param userId
	 * @param roleId
	 * @param requestType
	 * @param allocStatusDtlsMap
	 * @return
	 * @throws ResourceManagementException
	 */
	public ResourceApprovalDashboardDto getPendingResourceDetailsForAlloc(long userId, long roleId, String requestType,
			long workflowTypeId, HashBasedTable<String, String, Long> moduletable) throws ResourceManagementException {
		log.info("Entered into  ResourceDashboardServiceImpl.getPendingResourceDetailsForAlloc method:");
//		String actionNames = ResourceManagementConstant.ACTIVE_ACTION + ","
//				+ ResourceManagementConstant.SUBMIT_ACTION_FOR_ALLOCATION;
//		Map<String, ModuleStatusDto> allocStatusDtlsMap = resourceManagementServiceImpl
//				.getModuleStatusDtlsMap(actionNames, ResourceManagementConstant.RESOURCE_ALLOCATION);
		Long statusId = moduletable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long submitStatusId = moduletable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.SUBMITTED);
		List<Long> activeUserTransactions = tAssociateAllocationRepository.getActiveUserTransactions(userId, roleId,
				workflowTypeId, statusId, submitStatusId);
		ResourceApprovalDashboardDto approvalPendingResourceDtlsForAlloc = null;
		List<EmployeeDto> allocResourceDtlList = null;
		if (CollectionUtils.isNotEmpty(activeUserTransactions)) {
			approvalPendingResourceDtlsForAlloc = new ResourceApprovalDashboardDto();
			Map<String, List<Long>> pendingTransactionsMap = getApprovalPendingTransactions(activeUserTransactions,
					workflowTypeId, userId, roleId, requestType);
			List<Long> pendingForApprovalTransactions = (pendingTransactionsMap
					.containsKey(ResourceManagementConstant.PENDING_FOR_APPROVAL))
							? pendingTransactionsMap.get(ResourceManagementConstant.PENDING_FOR_APPROVAL)
							: null;
			List<Long> pendingWithOthersTransactions = (pendingTransactionsMap
					.containsKey(ResourceManagementConstant.PENDING_WITH_OTHERS))
							? pendingTransactionsMap.get(ResourceManagementConstant.PENDING_WITH_OTHERS)
							: null;
			if (CollectionUtils.isNotEmpty(pendingForApprovalTransactions)) {
				List<AllocatedResourceProjection> employeeAllocationDetails = tAssociateAllocationRepository
						.getAssociatesByAllocationId(pendingForApprovalTransactions);
				allocResourceDtlList = setdatafordeallocation(employeeAllocationDetails);
					
				approvalPendingResourceDtlsForAlloc.setResPendingAllocationApproval(allocResourceDtlList);
			}
			if (CollectionUtils.isNotEmpty(pendingWithOthersTransactions)) {
				List<AllocatedResourceProjection> employeeAllocationDetails = tAssociateAllocationRepository
						.getAssociatesByAllocationId(pendingWithOthersTransactions);
				allocResourceDtlList = setdatafordeallocation(employeeAllocationDetails);
				approvalPendingResourceDtlsForAlloc.setResPendingOtherAllocation(allocResourceDtlList);
			}
		}
		log.info("Just before leaving ResourceDashboardServiceImpl.getPendingResourceDetailsForAlloc method:");
		return approvalPendingResourceDtlsForAlloc;
	}

	/**
	 * Get list of resources pending for transfer approval
	 * 
	 * @param userId
	 * @param roleId
	 * @param requestType
	 * @param allocStatusDtlsMap
	 * @return
	 * @throws ResourceManagementException
	 */
	public ResourceApprovalDashboardDto getPendingResourceDetailsForTransfer(long userId, long roleId,
			String requestType, long workflowTypeId) throws ResourceManagementException {
		log.info("Entered into  ResourceDashboardServiceImpl.getPendingResourceDetailsForTransfer method:");
		Long statusIdForActive = resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
			Long statusIdForSubmitted = resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SUBMITTED);
     	List<Long> activeUserTransactions = tAssociateAllocationRepository.getActiveUserTransactions(userId, roleId,
				workflowTypeId, statusIdForActive,
				statusIdForSubmitted);
		ResourceApprovalDashboardDto approvalPendingResourceDtlsForAlloc = null;
		if (CollectionUtils.isNotEmpty(activeUserTransactions)) {
			approvalPendingResourceDtlsForAlloc = new ResourceApprovalDashboardDto();
			Map<String, List<Long>> pendingTransactionsMap = getApprovalPendingTransactions(activeUserTransactions,
					workflowTypeId, userId, roleId, requestType);
			List<Long> pendingForTargetApprovalTransactions = (pendingTransactionsMap
					.containsKey(ResourceManagementConstant.PENDING_FOR_APPROVAL))
							? pendingTransactionsMap.get(ResourceManagementConstant.PENDING_FOR_APPROVAL)
							: null;
			List<Long> pendingWithOthersTargetTransactions = (pendingTransactionsMap
					.containsKey(ResourceManagementConstant.PENDING_WITH_OTHERS))
							? pendingTransactionsMap.get(ResourceManagementConstant.PENDING_WITH_OTHERS)
							: null;

			if (CollectionUtils.isNotEmpty(pendingForTargetApprovalTransactions))
				approvalPendingResourceDtlsForAlloc.setResPendingTransferApproval(
						getResourceDashboardTransferDto(pendingForTargetApprovalTransactions));
			if (CollectionUtils.isNotEmpty(pendingWithOthersTargetTransactions))
				approvalPendingResourceDtlsForAlloc.setResPendingOtherTransfer(
						getResourceDashboardTransferDto(pendingWithOthersTargetTransactions));
		}
		log.info("Just before leaving ResourceDashboardServiceImpl.getPendingResourceDetailsForTransfer method:");
		return approvalPendingResourceDtlsForAlloc;
	}

	public List<ResourceDashboardTransferDto> getResourceDashboardTransferDto(
			List<Long> tAssociateAllocationIdTargetList) throws ResourceManagementException {
		log.info("Start getResourceDashboardTransferDto");
		List<ResourceDashboardTransferDto> resourceDashboardTransferDtoApprovalList = null;
		List<AllocatedResourceProjection> sourceAndTargetDetailsList = tAssociateAllocationRepository
				.getSourceAndTargetOfAssociateByAllocationIdList(tAssociateAllocationIdTargetList);
		Map<Long, AllocatedResourceProjection> sourceAndTargetDetailsByAlloIdMap = sourceAndTargetDetailsList.stream()
				.collect(HashMap::new, (m, v) -> m.put(v.getAssociateAllocationId(), v), HashMap::putAll);

		if (CollectionUtils.isNotEmpty(tAssociateAllocationIdTargetList)) {
			resourceDashboardTransferDtoApprovalList = new ArrayList<>();
			for (long tAssociateTargetAlloId : tAssociateAllocationIdTargetList) {
				ResourceDashboardTransferDto resourceDashboardTransferDto = new ResourceDashboardTransferDto();

				AllocatedResourceProjection tAssociateSourceProjection = sourceAndTargetDetailsByAlloIdMap
						.get(sourceAndTargetDetailsByAlloIdMap.get(tAssociateTargetAlloId).getTransactionHistoryId());
				AllocatedResourceProjection tAssociateTargetProjection = sourceAndTargetDetailsByAlloIdMap
						.get(tAssociateTargetAlloId);

				resourceDashboardTransferDto
						.setTargetProjectEmployeeDto(setDataForTransfer(tAssociateTargetProjection, 0D));
				resourceDashboardTransferDto.setSourceProjectEmployeeDto(
						setDataForTransfer(tAssociateSourceProjection, tAssociateTargetProjection.getFtePercent()));
				resourceDashboardTransferDtoApprovalList.add(resourceDashboardTransferDto);
			}
		}

		log.info("End getResourceDashboardTransferDto");
		return resourceDashboardTransferDtoApprovalList;
	}

	/**
	 * Get list of resources pending for extension approval
	 * 
	 * @param userId
	 * @param roleId
	 * @param requestType
	 * @param allocExtStatusDtlsMap
	 * @return
	 * @throws ResourceManagementException
	 */
	public ResourceApprovalDashboardDto getPendingResourceDetailsForAllocExt(long userId, long roleId,
			String requestType, long workflowTypeId) throws ResourceManagementException {
		log.info("Entered into  ResourceDashboardServiceImpl.getPendingResourceDetailsForAllocExt method:");
		String actionNames = ResourceManagementConstant.ACTIVATE + ","
				+ ResourceManagementConstant.SUBMITTED + ","
				+ ResourceManagementConstant.APPROVED;
		String subActionNames = ResourceManagementConstant.RESOURCE_ALLOCATION + ","
				+ ResourceManagementConstant.RESOURCE_EXTENSION;

		List<ModuleStatusDto> allocExtStatusDtlsList = null;
		ResourceApprovalDashboardDto approvalPendingResourceDtlsForAllocExt = null;
		List<EmployeeDto> allocExtResourceDtlList = null;
		allocExtStatusDtlsList = resourceManagementServiceImpl.getModuleStatusDtlsList(actionNames, subActionNames);
		List<AllocatedResourceProjection> activeAllocationExtensionDtls = tAssociateExtensionRepository
				.getActiveAllocationExtensionDetails(userId, roleId, workflowTypeId,
						resourceManagementServiceImpl.getModuleStatusId(allocExtStatusDtlsList,
								ResourceManagementConstant.RESOURCE_ALLOCATION,
								ResourceManagementConstant.ACTIVATE),
						resourceManagementServiceImpl.getModuleStatusId(allocExtStatusDtlsList,
								ResourceManagementConstant.RESOURCE_EXTENSION,
								ResourceManagementConstant.SUBMITTED),
						resourceManagementServiceImpl.getModuleStatusId(allocExtStatusDtlsList,
								ResourceManagementConstant.RESOURCE_ALLOCATION,
								ResourceManagementConstant.APPROVED));
		if (CollectionUtils.isNotEmpty(activeAllocationExtensionDtls)) {
			List<Long> activeUserTransactions = activeAllocationExtensionDtls.stream()
					.map(AllocatedResourceProjection::getAssociateAllocationId).collect(Collectors.toList());
			if (CollectionUtils.isNotEmpty(activeUserTransactions)) {
				approvalPendingResourceDtlsForAllocExt = new ResourceApprovalDashboardDto();
				Map<String, List<Long>> pendingTransactionsMap = getApprovalPendingTransactions(activeUserTransactions,
						workflowTypeId, userId, roleId, requestType);
				List<Long> pendingForApprovalTransactions = (pendingTransactionsMap
						.containsKey(ResourceManagementConstant.PENDING_FOR_APPROVAL))
								? pendingTransactionsMap.get(ResourceManagementConstant.PENDING_FOR_APPROVAL)
								: null;
				List<Long> pendingWithOthersTransactions = (pendingTransactionsMap
						.containsKey(ResourceManagementConstant.PENDING_WITH_OTHERS))
								? pendingTransactionsMap.get(ResourceManagementConstant.PENDING_WITH_OTHERS)
								: null;
				if (CollectionUtils.isNotEmpty(pendingForApprovalTransactions)) {
					List<AllocatedResourceProjection> pendingForApprovalResAllocExtDtlsList = activeAllocationExtensionDtls
							.stream()
							.filter(activeUserTransDto -> pendingForApprovalTransactions.stream().anyMatch(
									transcId -> activeUserTransDto.getAssociateAllocationId().equals(transcId)))
							.collect(Collectors.toList());
					allocExtResourceDtlList = setEmployeeDataForAllocExt(pendingForApprovalResAllocExtDtlsList);
					approvalPendingResourceDtlsForAllocExt.setResPendingExtensionApproval(allocExtResourceDtlList);
				}
				if (CollectionUtils.isNotEmpty(pendingWithOthersTransactions)) {
					List<AllocatedResourceProjection> pendingWithOthersResAllocExtDtlsList = activeAllocationExtensionDtls
							.stream()
							.filter(activeUserTransDto -> pendingWithOthersTransactions.stream().anyMatch(
									transcId -> activeUserTransDto.getAssociateAllocationId().equals(transcId)))
							.collect(Collectors.toList());
					allocExtResourceDtlList = setEmployeeDataForAllocExt(pendingWithOthersResAllocExtDtlsList);
					approvalPendingResourceDtlsForAllocExt.setResPendingOtherExtension(allocExtResourceDtlList);
				}
			}
		}
		log.info("Just before leaving ResourceDashboardServiceImpl.getPendingResourceDetailsForAllocExt method:");
		return approvalPendingResourceDtlsForAllocExt;
	}

	/**
	 * Get list of resources pending for Deallocation approval
	 * 
	 * @param userId
	 * @param roleId
	 * @param requestType
	 * @return
	 * @throws ResourceManagementException
	 */
	public ResourceApprovalDashboardDto getPendingResourceDetailsForDeAlloc(long userId, long roleId,
			String requestType, long workflowTypeId,HashBasedTable<String, String, Long> moduletable) throws ResourceManagementException {
		log.info("Entered into  ResourceDashboardServiceImpl.getPendingResourceDetailsForDeAlloc method:");
         Long workFlowIdForDealloctionSaved =  moduletable.get(
					ResourceManagementConstant.RESOURCE_DEALLOCATION,
					ResourceManagementConstant.SUBMITTED);
		Long workFlowIdforAllocationApproved = moduletable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED);
		Long statusIdForAllocationApproved = moduletable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
		 String actionNames = ResourceManagementConstant.ACTIVATE + ","
	                + ResourceManagementConstant.APPROVED;
	        Map<String, ModuleStatusDto> workflowStatusDtlsMapforAllocaion = resourceManagementServiceImpl
	                .getModuleStatusDtlsMap(actionNames, ResourceManagementConstant.RESOURCE_DEALLOCATION);
		Long moduleIdForDeallocation =   workflowStatusDtlsMapforAllocaion
                .get(ResourceManagementConstant.APPROVED).getModuleId();
		List<Long> activeUserTransactions = tAssociateDeAllocationRepository.getDeallocationpendingForApprovalRecords(
				statusIdForAllocationApproved, workFlowIdforAllocationApproved, workFlowIdForDealloctionSaved, userId,
				roleId,moduleIdForDeallocation);
		List<EmployeeDto> deallocResourceDtlList = null;
		ResourceApprovalDashboardDto approvalPendingResourceDtlsForDeAlloc = null;
		log.info("activeUserTransactions:" + activeUserTransactions); 
		if (CollectionUtils.isNotEmpty(activeUserTransactions)) {
			approvalPendingResourceDtlsForDeAlloc = new ResourceApprovalDashboardDto();
			Map<String, List<Long>> pendingTransactionsMap = getApprovalPendingTransactions(activeUserTransactions,
					workflowTypeId, userId, roleId, requestType);
			List<Long> pendingForApprovalTransactions = (pendingTransactionsMap
					.containsKey(ResourceManagementConstant.PENDING_FOR_APPROVAL))
							? pendingTransactionsMap.get(ResourceManagementConstant.PENDING_FOR_APPROVAL)
							: null;
			List<Long> pendingWithOthersTransactions = (pendingTransactionsMap
					.containsKey(ResourceManagementConstant.PENDING_WITH_OTHERS))
							? pendingTransactionsMap.get(ResourceManagementConstant.PENDING_WITH_OTHERS)
							: null;
			if (CollectionUtils.isNotEmpty(pendingForApprovalTransactions)) {
				List<AllocatedResourceProjection> deallocationPendingList = tAssociateDeAllocationRepository
						.getDeallocationApprovalListPendingData(pendingForApprovalTransactions);
				deallocResourceDtlList = setdatafordeallocation(deallocationPendingList);
				approvalPendingResourceDtlsForDeAlloc.setResPendingDeallocationApproval(deallocResourceDtlList);
			}
			if (CollectionUtils.isNotEmpty(pendingWithOthersTransactions)) {
				List<AllocatedResourceProjection> deallocationPendingList = tAssociateDeAllocationRepository
						.getDeallocationApprovalListPendingData(pendingWithOthersTransactions);
				deallocResourceDtlList = setdatafordeallocation(deallocationPendingList);
				approvalPendingResourceDtlsForDeAlloc.setResPendingOtherDeallocation(deallocResourceDtlList);
			}
		}
		log.info("Just before leaving ResourceDashboardServiceImpl.getPendingResourceDetailsForDeAlloc method:");
		return approvalPendingResourceDtlsForDeAlloc;
	}

//	/**
//	 * prepares map that contains list of statuses that needs to check for each
//	 * approver
//	 * 
//	 * @param requestType alias submodule name
//	 * @return
//	 * @throws ResourceManagementException
//	 */
//	public Map<String, List<Long>> getApproverStatusCheckListMap(String requestType)
//			throws ResourceManagementException {
//		log.info("Entered into ResourceDashboardServiceImpl.getApproverStatusCheckListMap method:");
//		String submitActionName = null;
//		List<Long> previousApproverStatusCheckList = new ArrayList<>();
//		List<Long> nextApproverStatusCheckList = new ArrayList<>();
//		Map<String, List<Long>> approverStatusCheckDtlsMap = new HashMap<>();
//		if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_ALLOCATION)) {
//			submitActionName = ResourceManagementConstant.SUBMIT_ACTION_FOR_ALLOCATION;
//		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_DEALLOCATION)) {
//			submitActionName = ResourceManagementConstant.SUBMIT_ACTION_FOR_DEALLOCATION;
//		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_EXTENSION)) {
//			submitActionName = ResourceManagementConstant.SUBMIT_ACTION_FOR_EXTENSION;
//		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_TRANSFER)) {
//			submitActionName = ResourceManagementConstant.SUBMIT_ACTION_FOR_TRANSFER;
//		}
//		String actionNames = ResourceManagementConstant.APPROVED_ACTION + ","
//				+ ResourceManagementConstant.REJECTED_ACTION + "," + submitActionName;
//		Map<String, ModuleStatusDto> workflowStatusDtlsMap = resourceManagementServiceImpl
//				.getModuleStatusDtlsMap(actionNames, requestType);
//		previousApproverStatusCheckList.add(workflowStatusDtlsMap.get(submitActionName).getModuleId());
//		previousApproverStatusCheckList
//				.add(workflowStatusDtlsMap.get(ResourceManagementConstant.APPROVED_ACTION).getModuleId());
//		nextApproverStatusCheckList
//				.add(workflowStatusDtlsMap.get(ResourceManagementConstant.REJECTED_ACTION).getModuleId());
//		nextApproverStatusCheckList.add(0L);
//		approverStatusCheckDtlsMap.put(ResourceManagementConstant.PREVIOUS_APPROVER_STATUS_CHECK_CONSTANT,
//				previousApproverStatusCheckList);
//		approverStatusCheckDtlsMap.put(ResourceManagementConstant.NEXT_APPROVER_STATUC_CHECK_CONSTANT,
//				nextApproverStatusCheckList);
//		log.info("Just before leaving ResourceDashboardServiceImpl.getApproverStatusCheckListMap method:");
//		return approverStatusCheckDtlsMap;
//	}

	/**
	 * prepares map that contains list of statuses that needs to check for each
	 * approver
	 *
	 * @param requestType alias submodule name
	 * @return
	 * @throws ResourceManagementException
	 */
	public Map<String, List<Long>> getApproverStatusCheckListMap(String requestType)
			throws ResourceManagementException {
		log.info("Entered into ResourceDashboardServiceImpl.getApproverStatusCheckListMap method:");
		String submitActionName = null;
		List<Long> previousApproverStatusCheckList = new ArrayList<>();
		List<Long> nextApproverStatusCheckList = new ArrayList<>();
		Map<String, List<Long>> approverStatusCheckDtlsMap = new HashMap<>();
		if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_ALLOCATION)) {
			submitActionName = ResourceManagementConstant.SUBMITTED;
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_DEALLOCATION)) {
			submitActionName = ResourceManagementConstant.SUBMITTED;
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_EXTENSION)) {
			submitActionName = ResourceManagementConstant.SUBMITTED;
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_TRANSFER)) {
			submitActionName = ResourceManagementConstant.SUBMITTED;
		}
		HashBasedTable<String, String, Long> moduletable = getModuleDta();  

		Long previousId1 = moduletable.get(requestType, ResourceManagementConstant.APPROVED);
		Long previousId2 = moduletable.get(requestType, ResourceManagementConstant.REJECTED);
		Long previousId3 = moduletable.get(requestType, submitActionName);

		previousApproverStatusCheckList.add(previousId3);
		previousApproverStatusCheckList.add(previousId1);
		nextApproverStatusCheckList.add(previousId2);
		nextApproverStatusCheckList.add(0L);
		approverStatusCheckDtlsMap.put(ResourceManagementConstant.PREVIOUS_APPROVER_STATUS_CHECK_CONSTANT,
				previousApproverStatusCheckList);
		approverStatusCheckDtlsMap.put(ResourceManagementConstant.NEXT_APPROVER_STATUC_CHECK_CONSTANT,
				nextApproverStatusCheckList);
		log.info("Just before leaving ResourceDashboardServiceImpl.getApproverStatusCheckListMap method:");
		return approverStatusCheckDtlsMap;
	} 

	/**
	 * Get list of pending transactions for approval
	 * 
	 * @param userId
	 * @param roleId
	 * @param requestType
	 * @param activeUserTransactions
	 * @return
	 * @throws ResourceManagementException
	 */
	public Map<String, List<Long>> getApprovalPendingTransactions(List<Long> activeUserTransactions,
			long workflowTypeId, long userId, long roleId, String requestType) throws ResourceManagementException {
		log.info("Entered into ResourceDashboardServiceImpl.getApprovalPendingTransactions method:");
		Map<String, List<Long>> approverStatusCheckDtlsMap = getApproverStatusCheckListMap(requestType);
		List<Long> pendingUserTransactions = new ArrayList<>();
		List<Long> pendingWithOtherUserTransactions = new ArrayList<>();
		List<Date> approverStatusUpdateDateList = null;
		Map<String, List<Long>> pendingTransactionDtlsMap = new HashMap<>();
		boolean prevApproverStatusCheck;
		boolean nextApprvrStatusAndCrrntApprvrDateCheck;
		for (Long transcId : activeUserTransactions) {
			approverStatusUpdateDateList = new ArrayList<>();
			prevApproverStatusCheck = getPreviousApproverStatusCheckResult(approverStatusUpdateDateList, transcId,
					userId, roleId, workflowTypeId, approverStatusCheckDtlsMap);
			if (prevApproverStatusCheck) {
				nextApprvrStatusAndCrrntApprvrDateCheck = getNextApprvrStatusAndCrrntApprvrDateCheckResult(
						approverStatusUpdateDateList, transcId, userId, roleId, workflowTypeId,
						approverStatusCheckDtlsMap, requestType);
				if (nextApprvrStatusAndCrrntApprvrDateCheck)
					pendingUserTransactions.add(transcId);
				else
					pendingWithOtherUserTransactions.add(transcId);
			} else {
				pendingWithOtherUserTransactions.add(transcId);
			}
		}
		log.info("pendingUserTransactions" + pendingUserTransactions);
		log.info("pendingWithOtherUserTransactions" + pendingWithOtherUserTransactions);
		pendingTransactionDtlsMap.put(ResourceManagementConstant.PENDING_FOR_APPROVAL, pendingUserTransactions);
		pendingTransactionDtlsMap.put(ResourceManagementConstant.PENDING_WITH_OTHERS, pendingWithOtherUserTransactions);
		log.info("Just before leaving ResourceDashboardServiceImpl.getApprovalPendingTransactions method:");
		return pendingTransactionDtlsMap;
	}

	/**
	 * verifies previous approver status check
	 * 
	 * @param userId
	 * @param roleId
	 * @param requestType
	 * @param approverStatusCheckDtlsMap
	 * @return
	 * @throws ResourceManagementException
	 */
	public boolean getPreviousApproverStatusCheckResult(List<Date> approverStatusUpdateDateList, long transactionId,
			long userId, long roleId, long workflowTypeId, Map<String, List<Long>> approverStatusCheckDtlsMap)
			throws ResourceManagementException {
		ResourceWorkflow prevApproverData = null;
		ResourceWorkflow prevApproverStatus = null;
		prevApproverData = resourceWorkflowRepository.getPreviousRowData(transactionId, userId, roleId);
		boolean prevApproverStatusCheck = true;
		if (prevApproverData != null) {
			log.info("Previous Approver Exists");
			prevApproverStatus = resourceWorkflowRepository.getRecentPreviousRowData(transactionId, workflowTypeId,
					userId, roleId,
					approverStatusCheckDtlsMap.get(ResourceManagementConstant.PREVIOUS_APPROVER_STATUS_CHECK_CONSTANT));
			if (prevApproverStatus != null)
				approverStatusUpdateDateList.add(prevApproverStatus.getLastUpdatedDate());
			else
				prevApproverStatusCheck = false;
		}
		return prevApproverStatusCheck;
	}

	/**
	 * verifies next approver status check and current approver date check
	 * 
	 * @param userId
	 * @param roleId
	 * @param requestType
	 * @param approverStatusCheckDtlsMap
	 * @return
	 * @throws ResourceManagementException
	 **/
	public boolean getNextApprvrStatusAndCrrntApprvrDateCheckResult(List<Date> approverStatusUpdateDateList,
			long transactionId, long userId, long roleId, long workflowTypeId,
			Map<String, List<Long>> approverStatusCheckDtlsMap, String requestType) throws ResourceManagementException {
		log.info("approverStatusUpdateDateList"+approverStatusUpdateDateList+"transactionId "+transactionId+"userId "+userId+"roleId "+roleId+  " workflowTypeId "+workflowTypeId);
		ResourceWorkflow currentApproverData = null;
		ResourceWorkflow nextApproverStatus = null;
		currentApproverData = resourceWorkflowRepository.getRecentRowData(transactionId, workflowTypeId, userId,
				roleId);
		boolean nextApprvrStatusAndCrrntApprvrDateCheck = true;
		if (currentApproverData != null) {
			approverStatusUpdateDateList.add(currentApproverData.getLastUpdatedDate());
			if (currentApproverData.getNextUserId() > 0 && currentApproverData.getNextRoleId() > 0) {
				log.info("Next Approver Exists");
				nextApproverStatus = resourceWorkflowRepository.getRecentNextRowData(transactionId, workflowTypeId,
						currentApproverData.getNextUserId(), currentApproverData.getNextRoleId(),
						approverStatusCheckDtlsMap.get(ResourceManagementConstant.NEXT_APPROVER_STATUC_CHECK_CONSTANT));
				if (nextApproverStatus != null)
					approverStatusUpdateDateList.add(nextApproverStatus.getLastUpdatedDate());
				else {
					if (currentApproverData.getCurrentRoleId() != currentApproverData.getNextRoleId()) {
						nextApprvrStatusAndCrrntApprvrDateCheck = false;
					}
				}
			}
			if (CollectionUtils.isNotEmpty(approverStatusUpdateDateList)
					&& (currentApproverData.getLastUpdatedDate() == (approverStatusUpdateDateList.stream()
							.filter(Objects::nonNull).max(Date::compareTo).get())))
				nextApprvrStatusAndCrrntApprvrDateCheck = false;
			if (currentApproverData.getCurrentRoleId().equals(currentApproverData.getNextRoleId()) ) {
				if (currentApproverData.getCurrentUserId().equals(currentApproverData.getNextUserId()) ) {
					if(requestType=="RESOURCE_TRANSFER")
						nextApprvrStatusAndCrrntApprvrDateCheck = true;
					else {
						nextApprvrStatusAndCrrntApprvrDateCheck = false;
					}
				}
				//nextApprvrStatusAndCrrntApprvrDateCheck = true;
			}
		}
		return nextApprvrStatusAndCrrntApprvrDateCheck;
	}

	private List<EmployeeDto> setdatafordeallocation(List<AllocatedResourceProjection> deallocationPendingList)
			throws ResourceManagementException {
		Map<Long, AllocatedResourceProjection> deallocationPendingListMap = deallocationPendingList.stream()
				.collect(Collectors.toMap(AllocatedResourceProjection::getAssociateAllocationId,
						allocatedResourceProjection -> allocatedResourceProjection));
		List<EmployeeDto> newEmployeeList = new ArrayList<>();
		List<Long> allocationIds = deallocationPendingList.stream()
				.map(AllocatedResourceProjection::getAssociateAllocationId).collect(Collectors.toList());
		List<AllocatedResourceProjection> resourceAllocationData = tAssociateAllocationRepository
				.getAssociatesByAllocationId(allocationIds);
		Map<Long, ResourceRequirementDto> resourceRequirmentMap = getRequirementMap(resourceAllocationData);
		Map<Long, ProjectDto> projectMap = getProjectMap(resourceAllocationData);
		List<ReasonForDeallocation> reasonForDeallocation = adminServiceClient.getReasonForDeallocation();
		Map<Long ,String> deallocationReasonMap = reasonForDeallocation.stream().collect(HashMap::new,
				(m, v) -> m.put(v.getReasonId(), v.getReason()), HashMap::putAll);
//		Map<Long, EmployeeDto> employeeMap = getPractiseDetails(resourceAllocationData);
		
		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList = adminServiceClient.getLookuIdByTypeAndDescrList(
				ResourceManagementConstant.RESOURCE_BILLABLE_TYPE,
				List.of(ResourceManagementConstant.Billable, ResourceManagementConstant.Ebr,
						ResourceManagementConstant.Non_Billable, ResourceManagementConstant.InTransit,
						ResourceManagementConstant.POOL));
		
		Map<Long, String> lookupDescToIdMap = lookuIdByTypeAndDescrList.stream().collect(Collectors
				.toMap(LookupValueAndDescDto::getLookupValueId,LookupValueAndDescDto::getLookupValueDescr));

		for (AllocatedResourceProjection listofDeallocationPendingResource : resourceAllocationData) {
			EmployeeDto empDto = new EmployeeDto();
			empDto = adminServiceClient.getEmployeeDetailsByEmpId(listofDeallocationPendingResource.getEmployeeId());
			empDto.setAssociateAllocationId(listofDeallocationPendingResource.getAssociateAllocationId());
			empDto.setEmployeeId(listofDeallocationPendingResource.getEmployeeId());
			empDto.setEmployeeNumber(empDto.getEmployeeNumber());
			empDto.setProjectId(listofDeallocationPendingResource.getProjectId());
			empDto.setProjectCode(projectMap.get(listofDeallocationPendingResource.getProjectId()).getProjectCode());
			empDto.setFte_percent(listofDeallocationPendingResource.getFtePercent());
			empDto.setActualAllocationDate(listofDeallocationPendingResource.getActualStartDate());
			empDto.setRequirementId(listofDeallocationPendingResource.getRequirementId());
			empDto.setComments(listofDeallocationPendingResource.getcomments());
			if(null != listofDeallocationPendingResource.getBillableStatusId() ) 
				empDto.setBillingStatus(lookupDescToIdMap.get(Long.valueOf(listofDeallocationPendingResource.getBillableStatusId())));
			if(listofDeallocationPendingResource.getIsPrimaryProject()) {
				empDto.setPrimaryProjectStatusField("YES");
			} else {
				empDto.setPrimaryProjectStatusField("NO");
			}
			empDto.setEstimatedEndDate(listofDeallocationPendingResource.getEstEndDate());
			empDto.setEmployeeName(empDto.getEmployeeName());
			if (!deallocationPendingListMap.isEmpty()) {
				AllocatedResourceProjection deallocationData = deallocationPendingListMap
						.get(listofDeallocationPendingResource.getAssociateAllocationId());
			//	empDto.setEstimatedEndDate(deallocationData.getEstEndDate());
				empDto.setDateOfDeallocation(deallocationData.getDeallocationDate());
				empDto.setAssociateDeAllocationId(deallocationData.getAssociateDeAllocationId());
				Long resonForDeallocId = deallocationData.getReasonForDeallocationId();
				if (resonForDeallocId != null)
				{
					String deallocReason = deallocationReasonMap.get(deallocationData.getReasonForDeallocationId());
					empDto.setReasonForDeallocation(deallocReason);
				}

			}
			setProjectName(projectMap, listofDeallocationPendingResource, empDto);
//			setEmployeeName(employeeMap, listofDeallocationPendingResource, empDto);
			setLocation(resourceRequirmentMap, listofDeallocationPendingResource, empDto);
			setVersion(resourceRequirmentMap, listofDeallocationPendingResource, empDto);
			setRole(resourceRequirmentMap, listofDeallocationPendingResource, empDto);

			newEmployeeList.add(empDto);
		}
		return newEmployeeList;
	}

	private void setLocation(Map<Long, ResourceRequirementDto> resourceRequirmentMap,
			AllocatedResourceProjection listofDeallocationPendingResource, EmployeeDto empDto) {
		if (!resourceRequirmentMap.isEmpty()) {
			Long requirementId = listofDeallocationPendingResource.getRequirementId();
			if (null != requirementId) {
				empDto.setEmployeeLocation(resourceRequirmentMap.get(requirementId).getResourceRequirementLocation());
			}
		}
	}

	private void setVersion(Map<Long, ResourceRequirementDto> resourceRequirmentMap,
			AllocatedResourceProjection listofDeallocationPendingResource, EmployeeDto empDto) {
		if (!resourceRequirmentMap.isEmpty()) {
			Long requirementId = listofDeallocationPendingResource.getRequirementId();
			if (null != requirementId) {
				empDto.setVersion(resourceRequirmentMap.get(requirementId).getVersion());
			}
		}
	}

	private void setRole(Map<Long, ResourceRequirementDto> resourceRequirmentMap,
			AllocatedResourceProjection listofDeallocationPendingResource, EmployeeDto empDto) {
		if (!resourceRequirmentMap.isEmpty()) {
			Long requirementId = listofDeallocationPendingResource.getRequirementId();
			if (null != requirementId) {
				empDto.setRole(resourceRequirmentMap.get(requirementId).getRequirementRole());
			}
		}
	}

	private void setEbrReason(AllocatedResourceProjection allocatedResourceProjection, EmployeeDto empDto)
			throws ResourceManagementException {
		Integer ebrReasonId = allocatedResourceProjection.getebrReason();
		if (null != ebrReasonId) {
			empDto.setEbrReason(adminServiceClient.getLookUpById(ebrReasonId).getLookupType());
		}
	}

	private void setEmployeeName(Map<Long, EmployeeDto> employeeMap,
			AllocatedResourceProjection listofDeallocationPendingResource, EmployeeDto empDto) {
		empDto.setPrimaryProjectStatusId(listofDeallocationPendingResource.getIsPrimaryProject());
		if (!employeeMap.isEmpty()) {
			Long empId = listofDeallocationPendingResource.getEmployeeId();
			if (null != empId) {
				empDto.setEmployeeName(employeeMap.get(empId).getEmployeeName());
				empDto.setEmployeeNumber(employeeMap.get(empId).getEmployeeNumber());
				empDto.setBand(employeeMap.get(empId).getBand());
			}

		}
	}

	private void setProjectName(Map<Long, ProjectDto> projectMap,
			AllocatedResourceProjection listofDeallocationPendingResource, EmployeeDto empDto) {
		if (!projectMap.isEmpty()) {
			Long projectId = listofDeallocationPendingResource.getProjectId();
			if (null != projectId) {
				empDto.setProjectId(projectId);
				empDto.setProjectName(projectMap.get(projectId).getProjectName());
				empDto.setProjectCode(projectMap.get(projectId).getProjectCode());

			}
		}
	}

	private Map<Long, ProjectDto> getProjectMap(List<AllocatedResourceProjection> employeeAllocationDetails)
			throws ResourceManagementException {
		List<Long> projectIds = employeeAllocationDetails.stream().map(AllocatedResourceProjection::getProjectId)
				.collect(Collectors.toList());
		List<ProjectDto> projectList = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(projectIds)) {
			projectList = bapServiceClient.getProjectDetailByIds(projectIds);
		}

		return projectList.stream().collect(Collectors.toMap(ProjectDto::getProjectId, projectDto -> projectDto));
	}

	private Map<Long, ResourceRequirementDto> getRequirementMap(
			List<AllocatedResourceProjection> employeeAllocationDetails) throws ResourceManagementException {
		List<Long> reqIds = employeeAllocationDetails.stream().map(AllocatedResourceProjection::getRequirementId)
				.collect(Collectors.toList());
		List<ResourceRequirementDto> requirementDetails = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(reqIds)) {
			requirementDetails = bapServiceClient.getResourceRequiremetList(reqIds);
		}
		return requirementDetails.stream().collect(
				Collectors.toMap(ResourceRequirementDto::getReqId, resourceRequirementDto -> resourceRequirementDto));
	}

	Map<Long, EmployeeDto> getPractiseDetails(List<AllocatedResourceProjection> associateList)
			throws ResourceManagementException {
		List<Long> empIds = associateList.stream().map(AllocatedResourceProjection::getEmployeeId)
				.collect(Collectors.toList());
		List<Long> empNumbers = tAssociateAllocationRepository.getEmployeeNumbers(empIds);
		List<EmployeeDto> practiseDetails = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(empNumbers)) {
			practiseDetails = adminServiceClient.getAssociatesDetails(empNumbers);
		}
		for(EmployeeDto p:practiseDetails) {
			System.out.println("AAAAAAAAA" + p.getEmployeeName() + "   " + p.getBand());
		}
		return practiseDetails.stream()
				.collect(Collectors.toMap(EmployeeDto::getEmployeeId, employeemap -> employeemap));

	}

	public List<EmployeeDto> getpendingForDeallocationSubmission(Long userId,HashBasedTable<String, String, Long> moduletable) throws ResourceManagementException {
		List<Long> employeeIds = tAssociateAllocationRepository.getEmployeeIds(List.of(userId));

		Long workFlowIdForDealloctionSaved = moduletable.get(ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.SAVED);
		Long workFlowIdforAllocationApproved = moduletable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
				Long statusIdForAllocationApproved = moduletable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED);
		Long workflowStausIdForDeallocationDeactive = moduletable.get(ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.DEACTIVATE);
	     List<AllocatedResourceProjection> pendingListForDeallocationSubmission = tAssociateDeAllocationRepository
				.getDeallocationPendingForSubmissionData(workFlowIdforAllocationApproved,statusIdForAllocationApproved,
						employeeIds.get(0), workFlowIdForDealloctionSaved,workflowStausIdForDeallocationDeactive);
		return setDataforPendingForSubmission(pendingListForDeallocationSubmission);
	}

	public List<EmployeeDto> setEmployeeDataForAllocExt(
			List<AllocatedResourceProjection> resourceAllocExtensionDtlsList) throws ResourceManagementException {
		List<EmployeeDto> employeeDtlsList = null;
		if (CollectionUtils.isNotEmpty(resourceAllocExtensionDtlsList)) {
			employeeDtlsList = new ArrayList<>();
			Map<Long, ProjectDto> projectMap = getProjectMap(resourceAllocExtensionDtlsList);
			Map<Long, EmployeeDto> employeeMap = getPractiseDetails(resourceAllocExtensionDtlsList);
			EmployeeDto employeeDtls = null;
			for (AllocatedResourceProjection resourceAllocExtDtls : resourceAllocExtensionDtlsList) {
				employeeDtls = new EmployeeDto();
				employeeDtls.setRequirementId(resourceAllocExtDtls.getRequirementId());
				employeeDtls.setEmployeeId(resourceAllocExtDtls.getEmployeeId());
				employeeDtls.setAssociateAllocationId(resourceAllocExtDtls.getAssociateAllocationId());
				employeeDtls.setAssociateProjectId(resourceAllocExtDtls.getProjectId());
				employeeDtls.setEstimatedEndDate(resourceAllocExtDtls.getEstEndDate());
				employeeDtls.setEstimatedExtendedEndDate(resourceAllocExtDtls.getExtEstEndDate());
				setProjectName(projectMap, resourceAllocExtDtls, employeeDtls);
				setEmployeeName(employeeMap, resourceAllocExtDtls, employeeDtls);
				employeeDtlsList.add(employeeDtls);
			}
		}
		return employeeDtlsList;
	}

	private EmployeeDto setDataForTransfer(AllocatedResourceProjection allocationPending, Double ftePercentage)
			throws ResourceManagementException {

		EmployeeDto empDto = new EmployeeDto();
		empDto.setAssociateAllocationId(allocationPending.getAssociateAllocationId());
		empDto.setEmployeeId(allocationPending.getEmployeeId());
		empDto.setProjectId(allocationPending.getProjectId());
		empDto.setFte_percent(allocationPending.getFtePercent() - ftePercentage);
        empDto.setProjectUtilization(allocationPending.getFtePercent() - ftePercentage);
		empDto.setActualAllocationDate(allocationPending.getActualStartDate());
		empDto.setRequirementId(allocationPending.getRequirementId());
		empDto.setPrimaryProjectStatusId(allocationPending.getIsPrimaryProject());
		empDto.setEstimatedEndDate(allocationPending.getEstEndDate());
		empDto.setComments(allocationPending.getcomments());
		empDto.setRequestReceivedOn(allocationPending.getRequestReceivedOn());
		if (ftePercentage == 0L) {
			empDto.setApprovedReleaseDate(null);
			empDto.setActualAllocationDate(allocationPending.getActualStartDate());
			empDto.setToBeAllocatedFrom(allocationPending.getActualStartDate());
		} else {  
			empDto.setApprovedReleaseDate(allocationPending.getReleaseDate());
			empDto.setActualAllocationDate(allocationPending.getActualStartDate());
		}
		Map<Long, ProjectDto> projectMap = getProjectMap(List.of(allocationPending));
		Map<Long, ResourceRequirementDto> resourceRequirmentMap = getRequirementMap(List.of(allocationPending));
		Map<Long, EmployeeDto> employeeMap = getPractiseDetails(List.of(allocationPending));

		setProjectName(projectMap, allocationPending, empDto);
		setEmployeeName(employeeMap, allocationPending, empDto);
		setLocation(resourceRequirmentMap, allocationPending, empDto);
		setVersion(resourceRequirmentMap, allocationPending, empDto);
		setRole(resourceRequirmentMap, allocationPending, empDto);
		setEbrReason(allocationPending, empDto);

		return empDto;
	}

	public List<EmployeeDto> getListOfRMPendingAllocationSubmission(Long userId) throws ResourceManagementException {
		log.info("Start getListOfRMPendingAllocationSubmission");
		List<Long> employeeIds = tAssociateAllocationRepository.getEmployeeIds(List.of(userId));

		ModuleStatusDto workflowStatusSaved = adminServiceClient.getModuleStatus(
				ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.SAVED);

		ModuleStatusDto statusDto = adminServiceClient.getModuleStatus(ResourceManagementConstant.RESOURCE_MANAGEMENT,
				ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);

		List<AllocatedResourceProjection> employeeAllocationDetails = tAssociateAllocationRepository
				.getPendingResourceSubmit(workflowStatusSaved.getModuleStatusId(), employeeIds.get(0), statusDto.getModuleStatusId());
		return setDataforPendingForSubmission(employeeAllocationDetails);
	}

	@Override
	@Transactional(readOnly = true)
	public TraceabilityDto getRMPendingTraceability(Long userId, Long roleId, Long allocationId,String requestType)
			throws ResourceManagementException {
		log.info("Entered into ResourceDashboardServiceImpl.getRMPendingTraceability method:");
		TraceabilityDto traceabilityDto = null;
		Set<Long> employeeIds = new HashSet<>();
		//List<RoleDto> listOfRoles = adminServiceClient.getListOfRoles();
		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList = adminServiceClient.getLookuIdByTypeAndDescrList(ResourceManagementConstant.ROLE_TYPE, List.of(ResourceManagementConstant.PROJECT_MANAGER,ResourceManagementConstant.PROGRAM_MANAGER,ResourceManagementConstant.TAG_TEAM));
		Map<Long, String> roleMap = lookuIdByTypeAndDescrList.stream()
				.collect(Collectors.toMap(LookupValueAndDescDto::getLookupValueId, LookupValueAndDescDto::getLookupValueDescr));
		
		TAssociateAllocation allocationByAllocationId = tAssociateAllocationRepository.getAllocationByAllocationId(allocationId);

		Map<Long, String> moduleStatusMap = getModuleStatusMap();
		List<ApprovalTraceabilityProjection> findByWrkflwTrnsctnId = null;
		if(requestType.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE) ||
				requestType.equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
			findByWrkflwTrnsctnId = resourceWorkflowRepository.getAllocationTraceAbilityDetails(allocationId);
		}
		else if(requestType.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE)) {
			findByWrkflwTrnsctnId = resourceWorkflowRepository.getDeAllocationTraceAbilityDetails(allocationId);
		}
		else if(requestType.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)) {
			findByWrkflwTrnsctnId = resourceWorkflowRepository.getExtensionTraceAbilityDetails(allocationId);
		}
		
		if(findByWrkflwTrnsctnId!=null && !findByWrkflwTrnsctnId.isEmpty()) {
			List<EmployeeDto> associatesDetailsbyEmpIds = adminServiceClient.getAssociatesDetailsbyEmpIds(List.of(findByWrkflwTrnsctnId.get(0).getEmployeeId()));
			employeeIds.add(associatesDetailsbyEmpIds.get(0).getEmployeeNumber());
			if (!CollectionUtils.isEmpty(findByWrkflwTrnsctnId)) {
				for (ApprovalTraceabilityProjection traceability : findByWrkflwTrnsctnId) {
					employeeIds.add(traceability.getCurrentUserId());
				}
				List<Long> empIds = new ArrayList<>(employeeIds);
				List<EmployeeDto> employeeList = adminServiceClient.getAssociatesDetails(empIds);
				Map<Long, String> userNameMap = employeeList.stream()
						.collect(Collectors.toMap(EmployeeDto::getEmployeeNumber, EmployeeDto::getEmployeeName));

				traceabilityDto = createTraceabilityObject(findByWrkflwTrnsctnId, userNameMap, roleMap, moduleStatusMap,
						userId, roleId,associatesDetailsbyEmpIds.get(0).getEmployeeName(),allocationByAllocationId,requestType);
			}
		}else
			throw new ResourceManagementException(ResourceManagementConstant.TRACEBILITY_MSG);	//Added by Shubham to throw exception when employee is pending for submission
		log.info("Entered into ResourceDashboardServiceImpl.getRMPendingTraceability method:");
		return traceabilityDto;
	}

	public Map<Long, String> getModuleStatusMap() throws ResourceManagementException {
		List<String> subModuleList = new ArrayList<>();
		subModuleList.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		subModuleList.add(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		subModuleList.add(ResourceManagementConstant.RESOURCE_TRANSFER);
		subModuleList.add(ResourceManagementConstant.RESOURCE_EXTENSION);

		List<String> actionList = new ArrayList<>();
		actionList.add(ResourceManagementConstant.SUBMITTED);
		actionList.add(ResourceManagementConstant.APPROVED);
		actionList.add(ResourceManagementConstant.REJECTED);
		List<ModuleStatusDto> moduleStatusList = adminServiceClient
				.getModuleStatusList(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModuleList, actionList);

		return moduleStatusList.stream()
				.collect(Collectors.toMap(ModuleStatusDto::getModuleStatusId, ModuleStatusDto::getAction));
	}

	public List<ResourceDashboardTransferDto> getListOfRMPendingTransferSubmission(Long userId)
			throws ResourceManagementException {
		List<Long> employeeIds = tAssociateAllocationRepository.getEmployeeIds(List.of(userId));
		Long statusIdForActive = resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
		Long wfStatusIdForSaved = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SAVED);
		List<TAssociateAllocation> tAssociateAllocationList = tAssociateAllocationRepository
				.getListOfRMPendingTransferSubmission(wfStatusIdForSaved, statusIdForActive, employeeIds.get(0));
		List<Long> tAssociateAllocationIdList = tAssociateAllocationList.stream()
				.map(TAssociateAllocation::getAssociateAllocationId).collect(Collectors.toList());
		return getResourceDashboardTransferDto(tAssociateAllocationIdList);
	}

	public TraceabilityDto createTraceabilityObject(List<ApprovalTraceabilityProjection> findByWrkflwTrnsctnId,
			Map<Long, String> userNameMap, Map<Long, String> roleMap, Map<Long, String> moduleStatusMap, Long userId,
			Long roleId,String employeeName,TAssociateAllocation allocation,String requestType) throws ResourceManagementException {
		TraceabilityDto traceabilityDto = new TraceabilityDto();
		List<TraceabilityApprSummaryDto> traceabilityApprSummaryDtoList = new ArrayList<>();
		List<TraceabilityCurrentStatusDto> traceabilityCurrentStatusDtoList = new ArrayList<>();
		TraceabilityApprSummaryDto apprSummaryDto = null;
		TraceabilityCurrentStatusDto currentStatusDto = null;

		for (ApprovalTraceabilityProjection workflow : findByWrkflwTrnsctnId) {
			String action = moduleStatusMap.get(workflow.getStatusId());
			if (workflow.getStatusId() == 0 || action==null
					|| action.equalsIgnoreCase(ResourceManagementConstant.PENDING_ALLOCATION_APPROVAL)
					|| action.equalsIgnoreCase(ResourceManagementConstant.PENDING_DEALLOCATION_APPROVAL)
					|| action.equalsIgnoreCase(ResourceManagementConstant.PENDING_TRANSFER_APPROVAL)
					|| action.equalsIgnoreCase(ResourceManagementConstant.PENDING_EXTENSION_APPROVAL)) {
				currentStatusDto = new TraceabilityCurrentStatusDto();
				currentStatusDto.setApproverEmpId(workflow.getCurrentUserId());
				if(roleMap.get(workflow.getCurrentRoleId()).equalsIgnoreCase("TAG TEAM"))
					currentStatusDto.setApproverName("TAG TEAM");
				else
					currentStatusDto.setApproverName(userNameMap.get(workflow.getCurrentUserId()));
				currentStatusDto.setRoleName(roleMap.get(workflow.getCurrentRoleId()));
				currentStatusDto.setEmployeeName(employeeName);
				currentStatusDto.setAction("PENDING");
				currentStatusDto.setComments("-");
				currentStatusDto.setActionDate("-");
				traceabilityCurrentStatusDtoList.add(currentStatusDto);
			}
			else if (action.equalsIgnoreCase(ResourceManagementConstant.APPROVED)
					//|| action.equalsIgnoreCase(ResourceManagementConstant.REJECTED) 
					|| action.equalsIgnoreCase(ResourceManagementConstant.SUBMITTED)) {
				apprSummaryDto = new TraceabilityApprSummaryDto();
				apprSummaryDto.setActionDate(workflow.getWrkflwLastUpdatedDate());
				if(userNameMap.get(workflow.getCurrentUserId())!=null) {
					apprSummaryDto.setApproverName(userNameMap.get(workflow.getCurrentUserId()));
					apprSummaryDto.setApproverEmpId(workflow.getCurrentUserId());
				}
				else
					apprSummaryDto.setApproverName(ResourceManagementConstant.TAG_TEAM);
				apprSummaryDto.setAction(moduleStatusMap.get(workflow.getStatusId()));
				apprSummaryDto.setRoleName(roleMap.get(workflow.getCurrentRoleId()));
				if(action.equalsIgnoreCase(ResourceManagementConstant.SUBMITTED) && (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE))) {
					apprSummaryDto.setComments(allocation.getRemarks());
				}
				else if(action.equalsIgnoreCase(ResourceManagementConstant.SUBMITTED) && (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE))) {
					apprSummaryDto.setComments(tAssociateDeAllocationRepository.findById(workflow.getTransactionId()).get().getRemarks());
				}
				else {
				apprSummaryDto.setComments(workflow.getComments());}
				traceabilityApprSummaryDtoList.add(apprSummaryDto);
			} 
			else if (action.equalsIgnoreCase(ResourceManagementConstant.REJECTED)) {
				apprSummaryDto = new TraceabilityApprSummaryDto();
				apprSummaryDto.setActionDate(workflow.getWrkflwLastUpdatedDate());
				if(userNameMap.get(workflow.getCurrentUserId())!=null) {
					apprSummaryDto.setApproverName(userNameMap.get(workflow.getCurrentUserId()));
					apprSummaryDto.setApproverEmpId(workflow.getCurrentUserId());
				}
				else {
					apprSummaryDto.setApproverName(ResourceManagementConstant.TAG_TEAM);
					apprSummaryDto.setApproverEmpId(workflow.getCurrentUserId());
				}
				apprSummaryDto.setAction(moduleStatusMap.get(workflow.getStatusId()));
				apprSummaryDto.setRoleName(roleMap.get(workflow.getCurrentRoleId()));
				apprSummaryDto.setComments(workflow.getComments());
				traceabilityApprSummaryDtoList.add(apprSummaryDto);
				
				//Commented by Mrunal Marne as pending approval is handled during rejection itself
				/*currentStatusDto = new TraceabilityCurrentStatusDto();
				ResourceWorkflow previousRowData = resourceWorkflowRepository.getPreviousRowData(workflow.getTransactionId(),workflow.getCurrentUserId(),workflow.getCurrentRoleId());
				currentStatusDto.setApproverEmpId(previousRowData.getCurrentUserId());
				currentStatusDto.setApproverName(userNameMap.get(previousRowData.getCurrentUserId()));
				currentStatusDto.setRoleName(roleMap.get(previousRowData.getCurrentRoleId()));
				currentStatusDto.setEmployeeName(employeeName);
				if(userNameMap.get(previousRowData.getCurrentUserId())!=null)
					currentStatusDto.setAction("PENDING");
				currentStatusDto.setComments("-");
				currentStatusDto.setActionDate("-");
				traceabilityCurrentStatusDtoList.add(currentStatusDto);*/
				//End by Mrunal Marne
			}
			else {
				apprSummaryDto = new TraceabilityApprSummaryDto();
				apprSummaryDto.setActionDate(workflow.getAllocLastUpdatedDate());
				apprSummaryDto.setApproverName(userNameMap.get(userId));
				apprSummaryDto.setApproverEmpId(userId);
				apprSummaryDto.setAction(moduleStatusMap.get(workflow.getWkflowStatusId()));
				apprSummaryDto.setRoleName(roleMap.get(roleId));
				traceabilityApprSummaryDtoList.add(apprSummaryDto);
			}
		}
		//Added by Mrunal Marne for sorting traceability
		List<Long> roleIdList = findByWrkflwTrnsctnId.stream().map(ApprovalTraceabilityProjection::getCurrentRoleId).distinct().collect(Collectors.toList());
		List<LookupValueDto> roleLookUpValueList = adminServiceClient.getLookUpValueDetailsByIds(roleIdList);
		roleLookUpValueList.sort((LookupValueDto val1, LookupValueDto val2) -> val1.getLookupValueCode().compareTo(val2.getLookupValueCode()));
		Map<Long, String> roleSortedMap = new HashMap<>();
		List<TraceabilityCurrentStatusDto> traceabilityCurrentStatusDtoListSorted = new ArrayList<>();
		Multimap<String, TraceabilityCurrentStatusDto> traceabilityCurrentStatusDtoMap = ArrayListMultimap.create();
		for (Long j = 0L; j < roleLookUpValueList.size(); j++) {
			LookupValueDto v1 = roleLookUpValueList.get(j.intValue());
			roleSortedMap.put(j, v1.getLookupType());
		}
		traceabilityCurrentStatusDtoList.forEach(value -> traceabilityCurrentStatusDtoMap.put(value.getRoleName(), value));
		for (Long j = 0L; j < roleSortedMap.size(); j++) {
			String role = roleSortedMap.containsKey(j) ? roleSortedMap.get(j) : null;
			if(Objects.nonNull(role) && traceabilityCurrentStatusDtoMap.containsKey(role))
				traceabilityCurrentStatusDtoListSorted.addAll(traceabilityCurrentStatusDtoMap.get(role));
		}
		traceabilityApprSummaryDtoList.sort((TraceabilityApprSummaryDto v1, TraceabilityApprSummaryDto v2) -> v1.getActionDate().compareTo(v2.getActionDate()));
		List<TraceabilityCurrentStatusDto> traceabilityCurrentStatusListSortedNew = new ArrayList<>();
		traceabilityCurrentStatusListSortedNew.add(traceabilityCurrentStatusDtoListSorted.get(0));
		//End by Mrunal Marne
		traceabilityDto.setApprovalSummary(traceabilityApprSummaryDtoList);
		//traceabilityDto.setCurrentStatus(traceabilityCurrentStatusDtoList);
		traceabilityDto.setCurrentStatus(traceabilityCurrentStatusListSortedNew);
		return traceabilityDto;
	}

	List<EmployeeDto> setDataforPendingForSubmission(List<AllocatedResourceProjection> resourceAllocationDataSubmission)
			throws ResourceManagementException {
		List<EmployeeDto> pendingforSubmissionList = new ArrayList<>();
		Map<Long, ProjectDto> projectMap = getProjectMap(resourceAllocationDataSubmission);
		Map<Long, ResourceRequirementDto> resourceRequirmentMap = getRequirementMap(resourceAllocationDataSubmission);
		List<ReasonForDeallocation> reasonForDeallocation = adminServiceClient.getReasonForDeallocation();
		Map<Long ,String> deallocationReasonMap = reasonForDeallocation.stream().collect(HashMap::new,
				(m, v) -> m.put(v.getReasonId(), v.getReason()), HashMap::putAll);

//		Map<Long, EmployeeDto> employeeMap = getPractiseDetails(resourceAllocationDataSubmission);
		//bill statuscode added -start
		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList = adminServiceClient.getLookuIdByTypeAndDescrList(
				ResourceManagementConstant.RESOURCE_BILLABLE_TYPE,
				List.of(ResourceManagementConstant.Billable, ResourceManagementConstant.Ebr,
						ResourceManagementConstant.Non_Billable, ResourceManagementConstant.InTransit,
						ResourceManagementConstant.POOL));
		
		Map<Long, String> lookupDescToIdMap = lookuIdByTypeAndDescrList.stream().collect(Collectors
				.toMap(LookupValueAndDescDto::getLookupValueId,LookupValueAndDescDto::getLookupValueDescr));
		//bill statuscode added -end
		for (AllocatedResourceProjection listofAllocationPendingResource : resourceAllocationDataSubmission) {
			EmployeeDto employeeDetails = adminServiceClient
					.getEmployeeDetailsByEmpId(listofAllocationPendingResource.getEmployeeId());
			EmployeeDto empDto = new EmployeeDto();
			empDto.setAssociateAllocationId(listofAllocationPendingResource.getAssociateAllocationId());
			empDto.setAssociateDeAllocationId(listofAllocationPendingResource.getAssociateDeAllocationId());
			empDto.setEmployeeNumber(employeeDetails.getEmployeeNumber());
			empDto.setEmployeeId(listofAllocationPendingResource.getEmployeeId());
			empDto.setProjectId(listofAllocationPendingResource.getProjectId());
			empDto.setFte_percent(listofAllocationPendingResource.getFtePercent());
			empDto.setActualAllocationDate(listofAllocationPendingResource.getActualStartDate());
			empDto.setRequirementId(listofAllocationPendingResource.getRequirementId());
			empDto.setPrimaryProjectStatusId(listofAllocationPendingResource.getIsPrimaryProject());
			empDto.setEstimatedEndDate(listofAllocationPendingResource.getEstEndDate());
			empDto.setDateOfDeallocation(listofAllocationPendingResource.getDeallocationDate());
			empDto.setEstimatedExtendedEndDate(listofAllocationPendingResource.getDeallocationDate());
			empDto.setComments(listofAllocationPendingResource.getcomments());
			empDto.setEmployeeName(employeeDetails.getEmployeeName());
			if(null != listofAllocationPendingResource.getBillableStatusId() ) 
				empDto.setBillingStatus(lookupDescToIdMap.get(Long.valueOf(listofAllocationPendingResource.getBillableStatusId())));
			setProjectName(projectMap, listofAllocationPendingResource, empDto);
			Long resonForDeallocId = listofAllocationPendingResource.getReasonForDeallocationId();
			if (resonForDeallocId != null)
			{
				String deallocReason = deallocationReasonMap.get(listofAllocationPendingResource.getReasonForDeallocationId());
				empDto.setReasonForDeallocation(deallocReason);
			}
//			setEmployeeName(employeeMap, listofAllocationPendingResource, empDto);
			if (listofAllocationPendingResource.getIsPrimaryProject()) {
				empDto.setPrimaryProjectStatusField("YES");
			} else {
				empDto.setPrimaryProjectStatusField("NO");

			}
			setLocation(resourceRequirmentMap, listofAllocationPendingResource, empDto);
			setVersion(resourceRequirmentMap, listofAllocationPendingResource, empDto);
			setRole(resourceRequirmentMap, listofAllocationPendingResource, empDto);

			pendingforSubmissionList.add(empDto);
		}
		return pendingforSubmissionList;
	}

	public HashBasedTable<String, String, Long> getModuleDta() throws ResourceManagementException {
		List<ModuleStatusDto> moduleList = adminServiceClient
				.getAllModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT);
		HashBasedTable<String, String, Long> table = HashBasedTable.create();
		for (ModuleStatusDto temp : moduleList) {
			table.put(temp.getSubModule(), temp.getAction(), temp.getModuleStatusId());
		}
		return table;
	} 

}