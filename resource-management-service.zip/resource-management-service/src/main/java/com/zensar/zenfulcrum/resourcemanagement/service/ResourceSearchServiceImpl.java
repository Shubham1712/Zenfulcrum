package com.zensar.zenfulcrum.resourcemanagement.service;

import java.io.IOError;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.HashBasedTable;
import com.zensar.zenfulcrum.resourcemanagement.dto.AllocationTypeStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateSearchDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeSkillDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LeaveDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueAndDescDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PracticeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PracticeProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApproversDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ReasonForDeallocation;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceSearchDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RoleDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ServiceLineDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SuperVisiorDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SupervisorDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.AllocatedResourceHelperClass;
import com.zensar.zenfulcrum.resourcemanagement.helper.JVCheckHelperService;
import com.zensar.zenfulcrum.resourcemanagement.helper.SendMailHelperService;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateProjectMapper;
import com.zensar.zenfulcrum.resourcemanagement.model.ResourceWorkflow;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateDeAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateExtension;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateProject;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateSkill;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AvaibalityProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.SrfProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.SupervisorProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.JVDetailsRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceWorkflowRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateExtensionRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateSkillRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TSrfRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceExtensionUtils;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class ResourceSearchServiceImpl implements ResourceSearchService {

	@Autowired
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Autowired
	private AdminServiceClient adminServiceClient;
	@Autowired
	private ResourceManagementServiceImpl resourceManagementServiceImpl;
	@Autowired
	private BAPServiceClient bapServiceClient;
	@Autowired
	private TSrfRepository tSrfRepository;
	@Autowired
	private TAssociateProjectRepository tAssociateProjectRepository;
	@Autowired
	private BudgetControlServiceClient budgetControlServiceClient;
	@Autowired
	private TAssociateProjectMapper tAssociateProjectMapper;
	@Autowired
	private ResourceAllocationServiceImpl resourceAllocationServiceImpl;
	@Autowired
	private TAssociateSkillRepository tAssociateSkillRepository;
	@Autowired
	private TAssociateExtensionRepository tAssociateExtensionRepository;

	@Autowired
	private TAssociateDeAllocationRepository tAssociateDeAllocationRepository;

	@Autowired
	private SendMailHelperService sendMailHelperServiceObj;
	@Autowired
	private ResourceWorkflowRepository resourceWorkflowRepository;

	@Autowired
	private AllocatedResourceHelperClass allocatedHelperClass;

	@Autowired
	private JVDetailsRepository jvDetailsRepository;

	@Autowired
	JVCheckHelperService jvCheckHelperService;

	@Autowired
	private ResourceRequirementServiceImpl resourceRequirementServiceImpl;

	@Autowired	
	private ResourceExtensionUtils resourceExtensionUtils;

	@Override
	public ResourceSearchDto getAssociateListByProjectId(Long projectId, Long loggedInRoleId, Long loggedInUserId) throws ResourceManagementException {
		log.info("Entered into ResourceAllocationServiceImpl.getAssociateListByProjectId method:");
		ResourceSearchDto resourceSearchDto = null;
		List<EmployeeDto> employeeList = new ArrayList<>();
		Long statusIdForActive = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
		Long statusIdForDeactive = resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.DEACTIVATE);
		List<String> subModuleListForAllo = List.of(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<String> subModuleListForDeallo = List.of(ResourceManagementConstant.RESOURCE_TRANSFER,	ResourceManagementConstant.RESOURCE_DEALLOCATION);
		List<String> actionListForSaveAndSubDeallo = List.of(ResourceManagementConstant.SAVED, ResourceManagementConstant.SUBMITTED);
		List<String> actionListForApproved = List.of(ResourceManagementConstant.APPROVED_ACTION);
		List<Long> workflowIds = new ArrayList<Long>();
		workflowIds.addAll(getWfStatusIdList(subModuleListForDeallo, actionListForApproved));
		workflowIds.addAll(getWfStatusIdList(subModuleListForDeallo, actionListForSaveAndSubDeallo));
		workflowIds.addAll(getWfStatusIdList(subModuleListForAllo, actionListForApproved));
		List<TAssociateAllocation> tAssociateAllocationList = tAssociateAllocationRepository
				.getAssociateListByProjectId(projectId, statusIdForActive, workflowIds);				//74
		
		if (CollectionUtils.isNotEmpty(tAssociateAllocationList)) {
			resourceSearchDto = new ResourceSearchDto();
			List<Long> associateAllocationIdList = tAssociateAllocationList.stream()
					.map(TAssociateAllocation::getAssociateAllocationId).collect(Collectors.toList());
			List<Long> deallocationApprovedList = tAssociateDeAllocationRepository.getDeallocationApprovedList(
					associateAllocationIdList, getWfStatusIdList(subModuleListForDeallo, actionListForApproved),statusIdForDeactive);	
			List<Long> reservedDeallocationList = tAssociateDeAllocationRepository.getReservedDeallocationList(
					associateAllocationIdList, getWfStatusIdList(subModuleListForDeallo, actionListForSaveAndSubDeallo), statusIdForDeactive);
			List<Long> allocationApprovedList = tAssociateAllocationRepository.getAllocationApprovedList(
					associateAllocationIdList, getWfStatusIdList(subModuleListForAllo, actionListForApproved), statusIdForActive);

			List<Long> employeeIdList = new ArrayList<>();
			tAssociateAllocationList.stream().forEach(record -> employeeIdList.add(record.getTAssociateProject().getEmployeeId()));
			Map<Long, EmployeeDto> employeeMap = getPractiseDetails(tAssociateAllocationRepository.getEmpNumbers(employeeIdList));
			//List<Long> skillIdList = tAssociateAllocationList.stream().map(TAssociateAllocation::getSkillId).collect(Collectors.toList());
			//Map<Long, SkillTaxonomyDto> defaultSkillMap = resourceRequirementServiceImpl.getDefaultSkillForAllocatedEmployee(skillIdList);
			List<ReasonForDeallocation> reasonForDeallocationList = adminServiceClient.getReasonForDeallocation();
			List<Long> serviceLineIds = tAssociateAllocationList.stream().map(TAssociateAllocation::getServiceLineId).collect(Collectors.toList());
			Map<Long, String> serviceLines = new HashMap<>();
			if (!StreamSupport.stream(serviceLineIds.spliterator(), true).allMatch(o -> o == null)) {
				serviceLines = getServiceLineMap(adminServiceClient.getServiceLineList(serviceLineIds));
			}
			List<Long> supervisorIds =  tAssociateAllocationList.stream().map(TAssociateAllocation::getSupervisorId).collect(Collectors.toList());
			Map<Long, SuperVisiorDetailsDto> supervisorMap = getSupervisorMap(adminServiceClient.getSuperVisiorList(supervisorIds));

			for (TAssociateAllocation tAssociateAllocation : tAssociateAllocationList) {
				EmployeeDto employeeDto = employeeMap.get(tAssociateAllocation.getTAssociateProject().getEmployeeId());
				ResourceRequirementDto resourceRequirementDto = bapServiceClient
						.getRequirementDetailByReqId(tAssociateAllocation.getRequirementId());
				if (employeeDto != null) {
					createSearchByProjectObject(reasonForDeallocationList, serviceLines, supervisorMap,
							tAssociateAllocation, employeeDto, resourceRequirementDto);
					//employeeDto.setIsReservedAllocation(getWfStatusIdList(subModuleListForAllo, actionListForSaveAndSubAllo).contains(tAssociateAllocation.getWorkflowStatusId()));
					//employeeDto.setIsAllocationApproved(getWfStatusIdList(subModuleListForAllo, actionListForApproved).contains(tAssociateAllocation.getWorkflowStatusId()));
					//employeeDto.setIsReservedForDeallocation(getWfStatusIdList(subModuleListForDeallo, actionListForSaveAndSubDeallo).contains(tAssociateAllocation.getWorkflowStatusId()));
	                employeeDto.setIsReservedForDeallocation(reservedDeallocationList.contains(tAssociateAllocation.getAssociateAllocationId()));
	                employeeDto.setIsReservedAllocation(null);
					if (tAssociateAllocation.getActualAllocationStartDate().compareTo(new Date()) > 0)
						employeeDto.setIsAllocationApproved(allocationApprovedList.contains(tAssociateAllocation.getAssociateAllocationId()));
					employeeDto.setIsDeallocationApproved(deallocationApprovedList.contains(tAssociateAllocation.getAssociateAllocationId()));
					//Added accessFlag by Mrunal Marne
					employeeDto.setIsAllowedToEdit(getOwnerCount(loggedInUserId, projectId, loggedInRoleId)>0);					
					//End by Mrunal Marne
					employeeList.add(employeeDto);
				}
			}
			resourceSearchDto.setTotalCount(Long.valueOf(tAssociateAllocationList.size()));
			resourceSearchDto.setEmployeeList(employeeList);
		}

		log.info("Just before leaving ResourceAllocationServiceImpl.getAssociateListByProjectId method:");
		return resourceSearchDto;
	}

	private Map<Long, SuperVisiorDetailsDto> getSupervisorMap(List<SuperVisiorDetailsDto> superVisiorList) {
		if(!superVisiorList.isEmpty()) {
			return superVisiorList.stream().collect(Collectors.toMap(SuperVisiorDetailsDto::getEmpId, supervisorDtoMap -> supervisorDtoMap));
		}
		return Collections.emptyMap(); 
	}
	
	private Map<Long, String> getServiceLineMap(List<ServiceLineDto> serviceLineList) {
		if (!serviceLineList.isEmpty()) {
			return serviceLineList.stream()
					.collect(Collectors.toMap(ServiceLineDto::getServiceLineId, ServiceLineDto::getServiceLine));
		}
		return Collections.emptyMap();
	}

	public List<Long> getWfStatusIdList(List<String> subModuleList, List<String> actionList)
			throws ResourceManagementException {
		List<Long> workflowStatusIdList = new ArrayList<>();
		for (String subModule : subModuleList) {
			for (String action : actionList) {
				Long wfStatusId = resourceManagementServiceImpl.getModuleStatusId(subModule, action);
				if (wfStatusId != 0)
					workflowStatusIdList.add(wfStatusId);
			}
		}
		return workflowStatusIdList;
	}

	public Boolean isPrimaryProject(Long isPrimaryProject) {
		Boolean primaryProject = null;
		if (isPrimaryProject != null && isPrimaryProject == 0)
			primaryProject = false;
		else
			primaryProject = true;
		return primaryProject;
	}

	@Override
	public ResourceSearchDto getResourceDtlsListByPractice(Long practiceId) throws ResourceManagementException {
		log.info("Entered into ResourceAllocationServiceImpl.getResourceDtlsListByPracticeName method:");
		Long statusIdForActive = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
		Long workflowStatusApproved = resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED_ACTION);
		ResourceSearchDto resourceSearchDto = null;

		List<EmployeeDto> employeeDtoList = adminServiceClient.getResourceDtlsListByPractice(practiceId);
		if (CollectionUtils.isNotEmpty(employeeDtoList)) {
			resourceSearchDto = new ResourceSearchDto();
			List<Long> allAllocatedEmpIdList = tAssociateAllocationRepository.getAllEmpIds(statusIdForActive);
			List<Long> empIdListbyPractice = employeeDtoList.stream().map(EmployeeDto::getEmployeeId).distinct()
					.collect(Collectors.toList());
			List<Long> empIdListOfAllocatedRes = allAllocatedEmpIdList.stream().filter(empIdListbyPractice::contains)
					.collect(Collectors.toList());
			List<TAssociateAllocation> tAssoAlloByPractice = tAssociateAllocationRepository
					.getResourceDetailsByEmpId(empIdListOfAllocatedRes, statusIdForActive, workflowStatusApproved);
			List<LookupValueAndDescDto> lookuIdByTypeAndDescrList = adminServiceClient.getLookuIdByTypeAndDescrList(
					ResourceManagementConstant.RESOURCE_BILLABLE_TYPE,
					List.of(ResourceManagementConstant.Billable, ResourceManagementConstant.Ebr,
							ResourceManagementConstant.Non_Billable, ResourceManagementConstant.InTransit,
							ResourceManagementConstant.POOL));
			Map<String, Long> lookupDescToIdMap = lookuIdByTypeAndDescrList.stream().collect(Collectors
					.toMap(LookupValueAndDescDto::getLookupValueDescr, LookupValueAndDescDto::getLookupValueId));

			Map<Long, EmployeeSkillDto> skillFamilyForAssociate = resourceAllocationServiceImpl
					.getSkillFamilyForAssociate(empIdListbyPractice);

			employeeDtoList = createEmpDtoObject(employeeDtoList, tAssoAlloByPractice,
					lookupDescToIdMap.get(ResourceManagementConstant.Billable),
					lookupDescToIdMap.get(ResourceManagementConstant.Non_Billable),
					lookupDescToIdMap.get(ResourceManagementConstant.Ebr), skillFamilyForAssociate,
					lookupDescToIdMap.get(ResourceManagementConstant.InTransit),
					lookupDescToIdMap.get(ResourceManagementConstant.POOL));

			resourceSearchDto.setTotalCount(Long.valueOf(employeeDtoList.size()));

			// Long totalActiveRecords = Long.valueOf(empIdListOfAllocatedRes.size());
			/*
			 * resourceSearchDto.setTotalResourceAllocated(tAssociateAllocationRepository.
			 * getBillabilityCount(List.of(lookupDescToIdMap.get(ResourceManagementConstant.
			 * Billable),lookupDescToIdMap.get(ResourceManagementConstant.Non_Billable),
			 * lookupDescToIdMap.get(ResourceManagementConstant.InTransit),lookupDescToIdMap
			 * .get(ResourceManagementConstant.Ebr)),statusIdForActive,
			 * empIdListOfAllocatedRes,workflowStatusApproved));
			 * resourceSearchDto.setTotalBillableResource(
			 * tAssociateAllocationRepository.getBillabilityCount(List.of(lookupDescToIdMap.
			 * get(ResourceManagementConstant.Billable)),statusIdForActive,
			 * empIdListOfAllocatedRes,workflowStatusApproved));
			 * resourceSearchDto.setTotalNonBillableResource(
			 * tAssociateAllocationRepository.getBillabilityCount(List.of(lookupDescToIdMap.
			 * get(ResourceManagementConstant.Non_Billable),lookupDescToIdMap.get(
			 * ResourceManagementConstant.InTransit)),statusIdForActive,
			 * empIdListOfAllocatedRes,workflowStatusApproved));
			 * resourceSearchDto.setTotalEBRResource(
			 * tAssociateAllocationRepository.getBillabilityCount(List.of(lookupDescToIdMap.
			 * get(ResourceManagementConstant.Ebr)),statusIdForActive,
			 * empIdListOfAllocatedRes,workflowStatusApproved));
			 * resourceSearchDto.setTotalPoolResources(
			 * (tAssociateAllocationRepository.getBillabilityCount(List.of(lookupDescToIdMap
			 * .get(ResourceManagementConstant.POOL)),statusIdForActive,
			 * empIdListOfAllocatedRes,workflowStatusApproved)));
			 */

			Double totalResourceAllocated = 0.00;
			Double totalBillableResource = 0.00;
			Double totalNonBillableResource = 0.00;
			Double totalEBRResource = 0.00;
			Double totalPoolResources = 0.00;
			List<EmployeeDto> allocatedResourceList = new ArrayList<>();
			List<EmployeeDto> poolResourceList = new ArrayList<>();
			setDtoObjectsForSkillAndPracSearch(resourceSearchDto, employeeDtoList, totalResourceAllocated,
					totalBillableResource, totalNonBillableResource, totalEBRResource, totalPoolResources,
					allocatedResourceList, poolResourceList);

		}
		log.info("Just before leaving ResourceAllocationServiceImpl.getResourceDtlsListByPracticeName method:");
		return resourceSearchDto;
	}

	/**
	 * Service method to get List of All skills
	 */
	@Override
	@Transactional(readOnly = true)
	public List<SkillDto> getListOfSkills() throws ResourceManagementException {
		log.info("Entered into ResourceSearchServiceImpl.getListOfSkills method:");
		List<SkillDto> skillList = adminServiceClient.getListOfSkills();
		Collections.sort(skillList);
		log.info("Just before leaving ResourceSearchServiceImpl.getListOfSkills method:");
		return skillList;
	}

	@Override
	public List<RoleDto> getRoleList() throws ResourceManagementException {
		log.info("Entered into ResourceAllocationServiceImpl.getRoleList method:");
		List<RoleDto> roleDto = adminServiceClient.getListOfRoles();
		log.info("end of ResourceAllocationServiceImpl.getRoleList method:");
		return roleDto;
	}

	/**
	 * Service method to get resource list based on input skill name.
	 */
	@Override
	@Transactional(readOnly = true)
	public ResourceSearchDto getResourceDtlsListBySkill(Long skillId) throws ResourceManagementException {
		log.info("Entered into ResourceSearchServiceImpl.getResourceDtlsListBySkill method:");
		Long statusIdForActive = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
		Long workflowStatusApproved = resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED_ACTION);
		Long skillActiveStatusId = tAssociateSkillRepository.getSkillActiveModuleStatusId();

		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList = adminServiceClient.getLookuIdByTypeAndDescrList(
				ResourceManagementConstant.RESOURCE_BILLABLE_TYPE,
				List.of(ResourceManagementConstant.Billable, ResourceManagementConstant.Ebr,
						ResourceManagementConstant.Non_Billable, ResourceManagementConstant.InTransit,
						ResourceManagementConstant.POOL));
		Map<String, Long> lookupDescToIdMap = lookuIdByTypeAndDescrList.stream().collect(
				Collectors.toMap(LookupValueAndDescDto::getLookupValueDescr, LookupValueAndDescDto::getLookupValueId));

		ResourceSearchDto resourceSearchDto = null;
		List<TAssociateSkill> associateSkillList = tAssociateSkillRepository.findBySkillId(skillId,
				skillActiveStatusId);
		if (CollectionUtils.isNotEmpty(associateSkillList)) {
			resourceSearchDto = new ResourceSearchDto();
			List<Long> employeeIdList = associateSkillList.stream().map(TAssociateSkill::getAssociateId).distinct()
					.collect(Collectors.toList());

			List<EmployeeDto> employeeDto = adminServiceClient.getAssociatesDetailsbyEmpIds(employeeIdList);
			List<Long> employeeDtoIdList = employeeDto.stream().map(EmployeeDto::getEmployeeId)
					.collect(Collectors.toList());

			List<TAssociateAllocation> totalAllocationsBySkill = tAssociateAllocationRepository
					.getAssociateAllocationByWorkflowStatusAndStatusId(workflowStatusApproved, statusIdForActive,
							employeeDtoIdList);
			/*
			 * List<Long> allocatedEmployeeIdList = new ArrayList<>();
			 * 
			 * for (TAssociateAllocation associate : totalAllocationsBySkill) {
			 * allocatedEmployeeIdList.add(associate.getTAssociateProject().getEmployeeId())
			 * ; }
			 * 
			 * employeeDtoIdList.retainAll(allocatedEmployeeIdList);
			 */

			/*
			 * Double totalAllocatedResources =
			 * tAssociateAllocationRepository.getTotalBillablesBySkill(employeeDtoIdList,
			 * List.of(lookupDescToIdMap.get(ResourceManagementConstant.Billable),
			 * lookupDescToIdMap.get(ResourceManagementConstant.Non_Billable),
			 * lookupDescToIdMap.get(ResourceManagementConstant.InTransit),
			 * lookupDescToIdMap.get(ResourceManagementConstant.Ebr)), statusIdForActive,
			 * workflowStatusApproved); ; Double totalBillableResources =
			 * tAssociateAllocationRepository.getTotalBillablesBySkill(employeeDtoIdList,
			 * List.of(lookupDescToIdMap.get(ResourceManagementConstant.Billable)),
			 * statusIdForActive, workflowStatusApproved); Double totalNonBillableResources
			 * = tAssociateAllocationRepository.getTotalBillablesBySkill( employeeDtoIdList,
			 * List.of(lookupDescToIdMap.get(ResourceManagementConstant.Non_Billable),
			 * lookupDescToIdMap.get(ResourceManagementConstant.InTransit)),
			 * statusIdForActive, workflowStatusApproved); Double totalEbrResources =
			 * tAssociateAllocationRepository.getTotalBillablesBySkill(employeeDtoIdList,
			 * List.of(lookupDescToIdMap.get(ResourceManagementConstant.Ebr)),
			 * statusIdForActive, workflowStatusApproved);
			 */

			Map<Long, EmployeeSkillDto> skillFamilyForAssociate = resourceAllocationServiceImpl
					.getSkillFamilyForAssociate(employeeIdList);
			List<EmployeeDto> createEmpDtoObject = createEmpDtoObject(employeeDto, totalAllocationsBySkill,
					lookupDescToIdMap.get(ResourceManagementConstant.Billable),
					lookupDescToIdMap.get(ResourceManagementConstant.Non_Billable),
					lookupDescToIdMap.get(ResourceManagementConstant.Ebr), skillFamilyForAssociate,
					lookupDescToIdMap.get(ResourceManagementConstant.InTransit),
					lookupDescToIdMap.get(ResourceManagementConstant.POOL));

			/*
			 * resourceSearchDto.setTotalResourceAllocated(totalAllocatedResources);
			 * resourceSearchDto.setTotalBillableResource(totalBillableResources);
			 * resourceSearchDto.setTotalNonBillableResource(totalNonBillableResources);
			 * resourceSearchDto.setTotalEBRResource(totalEbrResources);
			 * resourceSearchDto.setTotalPoolResources(tAssociateAllocationRepository.
			 * getTotalBillablesBySkill( employeeDtoIdList,
			 * List.of(lookupDescToIdMap.get(ResourceManagementConstant.POOL)),
			 * statusIdForActive, workflowStatusApproved));
			 */

			Double totalResourceAllocated = 0.00;
			Double totalBillableResource = 0.00;
			Double totalNonBillableResource = 0.00;
			Double totalEBRResource = 0.00;
			Double totalPoolResources = 0.00;
			List<EmployeeDto> allocatedResourceList = new ArrayList<>();
			List<EmployeeDto> poolResourceList = new ArrayList<>();
			setDtoObjectsForSkillAndPracSearch(resourceSearchDto, createEmpDtoObject, totalResourceAllocated,
					totalBillableResource, totalNonBillableResource, totalEBRResource, totalPoolResources,
					allocatedResourceList, poolResourceList);

			// resourceSearchDto.setEmployeeList(createEmpDtoObject);
		}
		log.info("Just before leaving ResourceSearchServiceImpl.getResourceDtlsListBySkill method:");
		return resourceSearchDto;
	}

	public void setDtoObjectsForSkillAndPracSearch(ResourceSearchDto resourceSearchDto,
			List<EmployeeDto> createEmpDtoObject, Double totalResourceAllocated, Double totalBillableResource,
			Double totalNonBillableResource, Double totalEBRResource, Double totalPoolResources,
			List<EmployeeDto> allocatedResourceList, List<EmployeeDto> poolResourceList) {
		for (EmployeeDto emplo : createEmpDtoObject) {
			if (emplo.getBillableType() != null) {
				if (emplo.getBillableType().equals(ResourceManagementConstant.Billable)
						|| emplo.getBillableType().equals(ResourceManagementConstant.Non_Billable)
						|| emplo.getBillableType().equals(ResourceManagementConstant.Ebr)) {
					allocatedResourceList.add(emplo);
					if (emplo.getBillableType().equals(ResourceManagementConstant.Billable)) {
						totalBillableResource = totalBillableResource + emplo.getFte_percent();
					} else if (emplo.getBillableType().equals(ResourceManagementConstant.Non_Billable)) {
						totalNonBillableResource = totalNonBillableResource + emplo.getFte_percent();
					} else if (emplo.getBillableType().equals(ResourceManagementConstant.Ebr)) {
						totalEBRResource = totalEBRResource + emplo.getFte_percent();
					}
				} else if (emplo.getBillableType().equals(ResourceManagementConstant.POOL)) {
					poolResourceList.add(emplo);
					totalPoolResources = totalPoolResources + emplo.getFte_percent();
				}
			}
		}
		totalResourceAllocated = (totalResourceAllocated + totalBillableResource + totalNonBillableResource
				+ totalEBRResource) / 100;
		resourceSearchDto.setTotalResourceAllocated(totalResourceAllocated);
		resourceSearchDto.setTotalBillableResource(totalBillableResource / 100);
		resourceSearchDto.setTotalNonBillableResource(totalNonBillableResource / 100);
		resourceSearchDto.setTotalEBRResource(totalEBRResource / 100);
		resourceSearchDto.setTotalPoolResources(totalPoolResources / 100);
		resourceSearchDto.setResourceReadyForAllocationList(poolResourceList);
		resourceSearchDto.setResourceAllocatedList(allocatedResourceList);

		List<EmployeeDto> allEmployeeList = Stream.of(allocatedResourceList, poolResourceList)
				.flatMap(Collection::stream).collect(Collectors.toList());
		resourceSearchDto.setEmployeeList(allEmployeeList);
	}

	public List<EmployeeDto> createEmpDtoObject(List<EmployeeDto> employeeDto,
			List<TAssociateAllocation> tAssociateAllocationList, Long billableId, Long nonBillableId, Long ebrId,
			Map<Long, EmployeeSkillDto> skillFamilyForAssociate, Long inTransitId, Long poolId)
			throws ResourceManagementException {
		for (EmployeeDto employee : employeeDto) {

			if (null != skillFamilyForAssociate) {
				EmployeeSkillDto empSkillDto = skillFamilyForAssociate.get(employee.getEmployeeId());
				List<SkillTaxonomyDto> skillFamilyList = empSkillDto.getSkillFamilyList();
				employee.setSkilltaxanomyList(skillFamilyList);
			}

			PracticeProjectDto practiceProjectDto = adminServiceClient
					.getPracticeProject(employee.getEmployeePracticeId());
			employee.setPoolProjectCode(practiceProjectDto.getProjectCode());
			employee.setPoolProjectName(practiceProjectDto.getPracticeProjectName());
			employee.setActualAllocationDate(employee.getPracticeAllocationStartDate());
			employee.setEstimatedEndDate(employee.getPracticeAllocationEndDate());
			employee.setAvailability(100.00);

			for (TAssociateAllocation associateAllocation : tAssociateAllocationList) {
				employee.setFte_percent(associateAllocation.getFtePercent());
				if ((associateAllocation.getTAssociateProject().getEmployeeId()).equals(employee.getEmployeeId())) {
					employee.setAssociateAllocationId(associateAllocation.getAssociateAllocationId());
					employee.setEstimatedProjectEndDate(associateAllocation.getEstAllocationEndDate());
					if (billableId.equals(associateAllocation.getBillableStatusId())) {
						employee.setIsAllocated(true);
						employee.setBillable(true);
						employee.setBillableUtilization(associateAllocation.getFtePercent());
						employee.setBillableType(ResourceManagementConstant.Billable);
						employee.setEstimatedProjectEndDate(associateAllocation.getEstAllocationEndDate());
						employee.setAvailability(employee.getAvailability() - employee.getBillableUtilization());
					} else if (nonBillableId.equals(associateAllocation.getBillableStatusId())
							|| inTransitId.equals(associateAllocation.getBillableStatusId())) {
						employee.setIsAllocated(true);
						employee.setBillable(false);
						employee.setNonBillableUtilization(associateAllocation.getFtePercent());
						employee.setBillableType(ResourceManagementConstant.Non_Billable);
						employee.setEstimatedProjectEndDate(associateAllocation.getEstAllocationEndDate());
						employee.setAvailability(employee.getAvailability() - employee.getNonBillableUtilization());
					} else if (ebrId.equals(associateAllocation.getBillableStatusId())) {
						employee.setIsAllocated(true);
						employee.setBillable(false);
						employee.setEbrUtilization(associateAllocation.getFtePercent());
						employee.setBillableType(ResourceManagementConstant.Ebr);
						employee.setEstimatedProjectEndDate(associateAllocation.getEstAllocationEndDate());
						employee.setAvailability(employee.getAvailability() - employee.getEbrUtilization());
					} else if (poolId.equals(associateAllocation.getBillableStatusId())) {
						employee.setIsAllocated(false);
						employee.setBillableType(ResourceManagementConstant.POOL);
						employee.setAvailability(associateAllocation.getFtePercent());
					}
				}
			}
		}
		return employeeDto;
	}

	/**
	 * Service method to get practice name.
	 */
	@Override
	@Transactional(readOnly = true)
	public List<PracticeDto> getPracticeList() throws ResourceManagementException {
		log.info("Entered into ResourceAllocationServiceImpl.getPracticeNames method:");
		List<PracticeDto> practiceDto = adminServiceClient.getListOfPractice();
		Collections.sort(practiceDto);
		log.info("Just before leaving ResourceAllocationServiceImpl.getPracticeNames method:");
		return practiceDto;
	}

	@Override
	public AssociateSearchDto getResourceProjectDtlsByAssociateID(String employeeIdOrName, String requestType, Long loggedInRoleId, Long loggedInUserId)
			throws ResourceManagementException {
		AssociateSearchDto associateDto = null;
		// String requestType = "allocated";
		HashBasedTable<String, String, Long> moduletable = allocatedHelperClass.getallModuleData();
		Long statusIdForActive = moduletable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long statusIdDeactiveDeallocation = moduletable.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
				ResourceManagementConstant.DEACTIVATE);
		Long statusIdForallocApproved = moduletable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long statusIdForDeallocApproved = moduletable.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
				ResourceManagementConstant.APPROVED);
		List<LookupValueDto> lookuTypes = adminServiceClient.getLookupValueByLookupType("RESOURCE_BILLABLE_TYPE");
		Map<String, Long> lookupDescrpMap = lookuTypes.stream()
				.collect(Collectors.toMap(LookupValueDto::getLookupType, LookupValueDto::getLookUpId));
		Long lookupIdForPool = lookupDescrpMap.get("POOL");
		EmployeeDto employee = adminServiceClient.getEmployeeByNameOrId(employeeIdOrName);
		if (null != employee) {
			associateDto = new AssociateSearchDto();
			if (requestType.equalsIgnoreCase("allocated")) {
				AllocationTypeStatusDto allocationTypeStatus = adminServiceClient
						.getAllocationTypeStatus(ResourceManagementConstant.TRAVEL_ALLOCATION_TYPE_STATUS);
				EmployeeDto empDto = getPractiseAllocationDetails(employee.getEmployeeNumber(), statusIdForActive,
						statusIdForallocApproved, employee, lookupDescrpMap);
				associateDto.setAssociatePractiseDetails(empDto);
				List<EmployeeDto> allocatedtoProjectempList = getEmployeeToProjectList(employee.getEmployeeId(),
						statusIdForActive, moduletable, lookupIdForPool, employee, allocationTypeStatus.getAllocationTypeId(),loggedInRoleId, loggedInUserId, requestType);
				associateDto.setAssociateProjectDetails(allocatedtoProjectempList);
				List<EmployeeDto> travelAllocation = getEmployeeTravelAllocation(employee.getEmployeeId(), employee,
						statusIdForActive, statusIdForallocApproved, allocationTypeStatus.getAllocationTypeId(), loggedInRoleId, loggedInUserId, requestType);
				associateDto.setAssociateTravelAllocationDetails(travelAllocation);
			} else if (requestType.equalsIgnoreCase("reservedforallocation")) {
				List<EmployeeDto> reservedForAllocation = getReservedForAllocation(employee.getEmployeeId(),
						statusIdForActive, moduletable, employee, loggedInRoleId, loggedInUserId, requestType);
				associateDto.setReservedForAllocation(reservedForAllocation);
			} else if (requestType.equalsIgnoreCase("allocationapproved")) {
				List<EmployeeDto> allocationApproved = getAllocationApprovedResource(employee.getEmployeeId(),
						statusIdForActive, moduletable, employee, loggedInRoleId, loggedInUserId, requestType);
				associateDto.setAllocationApproved(allocationApproved);
			} else if (requestType.equalsIgnoreCase("reservedfordeallocation")) {
				List<EmployeeDto> reservedForDeallocation = getReservedForDeallocation(employee.getEmployeeId(),
						statusIdForActive, statusIdDeactiveDeallocation, moduletable, employee, loggedInRoleId, loggedInUserId, requestType);
				associateDto.setReservedForDeallocation(reservedForDeallocation);
			} else if (requestType.equalsIgnoreCase("deallocationapproved")) {
				AllocationTypeStatusDto allocationTypeStatus = adminServiceClient
						.getAllocationTypeStatus(ResourceManagementConstant.TRAVEL_ALLOCATION_TYPE_STATUS);
				List<EmployeeDto> deallocationApproved = getDeallocationApproved(employee.getEmployeeId(),
						statusIdForActive, statusIdDeactiveDeallocation, moduletable, employee, allocationTypeStatus.getAllocationTypeId(), loggedInRoleId, loggedInUserId, requestType);
				associateDto.setDeallocationApproved(deallocationApproved);
				List<EmployeeDto> travelAllocation = getEmployeeTravelAllocation(employee.getEmployeeId(), employee,
						statusIdForActive, statusIdForDeallocApproved, allocationTypeStatus.getAllocationTypeId(), loggedInRoleId, loggedInUserId, requestType);
				associateDto.setAssociateTravelAllocationDetails(travelAllocation);

			}
		} else {
			throw new ResourceManagementException(ResourceManagementConstant.EMPLOYEE_NOT_FOUND);

		}
		return associateDto;
	}

	private EmployeeDto getPractiseAllocationDetails(Long employeeId, Long statusIdForActive,
			Long statusIdForallocApproved, EmployeeDto empDto, Map<String, Long> lookupDescrpMap)
			throws ResourceManagementException {
		PracticeProjectDto practiceProjectDto = adminServiceClient.getPracticeProject(empDto.getEmployeePracticeId());
		empDto.setPoolProjectCode(practiceProjectDto.getProjectCode());
		empDto.setPoolProjectName(practiceProjectDto.getPracticeProjectName());
		LeaveDetailsDto leaveDetails = adminServiceClient.getLeaveDetails(employeeId);
		List<String> lookupType = new ArrayList<>();
		lookupType.add("RESOURCE_BILLABLE_TYPE");
		Long lookupIdForBillable = lookupDescrpMap.get("Billable");
		Long lookupIdForNonBillable = lookupDescrpMap.get("Non Billable");
		Long lookupIdForEbr = lookupDescrpMap.get("EBR");
		Long lookupIdForPool = lookupDescrpMap.get("POOL");
		Long lookupIdForIntransit = lookupDescrpMap.get("InTransit");

		Double billableUtilization = tAssociateAllocationRepository.searchEmployeeBillableUtilization(
				empDto.getEmployeeId(), statusIdForActive, statusIdForallocApproved, lookupIdForBillable);
		if (null != billableUtilization) {
			empDto.setBillableUtilization(billableUtilization);
		}
		Double nonBillableUtilization = tAssociateAllocationRepository.searchEmployeeNonBillableUtilization(
				empDto.getEmployeeId(), statusIdForActive, statusIdForallocApproved, lookupIdForNonBillable, lookupIdForIntransit);
		if (null != nonBillableUtilization) {
			empDto.setNonBillableUtilization(nonBillableUtilization);
		}
		Double ebrUtilization = tAssociateAllocationRepository.searchEmployeeBillableUtilization(empDto.getEmployeeId(),
				statusIdForActive, statusIdForallocApproved, lookupIdForEbr);
		if (null != ebrUtilization) {
			empDto.setEbrUtilization(ebrUtilization);
		}
		if (null != leaveDetails) {
			empDto.setLeaveDetails(leaveDetails);
		}
		Long empId = empDto.getEmployeeId();
		List<AvaibalityProjection> employeeAvaibility = tAssociateAllocationRepository
				.getAllocatedResourceAvailabilityForPractice(List.of(empId), statusIdForActive, lookupIdForPool, statusIdForallocApproved);
		Map<Long, EmployeeSkillDto> skillMap = resourceAllocationServiceImpl.getSkillFamilyForAssociate(List.of(empId));
		if(skillMap!=null) {
		empDto.setSkilltaxanomyList(skillMap.get(empId).getSkillFamilyList());}
		if (CollectionUtils.isNotEmpty(employeeAvaibility)) {
			empDto.setAvailibility(employeeAvaibility.get(0).getAllocatedFte());
			empDto.setAvailability(employeeAvaibility.get(0).getAllocatedFte());
		} else {
			empDto.setAvailibility(100l);
			empDto.setAvailability(100l);
		}

		return empDto;
	}

	public List<EmployeeDto> getEmployeeToProjectList(long employeeId, long statusIdForActive,
			HashBasedTable<String, String, Long> moduleTable, Long lookupIdForPool, EmployeeDto employee, Long allocationTypeId, Long loggedInRoleId, Long loggedInUserId, String requestType)
			throws ResourceManagementException {
		List<Long> workflowStatusId = List.of(
				(moduleTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
						ResourceManagementConstant.APPROVED_ACTION)));
		List<Long> statusIdList = List.of(
				(moduleTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
						ResourceManagementConstant.DEACTIVATE)), statusIdForActive);
			//	(moduleTable.get(ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.APPROVED_ACTION)));
		List<EmployeeDto> empList = new ArrayList<>();
		List<AllocatedResourceProjection> employeeAllocationDetails = tAssociateAllocationRepository
				.searchAllocatedToProject(employeeId, statusIdForActive, workflowStatusId, lookupIdForPool, allocationTypeId, statusIdList);
		if (CollectionUtils.isNotEmpty(employeeAllocationDetails)) {
			setEmployeeDetails(empList, employeeAllocationDetails, employee, ResourceManagementConstant.APPROVED_ALLOCATION, loggedInRoleId, loggedInUserId, requestType);
		}
		return empList;
	}

	public List<EmployeeDto> getEmployeeTravelAllocation(long employeeId, EmployeeDto employee, Long statusIdForActive,
			Long statusIdForApproved, Long allocationTypeId, Long loggedInRoleId, Long loggedInUserId, String requestType) throws ResourceManagementException {
		List<EmployeeDto> empList = new ArrayList<>();
		List<AllocatedResourceProjection> employeeAllocationDetails = tAssociateAllocationRepository
				.searchTravelAllocationToProject(employeeId, statusIdForActive, statusIdForApproved, allocationTypeId);
		if (CollectionUtils.isNotEmpty(employeeAllocationDetails)) {
			setEmployeeDetails(empList, employeeAllocationDetails, employee, ResourceManagementConstant.TRAVEL_ALLOCATION, loggedInRoleId, loggedInUserId, requestType);
		}
		return empList;
	}

	public List<EmployeeDto> getReservedForAllocation(long employeeId, long statusIdForActive,
			HashBasedTable<String, String, Long> moduleTable, EmployeeDto employee, Long loggedInRoleId, Long loggedInUserId, String requestType) throws ResourceManagementException {
		List<Long> workflowStatusId = List.of(
				moduleTable.get(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SAVED),
				moduleTable.get(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SUBMITTED),
				moduleTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.SAVED),
				moduleTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.SUBMITTED));
		List<EmployeeDto> empList = new ArrayList<>();
		List<AllocatedResourceProjection> employeeAllocationDetails = tAssociateAllocationRepository
				.searchReservedForAllocation(employeeId, statusIdForActive, workflowStatusId);
		if (CollectionUtils.isNotEmpty(employeeAllocationDetails)) {
			setEmployeeDetails(empList, employeeAllocationDetails, employee, ResourceManagementConstant.RESERVED_ALLOCATION, loggedInRoleId, loggedInUserId, requestType);
		}
		return empList;

	}

	public List<EmployeeDto> getAllocationApprovedResource(long employeeId, long statusIdForActive,
			HashBasedTable<String, String, Long> moduleTable, EmployeeDto employee, Long loggedInRoleId, Long loggedInUserId, String requestType) throws ResourceManagementException {
		List<Long> workflowStatusId = List.of(
				moduleTable.get(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.APPROVED),
				moduleTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED));
		List<EmployeeDto> empList = new ArrayList<>();
		List<AllocatedResourceProjection> employeeAllocationDetails = tAssociateAllocationRepository
				.searchAllocationApproved(employeeId, statusIdForActive, workflowStatusId);
		if (CollectionUtils.isNotEmpty(employeeAllocationDetails)) {
			setEmployeeDetails(empList, employeeAllocationDetails, employee, ResourceManagementConstant.APPROVED_ALLOCATION, loggedInRoleId, loggedInUserId, requestType);
		}
		return empList;

	}

	public List<EmployeeDto> getReservedForDeallocation(long employeeId, long statusIdActiveAllocation,
			long statusIdDeactiveDeallocation, HashBasedTable<String, String, Long> moduleTable, EmployeeDto employee, 
			Long loggedInRoleId, Long loggedInUserId, String requestType)
			throws ResourceManagementException {
		// List<Long> workflowStatusIdTransfer =
		// List.of(moduleTable.get(ResourceManagementConstant.RESOURCE_TRANSFER,
		// ResourceManagementConstant.SAVED),moduleTable.get(ResourceManagementConstant.RESOURCE_TRANSFER,
		// ResourceManagementConstant.SUBMITTED));
		List<Long> workflowStatusIdDeallocation = List.of(
				moduleTable.get(ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.SAVED),
				moduleTable.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.SUBMITTED));
		List<Long> workflowStatusIdAllocation = List.of(
				moduleTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED));
		List<EmployeeDto> empList = new ArrayList<>();
		List<AllocatedResourceProjection> employeeAllocationDetails = tAssociateAllocationRepository
				.resourceResvrForDealloc(employeeId, workflowStatusIdAllocation, workflowStatusIdDeallocation,
						statusIdActiveAllocation, statusIdDeactiveDeallocation);
		if (CollectionUtils.isNotEmpty(employeeAllocationDetails)) {
			setEmployeeDetails(empList, employeeAllocationDetails, employee, ResourceManagementConstant.RESERVED_DEALLOCATION, loggedInRoleId, loggedInUserId, requestType);
		}
		return empList;

	}

	public List<EmployeeDto> getDeallocationApproved(long employeeId, Long statusIdForActive,
			Long statusIdDeactiveDeallocation, HashBasedTable<String, String, Long> moduleTable, EmployeeDto employee, Long allocationTypeId,
			Long loggedInRoleId, Long loggedInUserId, String requestType)
			throws ResourceManagementException {
		List<Long> wfStatusIdfortransferAndDeallocationApproved = List.of(
				moduleTable.get(ResourceManagementConstant.RESOURCE_EXTENSION, ResourceManagementConstant.APPROVED),
				moduleTable.get(ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.APPROVED),
				moduleTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED));
		/*
		 * List<Long> workflowStatusIdAllocation = List.of(
		 * moduleTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
		 * ResourceManagementConstant.APPROVED),
		 * moduleTable.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
		 * ResourceManagementConstant.APPROVED));
		 */
		List<EmployeeDto> empList = new ArrayList<>();
		List<AllocatedResourceProjection> employeeAllocationDetails = tAssociateAllocationRepository
				.searchDeallocationApproved(employeeId, statusIdForActive, statusIdDeactiveDeallocation,
						wfStatusIdfortransferAndDeallocationApproved, allocationTypeId);
		if (CollectionUtils.isNotEmpty(employeeAllocationDetails)) {
			setEmployeeDetails(empList, employeeAllocationDetails, employee, ResourceManagementConstant.APPROVED_DEALLOCATION, loggedInRoleId, loggedInUserId, requestType);
		}
		return empList;

	}

	private void setEmployeeDetails(List<EmployeeDto> empList,
			List<AllocatedResourceProjection> employeeAllocationDetails, EmployeeDto newempDto, String methodType, Long loggedInRoleId, Long loggedInUserId, String requestType)
			throws ResourceManagementException {
		Map<Long, ResourceRequirementDto> resourceRequirmentMap = getRequirementMap(employeeAllocationDetails);
		Map<Long, SrfProjection> srfMap = getSrfMap(employeeAllocationDetails);
		Map<Long, SuperVisiorDetailsDto> superVisiorList = getSuperVisiorMap(employeeAllocationDetails);
		Map<Long, ProjectDto> projectMap = getProjectMap(employeeAllocationDetails);
		List<ReasonForDeallocation> reasonForDeallocationList = adminServiceClient.getReasonForDeallocation();
		for (AllocatedResourceProjection allocatedResourceProjection : employeeAllocationDetails) {
			EmployeeDto empDto = new EmployeeDto();
			empDto.setServiceLineName(tAssociateAllocationRepository
					.getServiceLineByServiceLineId(allocatedResourceProjection.getServiceLineId()));
			empDto.setAssociateAllocationId(allocatedResourceProjection.getAssociateAllocationId());
			empDto.setEmployeeId(allocatedResourceProjection.getEmployeeId());
			empDto.setEmployeeProjectId(allocatedResourceProjection.getProjectId());
			//added check by Ravi
			if(null!=allocatedResourceProjection.getFtePercent())
			{
				empDto.setFte_percent(allocatedResourceProjection.getFtePercent());
			}
			else
			{
				empDto.setFte_percent(0.0);
			}
			empDto.setActualAllocationDate(allocatedResourceProjection.getActualStartDate());
			empDto.setEstimatedEndDate(allocatedResourceProjection.getEstEndDate());
			empDto.setApprovedReleaseDate(allocatedResourceProjection.getActualAllocationEndDate());
			empDto.setRequirementId(allocatedResourceProjection.getRequirementId());
			//Added below by Mrunal Marne
			if(requestType.equalsIgnoreCase("allocated")) {
//				empDto.setPrimaryProjectStatusId(allocatedResourceProjection.getIsPrimaryProjectFlag() == 1 ? true : false);
				//added by devAk
				empDto.setPrimaryProjectStatusId((Objects.nonNull(allocatedResourceProjection.getIsPrimaryProjectFlag()))
						&& allocatedResourceProjection.getIsPrimaryProjectFlag() == 1 ? true : false );
				
				empDto.setSkillChampion((Objects.nonNull(allocatedResourceProjection.getSkillChampionFlagInt()) 
						&& allocatedResourceProjection.getSkillChampionFlagInt() == 1) ? true : false);
			} else {
				empDto.setPrimaryProjectStatusId(allocatedResourceProjection.getIsPrimaryProject());
				empDto.setSkillChampion(allocatedResourceProjection.getSkillChampionFlag());
			}
			//End by Mrunal Marne
			empDto.setAssociateProjectId(allocatedResourceProjection.getAssociateProjectId());
			if(allocatedResourceProjection.getcomments()!=null)
				empDto.setComments(allocatedResourceProjection.getcomments());
			else
				empDto.setComments("OK");
			// empDto.setApprovedReleaseDate(allocatedResourceProjection.getDeallocationDate());
			empDto.setProjectId(allocatedResourceProjection.getProjectId());
			if(allocatedResourceProjection.getemployeeCostRate()!=null)
				empDto.setEmployeeCostRate(allocatedResourceProjection.getemployeeCostRate());
			else
				empDto.setEmployeeCostRate(0D);
			empDto.setReasonForDeallocationList(reasonForDeallocationList);
			empDto.setAllocationTypeId(allocatedResourceProjection.getAllocationTypeId());
			empDto.setAllocationType(tAssociateAllocationRepository.getAllocationTypeByAllocationTypeId(allocatedResourceProjection.getAllocationTypeId()));
			List<Long> totalFteForEmployee = tAssociateAllocationRepository.getTotalFteForEmployee(allocatedResourceProjection.getWorkflowStatusId(), allocatedResourceProjection.getStatusId(), empDto.getEmployeeId());
			Long totalFte = 0l; 
			for(Long l:totalFteForEmployee) {
				totalFte= totalFte + l; 
			}
			empDto.setAvailability(100- totalFte);
			Long skillId = allocatedResourceProjection.getdefaultSkillId();
			if (null != skillId) {
				List<Long> skillIdList = new ArrayList<>();
				skillIdList.add(skillId);
				List<SkillTaxonomyDto> skillList = adminServiceClient.getSkillFamilyByskillId(skillIdList);
				empDto.setDefaultSkillFamilyDto(skillList.get(0));
				empDto.setDefaultL4SkillName(skillList.get(0).getL4skillName());
			} else {
				 empDto.setDefaultL4SkillName(ResourceManagementConstant.NOT_AVAILABLE);
			}
			setPractiseDetails(empDto, newempDto);
			setBillingStatus(allocatedResourceProjection, empDto);
			setEbrReason(allocatedResourceProjection, empDto);
			ResourceRequirementDto resourceRequirementDto = resourceRequirmentMap
					.get(allocatedResourceProjection.getRequirementId());
			setRequirementDetails(empDto, resourceRequirementDto);
			int workingdays=0;
			if(allocatedResourceProjection.getEstEndDate() != null) {
				workingdays = resourceRequirementServiceImpl.getWorkingDaysBetweenTwoDates(
						allocatedResourceProjection.getActualStartDate(), allocatedResourceProjection.getEstEndDate());
			}else
				throw new ResourceManagementException("Resource end date is not present");
			
			//Added by Mrunal Marne for fetching SO billing hours
			long shoreWorkHour = ResourceManagementConstant.ONSHORE.equalsIgnoreCase(resourceRequirementDto.getShore())
					? 8
					: Objects.nonNull(resourceRequirementServiceImpl.getSOBillingHours(resourceRequirementDto.getProjectName()))
					? resourceRequirementServiceImpl.getSOBillingHours(resourceRequirementDto.getProjectName())
					: 9;
	
			Long allocationEffortsHrs = workingdays * shoreWorkHour;
			empDto.setBilliableEffortsHours(allocationEffortsHrs);
			SrfProjection srfProjection = srfMap.get(allocatedResourceProjection.getsrfId());
			if (null != srfProjection) {
				empDto.setSrfNo(srfProjection.getSrfNumber());
				empDto.setSrfId(allocatedResourceProjection.getsrfId());
			}else 
				empDto.setSrfNo(ResourceManagementConstant.NA);
			setSupervisiorName(superVisiorList, allocatedResourceProjection, empDto);
			setProjectName(projectMap, allocatedResourceProjection, empDto);
			//Added by Shubham to return requestType for tracebility
			String moduleName=null;
			if(methodType.equalsIgnoreCase(ResourceManagementConstant.RESERVED_ALLOCATION)) {
				moduleName = resourceWorkflowRepository.getModuleName(allocatedResourceProjection.getWorkflowStatusId());
				if(moduleName!=null) {
					if(moduleName.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_ALLOCATION))
						empDto.setRequestType(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
					else if(moduleName.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_TRANSFER))
						empDto.setRequestType(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE); 
				}
			}else if(methodType.equalsIgnoreCase(ResourceManagementConstant.RESERVED_DEALLOCATION)) {
				moduleName = resourceWorkflowRepository.getModuleName(allocatedResourceProjection.getWorkflowStatusId());
				if(moduleName!=null && moduleName.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_DEALLOCATION)) 
					empDto.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE); 
			}
			//Added accessFlag by Mrunal Marne
			empDto.setIsAllowedToEdit(getOwnerCount(loggedInUserId, allocatedResourceProjection.getProjectId(), loggedInRoleId)>0);					
			//End by Mrunal Marne
			empList.add(empDto);
		}
	}
	
	private void setBillingStatus(AllocatedResourceProjection allocatedResourceProjection, EmployeeDto empDto)
			throws ResourceManagementException {
		Integer billingStatusId = allocatedResourceProjection.getBillableStatusId();
		if (null != billingStatusId) {
			empDto.setBillingStatus(adminServiceClient.getLookUpById(billingStatusId).getLookupValueCode());
		}
		if(empDto.getBillingStatus().equalsIgnoreCase(ResourceManagementConstant.Billable)) {
			empDto.setBillableUtilization(empDto.getFte_percent());
		}
		else if(empDto.getBillingStatus().equalsIgnoreCase(ResourceManagementConstant.Non_Billable)) {
			empDto.setNonBillableUtilization(empDto.getFte_percent());
		}
	}

	private void setEbrReason(AllocatedResourceProjection allocatedResourceProjection, EmployeeDto empDto)
			throws ResourceManagementException {
		Integer ebrReasonId = allocatedResourceProjection.getebrReason();
		if (null != ebrReasonId) {
			empDto.setEbrReason(adminServiceClient.getLookUpById(ebrReasonId).getLookupType());
		}else
			empDto.setEbrReason(ResourceManagementConstant.NA);
	}

	private void setProjectName(Map<Long, ProjectDto> projectMap,
			AllocatedResourceProjection allocatedResourceProjection, EmployeeDto empDto) {
		if (!projectMap.isEmpty()) {
			Long projectId = allocatedResourceProjection.getProjectId();
			String projetName = projectMap.get(projectId).getProjectName();
			String projectCode = projectMap.get(projectId).getProjectCode();
			Date estimatedProjectEndDate=projectMap.get(projectId).getEstEndDate();
			empDto.setProjectName(projetName);
			empDto.setProjectCode(projectCode);
			empDto.setEstimatedProjectEndDate(estimatedProjectEndDate);
		}
	}

	private void setSupervisiorName(Map<Long, SuperVisiorDetailsDto> superVisiorList,
			AllocatedResourceProjection allocatedResourceProjection, EmployeeDto empDto) {
		Long supervisiorId = allocatedResourceProjection.getsuperVisorId();
		if(!superVisiorList.isEmpty()) {
			if (null != supervisiorId) {
				SuperVisiorDetailsDto supervisiorDto = superVisiorList.get(supervisiorId);
				if (null != supervisiorDto) {
					String supervisiorName = supervisiorDto.getEmpName();
					if (null != supervisiorName) {
						empDto.setSupervisorId(supervisiorDto.getEmpId());
						empDto.setSuperVisiorName(supervisiorName);
					}else
						empDto.setSuperVisiorName(ResourceManagementConstant.NA);
				}else {
					SupervisorProjection superVisor = tAssociateAllocationRepository.getSupervisorsList(allocatedResourceProjection.getProjectId());
					extractedSupervisor(empDto, superVisor);
				}
			}
		} else {
			SupervisorProjection superVisor = tAssociateAllocationRepository.getSupervisorsList(allocatedResourceProjection.getProjectId());
			extractedSupervisor(empDto, superVisor);
		}
	}

	private void extractedSupervisor(EmployeeDto empDto, SupervisorProjection superVisor) {
		if (null != superVisor) {
			String supervisiorName = superVisor.getEmpName();
			if (null != supervisiorName) {
				empDto.setSupervisorId(superVisor.getEmpId());
				empDto.setSuperVisiorName(superVisor.getEmpName());
			}else
				empDto.setSuperVisiorName(ResourceManagementConstant.NA);
		}
	}

	private Map<Long, ProjectDto> getProjectMap(List<AllocatedResourceProjection> employeeAllocationDetails)
			throws ResourceManagementException {
		List<Long> projectIds = employeeAllocationDetails.stream().map(AllocatedResourceProjection::getProjectId)
				.collect(Collectors.toList());
		List<ProjectDto> projectList = new ArrayList<>();
		if (!projectIds.isEmpty()) {
			projectList = bapServiceClient.getProjectDetailByIds(projectIds);
		}
		return projectList.stream().collect(Collectors.toMap(ProjectDto::getProjectId, projectDto -> projectDto));
	}

	private Map<Long, SuperVisiorDetailsDto> getSuperVisiorMap(
			List<AllocatedResourceProjection> employeeAllocationDetails) throws ResourceManagementException {
		List<Long> empIds = employeeAllocationDetails.stream().map(AllocatedResourceProjection::getsuperVisorId)
				.collect(Collectors.toList());
		List<SuperVisiorDetailsDto> listOfSuperVisior = null;
		if (!empIds.isEmpty()) 
			listOfSuperVisior = adminServiceClient.getSuperVisiorList(empIds);
		if(listOfSuperVisior!=null)
			return	listOfSuperVisior.stream().collect(
					Collectors.toMap(SuperVisiorDetailsDto::getEmpId, superVisiorDetailsDto -> superVisiorDetailsDto));
		else
			return Collections.emptyMap();
	}

	private Map<Long, ResourceRequirementDto> getRequirementMap(
			List<AllocatedResourceProjection> employeeAllocationDetails) throws ResourceManagementException {
		List<Long> reqIds = employeeAllocationDetails.stream().map(AllocatedResourceProjection::getRequirementId)
				.collect(Collectors.toList());
		List<ResourceRequirementDto> requirementDetails = new ArrayList<>();
		if (!reqIds.isEmpty()) {
			requirementDetails = bapServiceClient.getResourceRequiremetList(reqIds);
		}
		return requirementDetails.stream().collect(
				Collectors.toMap(ResourceRequirementDto::getReqId, resourceRequirementDto -> resourceRequirementDto));

	}

	private Map<Long, SrfProjection> getSrfMap(List<AllocatedResourceProjection> employeeAllocationDetails) {
		List<Long> srfIds = employeeAllocationDetails.stream().map(AllocatedResourceProjection::getsrfId)
				.collect(Collectors.toList());
		List<SrfProjection> srfList = tSrfRepository.findBysrfId(srfIds);
		return srfList.stream().collect(Collectors.toMap(SrfProjection::getSrfId, srfProjection -> srfProjection));
	}

	private void setRequirementDetails(EmployeeDto empDto, ResourceRequirementDto resourceRequirementDto) {
		if (null != resourceRequirementDto) {
			empDto.setResourceRequirementLocation(resourceRequirementDto.getResourceRequirementLocation());
			// empDto.setServiceLineName(resourceRequirementDto.getServiceLineName());
			empDto.setLocationType(resourceRequirementDto.getShore());
			empDto.setBillingRateInUSD(resourceRequirementDto.getBillingRateInUSD());
			empDto.setRole(resourceRequirementDto.getRequirementRole());
			empDto.setEmployeeLocation(resourceRequirementDto.getResourceRequirementLocation());
			empDto.setVersion(resourceRequirementDto.getVersion());
			empDto.setLocationType(resourceRequirementDto.getShore());
			//Added by Mrunal Marne for adding requirement est. end date
			empDto.setEstimatedRequirementEndDate(resourceRequirementDto.getRequirementEndDate());
		}
	}

	public Map<Long, EmployeeDto> getPractiseDetails(List<Long> empIds) throws ResourceManagementException {
		List<EmployeeDto> practiseDetails = adminServiceClient.getAssociatesDetails(empIds);
		return practiseDetails.stream()
				.collect(Collectors.toMap(EmployeeDto::getEmployeeId, employeemap -> employeemap));
	}

	private void setPractiseDetails(EmployeeDto empDto, EmployeeDto newempDto) {
		if (null != newempDto) {
			empDto.setEmployeeName(newempDto.getEmployeeName());
			empDto.setPracticeName(newempDto.getPracticeName());
			empDto.setSkills(newempDto.getSkills());
			empDto.setVersion(newempDto.getVersion());
			empDto.setPhaseName(newempDto.getPhaseName());
			empDto.setEmployeeNumber(newempDto.getEmployeeNumber());
			empDto.setBand(newempDto.getBand());
		}
	}

	@Override
	public List<SupervisorDto> getSupervisorList(Long projectId) throws ResourceManagementException {
		List<SupervisorDto> supervisorList = new ArrayList<>();
		Long statusIdForActive = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
		List<Long> empIdList = tAssociateProjectRepository.getEmpIdByProjectId(projectId, statusIdForActive);
		//Added by Mrunal Marne for getting project owners in supervisors list
		List<Long> projectOwnersList = adminServiceClient.getRMSupervisorsList(projectId);
		if(Objects.nonNull(projectOwnersList))
			empIdList.addAll(projectOwnersList);
		//End by Mrunal Marne
		List<EmployeeDto> employeeDtoList = adminServiceClient.getAssociatesDetailsbyEmpIds(empIdList);
		for (EmployeeDto employeeDto : employeeDtoList) {
			SupervisorDto supervisorDto = new SupervisorDto();
			supervisorDto.setSupervisorId(employeeDto.getEmployeeId());
			supervisorDto.setEmployeeNumber(employeeDto.getEmployeeNumber());
			supervisorDto.setSupervisorName(employeeDto.getEmployeeName());
			supervisorList.add(supervisorDto);
		}
		return supervisorList;
	}

	/**
	 * Service method for edit/update for Search By Associate and Project
	 * 
	 * @throws ParseException
	 */
	@Override
	@Transactional(readOnly = false)
	public void updateProjectDtlsForSearch(ResourceSearchDto resourceSearchDto)
			throws ResourceManagementException, ParseException {
		log.info("Entered into ResourceSearchServiceImpl.updateProjectDtlsForSearch method:");
		if(getOwnerCount(resourceSearchDto.getUserId(), resourceSearchDto.getEmployeeList().get(0).getProjectId(), resourceSearchDto.getRoleId())>0) {
			List<Long> empIdList = new ArrayList<>();
			Long activeStatusId = resourceManagementServiceImpl
					.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
			Long approvedStatus = resourceManagementServiceImpl
					.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED);
			ResourceRequirementDto resourceRequirementDto = bapServiceClient
					.getRequirementDetailByReqId(resourceSearchDto.getEmployeeList().get(0).getRequirementId());
	
			empIdList.add(resourceSearchDto.getEmployeeList().get(0).getEmployeeId());
	
			List<TAssociateAllocation> rAllocationDetailList = tAssociateAllocationRepository.getRAllocationDetails(
					resourceSearchDto.getEmployeeList().get(0).getProjectId(), activeStatusId, empIdList,
					resourceSearchDto.getEmployeeList().get(0).getRequirementId(), approvedStatus);
			if (CollectionUtils.isNotEmpty(rAllocationDetailList)) {
				TAssociateAllocation rAllocationDetail = rAllocationDetailList.get(0);
				TAssociateProject associateProject = rAllocationDetailList.get(0).getTAssociateProject();
				createSaveobjectForUpdate(resourceSearchDto, rAllocationDetail, associateProject, resourceRequirementDto);
			} else {
				throw new ResourceManagementException(ResourceManagementConstant.INVALID_REQUEST_TYPE);
			}
		}else {
			throw new ResourceManagementException(ResourceManagementConstant.NOT_AUTHORIZED);
		}
		log.info("Exited into ResourceSearchServiceImpl.updateProjectDtlsForSearch method:");
	}

	public int getOwnerCount(Long userId, Long projectId, Long loggedInRoleId) throws ResourceManagementException {
		return adminServiceClient.getOwnerCount(userId, projectId, loggedInRoleId);
	}

	public TAssociateProject setTAssociateProject(TAssociateProject associateProject, EmployeeDto employeeDto) {
		associateProject.setEmployeeId(employeeDto.getEmployeeId());
		associateProject.setProjectId(employeeDto.getProjectId());
		if(employeeDto.getSupervisorId()!=null)
			associateProject.setSupervisorId(employeeDto.getSupervisorId());
		if (Boolean.TRUE.equals(employeeDto.getPrimaryProjectStatusId())) {
			associateProject.setIsPrimaryProject(1l);
		} else {
			associateProject.setIsPrimaryProject(0l);
		}
		associateProject.setLastUpdatedDate(new Date());
		tAssociateProjectRepository.save(associateProject);
		return associateProject;
	}

	public TAssociateAllocation createAssociateAllocationObject(TAssociateAllocation rAllocationDetail,
			EmployeeDto employeeDto) throws ResourceManagementException, ParseException {

		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		tAssociateAllocation.setRoleId(rAllocationDetail.getRoleId());
		tAssociateAllocation.setRequirementId(rAllocationDetail.getRequirementId());
		tAssociateAllocation.setWorkLocationId(rAllocationDetail.getWorkLocationId());
		tAssociateAllocation.setBillableStatusId(rAllocationDetail.getBillableStatusId());
		tAssociateAllocation.setBillableStatusReasonId(rAllocationDetail.getBillableStatusReasonId());
		tAssociateAllocation.setEstAllocationEndDate(rAllocationDetail.getEstAllocationEndDate());
		tAssociateAllocation.setActualAllocationStartDate(rAllocationDetail.getActualAllocationStartDate());
		tAssociateAllocation.setActualAllocationEndDate(rAllocationDetail.getActualAllocationEndDate());
		tAssociateAllocation.setBaseHours(rAllocationDetail.getBaseHours());
		tAssociateAllocation.setWorkflowStatusId(rAllocationDetail.getWorkflowStatusId());
		tAssociateAllocation.setStatusId(rAllocationDetail.getStatusId());
		tAssociateAllocation.setCreatedBy(rAllocationDetail.getCreatedBy());
		tAssociateAllocation.setLastUpdatedBy(rAllocationDetail.getLastUpdatedBy());
		tAssociateAllocation.setLastUpdatedDate(new Date());
		tAssociateAllocation.setTransactionHistoryId(rAllocationDetail.getTransactionHistoryId());
		tAssociateAllocation.setAllocationTypeId(rAllocationDetail.getAllocationTypeId());
		tAssociateAllocation.setFtePercent(rAllocationDetail.getFtePercent());
		tAssociateAllocation.setSkillId(rAllocationDetail.getSkillId());
		tAssociateAllocation.setServiceLineId(rAllocationDetail.getServiceLineId());
		tAssociateAllocation.setStdCost(rAllocationDetail.getStdCost());
		
		if(employeeDto.getSkillChampion()!=null)
			tAssociateAllocation.setSkillChampionFlag(employeeDto.getSkillChampion());
		else
			tAssociateAllocation.setSkillChampionFlag(rAllocationDetail.getSkillChampionFlag());
		if(employeeDto.getCapHours()>0)
			tAssociateAllocation.setCapHours(employeeDto.getCapHours());
		else
			tAssociateAllocation.setCapHours(rAllocationDetail.getCapHours());
		if(employeeDto.getSupervisorId()!=null)
			tAssociateAllocation.setSupervisorId(employeeDto.getSupervisorId());
		else
			tAssociateAllocation.setSupervisorId(rAllocationDetail.getSupervisorId());
		if(employeeDto.getEffectiveStartDate()!=null) {
			Date jvDate = jvDetailsRepository.getWindowEndDate();
			if (Boolean.TRUE.equals(jvCheckHelperService.isJvCheckForSearch(jvDate, rAllocationDetail.getEffectiveStartDate(),
					employeeDto.getEffectiveStartDate()))) {
				tAssociateAllocation.setEffectiveEndDate(rAllocationDetail.getEffectiveEndDate());
				tAssociateAllocation.setEffectiveStartDate(employeeDto.getEffectiveStartDate());
			} else {
				throw new ResourceManagementException(ResourceManagementConstant.EFFECTIVE_DATE_CHECK);
			}
		}else {
			tAssociateAllocation.setEffectiveEndDate(rAllocationDetail.getEffectiveEndDate());
			tAssociateAllocation.setEffectiveStartDate(rAllocationDetail.getEffectiveStartDate());
		}
		tAssociateAllocation.setRemarks(employeeDto.getComments());
		return tAssociateAllocation;
	}

	/**
	 * Integrated method for search by skill,Project and Practice.
	 */
	@Override
	@Transactional(readOnly = true)
	public ResourceSearchDto getResourceDetails(String searchKey, long searchValueId, Long loggedInRoleId, Long loggedInUserId)
			throws ResourceManagementException {
		log.info("Entered into ResourceTransferServiceImpl.getSearchDetailsForResource method:");
		ResourceSearchDto resourceDtlsList = null;

		if (searchKey.equals(ResourceManagementConstant.BY_PRACTICE)) {
			resourceDtlsList = getResourceDtlsListByPractice(searchValueId);
		} else if (searchKey.equals(ResourceManagementConstant.BY_SKILL)) {
			resourceDtlsList = getResourceDtlsListBySkill(searchValueId);
		} else if (searchKey.equals(ResourceManagementConstant.BY_PROJECT)) {
			resourceDtlsList = getAssociateListByProjectId(searchValueId, loggedInRoleId, loggedInUserId);
		}

		log.info("Exited from ResourceTransferServiceImpl.getSearchDetailsForResource method:");
		return resourceDtlsList;
	}

	/**
	 * Fetches list for Search types.
	 */
	@Override
	@Transactional(readOnly = true)
	public List<LookupValueDto> getSearchList() throws ResourceManagementException {
		log.info("Entered from ResourceSearchServiceImpl.getSearchList method:");
		return adminServiceClient.getLookupValueByLookupType(ResourceManagementConstant.SEARCH_BY);
	}

	@Override
	@Transactional(readOnly = false)
	public void saveResourcesForExtension(ResourceSearchDto resourceSearchDto) throws ResourceManagementException {
		log.info("Entered into ResourceSearchServiceImpl.saveResourcesForExtension method:");
		if(getOwnerCount(resourceSearchDto.getUserId(), resourceSearchDto.getEmployeeList().get(0).getProjectId(), resourceSearchDto.getRoleId())>0) {
			Long statusIdForActive = resourceManagementServiceImpl
					.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
			Long statusIdSubmittedForExt = resourceManagementServiceImpl
					.getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION, ResourceManagementConstant.SUBMITTED);
			List<TAssociateAllocation> associateAllocationList = null;
			List<Long> associateAllocationIdList = null;
			if (CollectionUtils.isNotEmpty(resourceSearchDto.getEmployeeList())) {
	
				if (resourceSearchDto.getSupervisorId() != null && isSupervisorUpdated(resourceSearchDto.getEmployeeList(),
						resourceSearchDto.getSupervisorId(), statusIdForActive)) {
					log.info("Supervisor updated sucessfully");
				}
	
				if (resourceSearchDto.getEstEndDate() != null) {
					Long projectId = resourceSearchDto.getEmployeeList().get(0).getProjectId();
					List<Long> associateProjectIdList = new ArrayList<>();
					if (resourceAllocationServiceImpl.getBudgetAndCostCheck(projectId)) {
						associateProjectIdList = getAssoPrjtIdIfBudgetCheckPassed(resourceSearchDto);
					} else {
						for (EmployeeDto employeeDto : resourceSearchDto.getEmployeeList()) {
							TAssociateProject tAssociateProject = tAssociateProjectRepository
									.findByAssociateProjectId(employeeDto.getAssociateProjectId());
							associateProjectIdList.add(tAssociateProject.getAssociateProjectId());
						}
					}
					if (associateProjectIdList!=null && CollectionUtils.isNotEmpty(associateProjectIdList)) {
						associateAllocationList = tAssociateAllocationRepository
								.getAssociateAllocationIdByProjectId(associateProjectIdList, statusIdForActive);
						associateAllocationIdList = associateAllocationList.stream()
								.map(TAssociateAllocation::getAssociateAllocationId).collect(Collectors.toList());
						if (!checkEmpListIsInWorkflow(associateAllocationList, statusIdForActive,
								statusIdSubmittedForExt)) {
							List<Long> roleIds = adminServiceClient.getRoleIds(List.of(
									ResourceManagementConstant.TAG_ROLE_NAME, ResourceManagementConstant.ADMIN_ROLE_NAME));
							if (roleIds.contains(resourceSearchDto.getRoleId())) {
								tAssociateAllocationRepository.updateEstEndDate(resourceSearchDto.getEstEndDate(),
										associateAllocationIdList, statusIdForActive, tAssociateAllocationRepository.getEmployeeId(resourceSearchDto.getUserId()));
								log.info("Extension Successfull : Est End Date is updated by TAG/ADMIN");
							} else {
								saveExtensionAndSubmitWrkflw(associateAllocationList, resourceSearchDto, statusIdForActive,
										statusIdSubmittedForExt);
								log.info("Extension successfully saved and submitted");
							}
						}
					}else {
						throw new ResourceManagementException(ResourceManagementConstant.BUDGET_CHECK_FAILED);
					}
				}
			} else {
				throw new ResourceManagementException(ResourceManagementConstant.INVALID_REQUEST_TYPE);
			}
		}else {
			throw new ResourceManagementException(ResourceManagementConstant.NOT_AUTHORIZED);
		}
		log.info("Exiting into ResourceSearchServiceImpl.saveResourcesForExtension method:");
	}

	public List<Long> getAssoPrjtIdIfBudgetCheckPassed(ResourceSearchDto resourceSearchDto)
			throws ResourceManagementException {
		boolean isBudgetCheckPassed = true;
		List<TAssociateProject> tAssociateProjectList = new ArrayList<>();
		List<Long> associateProjectIdList = new ArrayList<>();
		Long projectId = resourceSearchDto.getEmployeeList().get(0).getProjectId();
		List<ProjectBudgetDto> projectBudgetDto = budgetControlServiceClient.getProjectMonthlyBudgetsDetails(projectId);
		Map<String, ProjectBudgetDto> projectBudgets = projectBudgetDto.stream().collect(HashMap::new,
				(m, v) -> m.put(v.getMonth(), v), HashMap::putAll);
		for (EmployeeDto employeeDto : resourceSearchDto.getEmployeeList()) {
			ResourceRequirementDto resourceRequirementDto = bapServiceClient
					.getRequirementDetailByReqId(employeeDto.getRequirementId());
			TAssociateProject tAssociateProject = tAssociateProjectRepository
					.findByAssociateProjectId(employeeDto.getAssociateProjectId());
			TAssociateProjectDto tAssociateProjectDto = tAssociateProjectMapper
					.tAssociateProjectToTAssociateProjectDto(tAssociateProject);
			
			
			Calendar c = Calendar.getInstance(); 
			c.setTime(tAssociateProjectDto.getTAssociateAllocation().getEstAllocationEndDate()); 
			c.add(Calendar.DATE, 1);
			Date allocationDate = c.getTime();
			
			//LocalDateTime allocationDate = LocalDateTime.from(tAssociateProjectDto.getTAssociateAllocation().getEstAllocationEndDate().toInstant()).plusDays(1);
			tAssociateProjectDto.getTAssociateAllocation().setActualAllocationStartDate(allocationDate);
			tAssociateProjectDto.getTAssociateAllocation().setEstAllocationEndDate(resourceSearchDto.getEstEndDate());
			List<TAssociateProjectDto> tAssociateProjectDtoForOneObj = Arrays.asList(tAssociateProjectDto);
			tAssociateProjectList.add(tAssociateProject);
			associateProjectIdList.add(tAssociateProject.getAssociateProjectId());
			if (!resourceAllocationServiceImpl.performBudgetControlCheck(resourceRequirementDto,
					tAssociateProjectDtoForOneObj, projectBudgets)) {
				isBudgetCheckPassed = false;
				log.info("Validation Failed : Budget Check failed");
				break;
			}
			if (isBudgetCheckPassed) {
				resourceAllocationServiceImpl.updateBudget(projectBudgets);
			}
		}
		return (isBudgetCheckPassed) ? associateProjectIdList : null;
	}

	public void saveExtensionAndSubmitWrkflw(List<TAssociateAllocation> associateAllocationList,
			ResourceSearchDto resourceSearchDto, Long statusIdForActive, Long statusIdSubmittedForExt)
			throws ResourceManagementException {
		List<TAssociateExtension> alloListExtLockingPeriod = new ArrayList<>();
		List<TAssociateExtension> alloListExtension = new ArrayList<>();
		List<TAssociateExtension> tAssociateExtension = tAssociateExtensionRepository
				.saveAll(createTAssociateExtensionObject(associateAllocationList, resourceSearchDto.getEstEndDate(),
						statusIdForActive, statusIdSubmittedForExt));
		Map<Long, TAssociateAllocation> associateExtensionDltsMap = associateAllocationList.stream()
				.collect(HashMap::new, (m, v) -> m.put(v.getAssociateAllocationId(), v), HashMap::putAll);

		for (TAssociateExtension tAssociateAllocation : tAssociateExtension) {
			Long difference = (associateExtensionDltsMap.get(tAssociateAllocation.getTransactionHistoryId())
					.getEstAllocationEndDate().getTime() - new Date().getTime()) / 86400000;
			if (difference <= 28)
				alloListExtLockingPeriod.add(tAssociateAllocation);
			else
				alloListExtension.add(tAssociateAllocation);
		}

		if (!CollectionUtils.isEmpty(alloListExtLockingPeriod))
			resourceExtensionUtils
					.submitRMApproval(createRMApprovalObject(resourceSearchDto, true, alloListExtLockingPeriod));
		if (!CollectionUtils.isEmpty(alloListExtension))
			resourceManagementServiceImpl
					.submitRMApproval(List.of(createRMApprovalObject(resourceSearchDto, false, alloListExtension)));
	}

	public RMApprovalInputDto createRMApprovalObject(ResourceSearchDto resourceSearchDto,
			boolean isResourceListForLockingPeriod, List<TAssociateExtension> tAssociateAllocationList)
			throws ResourceManagementException {
		RMApprovalInputDto rmApprovalInputDto = new RMApprovalInputDto();
		List<RMApproversDto> rmApproversList = null;
		rmApprovalInputDto.setUserId(resourceSearchDto.getUserId());
		rmApprovalInputDto.setRoleId(resourceSearchDto.getRoleId());
		rmApprovalInputDto.setRoleName(resourceSearchDto.getRoleName());
		rmApprovalInputDto.setUserName(resourceSearchDto.getUserName());
		rmApprovalInputDto.setProjectId(resourceSearchDto.getProjectId());
		if (isResourceListForLockingPeriod) {
			rmApproversList = resourceExtensionUtils.getRMApproversList(resourceSearchDto.getProjectId(),
					resourceSearchDto.getUserId(), resourceSearchDto.getRoleId(),
					ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD);
			rmApprovalInputDto
					.setRequestType(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD);
		} else {
			rmApproversList = resourceExtensionUtils.getRMApproversList(resourceSearchDto.getProjectId(),
					resourceSearchDto.getUserId(), resourceSearchDto.getRoleId(),
					ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
			rmApprovalInputDto.setRequestType(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		}
		rmApprovalInputDto.setRmApproversList(rmApproversList);
		rmApprovalInputDto.setTAssociateExtensionList(tAssociateAllocationList);
		rmApprovalInputDto.setProposedEsEndDate(resourceSearchDto.getEstEndDate());
		Map<Long, Date> empCurrentEstEndDateMap =resourceSearchDto.getEmployeeList().stream().collect(Collectors.toMap(EmployeeDto::getEmployeeId, EmployeeDto::getEstimatedEndDate));
		rmApprovalInputDto.setEmpCurrentEstEndDateMap(empCurrentEstEndDateMap);
		rmApprovalInputDto.setEmployeeIdList(resourceSearchDto.getEmployeeList().stream().map(EmployeeDto::getEmployeeId).collect(Collectors.toList()));
		return rmApprovalInputDto;
	}

	public boolean isSupervisorUpdated(List<EmployeeDto> employeeDtoList, Long supervisorId, Long statusIdForActive)
			throws ResourceManagementException {
		boolean isSupervisorOfHigherBand = true;
		List<Long> associateAllocationIdList = new ArrayList<>();
		EmployeeDto supervisorEmployeeDto = adminServiceClient.getEmployeeDetails(supervisorId);
		for (EmployeeDto employeeDto : employeeDtoList) {
			associateAllocationIdList.add(employeeDto.getAssociateAllocationId());
			if (employeeDto.getBand().compareTo(supervisorEmployeeDto.getBand()) < 0) {
				isSupervisorOfHigherBand = false;
				log.info("Validation Failed : Employee Band is higher than Supervisor employeeDto.getBand()::{}");
				break;
			}
		}
		if (isSupervisorOfHigherBand) {
			Long statusIdForDeactive = resourceManagementServiceImpl.getModuleStatusId(
					ResourceManagementConstant.RESOURCE_EXTENSION, ResourceManagementConstant.DEACTIVATE);
			tAssociateAllocationRepository.updateStatusIdDeactive(statusIdForDeactive, associateAllocationIdList);
			List<TAssociateAllocation> associateAllocationList = tAssociateAllocationRepository
					.getAssociateAllocationById(associateAllocationIdList);
			tAssociateAllocationRepository
					.saveAll(createAssociateAlloObject(associateAllocationList, supervisorId, statusIdForActive));
		}
		return isSupervisorOfHigherBand;
	}

	public List<TAssociateAllocation> createAssociateAlloObject(List<TAssociateAllocation> associateAllocationList,
			Long supervisorId, Long statusIdForActive) throws ResourceManagementException {
		List<TAssociateAllocation> assAlloListWithUpdatedSupervisor = new ArrayList<>();

		Long wfIdForApproved = resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED_ACTION);
		for (TAssociateAllocation associateAllocation : associateAllocationList) {

			TAssociateAllocation assAlloWithUpdatedSupervisor = new TAssociateAllocation();
			assAlloWithUpdatedSupervisor.setTAssociateProject(associateAllocation.getTAssociateProject());
			assAlloWithUpdatedSupervisor.setCreatedBy(associateAllocation.getCreatedBy());
			assAlloWithUpdatedSupervisor.setCreatedDate(associateAllocation.getCreatedDate());
			assAlloWithUpdatedSupervisor.setLastUpdatedBy(associateAllocation.getLastUpdatedBy());
			assAlloWithUpdatedSupervisor.setLastUpdatedDate(new Date());
			assAlloWithUpdatedSupervisor.setStatusId(statusIdForActive);
			assAlloWithUpdatedSupervisor.setEffectiveEndDate(associateAllocation.getEffectiveEndDate());
			assAlloWithUpdatedSupervisor.setEffectiveStartDate(associateAllocation.getEffectiveStartDate());
			assAlloWithUpdatedSupervisor
					.setActualAllocationStartDate(associateAllocation.getActualAllocationStartDate());
			assAlloWithUpdatedSupervisor.setEstAllocationEndDate(associateAllocation.getEstAllocationEndDate());
			assAlloWithUpdatedSupervisor.setFtePercent(associateAllocation.getFtePercent());
			assAlloWithUpdatedSupervisor.setRequirementId(associateAllocation.getRequirementId());
			assAlloWithUpdatedSupervisor.setRemarks(associateAllocation.getRemarks());
			assAlloWithUpdatedSupervisor.setRoleId(associateAllocation.getRoleId());
			assAlloWithUpdatedSupervisor.setWorkLocationId(associateAllocation.getWorkLocationId());
			assAlloWithUpdatedSupervisor.setBaseHours(associateAllocation.getBaseHours());
			assAlloWithUpdatedSupervisor.setWorkflowReasonId(associateAllocation.getWorkflowReasonId());
			assAlloWithUpdatedSupervisor.setBillableStatusId(associateAllocation.getBillableStatusId());
			assAlloWithUpdatedSupervisor.setBillableStatusReasonId(associateAllocation.getBillableStatusReasonId());
			assAlloWithUpdatedSupervisor.setActualAllocationEndDate(associateAllocation.getActualAllocationEndDate());

			assAlloWithUpdatedSupervisor.setWorkflowStatusId(wfIdForApproved);
			assAlloWithUpdatedSupervisor.setTransactionHistoryId(associateAllocation.getAssociateAllocationId());
			assAlloWithUpdatedSupervisor.setSupervisorId(supervisorId);
			assAlloListWithUpdatedSupervisor.add(assAlloWithUpdatedSupervisor);
		}
		return assAlloListWithUpdatedSupervisor;
	}

	public boolean checkEmpListIsInWorkflow(List<TAssociateAllocation> associateAllocationList, Long statusIdForActive,
			Long statusIdSubmittedForExt) throws ResourceManagementException {
		boolean isEmpListIsInWorkflow = false;
		List<String> subModuleList = List.of(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.RESOURCE_EXTENSION);
		List<String> actionList = List.of(ResourceManagementConstant.SAVED, ResourceManagementConstant.SUBMITTED,
				ResourceManagementConstant.SUBMITTED, ResourceManagementConstant.SUBMITTED,
				ResourceManagementConstant.SUBMITTED);
		List<Long> wfStatusIdForSelectedEmp = associateAllocationList.stream()
				.map(TAssociateAllocation::getWorkflowStatusId).collect(Collectors.toList());
		List<Long> intersection = getWfStatusIdList(subModuleList, actionList).stream()
				.filter(wfStatusIdForSelectedEmp::contains).collect(Collectors.toList());
		List<Long> associateAllocationIds = associateAllocationList.stream()
				.map(TAssociateAllocation::getAssociateAllocationId).collect(Collectors.toList());
		List<TAssociateExtension> tAssociateExtensionList = tAssociateExtensionRepository
				.getExtensionByTransactionId(associateAllocationIds, statusIdForActive, statusIdSubmittedForExt);
		List<TAssociateDeAllocation> tAssociateDeAllocationList = tAssociateDeAllocationRepository
				.getDeallocationByAssoAlloId(associateAllocationIds, statusIdForActive,
						getWfStatusIdList(List.of(ResourceManagementConstant.RESOURCE_DEALLOCATION),
								List.of(ResourceManagementConstant.SUBMITTED, ResourceManagementConstant.SAVED)));
		if (!intersection.isEmpty() || CollectionUtils.isNotEmpty(tAssociateExtensionList)
				|| CollectionUtils.isNotEmpty(tAssociateDeAllocationList)) {
			isEmpListIsInWorkflow = true;
			log.info("Validation Failed : selected Employees are already in workflow");
			throw new ResourceManagementException(ResourceManagementConstant.EMPLOYEE_ALREADY_IN_WORKFLOW);
		}
		return isEmpListIsInWorkflow;
	}

	public List<TAssociateExtension> createTAssociateExtensionObject(
			List<TAssociateAllocation> tAssociateAllocationList, Date estEndDate, Long statusIdForActive,
			Long statusIdSubmittedForExt) {
		List<TAssociateExtension> tAssociateExtensionList = new ArrayList<>();

		for (TAssociateAllocation tAssociateAllocation : tAssociateAllocationList) {

			TAssociateExtension tAssociateExtension = new TAssociateExtension();
			tAssociateExtension.setActualAllocationEndDate(tAssociateAllocation.getActualAllocationEndDate());
			tAssociateExtension.setRequirementId(tAssociateAllocation.getRequirementId());

			tAssociateExtension.setTAssociateProject(tAssociateAllocation.getTAssociateProject());
			tAssociateExtension.setCreatedBy(tAssociateAllocation.getCreatedBy());
			tAssociateExtension.setCreatedDate(tAssociateAllocation.getCreatedDate());
			tAssociateExtension.setLastUpdatedBy(tAssociateAllocation.getLastUpdatedBy());
			tAssociateExtension.setLastUpdatedDate(new Date());
			tAssociateExtension.setStatusId(statusIdForActive);
			tAssociateExtension.setEffectiveEndDate(tAssociateAllocation.getEffectiveEndDate());
			tAssociateExtension.setEffectiveStartDate(tAssociateAllocation.getEffectiveStartDate());
			tAssociateExtension.setActualAllocationStartDate(tAssociateAllocation.getActualAllocationStartDate());
			tAssociateExtension.setFtePercent(tAssociateAllocation.getFtePercent());
			tAssociateExtension.setRequirementId(tAssociateAllocation.getRequirementId());
			tAssociateExtension.setRemarks(tAssociateAllocation.getRemarks());
			tAssociateExtension.setRoleId(tAssociateAllocation.getRoleId());
			tAssociateExtension.setWorkLocationId(tAssociateAllocation.getWorkLocationId());
			tAssociateExtension.setBaseHours(tAssociateAllocation.getBaseHours());
			tAssociateExtension.setWorkflowReasonId(tAssociateAllocation.getWorkflowReasonId());
			tAssociateExtension.setBillableStatusId(tAssociateAllocation.getBillableStatusId());
			tAssociateExtension.setBillableStatusReasonId(tAssociateAllocation.getBillableStatusReasonId());
			tAssociateExtension.setActualAllocationEndDate(tAssociateAllocation.getActualAllocationEndDate());

			tAssociateExtension.setSupervisorId(tAssociateAllocation.getTAssociateProject().getSupervisorId());
			if (null != tAssociateAllocation.getSupervisorId())
				tAssociateExtension.setSupervisorId(tAssociateAllocation.getSupervisorId());
			tAssociateExtension.setWorkflowStatusId(statusIdSubmittedForExt);
			tAssociateExtension.setEstAllocationEndDate(estEndDate);
			tAssociateExtension.setTransactionHistoryId(tAssociateAllocation.getAssociateAllocationId());
			tAssociateExtensionList.add(tAssociateExtension);
		}

		return tAssociateExtensionList;
	}

	public RMApprovalInputDto createRMApprovalObjectForFte(ResourceSearchDto resourceSearchDto,
			TAssociateAllocation tAssociateAllocation) throws ResourceManagementException {
		RMApprovalInputDto rmApprovalInputDto = new RMApprovalInputDto();
		List<RMApproversDto> rmApproversList = null;
		List<TAssociateAllocation> allocationList = new ArrayList<>();
		rmApprovalInputDto.setUserId(resourceSearchDto.getUserId());
		rmApprovalInputDto.setRoleId(resourceSearchDto.getRoleId());
		rmApprovalInputDto.setRoleName(resourceSearchDto.getRoleName());
		rmApprovalInputDto.setUserName(resourceSearchDto.getUserName());
		rmApproversList = resourceManagementServiceImpl.getRMApproversList(resourceSearchDto.getProjectId(),
				resourceSearchDto.getUserId(), resourceSearchDto.getRoleId(),
				ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE, false);
		rmApprovalInputDto.setRequestType(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		allocationList.add(tAssociateAllocation);
		rmApprovalInputDto.setRmApproversList(rmApproversList);
		// rmApprovalInputDto.setTAssociateAllocationList(allocationList);
		return rmApprovalInputDto;
	}

	public void createSaveobjectForUpdate(ResourceSearchDto resourceSearchDto, TAssociateAllocation rAllocationDetail,
			TAssociateProject associateProject, ResourceRequirementDto resourceRequirementDto)
			throws ResourceManagementException, ParseException {
		List<Long> allocationIdList = new ArrayList<>();
		allocationIdList.add(rAllocationDetail.getAssociateAllocationId());
		List<TAssociateProject> projectList = new ArrayList<>();
		projectList.add(associateProject);
		List<TAssociateProjectDto> associateProjectListDto = tAssociateProjectMapper
				.tAssociateProjectToTAssociateProjectDto(projectList);

		Long deactiveStatusId = resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.DEACTIVATE);
		if (resourceSearchDto.getEmployeeList().get(0).getFte_percent() != rAllocationDetail.getFtePercent()) {
			List<ProjectBudgetDto> projectBudgetDto = budgetControlServiceClient
					.getProjectMonthlyBudgetsDetails(resourceSearchDto.getEmployeeList().get(0).getProjectId());
			Map<String, ProjectBudgetDto> projectBudgets = projectBudgetDto.stream().collect(HashMap::new,
					(m, v) -> m.put(v.getMonth(), v), HashMap::putAll);

			if (resourceAllocationServiceImpl.performBudgetControlCheck(resourceRequirementDto, associateProjectListDto,
					projectBudgets) && associateProject != null) {

				associateProject = setTAssociateProject(associateProject, resourceSearchDto.getEmployeeList().get(0));
				TAssociateAllocation tAssociateAllocation = createAssociateAllocationObject(rAllocationDetail,
						resourceSearchDto.getEmployeeList().get(0));
				tAssociateAllocation.setFtePercent(resourceSearchDto.getEmployeeList().get(0).getFte_percent());
				tAssociateAllocation.setTAssociateProject(associateProject);
				tAssociateAllocation.setCreatedDate(new Date());
				tAssociateAllocationRepository.save(tAssociateAllocation);
				tAssociateAllocationRepository.deactivateAllocTransaction(deactiveStatusId, allocationIdList,
						new Date());

				/*
				 * List<Long> roleIds =
				 * adminServiceClient.getRoleIds(List.of(ResourceManagementConstant.
				 * TAG_ROLE_NAME, ResourceManagementConstant.ADMIN_ROLE_NAME)); if
				 * (roleIds.contains(resourceSearchDto.getRoleId())) {
				 * tAssociateAllocationRepository.save(tAssociateAllocation);
				 * tAssociateAllocationRepository.deactivateAllocTransaction(deactiveStatusId,
				 * allocationIdList, new Date());
				 * log.info("Project utilization change Successfull : Updated by TAG/ADMIN"); }
				 * else { tAssociateAllocationRepository.save(tAssociateAllocation);
				 * resourceManagementServiceImpl.submitRMApproval(createRMApprovalObjectForFte(
				 * resourceSearchDto,tAssociateAllocation)); }
				 */
			}
		} else {
			if (associateProject != null) {
				associateProject = setTAssociateProject(associateProject, resourceSearchDto.getEmployeeList().get(0));
				TAssociateAllocation tAssociateAllocation = createAssociateAllocationObject(rAllocationDetail,
						resourceSearchDto.getEmployeeList().get(0));
				tAssociateAllocation.setAssociateAllocationId(rAllocationDetail.getAssociateAllocationId());
				tAssociateAllocation.setTAssociateProject(associateProject);
				tAssociateAllocationRepository.save(tAssociateAllocation);
			}
		}
	}

	public void approveOrRejectRMApproval(List<RMApprovalInputDto> rmApproveOrRejectDtlsList)
			throws ResourceManagementException {
		log.info("Entered into ResourceSearchServiceImpl.approveOrRejectRMApproval method:");
		List<Long> statusIdList = new ArrayList<>();
		statusIdList.add(0L);
		for (RMApprovalInputDto rmApproveOrRejectDtls : rmApproveOrRejectDtlsList) {
			if (rmApproveOrRejectDtls.getRequestType()
					.equalsIgnoreCase(ResourceManagementConstant.RM_FTE_CHANGE_REQUEST_CODE)) {
				List<TAssociateAllocation> tAllocationDtlsListObj = tAssociateAllocationRepository
						.getRAllocationDetailsForFte(rmApproveOrRejectDtls.getProjectId(),
								resourceManagementServiceImpl.getModuleStatusId(
										ResourceManagementConstant.RESOURCE_ALLOCATION,
										ResourceManagementConstant.ACTIVATE),
								rmApproveOrRejectDtls.getEmployeeIdList(), rmApproveOrRejectDtls.getRequirementId(),
								resourceManagementServiceImpl.getModuleStatusId(
										ResourceManagementConstant.RESOURCE_ALLOCATION,
										ResourceManagementConstant.SUBMIT_ACTION_FOR_FTE_CHANGE));
				if (CollectionUtils.isNotEmpty(tAllocationDtlsListObj)) {
					if (rmApproveOrRejectDtls.getApproverAction()
							.equalsIgnoreCase(ResourceManagementConstant.APPROVED_ACTION))
						approveRMApprovalReqForFte(tAllocationDtlsListObj, rmApproveOrRejectDtls, statusIdList);
					else
						rejectRMApprovalReqForFte(tAllocationDtlsListObj, rmApproveOrRejectDtls, statusIdList);
				}
			}
		}
	}

	public void rejectRMApprovalReqForFte(List<TAssociateAllocation> tAllocationDtlsListObj,
			RMApprovalInputDto rmApprovalRejectionDtls, List<Long> statusIdList) throws ResourceManagementException {
		log.info("Entered into ResourceSearchServiceImpl.rejectRMApprovalReqForFte method:");
		String wrkflwCode = resourceManagementServiceImpl.setWrkflwCode(rmApprovalRejectionDtls.getRequestType(), rmApprovalRejectionDtls.getRoleName());
		ResourceWorkflow rsrcWrkflwPrevObj = resourceWorkflowRepository.getPreviousRowData(
				tAllocationDtlsListObj.get(0).getAssociateAllocationId(), rmApprovalRejectionDtls.getUserId(),
				rmApprovalRejectionDtls.getRoleId());
		long allocRejectedStatusId = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION, ResourceManagementConstant.REJECTED);
		for (TAssociateAllocation tAssociateAllocationObj : tAllocationDtlsListObj) {
			ResourceWorkflow rsrcWrkflwCrrntObj = resourceWorkflowRepository.getRowDataOfDefaultStatus(
					tAssociateAllocationObj.getAssociateAllocationId(), statusIdList,
					rmApprovalRejectionDtls.getUserId(), rmApprovalRejectionDtls.getRoleId());
			if (rsrcWrkflwCrrntObj != null && rsrcWrkflwCrrntObj.getResourceWrkflwId() > 0) {
				rsrcWrkflwCrrntObj.setStatusId(allocRejectedStatusId);
				rsrcWrkflwCrrntObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
				rsrcWrkflwCrrntObj.setLastUpdatedBy(rmApprovalRejectionDtls.getUserId());
				rsrcWrkflwCrrntObj.setComment(rmApprovalRejectionDtls.getApproverComments());
				resourceWorkflowRepository.save(rsrcWrkflwCrrntObj);

			} else {
				rsrcWrkflwCrrntObj = resourceWorkflowRepository.getRowData(
						tAssociateAllocationObj.getAssociateAllocationId(), rmApprovalRejectionDtls.getUserId(),
						rmApprovalRejectionDtls.getRoleId());
				rsrcWrkflwCrrntObj.setStatusId(allocRejectedStatusId);
				rsrcWrkflwCrrntObj.setComment(rmApprovalRejectionDtls.getApproverComments());
				resourceWorkflowRepository.save(resourceManagementServiceImpl.createRsrcWrkflwDataObject(
						rsrcWrkflwCrrntObj, tAssociateAllocationObj.getAssociateAllocationId(), rmApprovalRejectionDtls,
						ResourceManagementConstant.APPROVAL_CONSTANT));
			}
		}
		if (rsrcWrkflwPrevObj != null) {
			long prevUsrId = rsrcWrkflwPrevObj.getCurrentUserId();
			long prevRoleId = rsrcWrkflwPrevObj.getCurrentRoleId();
			if (prevUsrId > 0 && prevRoleId > 0) {
				log.info("Rejection process still exist:");
				sendMailHelperServiceObj.sendEmailForApproveOrRejectionPending(rmApprovalRejectionDtls, wrkflwCode,
						tAllocationDtlsListObj.get(0).getAssociateAllocationId());
			}
		} else {
			log.info("Current user is final  Reject, Rejection process completed:");
			List<Long> rmTrnsctnIdListObj = tAllocationDtlsListObj.stream()
					.map(TAssociateAllocation::getAssociateAllocationId).collect(Collectors.toList());
			tAssociateAllocationRepository.updateStatusAndEffectiveEndDate(
					resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
							ResourceManagementConstant.REJECTED),
					rmTrnsctnIdListObj, new Date(System.currentTimeMillis()), resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
							ResourceManagementConstant.DEACTIVATE), tAssociateAllocationRepository.getEmployeeId(rmApprovalRejectionDtls.getUserId()));
			resourceManagementServiceImpl.releaseAllocatedBudgetForAlloc(tAllocationDtlsListObj,
					rmApprovalRejectionDtls.getProjectId(), rmApprovalRejectionDtls.getRequirementId());
			sendMailHelperServiceObj.sendEmailForRejectionConfirmation(rmApprovalRejectionDtls, wrkflwCode);
		}
		log.info("Just before leaving ResourceSearchServiceImpl.rejectRMApprovalReqForFte method:");
	}

	public void approveRMApprovalReqForFte(List<TAssociateAllocation> tAllocationDtlsListObj,
			RMApprovalInputDto rmApprovalDtls, List<Long> statusIdList) throws ResourceManagementException {
		log.info("Entered into ResourceSearchServiceImpl.approveRMApprovalReqForFte method:");
		ResourceWorkflow rsrcWrkflwObj = null;
		String wrkflwCode = resourceManagementServiceImpl.setWrkflwCode(rmApprovalDtls.getRequestType(), rmApprovalDtls.getRoleName());
		long allocApprovedStatusId = resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_EXTENSION, ResourceManagementConstant.APPROVED_ACTION);
		for (TAssociateAllocation tAssociateAllocationObj : tAllocationDtlsListObj) {
			rsrcWrkflwObj = resourceWorkflowRepository.getRowDataOfDefaultStatus(
					tAssociateAllocationObj.getAssociateAllocationId(), statusIdList, rmApprovalDtls.getUserId(),
					rmApprovalDtls.getRoleId());
			if (rsrcWrkflwObj != null && rsrcWrkflwObj.getResourceWrkflwId() > 0) {
				rsrcWrkflwObj.setStatusId(allocApprovedStatusId);
				rsrcWrkflwObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
				rsrcWrkflwObj.setLastUpdatedBy(rmApprovalDtls.getUserId());
				rsrcWrkflwObj.setComment(rmApprovalDtls.getApproverComments());
				resourceWorkflowRepository.save(rsrcWrkflwObj);
			} else {
				rsrcWrkflwObj = resourceWorkflowRepository.getRowData(
						tAssociateAllocationObj.getAssociateAllocationId(), rmApprovalDtls.getUserId(),
						rmApprovalDtls.getRoleId());
				rsrcWrkflwObj.setStatusId(allocApprovedStatusId);
				rsrcWrkflwObj.setComment(rmApprovalDtls.getApproverComments());
				resourceWorkflowRepository.save(resourceManagementServiceImpl.createRsrcWrkflwDataObject(rsrcWrkflwObj,
						tAssociateAllocationObj.getAssociateAllocationId(), rmApprovalDtls,
						ResourceManagementConstant.APPROVAL_CONSTANT));
			}
		}
		if (rsrcWrkflwObj != null) {
			long nextUsrId = rsrcWrkflwObj.getNextUserId();
			long nextRoleId = rsrcWrkflwObj.getNextRoleId();
			if (nextUsrId > 0 && nextRoleId > 0) {
				log.info("Approval process still exist:");
				sendMailHelperServiceObj.sendEmailForApprovalConfirmation(rmApprovalDtls, wrkflwCode);
				sendMailHelperServiceObj.sendEmailForApproveOrRejectionPending(rmApprovalDtls, wrkflwCode,
						tAllocationDtlsListObj.get(0).getAssociateAllocationId());
			} else {
				log.info("Current user is final  approver, Approval process completed:");
				Long deactiveStatusId = resourceManagementServiceImpl.getModuleStatusId(
						ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.DEACTIVATE);
				List<Long> allocationIdList = new ArrayList<>();
				allocationIdList.add(tAllocationDtlsListObj.get(0).getTransactionHistoryId());
				tAssociateAllocationRepository.updateWorkflowStatus(allocationIdList, deactiveStatusId);
				sendMailHelperServiceObj.sendEmailForFinalApprovalConfirmation(rmApprovalDtls, wrkflwCode,
						tAllocationDtlsListObj.get(0).getTransactionHistoryId());
			}
		}
		log.info("Just before leaving ResourceSearchServiceImpl.approveRMApprovalReqForFte method:");
	}

	@Override
	public void updateSupervisorDetails(@Valid SupervisorDto supervisorDto) throws ResourceManagementException {
		log.info("Entered into ResourceSearchServiceImpl.updateSupervisorDetails method:");
		try {
			if (supervisorDto != null && supervisorDto.getEmployeeIds() != null) {
				Long statusIdForActive = resourceManagementServiceImpl.getModuleStatusId(
						ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
				tAssociateProjectRepository.updateSupervisorDetails(supervisorDto, statusIdForActive);
				supervisorDto.getEmployeeIds().stream().forEach(empId -> tAssociateAllocationRepository
						.updateSupervisorDetails(supervisorDto, empId, statusIdForActive));
			}
		} catch (DataAccessException | IOError exp) {
			log.error("Encountered error in updateSupervisorDetails, error - {}", exp.getMessage());
			throw new ResourceManagementException(exp);
		}
		log.info("Just before leaving ResourceSearchServiceImpl.updateSupervisorDetails method:");
	}

	@Override
	public ResourceSearchDto getReservedAssociateListByProjectId(@Valid long projectId) throws ResourceManagementException {
		log.info("Entered into ResourceAllocationServiceImpl.getAssociateListByProjectId method:");
		ResourceSearchDto resourceSearchDto = null;
		List<EmployeeDto> employeeList = new ArrayList<>();
		Long statusIdForActive = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
		List<String> subModuleListForAllo = List.of(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<String> actionListForSaveAndSubAllo = List.of(ResourceManagementConstant.SAVED, ResourceManagementConstant.SUBMITTED);
		List<TAssociateAllocation> reservedAssociateAllocationList = tAssociateAllocationRepository
				.getReservedAssociateAllocationList(projectId, statusIdForActive, getWfStatusIdList(subModuleListForAllo, actionListForSaveAndSubAllo));	
		
		if (CollectionUtils.isNotEmpty(reservedAssociateAllocationList)) {
			resourceSearchDto = new ResourceSearchDto();
			List<Long> employeeIdList = new ArrayList<>();
			reservedAssociateAllocationList.stream().forEach(record -> employeeIdList.add(record.getTAssociateProject().getEmployeeId()));
			Map<Long, EmployeeDto> employeeMap = getPractiseDetails(tAssociateAllocationRepository.getEmpNumbers(employeeIdList));
			List<ReasonForDeallocation> reasonForDeallocationList = adminServiceClient.getReasonForDeallocation();
			List<Long> serviceLineIds = reservedAssociateAllocationList.stream().map(TAssociateAllocation::getServiceLineId).collect(Collectors.toList());
			Map<Long, String> serviceLines = new HashMap<>();
			if (!StreamSupport.stream(serviceLineIds.spliterator(), true).allMatch(o -> o == null)) {
				serviceLines = getServiceLineMap(adminServiceClient.getServiceLineList(serviceLineIds));
			}
			List<Long> supervisorIds =  reservedAssociateAllocationList.stream().map(TAssociateAllocation::getSupervisorId).collect(Collectors.toList());
			Map<Long, SuperVisiorDetailsDto> supervisorMap = getSupervisorMap(adminServiceClient.getSuperVisiorList(supervisorIds));

			for (TAssociateAllocation tAssociateAllocation : reservedAssociateAllocationList) {
				EmployeeDto employeeDto = employeeMap.get(tAssociateAllocation.getTAssociateProject().getEmployeeId());
				ResourceRequirementDto resourceRequirementDto = bapServiceClient
						.getRequirementDetailByReqId(tAssociateAllocation.getRequirementId());
				if (employeeDto != null) {
					createSearchByProjectObject(reasonForDeallocationList, serviceLines, supervisorMap,
							tAssociateAllocation, employeeDto, resourceRequirementDto);
	                employeeDto.setIsReservedForDeallocation(false);
					employeeDto.setIsAllocationApproved(false);
					employeeDto.setIsDeallocationApproved(false);
					employeeDto.setIsReservedAllocation(true);
					
					employeeList.add(employeeDto);
				}
			}
			resourceSearchDto.setTotalCount(Long.valueOf(reservedAssociateAllocationList.size()));
			resourceSearchDto.setEmployeeList(employeeList);
		}

		log.info("Just before leaving ResourceAllocationServiceImpl.getAssociateListByProjectId method:");
		return resourceSearchDto;
	}

	private void createSearchByProjectObject(List<ReasonForDeallocation> reasonForDeallocationList,
			Map<Long, String> serviceLines, Map<Long, SuperVisiorDetailsDto> supervisorMap,
			TAssociateAllocation tAssociateAllocation, EmployeeDto employeeDto,
			ResourceRequirementDto resourceRequirementDto) throws ResourceManagementException {
		employeeDto.setActualAllocationDate(tAssociateAllocation.getActualAllocationStartDate());
		employeeDto.setEstimatedEndDate(tAssociateAllocation.getEstAllocationEndDate());
		employeeDto.setBillingStatus(adminServiceClient.getLookUpById(tAssociateAllocation.getBillableStatusId()).getLookupType());
		employeeDto.setPrimaryProjectStatusId(isPrimaryProject(tAssociateAllocation.getTAssociateProject().getIsPrimaryProject()));
		employeeDto.setBillingRatePerHour(resourceRequirementDto.getBillingEffortsPerHrs());
		if (serviceLines.containsKey(tAssociateAllocation.getServiceLineId()))
			employeeDto.setServiceLineName(serviceLines.get(tAssociateAllocation.getServiceLineId()));
		else
			employeeDto.setServiceLineName(ResourceManagementConstant.NA);
		if (tAssociateAllocation.getBillableStatusReasonId() != null)
			employeeDto.setEbrReason(adminServiceClient
					.getLookUpById(tAssociateAllocation.getBillableStatusReasonId()).getLookupType());
		else
			employeeDto.setEbrReason(ResourceManagementConstant.NA);
		employeeDto.setProjectUtilization(tAssociateAllocation.getFtePercent());
		if (tAssociateAllocation.getTAssociateProject().getSrfId() != null)
			employeeDto.setSrfNo(tSrfRepository.getSrfNoFromId(tAssociateAllocation.getTAssociateProject().getSrfId()));
		else
			employeeDto.setSrfNo(ResourceManagementConstant.NA);
		if (tAssociateAllocation.getRemarks() != null)
			employeeDto.setRemarks(tAssociateAllocation.getRemarks());
		else
			employeeDto.setRemarks(ResourceManagementConstant.NA);
		employeeDto.setVersion(resourceRequirementDto.getVersion());
		employeeDto.setIsAllocated(true);
		employeeDto.setRequirementId(tAssociateAllocation.getRequirementId());
		employeeDto.setAssociateAllocationId(tAssociateAllocation.getAssociateAllocationId());
		employeeDto.setProjectId(tAssociateAllocation.getTAssociateProject().getProjectId());
		employeeDto.setAssociateProjectId(tAssociateAllocation.getTAssociateProject().getAssociateProjectId());
		employeeDto.setFte_percent(tAssociateAllocation.getFtePercent());
		employeeDto.setProjectName(resourceRequirementDto.getProjectName());
		employeeDto.setEmployeeCostRate(resourceRequirementDto.getRequirmentCostRate());
		employeeDto.setSkillChampion(tAssociateAllocation.getSkillChampionFlag());
		employeeDto.setReasonForDeallocationList(reasonForDeallocationList);
		if(resourceRequirementDto.getCountryName()!=null) {
			employeeDto.setCountryName(resourceRequirementDto.getCountryName());
		}
		if(employeeDto.getBillingStatus().equalsIgnoreCase(ResourceManagementConstant.Billable)) {
			employeeDto.setBillableUtilization(employeeDto.getFte_percent());
		}
		else if(employeeDto.getBillingStatus().equalsIgnoreCase(ResourceManagementConstant.Non_Billable)) {
			employeeDto.setNonBillableUtilization(employeeDto.getFte_percent());
		}
		List<Long> totalFteForEmployee = tAssociateAllocationRepository.getTotalFteForEmployee(tAssociateAllocation.getWorkflowStatusId(), tAssociateAllocation.getStatusId(), employeeDto.getEmployeeId());
		Long totalFte = 0l; 
		for(Long l:totalFteForEmployee) {
			totalFte= totalFte + l; 
		}
		employeeDto.setAvailability(100- totalFte);
		employeeDto.setAllocationTypeId(tAssociateAllocation.getAllocationTypeId());
		employeeDto.setAllocationType(tAssociateAllocationRepository.getAllocationTypeByAllocationTypeId(tAssociateAllocation.getAllocationTypeId()));
		if(supervisorMap.containsKey(tAssociateAllocation.getSupervisorId()))
			employeeDto.setSupervisorDto(supervisorMap.get(tAssociateAllocation.getSupervisorId()));
		employeeDto.setHiveFlag(Objects.isNull(tSrfRepository.getHiveFlag(employeeDto.getEmployeeNumber())) ? "NO" : tSrfRepository.getHiveFlag(employeeDto.getEmployeeNumber()));
		//Added by Mrunal Marne for adding project est. end date
		employeeDto.setEstimatedProjectEndDate(resourceRequirementDto.getProjectEndDate());
		//Added by Mrunal Marne for adding requirement est. end date
		employeeDto.setEstimatedRequirementEndDate(resourceRequirementDto.getRequirementEndDate());
	}

}
