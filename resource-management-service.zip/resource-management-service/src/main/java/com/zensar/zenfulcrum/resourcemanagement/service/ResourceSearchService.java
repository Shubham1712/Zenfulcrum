package com.zensar.zenfulcrum.resourcemanagement.service;

import java.text.ParseException;
import java.util.List;

import javax.validation.Valid;

import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateSearchDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PracticeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceSearchDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RoleDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SupervisorDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

public interface ResourceSearchService {

	public ResourceSearchDto getAssociateListByProjectId(Long projectId, Long loggedInRoleId, Long loggedInUserId) throws ResourceManagementException;

	public ResourceSearchDto getResourceDtlsListByPractice(Long practiceId) throws ResourceManagementException;

	public List<SkillDto> getListOfSkills() throws ResourceManagementException;

	public List<RoleDto> getRoleList() throws ResourceManagementException;

	public ResourceSearchDto getResourceDtlsListBySkill(Long skillId) throws ResourceManagementException;

	public List<PracticeDto> getPracticeList() throws ResourceManagementException;
	
	public AssociateSearchDto getResourceProjectDtlsByAssociateID(String employeeIdOrName,String requestType, Long loggedInRoleId, Long loggedInUserId) throws ResourceManagementException;

	public List<SupervisorDto> getSupervisorList(Long projectId) throws ResourceManagementException;
	
	public void updateProjectDtlsForSearch(ResourceSearchDto resourceSearchDto) throws ResourceManagementException,ParseException;

	public ResourceSearchDto getResourceDetails(String searchKey, long searchValueId, Long loggedInRoleId, Long loggedInUserId) throws ResourceManagementException;

	public List<LookupValueDto> getSearchList() throws ResourceManagementException;

	public void saveResourcesForExtension(ResourceSearchDto resourceSearchDto) throws ResourceManagementException;

	public void updateSupervisorDetails(@Valid SupervisorDto supervisorDto) throws ResourceManagementException;

	public ResourceSearchDto getReservedAssociateListByProjectId(@Valid long projectId) throws ResourceManagementException;

}
