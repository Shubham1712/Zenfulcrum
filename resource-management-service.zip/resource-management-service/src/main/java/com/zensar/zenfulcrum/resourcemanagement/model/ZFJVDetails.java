package com.zensar.zenfulcrum.resourcemanagement.model;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Data;

@Entity
@Data
@Immutable
@Table(schema = "zf_staging", name = "ZF_JV_DETAILS", catalog = "zf_staging")
public class ZFJVDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "zf_jv_details_key")
	private Long zfJVDetailsKey;
	
	@Column(name = "window_start_date")
	private Date windowStartDate;
	
	@Column(name = "window_end_date")
	private Date windowEndDate;
	
	@Column(name = "field1")
	private String field1;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "created_by")
	private String createdBy;
	
}