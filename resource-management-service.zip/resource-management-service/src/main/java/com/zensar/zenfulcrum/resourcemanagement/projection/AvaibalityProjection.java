package com.zensar.zenfulcrum.resourcemanagement.projection;

public interface AvaibalityProjection {
	public Long getEmployeeId();
	public Long getAllocatedFte();
	public void setEmployeeId(long l);
    public void setAllocatedFte(long l);

}
