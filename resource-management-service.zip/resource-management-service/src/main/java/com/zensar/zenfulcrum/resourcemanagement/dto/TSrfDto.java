package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class TSrfDto implements Serializable {
	private static final long serialVersionUID = 920443184560902615L;
	
	private Integer srfId;
	private String srfNumber;
	private String projectId;
	private Date selectionDate;
	private Date statusStartDate;
	private Date statusEndDate;
	private boolean isSelected;
	private String resourceStatus;
	private long statusId;
	private long createdBy;
	private long lastUpdatedBy;
	private Date createdDate;
	private Date lastUpdatedDate;
}
