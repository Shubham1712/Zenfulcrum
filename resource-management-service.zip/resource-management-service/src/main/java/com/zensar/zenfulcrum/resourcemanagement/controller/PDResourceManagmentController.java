package com.zensar.zenfulcrum.resourcemanagement.controller;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.PDResourceManagmentService;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Api(tags = "PDResourceManagmentController")
@RestController
@Slf4j
@Validated
@RequestMapping(path = "pdresourcemanagment")
public class PDResourceManagmentController {

	@Autowired
	PDResourceManagmentService pdResourceManagmentService;
	
	 @GetMapping(path="/associatelistbyprojectid")
	 public ResponseEntity<List<TAssociateAllocationDto>> getAssociateListByProjectId(@RequestParam(name="projectId") Long projectId) throws ResourceManagementException{
		 log.info("Entered into PDResourceManagmentController : getAssociateListByProjectId");
		 List<TAssociateAllocationDto> tAssociateAllocationList = pdResourceManagmentService.getAssociateListByProjectId(projectId);
		 if (CollectionUtils.isNotEmpty(tAssociateAllocationList)) {
				log.info("End getAssociateListByProjectId success");
				return new ResponseEntity<>(tAssociateAllocationList, HttpStatus.OK);
			} else {
				log.info("End getAssociateListByProjectId failure");
				return new ResponseEntity<>(tAssociateAllocationList, HttpStatus.NO_CONTENT);
			}
	 }
	 
	 @GetMapping(path="/associatelist")
	 public ResponseEntity<List<TAssociateAllocationDto>> getAssociateList(@RequestParam(name="projectId") Long projectId) throws ResourceManagementException{
		 log.info("Entered into PDResourceManagmentController : getAssociateListByProjectId");
		 List<TAssociateAllocationDto> tAssociateAllocationList = pdResourceManagmentService.getAssociateList(projectId);
		 if (CollectionUtils.isNotEmpty(tAssociateAllocationList)) {
				log.info("End getAssociateList success");
				return new ResponseEntity<>(tAssociateAllocationList, HttpStatus.OK);
			} else {
				log.info("End getAssociateList failure");
				return new ResponseEntity<>(tAssociateAllocationList, HttpStatus.NO_CONTENT);
			}
	 }
}
