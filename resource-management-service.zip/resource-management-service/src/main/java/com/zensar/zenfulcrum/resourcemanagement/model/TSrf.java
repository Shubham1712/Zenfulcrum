package com.zensar.zenfulcrum.resourcemanagement.model;

import java.util.Date;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="T_SRF")
@Data
public class TSrf {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="SRF_ID")	
	private Long srfId;
	
	@Column(name="SRF_NUMBER")
	private String srfNumber;
	
	@Column(name="CANDIDATE_ID")
	private Long candidateId;
	
	@Column(name="PROJECT_ID")
	private String projectId;
	
	@Column(name="SELECTION_DATE")
	private Date selectionDate;
	
	@Column(name="STATUS_START_DATE")
	private Date statusStartDate;
	
	@Column(name="STATUS_END_DATE")
	private Date statusEndDate;
	
	@Column(name="IS_SELECTED")
	private boolean isSelected;
	
	@Column(name="RESOURCE_STATUS")
	private String resourceStatus;
	
	@Column(name="STATUS_ID")
	private Long statusId;
	
	@Column(name="CREATED_BY")
	private Long createdBy;
	
	@Column(name="LAST_UPDATED_BY")
	private Long lastUpdatedBy;
	
	@Column(name="CREATED_DATE")
	private Date createdDate;
	
	@Column(name="LAST_UPDATED_DATE")
	private Date lastUpdatedDate;
}
