package com.zensar.zenfulcrum.resourcemanagement.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocationBudget;

@Repository
public interface AssociateAllocationBudgetRepository extends JpaRepository<TAssociateAllocationBudget, Long>  {
	@Query( value ="SELECT tssb.* FROM (T_ASSOCIATE_ALLOCATION talloc INNER JOIN T_ASSOCIATE_ALLOCATION_BUDGET tssb ON tssb.associate_allocation_id=talloc.associate_allocation_id) WHERE talloc.associate_allocation_id=:associateAllocationId  AND tssb.budget_allocation_month=:budgetAllocationMonth", nativeQuery = true)
	public List<TAssociateAllocationBudget> findByAssociateAllocationIdAndBudgetAllocationMonth(@Param("associateAllocationId")Long associateAllocationId, @Param("budgetAllocationMonth")String budgetAllocationMonth);

	//Added by Mrunal Marne for removing records for RM transfer/allocation saved on rejection by Project Manager
	@Modifying
	@Transactional
	@Query(value = "DELETE FROM T_ASSOCIATE_ALLOCATION_BUDGET WHERE associate_allocation_id IN (:associateAllocationIdList)", nativeQuery = true)
	void removeSavedBudgetDetailsForTransfer(@Param("associateAllocationIdList") List<Long> associateAllocationIdList) throws ResourceManagementException;
	//End by Mrunal
}
