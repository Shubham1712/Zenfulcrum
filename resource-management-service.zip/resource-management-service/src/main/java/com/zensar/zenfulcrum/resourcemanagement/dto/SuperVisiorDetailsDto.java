package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class SuperVisiorDetailsDto {
	
	 public Long empId;
     public String empName;
     public Long empNumber;

}
