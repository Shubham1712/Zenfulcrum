package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;

import lombok.Data;

@Data
public class RTProjectDto {

	private double projectUtilization;
	private Date allocationDate;
	private Date estimatedReleaseDate;
	private long requirementId;
	private Long skillId;
	private Double stdCost;
	private Long serviceLineId;
	private Long billableStatusReasonId;
	private long associateBillableTypeId;
}
