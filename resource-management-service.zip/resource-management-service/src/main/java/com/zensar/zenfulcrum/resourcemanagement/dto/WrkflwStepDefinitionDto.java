package com.zensar.zenfulcrum.resourcemanagement.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class WrkflwStepDefinitionDto {
	
	private long roleId;
	private long stepId;
	private long nextRoleId;
	private String wrkflwCode;
	@JsonProperty(value = "workflowDefinitionId", required = true)
	private long wrkflwDefinitionId;
	@JsonProperty(value = "decision", required = true)
	private String wrkflwStepDecision;
	private String firstStep;
	private boolean sendMail;	
	private boolean uiDisplay;
	
}
