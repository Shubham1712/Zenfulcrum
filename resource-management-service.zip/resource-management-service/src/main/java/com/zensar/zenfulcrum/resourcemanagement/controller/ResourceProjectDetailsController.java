package com.zensar.zenfulcrum.resourcemanagement.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDtlsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceProjectDetailsService;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceRequirementServiceImpl;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Api(tags = "ResourceProjectDetailsController")
@RestController
@Slf4j
@Validated
@RequestMapping(path = "rmprojectDetails")
public class ResourceProjectDetailsController {

	@Autowired
	ResourceProjectDetailsService service;
	
	@Autowired
	ResourceRequirementServiceImpl impl;

	 
	
	 
	 
	 @GetMapping(path = "/getprojectidsbyuserid")
		public ResponseEntity<List<ProjectDto>> getProjectIdsByUserId(@Valid @RequestParam long userId ) throws ResourceManagementException {
			log.info("Start getProjectList projectId::{}");

			List<ProjectDto> projectList = service.getProjectIdsByUserId(userId);
			if (projectList!=null) {
				return new ResponseEntity<>(projectList, HttpStatus.OK);
			} else {
				log.info("Exit getProjectList method");
				return new ResponseEntity<>(projectList, HttpStatus.NO_CONTENT);
			}

		}
 
	 @GetMapping(path = "/getprojectbudgetdetails")
		public ResponseEntity<List<ProjectBudgetDto>> getProjectMonthlyBudgetsDetails(@Valid @RequestParam long projectId ) throws ResourceManagementException {
			log.info("Start getProjectList - projectId::{}");

			List<ProjectBudgetDto> projectBudgetList = service.getProjectMonthlyBudgetsDetails(projectId);
			if (projectBudgetList!=null) {
				return new ResponseEntity<>(projectBudgetList, HttpStatus.OK);
			} else {
				log.info("Exit getProjectList method");
				return new ResponseEntity<>(projectBudgetList, HttpStatus.NO_CONTENT);
			}

		}
	 
	 
	 @GetMapping(path = "/getallocatedresources")
		public ResponseEntity<ProjectDtlsDto> getAllocatedResources(@Valid @RequestParam long projectId ) throws ResourceManagementException {
			log.info("Start getProjectList - projectId::{}");

			ProjectDtlsDto projectDto= service.getAllocatedResources(projectId);
			if (projectDto!=null) {
				return new ResponseEntity<>(projectDto, HttpStatus.OK);
			} else {
				log.info("Exit getProjectList method");
				return new ResponseEntity<>(projectDto, HttpStatus.NO_CONTENT);
			}

		}
	 
}
