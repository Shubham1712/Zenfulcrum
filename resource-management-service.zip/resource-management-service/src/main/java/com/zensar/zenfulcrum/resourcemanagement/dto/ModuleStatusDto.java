package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class ModuleStatusDto {

	private Long moduleId;
	private String parentModule;
	private String subModule;
	private String action;
	private String moduleCode;
	private Long moduleStatusId;

}
