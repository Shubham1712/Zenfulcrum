package com.zensar.zenfulcrum.resourcemanagement.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateDeAllocation;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AssociateDeAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.ReservedAssociateProjection;

public interface TAssociateDeAllocationRepository extends JpaRepository<TAssociateDeAllocation, Long> {

	@Modifying
	@Transactional
	@Query(value = "UPDATE `T_ASSOCIATE_DEALLOCATION` SET workflow_status_id = :statusId WHERE EMPLOYEE_ID IN :resourceIdList AND REQUIREMENT_ID = :reqId", nativeQuery = true)
	void rejectRMSavedResources(@Param("statusId") long statusId, @Param("resourceIdList") List<Long> resourceIdList,
			@Param("reqId") long reqId) throws ResourceManagementException;

	@Query(value = "SELECT tdealloc.associate_allocation_id as AssociateAllocationId, talloc.actual_allocation_start_date as ActualAllocationStartDate,talloc.actual_allocation_end_date as ActualAllocationEndDate,tdealloc.std_cost AS employeeCostRate,"
			+ "tdealloc.deallocation_date as DeallocationDate, tdealloc.associate_deallocation_id as AssociateDeAllocationId , talloc.fte_percent as FtePercent, talloc.est_allocation_end_date as estAllocationEndDate FROM (T_ASSOCIATE_DEALLOCATION tdealloc\r\n"
			+ "INNER JOIN T_ASSOCIATE_ALLOCATION talloc ON talloc.associate_allocation_id = tdealloc.associate_allocation_id \r\n"
			+ "INNER JOIN T_ASSOCIATE_PROJECT tpro ON tpro.associate_project_id=talloc.associate_project_id) \r\n"
			+ "WHERE tpro.project_id=:projectId  AND talloc.status_id=:allocStatusId AND tpro.employee_id IN (:empIdList) AND talloc.requirement_id=:requirementId AND tdealloc.status_id=:deallocStatusId", nativeQuery = true)
	List<AssociateDeAllocationProjection> getRDeAllocationRequiredDetails(@Param("projectId") long projectId,
			@Param("deallocStatusId") long deallocStatusId, @Param("empIdList") List<Long> empIdList,
			@Param("requirementId") long requirementId, @Param("allocStatusId") long allocStatusId)
			throws ResourceManagementException;

	@Query(value = "SELECT tdealloc.* FROM (T_ASSOCIATE_DEALLOCATION tdealloc\r\n"
			+ "INNER JOIN T_ASSOCIATE_ALLOCATION talloc ON talloc.associate_allocation_id = tdealloc.associate_allocation_id \r\n"
			+ "INNER JOIN T_ASSOCIATE_PROJECT tpro ON tpro.associate_project_id=talloc.associate_project_id) \r\n"
			+ "WHERE tpro.project_id=:projectId  AND talloc.status_id=:allocStatusId AND tpro.employee_id IN (:empIdList) AND talloc.requirement_id=:requirementId AND tdealloc.status_id=:deallocStatusId", nativeQuery = true)
	List<TAssociateDeAllocation> getRDeAllocationDetails(@Param("projectId") long projectId,
			@Param("deallocStatusId") long deallocStatusId, @Param("empIdList") List<Long> empIdList,
			@Param("requirementId") long requirementId, @Param("allocStatusId") long allocStatusId)
			throws ResourceManagementException;

	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_DEALLOCATION SET status_id=:statusId WHERE project_id=:projectId  AND associate_deallocation_id IN (:rmTranscIdList)", nativeQuery = true)
	void updateStatusId(@Param("statusId") long statusId, @Param("projectId") long projectId,
			@Param("rmTranscIdList") List<Long> rmTranscIdList) throws ResourceManagementException;

	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_DEALLOCATION SET workflow_status_id= :statusId, effective_start_date=:effectiveEndDate WHERE associate_deallocation_id IN :rmDeAllocTranscIdList", nativeQuery = true)
	void updateStatusAndEffectiveEndDate(@Param("statusId") long statusId,
			@Param("rmDeAllocTranscIdList") List<Long> rmDeAllocTranscIdList,
			@Param("effectiveEndDate") Date effectiveEndDate) throws ResourceManagementException;

	@Query(value = "SELECT requirement_id AS requirementId ,COUNT(`requirement_id`) AS reservedAssociateCount FROM `T_ASSOCIATE_DEALLOCATION` WHERE `workflow_status_id` IN :workflowStatusIdsDealloc AND requirement_id IN :requirmentIdList  GROUP BY 1;", nativeQuery = true)
	List<ReservedAssociateProjection> getReservedAssociateForDeallocation(
			@Param("requirmentIdList") List<Long> requirmentId,
			@Param("workflowStatusIdsDealloc") List<Long> workflowStatusIdsDealloc);

	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_DEALLOCATION SET workflow_status_id=:statusId, last_updated_date= NOW() WHERE associate_deallocation_id IN (:rmDeAllocTranscIdList)", nativeQuery = true)
	void updateWorkflowStatus(@Param("rmDeAllocTranscIdList") List<Long> rmDeAllocTranscIdList,
			@Param("statusId") long statusId) throws ResourceManagementException;

	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_DEALLOCATION SET status_id=:statusId WHERE associate_allocation_id IN (:associateAllocationIdList)", nativeQuery = true)
	void updateWorkflowSta(@Param("associateAllocationIdList") List<Long> associateAllocationIdList,
			@Param("statusId") long statusId) throws ResourceManagementException;

	@Query(value = "SELECT associate_allocation_id FROM `T_ASSOCIATE_DEALLOCATION` WHERE workflow_status_id IN (:wfStatusId) AND status_id=:statusIdForDeactive AND DATE(deallocation_date) >= CURDATE()\r\n"
			+ "AND associate_allocation_id IN (:associateAllocationIds)", nativeQuery = true)
	List<Long> getDeallocationApprovedList(@Param("associateAllocationIds") List<Long> associateAllocationIds,
			@Param("wfStatusId") List<Long> wfStatusId, @Param("statusIdForDeactive") Long statusIdForDeactive);

	@Query(value = "SELECT DISTINCT TW.transaction_id FROM T_ASSOCIATE_ALLOCATION TA LEFT OUTER JOIN T_ASSOCIATE_DEALLOCATION TD\r\n"
			+ "ON TA.associate_allocation_id = TD.associate_allocation_id\r\n"
			+ "JOIN T_RESOURCE_WORKFLOW TW ON TD.associate_deallocation_id = TW.transaction_id\r\n"
			+ "WHERE TA.status_id = :statusIdActiveforAllocation AND TA.workflow_status_id = :workFlowIdApprovedForAllocation  AND TD.workflow_status_id = :submittedForDeallocation AND TW.current_user_id = :userId AND TW.current_role_id = :roleId AND TW.workflow_type_id = :moduleId", nativeQuery = true)
	List<Long> getDeallocationpendingForApprovalRecords(
			@Param("statusIdActiveforAllocation") Long statusIdActiveforAllocation,
			@Param("workFlowIdApprovedForAllocation") Long workFlowIdApprovedForAllocation,
			@Param("submittedForDeallocation") Long submittedForDeallocation, @Param("userId") Long userId,
			@Param("roleId") Long roleId, @Param("moduleId") Long moduleId);

	@Query(value = "SELECT associate_deallocation_id AS AssociateDeAllocationId,employee_id AS EmployeeId,project_id AS ProjectId,deallocation_date AS DeallocationDate, associate_allocation_id AS AssociateAllocationId ,deallocation_reason_id AS ReasonForDeallocationId  FROM T_ASSOCIATE_DEALLOCATION WHERE associate_deallocation_id IN  :transactionIds", nativeQuery = true)
	List<AllocatedResourceProjection> getDeallocationApprovalListPendingData(
			@Param("transactionIds") List<Long> transactionIds);

	@Query(value = "SELECT TD.`associate_deallocation_id` FROM `T_ASSOCIATE_ALLOCATION` TA LEFT OUTER JOIN `T_ASSOCIATE_DEALLOCATION`  TD\r\n"
			+ "ON TA.`associate_allocation_id` = TD.`associate_allocation_id`\r\n"
			+ "WHERE TA.`status_id`= :statusIdActiveforAllocation AND TA.`workflow_status_id`= :workFlowIdApprovedForAllocation  AND  TD.`created_by` = :userId AND TD.`workflow_status_id` = :savedForDeallocation", nativeQuery = true)
	List<Long> getDeallocationPendingForSubmissionRecords(
			@Param("statusIdActiveforAllocation") Long statusIdActiveforAllocation,
			@Param("workFlowIdApprovedForAllocation") Long workFlowIdApprovedForAllocation,
			@Param("userId") Long userId, @Param("savedForDeallocation") Long savedForDeallocation);

	@Query(value = "SELECT * FROM `T_ASSOCIATE_DEALLOCATION` WHERE associate_allocation_id IN (:associteAllocationIds) AND \r\n"
			+ "workflow_status_id IN (:workflowStatusId) AND status_id = :statusId", nativeQuery = true)
	List<TAssociateDeAllocation> getDeallocationByAssoAlloId(List<Long> associteAllocationIds, Long statusId,
			List<Long> workflowStatusId);

	@Query(value = "SELECT TD.associate_deallocation_id AS AssociateDeAllocationId,TD.remarks AS comments,TA.associate_allocation_id AS AssociateAllocationId,TA.requirement_id AS RequirementId,\r\n"
			+ "TP.employee_id AS EmployeeId,TP.project_id AS ProjectId,TP.is_primary_project AS IsPrimaryProject ,\r\n"
			+ "TA.fte_percent AS FtePercent,TA.billable_status_id AS BillableStatusId,\r\n"
			+ "TA.actual_allocation_start_date AS ActualStartDate,TA.est_allocation_end_date AS EstEndDate,TD.`deallocation_date` AS DeallocationDate,TD.deallocation_reason_id AS ReasonForDeallocationId\r\n"
			+ "FROM `T_ASSOCIATE_ALLOCATION` TA \r\n" + "INNER JOIN `T_ASSOCIATE_DEALLOCATION` TD\r\n"
			+ "ON TA.`associate_allocation_id` = TD.`associate_allocation_id`\r\n"
			+ "INNER JOIN `T_ASSOCIATE_PROJECT` TP \r\n"
			+ "ON TA.`associate_project_id` =  TP.`associate_project_id`\r\n"
			+ "WHERE  TD.`created_by` = :userId AND TA.`status_id` = :statusIdActiveforAllocation AND TA.`workflow_status_id` = :workFlowIdApprovedForAllocation \r\n"
			+ "AND TD.`workflow_status_id` = :savedForDeallocation  AND TD.`status_id` = :deallocationDeactive", nativeQuery = true)
	List<AllocatedResourceProjection> getDeallocationPendingForSubmissionData(
			@Param("statusIdActiveforAllocation") Long statusIdActiveforAllocation,
			@Param("workFlowIdApprovedForAllocation") Long workFlowIdApprovedForAllocation,
			@Param("userId") Long userId, @Param("savedForDeallocation") Long savedForDeallocation,
			@Param("deallocationDeactive") Long deallocationDeactive);

	@Query(value = "SELECT d.* FROM T_ASSOCIATE_DEALLOCATION d INNER JOIN T_ASSOCIATE_ALLOCATION a ON d.requirement_id = a.requirement_id", nativeQuery = true)
	List<TAssociateDeAllocation> getDeallocationDetails();
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE T_ASSOCIATE_DEALLOCATION SET status_id=:statusId,workflow_status_id=:statusId  WHERE associate_allocation_id IN (:associateAllocationIdList)", nativeQuery = true)
	void updateWorkflowStaforTransfer(@Param("associateAllocationIdList") List<Long> associateAllocationIdList,
			@Param("statusId") long statusId) throws ResourceManagementException;

	@Query(value = "SELECT DISTINCT associate_allocation_id FROM `T_ASSOCIATE_DEALLOCATION` WHERE workflow_status_id IN (:wfStatusId) AND status_id=:statusIdForDeactive AND deallocation_date > NOW() \r\n"
			+ "AND associate_allocation_id IN (:associateAllocationIds)", nativeQuery = true)
	List<Long> getReservedDeallocationList(@Param("associateAllocationIds") List<Long> associateAllocationIds,
			@Param("wfStatusId") List<Long> wfStatusId, @Param("statusIdForDeactive") Long statusIdForDeactive);

	//Added by Mrunal Marne for removing records for RM transfer saved on rejection by Project Manager
	@Modifying
	@Transactional
	@Query(value = "DELETE FROM T_ASSOCIATE_DEALLOCATION WHERE associate_allocation_id IN (:associateAllocationIdList)", nativeQuery = true)
	void removeSavedResourcesForTransfer(@Param("associateAllocationIdList") List<Long> associateAllocationIdList) throws ResourceManagementException;
	//End by Mrunal
}
