package com.zensar.zenfulcrum.resourcemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.client.RestTemplate;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableEurekaClient
@ComponentScan("com.zensar.zenfulcrum.resourcemanagement.*")
@EnableFeignClients
@EnableSwagger2
public class ResourceManagementApplication extends SpringBootServletInitializer {
	public static void main(String[] args) {
		SpringApplication.run(ResourceManagementApplication.class, args);
	}

	/**
	 * @return Rest Template object at runtime.
	 */
    @Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
