package com.zensar.zenfulcrum.resourcemanagement.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocationBudget;

@Mapper(componentModel = "spring")
@Component
public interface TAssociateAllocationBudgetMapper {

	TAssociateAllocationBudgetDto tAssociateAllocationBudgetToTAssociateAllocationBudgetDto(
			TAssociateAllocationBudget value);

	TAssociateAllocationBudget tAssociateAllocationBudgetDtoToTAssociateAllocationBudget(
			TAssociateAllocationBudgetDto value);

	List<TAssociateAllocationBudgetDto> tAssociateAllocationBudgetToTAssociateAllocationBudgetDto(
			List<TAssociateAllocationBudget> value);

	List<TAssociateAllocationBudget> tAssociateAllocationBudgetDtoToTAssociateAllocationBudget(
			List<TAssociateAllocationBudgetDto> value);
}
