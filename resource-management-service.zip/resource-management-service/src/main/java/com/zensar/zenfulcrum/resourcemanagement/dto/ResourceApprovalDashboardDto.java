package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class ResourceApprovalDashboardDto {
   
    private Map<String,Integer> resourcePendingCountMap;
   
    private List<EmployeeDto> resPendingAllocationApproval;
    private List<EmployeeDto> resPendingDeallocationApproval;
    private List<EmployeeDto> resPendingExtensionApproval;
    private List<EmployeeDto> resPendingAllocationSubmission;
    private List<EmployeeDto> resPendingDeallocationSubmission;
    private List<EmployeeDto> resPendingOtherAllocation;
    private List<EmployeeDto> resPendingOtherDeallocation;
    private List<EmployeeDto> resPendingOtherExtension;
 
    private List<ResourceDashboardTransferDto> resPendingTransferApproval;
    private List<ResourceDashboardTransferDto> resPendingOtherTransfer;
    private List<ResourceDashboardTransferDto> resPendingTransferSubmission;

}
