package com.zensar.zenfulcrum.resourcemanagement.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDtlsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class ResourceProjectDetailsServiceImpl implements ResourceProjectDetailsService {
	@Autowired
	private AdminServiceClient adminClient;

	@Autowired
	private BAPServiceClient bapServiceClient;

	@Autowired
	TAssociateProjectRepository tAssociateProjectRepository;
	
	@Autowired
	ResourceRequirementServiceImpl resourceRequirementServiceImpl;
	
	@Autowired
	BudgetControlServiceClient budgetControlServiceClient;

	 
	@Override
	public List<ProjectDto>getProjectIdsByUserId(long userId) {
		List<ProjectDto> projectIdsList= new ArrayList<ProjectDto>();
		 
		List<Long> projectList = tAssociateProjectRepository.getProjectIds(userId);
		 
		for(long id : projectList) {
			ProjectDto projectDto= new ProjectDto();
			projectDto.setProjectId(id);
			projectIdsList.add(projectDto);
		}
		
		return projectIdsList;
		  	}
	
	 
	
	@Override
	public ProjectDtlsDto getAllocatedResources(long projectId) {
		ProjectDtlsDto projectDto= new ProjectDtlsDto();
		projectDto.setAllocatedResources(tAssociateProjectRepository.getAllocatedResource(projectId));
		
		return projectDto;
	}
	
	
	 
	
	@Override
	public  List<ProjectBudgetDto> getProjectMonthlyBudgetsDetails(Long projectId) throws ResourceManagementException{
		log.info("Start getProjectMonthlyBudgetsDetails");
		return budgetControlServiceClient.getProjectMonthlyBudgetsDetails(projectId);
	}
	 
		
	 
	
	
}
