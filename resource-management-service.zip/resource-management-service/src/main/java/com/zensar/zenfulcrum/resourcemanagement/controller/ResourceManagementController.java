package com.zensar.zenfulcrum.resourcemanagement.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PoAndMilestoneDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApproversDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TransferApproverResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceManagementService;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementUtil;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Api(tags = "ResourceManagementController")
@RestController
@Slf4j
@Validated
@RequestMapping(path = "resourcemanagement/")
public class ResourceManagementController {

	@Autowired  
	private ResourceManagementService resourceManagementService;

	/**
	 * @throws ResourceManagementException
	 *  This method return all project details for the role.
	 *  @return 
	 *  @throws
	 */
   
	@GetMapping(path = "/projectList")
	public ResponseEntity<RMResponseDto> getProjectList(@Valid @RequestParam Long userId,
			@Valid @RequestParam Long roleId) throws ResourceManagementException {
		log.info("Start getProjectList - userId::{}", userId, "roleId{}", roleId);
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<ProjectDto> projectList = resourceManagementService.getProjectList(userId, roleId);
		if (!CollectionUtils.isEmpty(projectList)) {
			List<Object> objectList = new ArrayList<>(projectList);
			ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, objectList);
		} else {
			log.info("Exit getProjectList method");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getProjectList");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}

	/**
	 * get RM Approvers list of respective workflow.
	 * @param userId
	 * @param roleId
	 * @param projectId
	 * @param requestType
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path = "/rmapproverslist")
	public ResponseEntity<RMResponseDto> getRMApproversList(@Valid @RequestParam(name = "projectId") long projectId,
			@Valid @RequestParam(name = "userId") long userId, @Valid @RequestParam(name = "roleId") long roleId,
			@Valid @RequestParam("requestType") String requestType) throws ResourceManagementException {
		log.info("Entered into ResourceManagementController.getRMApproversList method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		ResponseEntity<RMResponseDto> respEntityObj = null;
		List<RMApproversDto> rmApproversListObj = resourceManagementService.getRMApproversList(projectId, userId,
				roleId, requestType, false);
		if (!CollectionUtils.isEmpty(rmApproversListObj)) {
			List<Object> dataObjList = new ArrayList<>(rmApproversListObj);
			ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, dataObjList);
			respEntityObj = new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
		} else {
			respEntityObj = new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("Just before leaving ResourceManagementController.getRMApproversList method:");
		return respEntityObj;
	}
	
	/**
	 * Submits the request for approval of respective workflow.
	 * @param RMApprovalInputDto
	 * @return
	 * @throws ResourceManagementException
	 */
	@PostMapping(path = "/rmapproval", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RMResponseDto> submitRMApproval(@Valid @RequestBody List<RMApprovalInputDto> rmApprovalDtlsList)
			throws ResourceManagementException {
		log.info("Entered into ResourceManagementController.submitRMApproval method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		resourceManagementService.submitRMApproval(rmApprovalDtlsList);			
		log.info("Just before leaving ResourceManagementController.submitRMApproval method:");
		return new ResponseEntity<>(rmResponseDto,	HttpStatus.CREATED);		 
	}	
	
	/**
	 * approve or rejects the RM request of respective workflow.
	 * @param RMApprovalInputDto List
	 * @return
	 * @throws ResourceManagementException
	 * @throws ParseException 
	 */
	@PostMapping(path ="/approveorrejectrmapproval", produces= MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE )
	public  ResponseEntity<RMResponseDto> approveOrRejectRMApproval(@Valid @RequestBody List<RMApprovalInputDto> rmApproveOrRejectDtls) throws ResourceManagementException, ParseException {
		log.info("Entered into ResourceManagementController.approveOrRejectRMApproval method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		resourceManagementService.approveOrRejectRMApproval(rmApproveOrRejectDtls);			
		log.info("Just before leaving ResourceManagementController.approveOrRejectRMApproval method:");
		return new ResponseEntity<>(rmResponseDto,	HttpStatus.CREATED);
	}	
	
	
	/**
	 * update the statusId to Rejected for the given list of employees, based on the request type.
	 * @param RMApprovalInputDto
	 * @return
	 * @throws ResourceManagementException
	 */
	@PostMapping(path = "/rmsavedresourcesrejection", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<RMResponseDto>  rejectRMSavedResources(@Valid @RequestBody List<RMApprovalInputDto> rejectResourceDtlsList)
			throws ResourceManagementException {		
		log.info("Entered into ResourceManagementController.rejectRMSavedResources method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		resourceManagementService.rejectRMSavedResources(rejectResourceDtlsList);			
		log.info("Just before leaving ResourceManagementController.rejectRMSavedResources method:");
		return new ResponseEntity<>(rmResponseDto,	HttpStatus.CREATED);		
	}

	@GetMapping(path = "/rmatransferpproverslist")
	public ResponseEntity<RMResponseDto> getRMTransferApproversList(
			@Valid @RequestParam(name = "sourceProjectId") long sourceProjectId,
			@Valid @RequestParam(name = "targetProjectId") long targetProjectId,
			@Valid @RequestParam(name = "userId") long userId, @Valid @RequestParam(name = "roleId") long roleId,
			@Valid @RequestParam("requestType") String requestType) throws ResourceManagementException {
		log.info("Entered into ResourceManagementController.getRMTransApproversList method:");
		RMResponseDto rmResponseDto = new RMResponseDto();
		ResponseEntity<RMResponseDto> respEntityObj = null;
		TransferApproverResponseDto rmTransferApproversListObj = resourceManagementService
				.getRMTransferApproversList(sourceProjectId, targetProjectId, userId, roleId, requestType);

		if (null != rmTransferApproversListObj) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, rmTransferApproversListObj);
			respEntityObj = new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
		} else {
			respEntityObj = new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("Just before leaving ResourceManagementController.getRMTransApproversList method:");
		return respEntityObj;
	}
	
	/**
	 * approve or rejects the RM request of respective workflow.
	 * @param RMApprovalInputDto List
	 * @return
	 * @throws ResourceManagementException
	 */
	@PostMapping(path ="/approveorrejectrmapprovalextension", produces= MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE )
	public  ResponseEntity<RMResponseDto> approveOrRejectRMApprovalForExtension(@Valid @RequestBody List<RMApprovalInputDto> rmApproveOrRejectDtlsExtension) throws ResourceManagementException {
		log.info("Entered into ResourceManagementController.approveOrRejectRMApproval method:");
		RMResponseDto newrmResponseDto = new RMResponseDto();
		resourceManagementService.approveOrRejectRMApprovalForExtension(rmApproveOrRejectDtlsExtension);		
		log.info("Just before leaving ResourceManagementController.approveOrRejectRMApproval method:");
		return new ResponseEntity<>(newrmResponseDto,	HttpStatus.CREATED);
	}	
	
	
	@PostMapping(path = "/costcard")
	public ResponseEntity<CostCardDto> getCostCard(@RequestBody CostCardInputDto costCardInputDto
	) throws ResourceManagementException {
		log.info("Start getCostCard");
		CostCardDto costCardDto = resourceManagementService.getCostCard(costCardInputDto);
		if (null != costCardDto) {
			log.info("Exiting getCostCard");
			return new ResponseEntity<>(costCardDto, HttpStatus.OK);
		} else {
			log.info("Exiting getCostCard with error");
			throw new ResourceManagementException(ResourceManagementConstant.Cost_Card_Message);

		}
  
	}
	
	
	/**
	 * @param
	 * @return
	 * @throws ProjectDefinitionException
	 */
	@GetMapping(path = "/newemployeedetails")
	public ResponseEntity<RMResponseDto> getAllEmployeeDetails(@Valid @NotNull @RequestParam String searchParameter) throws ResourceManagementException {
		log.info("inside getAllEmployeeDetails");
		RMResponseDto pdResponseDto = new RMResponseDto();
		List<EmployeeDto> employeeDetails = resourceManagementService.getAllEmployeeDetails(searchParameter);
		if (null != employeeDetails) {
			ResourceManagementUtil.setResourceManagementDto(pdResponseDto, employeeDetails);
		} else {
			log.info("Exiting getAllEmployeeDetails with error");
			throw new ResourceManagementException(ResourceManagementConstant.IN_VALID_EMPLOYEE);
		}
		log.info("Exiting getAllEmployeeDetails with error");
		return new ResponseEntity<>(pdResponseDto, HttpStatus.OK);
	}
	
	
	//Added by Mrunal Marne for milestone selection while resource allocation
	@GetMapping(path = "/pomilestonedetailsbyprojectid")
	public ResponseEntity<RMResponseDto> getPoAndMilestoneDetailsByProjectId(
			@Valid @NotNull(message = ResourceManagementConstant.PROJECT_ID_VALID) @RequestParam(name = "projectId") Long projectId, 
			@Valid @NotNull(message = ResourceManagementConstant.INVALID_INPUT) @RequestParam(name = "allocStartDate") String allocStartDate,
			@Valid @NotNull(message = ResourceManagementConstant.INVALID_INPUT) @RequestParam(name = "allocEndDate") String allocEndDate) 
			throws ResourceManagementException, ParseException {		
		log.info("Start getPoAndMilestoneDetailsByProjectId - projectId::{}", projectId, "allocStartDate::{}", allocStartDate, "allocEndDate::{}", allocEndDate);
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<PoAndMilestoneDetailsDto> poAndMilestoneList = resourceManagementService.getPoAndMilestoneDetailsByProjectId(projectId, allocStartDate, allocEndDate);
		if (!CollectionUtils.isEmpty(poAndMilestoneList)) {
			List<Object> objectList = new ArrayList<>(poAndMilestoneList);
			ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, objectList);
		} else {
			log.info("Exit getPoAndMilestoneDetailsByProjectId method");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getPoAndMilestoneDetailsByProjectId");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	//Added by Mrunal Marne for RMG Tagging
	/*@GetMapping(path = "/rmgtype")
	public ResponseEntity<RMResponseDto> getAllRMGTypeList() throws ResourceManagementException {		
		log.info("Start rmgtype");
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<LookupValueDto> rmgTypeDtoList = resourceManagementService.getRMGTypeDetailsDtos();
		if (!CollectionUtils.isEmpty(rmgTypeDtoList)) {
			List<Object> objectList = new ArrayList<>(rmgTypeDtoList);
			ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, objectList);
		} else {
			log.info("Exit rmgtype method");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End rmgtype");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	@GetMapping(path = "/rmgtagging")
	public ResponseEntity<RMResponseDto> getRmgTagging(@Valid @NotNull(message = ResourceManagementConstant.INVALID_INPUT) @RequestParam(name = "employeeNumber") Long employeeNumber) 
			throws ResourceManagementException {		
		log.info("Start getRmgTagging");
		RMResponseDto rmResponseDto = new RMResponseDto();
		TAssociateRmgTagDto rmgTaggingResponseDto = resourceManagementService.getRmgTagging(employeeNumber);
		if (rmgTaggingResponseDto != null) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, rmgTaggingResponseDto);
		} else {
			log.info("Exit getRmgTagging method");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getRmgTagging");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.CREATED);
	}
	
	@PostMapping(path = "/savermgtagging", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RMResponseDto> saveRmgTagging(@Valid @RequestBody TAssociateRmgTagDto rmgTaggingRequestDto) 
			throws ResourceManagementException, ParseException {		
		log.info("Start rmgtype");
		RMResponseDto rmResponseDto = new RMResponseDto();
		TAssociateRmgTagDto rmgTaggingResponseDto = resourceManagementService.saveRmgTagging(rmgTaggingRequestDto);
		if (rmgTaggingResponseDto != null) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, rmgTaggingResponseDto);
		} else {
			log.info("Exit rmgtype method");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End rmgtype");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.CREATED);
	}*/
	//End by Mrunal Marne
	
}
