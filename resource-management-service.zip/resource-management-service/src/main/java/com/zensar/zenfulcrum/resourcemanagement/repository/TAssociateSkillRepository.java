package com.zensar.zenfulcrum.resourcemanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateSkill;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

@Repository
public interface TAssociateSkillRepository extends JpaRepository<TAssociateSkill, Long> {

	@Query(value="SELECT * FROM T_ASSOCIATE_SKILL WHERE skill_id =:skillId AND status_id =:statusId",nativeQuery=true)
	List<TAssociateSkill> findBySkillId(@Param("skillId") Long skillId,@Param("statusId") Long statusId);
	
	  
	List<TAssociateSkill> findByAssociateIdIn(List<Long> associateId);
	
	@Query(value="SELECT * FROM`T_ASSOCIATE_SKILL` WHERE `associate_id` IN :associateId AND `skill_competancy_id` = :primarySkillFlag AND `status_id` = :statusIdForSkillActive",nativeQuery=true)
	List<TAssociateSkill> getPrimarySkillForAssociate(List<Long> associateId,Long primarySkillFlag,Long statusIdForSkillActive);

	@Query(value="SELECT `skill_id` FROM  `T_ASSOCIATE_SKILL` WHERE `associate_id` = :employeeId",nativeQuery=true)
     List<Long> getSkillListForEmployee(Long employeeId);
	
	@Query(value="SELECT `skill_id` FROM  `T_ASSOCIATE_SKILL` WHERE `associate_id` = :employeeId AND `skill_competancy_id` = :primarySkillFlag AND `status_id` = :statusIdForSkillActive ",nativeQuery=true)
    List<Long> getSkillListForEmployee(Long employeeId,Long primarySkillFlag,Long statusIdForSkillActive);
	
	@Query(value="SELECT bms.module_status_id FROM `zf_admin`.B_MODULE_STATUS bms INNER JOIN `zf_admin`.M_MODULE mm ON bms.module_id = mm.module_id WHERE mm.module_code ='SKILL' AND bms.link_status_id =1 AND mm.status='ACTIVATE' AND bms.status ='ACTIVATE'",nativeQuery=true)
	Long  getSkillActiveModuleStatusId();
	
	//Added by Mrunal Marne for budget calculation in transfer within same phase
	@Query(value="SELECT * FROM`T_ASSOCIATE_SKILL` WHERE `associate_id` IN :associateId AND `skill_competancy_id` = :primarySkillFlag AND `status_id` = :statusIdForSkillActive LIMIT 1",nativeQuery=true)
	TAssociateSkill getSinglePrimarySkillForAssociate(List<Long> associateId,Long primarySkillFlag,Long statusIdForSkillActive);

}
