package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class AssociateHistoryReportDto {

	Long projectId; 
	String srfNo;
	Double utilization;
	String actualAllocationStartDate;
	String actualAllocationEndDate;
	String estimatedReleaseDate;
	String allocationStatus;
	Long statusId;
	Long serviceLineId;
	String createdDate;
}
