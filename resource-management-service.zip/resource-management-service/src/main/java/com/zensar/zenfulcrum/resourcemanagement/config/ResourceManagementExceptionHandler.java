package com.zensar.zenfulcrum.resourcemanagement.config;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.zensar.zenfulcrum.resourcemanagement.dto.RMErrorDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
public class ResourceManagementExceptionHandler {
	@ExceptionHandler(ConstraintViolationException.class)
	public final ResponseEntity<RMResponseDto> handleConstraintViolationException(Exception ex) {
		log.error(ex.getMessage(), ex);
		RMResponseDto rmRMResponseDto = new RMResponseDto();
		RMErrorDto rmErrorDto = new RMErrorDto();
		if (null != ex.getMessage()) {
			List<String> list = Arrays.asList(ex.getMessage().split(","));
			rmErrorDto.setErrorMessage(list.stream().map(i -> i.split(":")[1]).collect(Collectors.toSet()).toString()
					.replace("[", "").replace("]", "").trim());
			rmErrorDto.setErrorCause("ConstraintViolationException");
			rmRMResponseDto.setError(rmErrorDto);
		}
		return ResponseEntity.badRequest().body(rmRMResponseDto);
	}

	@ExceptionHandler(RuntimeException.class)
	public final ResponseEntity<RMResponseDto> handleRuntimeException(Exception ex) {
		log.info("Inside handleRuntimeException");
		log.error(ex.getMessage(), ex);
		return processException(ex);

	}

	@ExceptionHandler(ResourceManagementException.class)
	public final ResponseEntity<RMResponseDto> handleWorkflowException(Exception ex) {
		log.info("Inside handleWorkflowException");
		log.error(ex.getMessage(), ex);
		return processException(ex);
	}

	@ExceptionHandler(MissingServletRequestParameterException.class)
	public final ResponseEntity<RMResponseDto> handleMissingServletRequestParameterException(
			MissingServletRequestParameterException ex) {
		log.info("Inside handleMissingServletRequestParameterException");
		log.error(ex.getMessage(), ex);
		RMResponseDto rmResponseDto = new RMResponseDto();
		RMErrorDto rmErrorDto = new RMErrorDto();
		rmErrorDto.setErrorMessage(ex.getMessage());
		rmErrorDto.setErrorCause("MissingServletRequestParameterException");
		rmResponseDto.setError(rmErrorDto);
		return ResponseEntity.badRequest().body(rmResponseDto);

	}

	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public final ResponseEntity<RMResponseDto> handleMethodArgumentTypeMismatchException(
			MethodArgumentTypeMismatchException ex) {
		log.info("Inside handleMissingServletRequestParameterException");
		log.error(ex.getMessage(), ex);
		RMResponseDto rmResponseDto = new RMResponseDto();
		RMErrorDto rmErrorDto = new RMErrorDto();
		rmErrorDto.setErrorMessage(ex.getMessage());
		rmErrorDto.setErrorCause("MissingServletRequestParameterException");
		rmResponseDto.setError(rmErrorDto);
		return ResponseEntity.badRequest().body(rmResponseDto);
	}

	private ResponseEntity<RMResponseDto> processException(Exception ex) {
		RMResponseDto rmResponseDto = new RMResponseDto();
		RMErrorDto rmErrorDto = new RMErrorDto();
		if (ex.getCause() != null && ResourceManagementConstant.CONSTRAINT_EXCEPTION.equals(ex.getCause().getMessage())) {
			rmErrorDto.setErrorMessage(ex.getMessage());
			rmErrorDto.setErrorCause(ex.getCause().getMessage());
			rmResponseDto.setError(rmErrorDto);
			return ResponseEntity.badRequest().body(rmResponseDto);
		}
		if (null != ex.getMessage()) {
			rmErrorDto.setErrorCause("Unable to process your request");
			rmErrorDto.setErrorMessage(ex.getMessage());
			rmResponseDto.setError(rmErrorDto);
		}
		return new ResponseEntity<>(rmResponseDto, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(org.springframework.dao.DataIntegrityViolationException.class)
	public ResponseEntity<RMResponseDto> handleSQLIntegrityConstraintViolationException(
			org.springframework.dao.DataIntegrityViolationException ex) {
		log.info("Inside handleSQLIntegrityConstraintViolationException");
		log.error(ex.getMessage(), ex);
		RMResponseDto rmResponseDto = new RMResponseDto();
		RMErrorDto rmErrorDto = new RMErrorDto();
		rmErrorDto.setErrorMessage(ex.getCause().getCause().getMessage());
		rmErrorDto.setErrorCause("SQLIntegrityConstraintViolationException");
		rmResponseDto.setError(rmErrorDto);
		return ResponseEntity.badRequest().body(rmResponseDto);
	}

	@ExceptionHandler(org.springframework.web.bind.MethodArgumentNotValidException.class)
	public ResponseEntity<RMResponseDto> handleMethodArgumentNotValidException(
			org.springframework.web.bind.MethodArgumentNotValidException ex) {
		log.info("Inside handleMethodArgumentNotValidException");
		log.error(ex.getMessage(), ex);
		BindingResult result = ex.getBindingResult();
		List<FieldError> fieldErrors = result.getAllErrors().stream().filter(e -> e instanceof FieldError)
				.map(a -> (FieldError) a).collect(Collectors.toList());
		RMResponseDto rmResponseDto = new RMResponseDto();
		RMErrorDto rmErrorDto = new RMErrorDto();
		rmErrorDto.setErrorMessage(fieldErrors.stream().map(FieldError::getDefaultMessage)
				.collect(Collectors.toSet()).toString().replace("[", "").replace("]", "").trim());
		rmErrorDto.setErrorCause("org.springframework.web.bind.MethodArgumentNotValidException");
		rmResponseDto.setError(rmErrorDto);
		return ResponseEntity.badRequest().body(rmResponseDto);
	}
	
	@ExceptionHandler(javax.persistence.EntityNotFoundException.class)
	public ResponseEntity<RMResponseDto> handleEntityNotFoundException(javax.persistence.EntityNotFoundException ex){
		log.info("Inside handleEntityNotFoundException");
		log.error(ex.getMessage(), ex);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
