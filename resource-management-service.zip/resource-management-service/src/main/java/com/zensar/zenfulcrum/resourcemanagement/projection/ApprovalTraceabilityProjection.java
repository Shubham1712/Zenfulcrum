package com.zensar.zenfulcrum.resourcemanagement.projection;

import java.util.Date;

public interface ApprovalTraceabilityProjection {
	
	public Date getAllocLastUpdatedDate();
	
	public Date getWrkflwLastUpdatedDate();
	
	public Long getCurrentUserId();
	
	public Long getCurrentRoleId();
	
	public Long getWkflowStatusId();
	
	public Long getStatusId();
	
	public String getComments();
	
	public Long getEmployeeId();
	
	public Long getTransactionId();
	
	public Date setAllocLastUpdatedDate(Date date);
	
	public Date setWrkflwLastUpdatedDate(Date date);
	
	public Long setCurrentUserId(long currentuserId);
	
	public Long setCurrentRoleId(long currentRoleId);
	
	public Long setWkflowStatusId(long workflowStatusId);
	
	public Long setStatusId(long statusId);
	
	public String setComments(String comment);
	
	public Long setEmployeeId(long empId);
	
	public Long setTransactionId(long transactionId);
	
	

}
