package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;

import lombok.Data;

@Data
public class FYIapproverDto {

	private List<PrimaryUsersDto> sourceFYIapproversList;
	private List<PrimaryUsersDto> targetFYIapproversList;

}
