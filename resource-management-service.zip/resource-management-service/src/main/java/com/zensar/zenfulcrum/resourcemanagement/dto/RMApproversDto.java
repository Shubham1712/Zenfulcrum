package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class RMApproversDto{ 	
	private String roleName;
	private long roleId;
	private String userName;
	private long userId;
	private long stepId;
}
