package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class TraceabilityApprSummaryDto {
	
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date actionDate;

	private String approverName;
	
	private String roleName;
	
	private String action;
	
	private String comments;
	
	private long approverEmpId;
}
