package com.zensar.zenfulcrum.resourcemanagement.projection;

public interface TAssociateAllocationProjection {

	public Long getassociateProjectId();

	public void setassociateProjectId(String associateProjectId);

	public Long getbillableStatusId();

	public void setbillableStatusId(Long billableStatusId);

	public double getftePercent();

	public void setftePercent(double ftePercent);

}
