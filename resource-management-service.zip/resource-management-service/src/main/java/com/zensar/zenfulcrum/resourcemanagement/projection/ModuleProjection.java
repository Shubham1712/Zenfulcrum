package com.zensar.zenfulcrum.resourcemanagement.projection;

public interface ModuleProjection {
	
	public Long getModuleId();
	public String getModuleCode();
    public String getModuleName();
	
    public void setModuleId(long l);
	public void setModuleCode(String s);
	public void setModuleName(String s);


}
