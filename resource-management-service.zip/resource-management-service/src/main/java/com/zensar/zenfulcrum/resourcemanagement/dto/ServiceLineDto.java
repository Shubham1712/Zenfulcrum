package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class ServiceLineDto {
	private long serviceLineId;
	private String serviceLine;
}
