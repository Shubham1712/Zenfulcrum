package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;

import lombok.Data;

@Data
public class TAssociateDeallocationInputDto {

	private String roleName;
	private List<TAssociateDeAllocationDto> tassociateDeAllocationList;
	private Long userId;

}
