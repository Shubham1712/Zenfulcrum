package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;
import lombok.Data;

/**
 * @author MM54168
 *
 */

@Data
public class BAllocationMilestoneDto {
	
	private Long allocationMilestoneId;
	
	private Long associateAllocationId;
	
	private Long employeeId;

	private Long projectId;

	private String milestoneName;

	private Date milestoneStartDate;

	private Date milestoneEndDate;

	private String poNumber;

	private Long bapPaymentScheduleKey;

	private Long poInvoiceKey;
		
	private Long statusId;

	private Long createdBy;

	private Long  lastUpdatedBy;

	private Date createdDate;
	
	private Date lastUpdatedDate;

}
