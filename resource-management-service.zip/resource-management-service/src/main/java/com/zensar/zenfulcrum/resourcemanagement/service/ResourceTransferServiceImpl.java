package com.zensar.zenfulcrum.resourcemanagement.service;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.HashBasedTable;
import com.zensar.zenfulcrum.resourcemanagement.dto.AllocationTypeStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.BAllocationMilestoneDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeSkillDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueNewDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PrimaryUsersDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApproversDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTResourceDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTWithinSamePhaseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ServiceLineDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TransferResourceListDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.AllocatedResourceHelperClass;
import com.zensar.zenfulcrum.resourcemanagement.helper.JVCheckHelperService;
import com.zensar.zenfulcrum.resourcemanagement.helper.SendMailHelperService;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateDeAllocationMapper;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateProjectMapper;
import com.zensar.zenfulcrum.resourcemanagement.model.ResourceWorkflow;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocationBudget;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateDeAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateProject;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateSkill;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.AssociateAllocationBudgetRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.AssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.JVDetailsRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceWorkflowRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateSkillRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.RMBudgetControlUtil;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

import lombok.Lombok;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class ResourceTransferServiceImpl implements ResourceTransferService {

	@Autowired
	private TAssociateProjectMapper tAssociateProjectMapper;

	@Autowired
	private ResourceAllocationServiceImpl resourceAllocationServiceImpl;

	@Autowired
	private TAssociateProjectRepository tAssociateProjectRepository;

	@Autowired
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Autowired
	private ResourceManagementServiceImpl resourceManagementServiceImpl;

	@Autowired
	private BAPServiceClient bapServiceClient;

	@Autowired
	private AdminServiceClient adminServiceClient;
	@Autowired
	private BudgetControlServiceClient budgetControlServiceClient;

	@Autowired
	private ResourceWorkflowRepository resourceWorkflowRepository;

	@Autowired
	private SendMailHelperService sendMailHelperServiceObj;

	@Autowired
	private TAssociateDeAllocationRepository tAssociateDeAllocationRepository;

	@Autowired
	private TAssociateDeAllocationMapper asssociateDeallocationMapper;

	@Autowired
	private TAssociateSkillRepository skillRepository;

	@Autowired
	private JVDetailsRepository jvDetailsRepository;

	@Autowired
	JVCheckHelperService jvCheckHelperService;

	@Autowired
	AllocatedResourceHelperClass allocatedResourceHelperClass;

	@Autowired
	ResourceRequirementServiceImpl resourceRequirementServiceImpl;

	@Autowired
	private ResourceAllocationServiceImpl resourceAllocationServiceImplObj;

	@Autowired
	AssociateAllocationBudgetRepository associateAllocationBudgetRepository;

	@Autowired
	private AssociateProjectRepository associateProjectRepository;

	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

	/**
	 * Service method for Transfer within same phase.
	 * 
	 * @throws ParseException
	 */
	@Override
	@Transactional(readOnly = false)
	public void updateResTransferInSameProject(RTWithinSamePhaseDto rtWithinSamePhaseDto)
			throws ResourceManagementException, ParseException {
		log.info("Start updateResTransferInSamePhase");

		List<TAssociateAllocation> tAllocationList = null;
		List<Long> employeeIdList = null;
		List<TransferResourceListDto> requirementList = rtWithinSamePhaseDto.getRequirementList();

		HashBasedTable<String, String, Long> getallModuleData = allocatedResourceHelperClass.getallModuleData();
		Long activeStatus = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long workflowStatusApproved = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);

		Long lookupIdForNb = adminServiceClient.getLookuIdByTypeAndDescr(
				ResourceManagementConstant.PROJECT_BILLABLE_TYPE, ResourceManagementConstant.Non_Billable);

		Long projectBillableIdbyProjectId = adminServiceClient
				.getProjectBillableIdbyProjectId(rtWithinSamePhaseDto.getProjectId());

		if (projectBillableIdbyProjectId.equals(lookupIdForNb)) {
			for (TransferResourceListDto requirement : requirementList) {
				employeeIdList = requirement.getEmployeeIdList();
				Long projectId = rtWithinSamePhaseDto.getProjectId();
				List<TAssociateProject> allocationProjectListByEmployeeId = tAssociateProjectRepository
						.getAssociateProjectByEmployeeIdAndStatusId(employeeIdList, activeStatus,
								workflowStatusApproved, projectId);
				Map<Long, TAssociateProject> tAssociateProjectMap = allocationProjectListByEmployeeId.stream().collect(
						Collectors.toMap(TAssociateProject::getEmployeeId, associateproject -> associateproject));

				tAllocationList = setResourceDetailsForTransferWithinProject(tAssociateProjectMap, rtWithinSamePhaseDto,
						requirement);

				List<TAssociateAllocation> transferResourceList = tAssociateAllocationRepository
						.saveAll(tAllocationList);
				Long deactiveStatus = getallModuleData.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.DEACTIVATE);
				Long workflowApprovedStatus = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
						ResourceManagementConstant.APPROVED);
				List<Long> transactionHistoryIdList = transferResourceList.stream()
						.map(TAssociateAllocation::getTransactionHistoryId).collect(Collectors.toList());
				tAssociateAllocationRepository.deactivateNBTransferResourceAllocation(transactionHistoryIdList,
						deactiveStatus, rtWithinSamePhaseDto.getUserId(),
						transferResourceList.get(0).getEffectiveStartDate(), workflowApprovedStatus);
			}
		} else {
			if (rtWithinSamePhaseDto.getRoleName().equals(ResourceManagementConstant.ADMIN_ROLE_NAME)
					|| rtWithinSamePhaseDto.getRoleName().equals(ResourceManagementConstant.TAG_ROLE_NAME)) {
				saveTransferWithinSameProjectObject(rtWithinSamePhaseDto);
				List<TAssociateAllocation> tAllocationDtlsListObj = null;
				for (TransferResourceListDto transferResource : rtWithinSamePhaseDto.getRequirementList()) {
					tAllocationDtlsListObj = tAssociateAllocationRepository.getRAllocationDetails(
							rtWithinSamePhaseDto.getProjectId(), activeStatus, transferResource.getEmployeeIdList(),
							transferResource.getRequirementId(), workflowStatusApproved);

					List<Long> transactionHistoryIdList = tAllocationDtlsListObj.stream()
							.map(TAssociateAllocation::getTransactionHistoryId).collect(Collectors.toList());
					RMApprovalInputDto rtApproveDtls = new RMApprovalInputDto();
					rtApproveDtls.setCurrentProjectId(rtWithinSamePhaseDto.getProjectId());
					rtApproveDtls.setCurrentRequirementId(transferResource.getSourceRequirementId());
					rtApproveDtls.setResourceList(transferResource.getRtResourceDtoList());
					performUpdateBudgetAndDeactivateFinalApproval(tAllocationDtlsListObj, transactionHistoryIdList,
							rtApproveDtls);
				}
			} else {
				saveTransferWithinSameProjectObject(rtWithinSamePhaseDto);
			}
		}
		log.info("End updateResTransferInSamePhase");
	}

	public void saveTransferWithinSameProjectObject(RTWithinSamePhaseDto rtWithinSamePhaseDto)
			throws ResourceManagementException, ParseException {
		Date jvDate = jvDetailsRepository.getWindowEndDate();
		// Added by Mrunal Marne for milestone selection while resource transfer
		List<BAllocationMilestoneDto> bAllocationMilestoneList = new ArrayList<>();
		List<String> lookupValueDescList = List.of(ResourceManagementConstant.COMMERCIAL_MODEL_FIXED_PRICE, ResourceManagementConstant.COMMERCIAL_MODEL_FIXED_PRICE_AMC);
		List<LookupValueNewDto> lookupValueListByLookupDesc = adminServiceClient.getLookupValueListByLookupDesc(lookupValueDescList);
		List<Long> fixedPriceStatusIdList = lookupValueListByLookupDesc.stream().map(LookupValueNewDto::getLookupValueId).collect(Collectors.toList());
		Long projectCommercialTypeId = bapServiceClient.getSalesOrderDetailByProjectId(rtWithinSamePhaseDto.getProjectId());
		Long lookupIdForNb = adminServiceClient.getLookuIdByTypeAndDescr(ResourceManagementConstant.PROJECT_BILLABLE_TYPE, ResourceManagementConstant.Non_Billable);
		Long projectBillableIdbyProjectId = adminServiceClient.getProjectBillableIdbyProjectId(rtWithinSamePhaseDto.getProjectId());
		// End by Mrunal Marne
		HashBasedTable<String, String, Long> getallModuleData = allocatedResourceHelperClass.getallModuleData();
		Long activeStatus = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long workflowStatusApproved = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);

		if (null != jvCheckHelperService.isJvCheck(jvDate) && jvCheckHelperService.isJvCheck(jvDate)) {
			throw new ResourceManagementException(ResourceManagementConstant.TRANSFER_NOT_POSSIBLE);
		} else {
			List<TAssociateAllocation> tAllocationList = null;
			List<Long> employeeIdList = null;
			List<TransferResourceListDto> requirementList = rtWithinSamePhaseDto.getRequirementList();
			// Added by Mrunal Marne for milestone selection while resource transfer
			List<TAssociateAllocation> tAllocationListAll = new ArrayList<>();
			Map<Long, TransferResourceListDto> requirementMap = new HashMap<>();
			if (Objects.nonNull(requirementList)) {
				requirementList.forEach(obj -> {
					obj.getEmployeeIdList().forEach(emp -> {
						requirementMap.put(emp, obj);
					});
				});
			}
			// End by Mrunal Marne
			Long projectId = rtWithinSamePhaseDto.getProjectId();
			boolean budgetCheck = true;
			boolean isBudgetPresent = resourceAllocationServiceImpl.getBudgetAndCostCheck(projectId);
			if (isBudgetPresent) {
				budgetCheck = budgetControlCheck(requirementList, projectId);
			}
			if (budgetCheck) {
				for (TransferResourceListDto requirement : requirementList) {
					employeeIdList = requirement.getEmployeeIdList();
					List<TAssociateProject> allocationProjectListByEmployeeId = tAssociateProjectRepository
							.getAssociateProjectByEmployeeIdAndStatusId(employeeIdList, activeStatus,
									workflowStatusApproved, projectId);
					Map<Long, TAssociateProject> tAssociateProjectMap = allocationProjectListByEmployeeId.stream()
							.collect(Collectors.toMap(TAssociateProject::getEmployeeId,
									associateproject -> associateproject));

					tAllocationList = setResourceDetailsForTransferWithinProject(tAssociateProjectMap,
							rtWithinSamePhaseDto, requirement);
					// Added by Mrunal Marne for milestone selection while resource transfer
					tAllocationListAll.addAll(tAssociateAllocationRepository.saveAll(tAllocationList));
				}
			}
			// Added by Mrunal Marne for milestone selection while resource transfer
			Map<Long, TAssociateAllocation> associateProjectMap = new HashMap<>();
			if (Objects.nonNull(tAllocationListAll))
				tAllocationListAll.forEach(obj -> associateProjectMap.put(obj.getTAssociateProject().getEmployeeId(), obj));
			bAllocationMilestoneList = prepareMilestoneDetailsForSaveResourceTransferInSameProject(requirementMap, associateProjectMap, projectCommercialTypeId, fixedPriceStatusIdList, projectBillableIdbyProjectId, lookupIdForNb);		
			if (!bAllocationMilestoneList.isEmpty()) {
				bapServiceClient.savePoAndMilestoneDetailsDuringAllocation(bAllocationMilestoneList);
			}
		}
	}

	public boolean budgetControlCheck(List<TransferResourceListDto> requirementList, Long projectId)
			throws ResourceManagementException {
		boolean isBudgetCheckPassed = true;

		HashBasedTable<String, String, Long> getallModuleData = allocatedResourceHelperClass.getallModuleData();
		Long activeStatus = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long workflowStatusApproved = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);

		List<ProjectBudgetDto> projectBudgetDto = budgetControlServiceClient.getProjectMonthlyBudgetsDetails(projectId);
		Map<String, ProjectBudgetDto> projectBudgets = projectBudgetDto.stream().collect(HashMap::new,
				(m, v) -> m.put(v.getMonth(), v), HashMap::putAll);
		/*
		 * Long activeStatus = resourceManagementServiceImpl.getModuleStatusId(
		 * ResourceManagementConstant.RESOURCE_ALLOCATION,
		 * ResourceManagementConstant.ACTIVE_ACTION); Long workflowStatusApproved =
		 * resourceManagementServiceImpl.getModuleStatusId(
		 * ResourceManagementConstant.RESOURCE_ALLOCATION,
		 * ResourceManagementConstant.APPROVED_ACTION);
		 */

		for (TransferResourceListDto requirement : requirementList) {
			List<Long> employeeIdList = requirement.getEmployeeIdList();
			ResourceRequirementDto resourceRequirementDto = bapServiceClient
					.getRequirementDetailByReqId(requirement.getRequirementId());

			List<TAssociateProject> allocationProjectListByEmployeeId = tAssociateProjectRepository
					.getAssociateProjectByEmployeeIdAndStatusId(employeeIdList, activeStatus, workflowStatusApproved,
							projectId);
			List<TAssociateProjectDto> associateProjectListDto = tAssociateProjectMapper
					.tAssociateProjectToTAssociateProjectDto(allocationProjectListByEmployeeId);
			//Added by Mrunal Marne for budget calculation in transfer within same phase
			for (TAssociateProjectDto tAssociateProjectData : associateProjectListDto) {
				tAssociateProjectData.getTAssociateAllocation()
						.setActualAllocationStartDate(requirement.getTransferStartDate());
				tAssociateProjectData.getTAssociateAllocation().setActualAllocationEndDate(requirement.getTransferEndDate());
				tAssociateProjectData.getTAssociateAllocation().setEstAllocationEndDate(requirement.getTransferEndDate());
				Double stdCost = getStdCost(Objects.nonNull(tAssociateProjectData.getTAssociateAllocation().getSkillId()) ? tAssociateProjectData.getTAssociateAllocation().getSkillId() : null, 
						requirement, tAssociateProjectData.getEmployeeId());
				tAssociateProjectData.getTAssociateAllocation().setStdCost(stdCost);
			}
			//End by Mrunal Marne
			boolean performBudgetControlCheck = resourceAllocationServiceImpl
					.performBudgetControlCheck(resourceRequirementDto, associateProjectListDto, projectBudgets);
			if (!performBudgetControlCheck) {
				isBudgetCheckPassed = false;
				break;
			}
		}
		if (isBudgetCheckPassed) {
			resourceAllocationServiceImpl.updateBudget(projectBudgets);
		}
		return isBudgetCheckPassed;
	}

	public List<TAssociateAllocation> setResourceDetailsForTransferWithinProject(
			Map<Long, TAssociateProject> tAssociateProjectMap, RTWithinSamePhaseDto rtWithinSamePhaseDto,
			TransferResourceListDto requirement) throws ResourceManagementException {
		List<TAssociateAllocation> tAllocationList = new ArrayList<>();

		HashBasedTable<String, String, Long> getallModuleData = allocatedResourceHelperClass.getallModuleData();
		Long activeStatus = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long workflowStatusApproved = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long workflowStatusSaved = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.SAVED);
		//Added by Mrunal Marne for setting updated cost rate during transfer within same project
		List<LookupValueDto> projectBillableStatusList = adminServiceClient.getLookupValueByLookupType("PROJECT_BILLABLE_TYPE");
		List<LookupValueDto> resourceBillableStatusList = adminServiceClient.getLookupValueByLookupType("RESOURCE_BILLABLE_TYPE");
		Map<Long, String> projectBillableStatusMap = projectBillableStatusList.stream().collect(Collectors.toMap(LookupValueDto::getLookUpId, LookupValueDto::getLookupValueCode));		
		Map<String, Long> resourceBillableStatusMap = resourceBillableStatusList.stream().collect(Collectors.toMap(LookupValueDto::getLookupValueCode, LookupValueDto::getLookUpId));
		// End by Mrunal Marne
		Long lookupIdForNb = adminServiceClient.getLookuIdByTypeAndDescr(
				ResourceManagementConstant.PROJECT_BILLABLE_TYPE, ResourceManagementConstant.Non_Billable);

		Long projectBillableIdbyProjectId = adminServiceClient
				.getProjectBillableIdbyProjectId(rtWithinSamePhaseDto.getProjectId());

		List<Long> roleId = new ArrayList<>();
		roleId.add(rtWithinSamePhaseDto.getRoleId());
		List<PrimaryUsersDto> primaryUserList = bapServiceClient
				.getRoleBasedPrimaryOwnersList(rtWithinSamePhaseDto.getProjectId(), roleId);
		List<Long> employeeIds = tAssociateAllocationRepository.getEmployeeIds(List.of(rtWithinSamePhaseDto.getUserId()));

		//Commented check by Mrunal Marne for storing supervisor id from source allocation record
		// if (null != primaryUserList) {
		tAssociateProjectMap.forEach((k, associateProject) -> {
			TAssociateAllocation allocation = new TAssociateAllocation();
			Long associateProjectId = associateProject.getAssociateProjectId();
			TAssociateAllocation sourceAlloObj = tAssociateAllocationRepository
					.getAllocationByassociateProjId(associateProjectId, activeStatus, workflowStatusApproved);
			allocation.setRequirementId(requirement.getRequirementId());
			//Added by Mrunal Marne for setting updated cost rate during transfer within same project
			boolean budgetCheck = false;
			try {
				budgetCheck = resourceAllocationServiceImpl.getBudgetAndCostCheck(rtWithinSamePhaseDto.getProjectId());
			} catch (ResourceManagementException rme) {
					new ResourceManagementException("Error in fetching employee details during transfer within same project for resource id - " + k);
			}
			String band = "";
			try {
				band = (adminServiceClient.getEmployeeDetailsByEmpId(k)).getBand();
			} catch (ResourceManagementException e1) {
				Lombok.sneakyThrow(e1);
			}
			if (band.equalsIgnoreCase("S0") || band.equalsIgnoreCase("R0")) {
				allocation.setStdCost(sourceAlloObj.getStdCost());
			} else {
				if (budgetCheck) {
					Double stdCost = 0.0;
					try {
						stdCost = getStdCost(Objects.nonNull(sourceAlloObj.getSkillId()) ? sourceAlloObj.getSkillId() : null, requirement, k);
					} catch (ResourceManagementException e) {
						Lombok.sneakyThrow(e);
					}
					allocation.setStdCost(stdCost);
					log.info("Cost rate updated in transfer within same project for resource id - " + k);
				} else {
					allocation.setStdCost(sourceAlloObj.getStdCost());
				}
			}
			// End by Mrunal Marne
			allocation.setRoleId(requirement.getRoleId());
			allocation.setWorkLocationId(requirement.getWorkLocationId());
			allocation.setCreatedBy(employeeIds.get(0));
			allocation.setLastUpdatedBy(employeeIds.get(0));
			// Commented and added below by Mrunal Marne for setting updated cost rate
			// during transfer within same project
			// allocation.setBillableStatusId(requirement.getBillingStatusId());
			// allocation.setEffectiveStartDate(rtWithinSamePhaseDto.getEffectiveStartDate());
			allocation.setBillableStatusId(
					projectBillableStatusMap.containsKey(requirement.getBillingStatusId()) && resourceBillableStatusMap
							.containsKey(projectBillableStatusMap.get(requirement.getBillingStatusId()))
									? resourceBillableStatusMap.get(
											projectBillableStatusMap.get(requirement.getBillingStatusId()))
									: null);
			allocation.setEffectiveStartDate(requirement.getTransferStartDate());
			allocation.setEffectiveEndDate(requirement.getTransferEndDate());
			// End by Mrunal Marne
			allocation.setLastUpdatedDate(new Date());
			allocation.setCreatedDate(new Date());
			if (rtWithinSamePhaseDto.getRoleName().equals(ResourceManagementConstant.ADMIN_ROLE_NAME)
					|| rtWithinSamePhaseDto.getRoleName().equals(ResourceManagementConstant.TAG_ROLE_NAME)
					|| (projectBillableIdbyProjectId).equals(lookupIdForNb)) {
				allocation.setWorkflowStatusId(workflowStatusApproved);
			} else {
				allocation.setWorkflowStatusId(workflowStatusSaved);
			}

			allocation.setStatusId(activeStatus);
			allocation.setTAssociateProject(associateProject);
			allocation.setFtePercent(sourceAlloObj.getFtePercent());
			// Commented and added below by Mrunal Marne for setting updated cost rate
			// during transfer within same project
			// allocation.setActualAllocationStartDate(rtWithinSamePhaseDto.getEffectiveStartDate());
			// allocation.setActualAllocationEndDate(sourceAlloObj.getActualAllocationEndDate());
			// allocation.setEstAllocationEndDate(sourceAlloObj.getEstAllocationEndDate());
			allocation.setActualAllocationStartDate(requirement.getTransferStartDate());
			try {
				allocation.setActualAllocationEndDate(sdf.parse(ResourceManagementConstant.DEFAULT_EFFECTIVE_END_DATE));
			} catch (ParseException e) {
				new ResourceManagementException(ResourceManagementConstant.DATE_PARSE_EXCEPTION, e);
			}
			allocation.setEstAllocationEndDate(requirement.getTransferEndDate());
			// End by Mrunal Marne
			allocation.setBaseHours(sourceAlloObj.getBaseHours());
			// allocation.setSupervisorId(primaryUserList.get(0).getUserId());
			allocation.setSupervisorId(sourceAlloObj.getSupervisorId());
			//allocation.setBillableStatusReasonId(sourceAlloObj.getBillableStatusReasonId());
			if(Objects.nonNull(requirement.getBillableStatusReasonId()))
				allocation.setBillableStatusReasonId(requirement.getBillableStatusReasonId());
			else
				allocation.setBillableStatusReasonId(null);
			allocation.setSkillId(sourceAlloObj.getSkillId());
			allocation.setAllocationTypeId(sourceAlloObj.getAllocationTypeId());
			allocation.setTransactionHistoryId(sourceAlloObj.getAssociateAllocationId());
			allocation.setSkillChampionFlag(sourceAlloObj.getSkillChampionFlag());
			allocation.setSrReference(sourceAlloObj.getSrReference());
			allocation.setServiceLineId(requirement.getServiceId().longValue());
			tAllocationList.add(allocation);
			// Added below by Mrunal Marne for updating source record during transfer within
			// same project
			sourceAlloObj.setActualAllocationEndDate(
					new Date(requirement.getTransferStartDate().getTime() - ResourceManagementConstant.ONE_DAY));
			tAssociateAllocationRepository.save(sourceAlloObj);
			// End by Mrunal Marne
		});
		// }
		return tAllocationList;
	}

	//Added by Mrunal Marne for budget calculation in transfer within same phase
	public Double getStdCost(Long allocatedSkillId, TransferResourceListDto requirement, Long employeeId) 
			throws ResourceManagementException{
		Double costRate = 0.0;
		EmployeeDto employeeDetailsDto = new EmployeeDto();
		ResourceRequirementDto requirementDetailByReqId = new ResourceRequirementDto();
		SkillTaxonomyDto skillFamilyDto = new SkillTaxonomyDto();
		// Employee details
		try {
			employeeDetailsDto = adminServiceClient.getEmployeeDetailsByEmpId(employeeId);
		} catch (ResourceManagementException e1) {
			Lombok.sneakyThrow(e1);
			// new ResourceManagementException("Error in fetching employee details during ransfer within same project for resource id - " + k);
		}
		// Requirement details
		try {
			requirementDetailByReqId = bapServiceClient.getRequirementDetailByReqId(requirement.getRequirementId());
		} catch (ResourceManagementException e2) {
			Lombok.sneakyThrow(e2);
			// new ResourceManagementException("Error in fetching requirement details during transfer within same project for resource id - " + k);
		}
		// Skill details
		List<Long> skillIdsList = new ArrayList<>();
		if(Objects.nonNull(allocatedSkillId))
			skillIdsList.add(allocatedSkillId);
		else {
			Long statusIdForSkillActive = adminServiceClient.getModuleStatusByAction(ResourceManagementConstant.SKILL, ResourceManagementConstant.ACTIVATE);
			Long primarySkillFlag = adminServiceClient.getLookuIdByTypeAndDescr(ResourceManagementConstant.SKILL_COMPETANCY, ResourceManagementConstant.PRIMARY);
	        TAssociateSkill skillList = skillRepository.getSinglePrimarySkillForAssociate(List.of(employeeId), primarySkillFlag, statusIdForSkillActive);
	        skillIdsList.add(skillList.getSkillId());
		}
		try {
			skillFamilyDto = adminServiceClient.getSkillFamilyByskillId(skillIdsList).get(0);
		} catch (ResourceManagementException e3) {
			Lombok.sneakyThrow(e3);
			// new ResourceManagementException("Error in fetching skill details during transfer within same project for resource id - " + k);
		}
		// Project details
		/*try {
			projectDetail = bapServiceClient.getProjectDetail(rtWithinSamePhaseDto.getProjectId());
		} catch (ResourceManagementException e3) {
			new ResourceManagementException("Error in fetching project details during transfer within same project for resource id - " + k);
		}
		//Shore details
		try {
			shoreValue = adminServiceClient.getLookUpById(projectDetail.getProjectEngId());
		} catch (ResourceManagementException e4) {
			new ResourceManagementException("Error in fetching shore details during transfer within same project for resource id - " + k);
		}
		//Currency details
		try {
			currenctValueDto = adminServiceClient.getLookUpById(projectDetail.getProjectCurrencyId());
		} catch (ResourceManagementException e5) {
			new ResourceManagementException("Error in fetching currency details during transfer within same project for resource id - " + k);
		}*/
		// Fetch cost card
		CostCardInputDto costCardInputDto = new CostCardInputDto();
		costCardInputDto.setLocationId(requirement.getWorkLocationId());
		costCardInputDto.setBand(employeeDetailsDto.getBand());
		costCardInputDto.setPayrolld(Objects.nonNull(requirementDetailByReqId.getPayrollArrangementId())
				? requirementDetailByReqId.getPayrollArrangementId().longValue()
				: 0);
		costCardInputDto.setPracticeId(skillFamilyDto.getL2SubPracticeId());
		costCardInputDto.setLocationTypeId(requirementDetailByReqId.getReqlocationTypeId());
		costCardInputDto.setSkillFamilyId(skillFamilyDto.getL3SkillFamilyId());
		costCardInputDto.setProjectBillingHours(requirementDetailByReqId.getProjectBillingHours());
		costCardInputDto.setShore(requirementDetailByReqId.getShore());
		costCardInputDto.setCurrencyName(requirementDetailByReqId.getCurrencyName());
		costCardInputDto.setProjectRequirementId(requirementDetailByReqId.getReqId());
		try {
			CostCardDto costCardDto = resourceManagementServiceImpl.getCostCard(costCardInputDto); 
			if (null != costCardDto) {
				if (requirementDetailByReqId.getProjectBillingHours() == 8)
					costRate = costCardDto.getEightHrsCostRate().doubleValue();
				else {
					if(requirementDetailByReqId.getShore().equalsIgnoreCase(ResourceManagementConstant.ONSHORE))
						costRate = costCardDto.getEightHrsCostRate().doubleValue();
					else
						costRate = costCardDto.getNineHrsCostRate().doubleValue();
				}
				log.info("Cost rate updated in transfer within same project for resource id - " + employeeId);
			}
		} catch (ResourceManagementException e) {
			log.info("Error in fetching cost rate details in transfer within same project for resource id - " + employeeId);
			Lombok.sneakyThrow(e);
			// new ResourceManagementException(ResourceManagementConstant.Cost_Card_Message);
		}
		return costRate;
	}
	//End by Mrunal Marne

	@Override
	public void saveRTWithinODCAndProjectAndBU(RMApprovalInputDto rtInputDto)
			throws ResourceManagementException, ParseException {
		log.info("Entered into ResourceTransferServiceImpl.saveRTWithinODCAndProjectAndBU method:");
		Date jvDate = jvDetailsRepository.getWindowEndDate();
        
		HashBasedTable<String, String, Long> getallModuleData = allocatedResourceHelperClass.getallModuleData();
		Long statusIdForActive = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long wrkflwStatusTransferApproved = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long deAllocationApproStatusId = getallModuleData.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long deAllocationStatusId = getallModuleData.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
				ResourceManagementConstant.SAVED);
		Long wrkflwStatusAlloApproved = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.APPROVED);

		// Added by Mrunal Marne for milestone selection while resource transfer
		List<Long> fixedPriceStatusIdList = new ArrayList<>();
		Long projectCommercialTypeId = 0L;
		Map<Long, RTResourceDto> resourceListDtoMap = new HashMap<>();
		List<BAllocationMilestoneDto> bAllocationMilestoneList = new ArrayList<>();
		// End by Mrunal Marne
		Long userId=null;
		if (null != jvCheckHelperService.isJvCheck(jvDate) && jvCheckHelperService.isJvCheck(jvDate)) {
			throw new ResourceManagementException(ResourceManagementConstant.TRANSFER_NOT_POSSIBLE);
		} else {
			List<RTResourceDto> resourceList = rtInputDto.getResourceList();
			Long targetRequirmentId = rtInputDto.getRequirementId();
			Long targetprojectId = rtInputDto.getProjectId();
			List<Long> employeeIdList = resourceList.stream().map(RTResourceDto::getEmpId).collect(Collectors.toList());
			List<Long> employeeNumbers = getListOfAssociateAlredyAllocated(targetRequirmentId, targetprojectId,
					employeeIdList, getallModuleData);
			userId=rtInputDto.getUserId();
			rtInputDto.setUserId(tAssociateAllocationRepository.getEmployeeIds(List.of(rtInputDto.getUserId())).get(0));
			if (!CollectionUtils.isEmpty(employeeNumbers)) {
				throw new ResourceManagementException(
						employeeNumbers + "" + ResourceManagementConstant.SAME_ALLOCATION_REQUIREMENT);

			}
			// Added by Mrunal Marne for milestone selection while resource transfer
			resourceListDtoMap = resourceList.stream().
	        		collect(HashMap::new, (m, v) -> m.put(v.getEmpId(), v), HashMap::putAll);
			projectCommercialTypeId = bapServiceClient.getSalesOrderDetailByProjectId(rtInputDto.getProjectId());
			List<String> lookupValueDescList = List.of(ResourceManagementConstant.COMMERCIAL_MODEL_FIXED_PRICE, ResourceManagementConstant.COMMERCIAL_MODEL_FIXED_PRICE_AMC);
			List<LookupValueNewDto> lookupValueListByLookupDesc = adminServiceClient.getLookupValueListByLookupDesc(lookupValueDescList);
			fixedPriceStatusIdList = lookupValueListByLookupDesc.stream().map(LookupValueNewDto::getLookupValueId).collect(Collectors.toList());
			// End by Mrunal Marne
			ModuleStatusDto moduleStatusDto = adminServiceClient.getModuleStatus(
					ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_DEALLOCATION,
					ResourceManagementConstant.DEACTIVATE);
			List<Long> approvedWrkflwStatusIdList = new ArrayList<>();
			approvedWrkflwStatusIdList.add(wrkflwStatusAlloApproved);
			approvedWrkflwStatusIdList.add(wrkflwStatusTransferApproved);
			List<TAssociateProject> tAssociateProjectListForTarget = new ArrayList<>();
			List<TAssociateAllocation> tAssociateProjectListForCurrent = new ArrayList<>();
			List<TAssociateProjectDto> tAssociateProjectDtoListForTarget = new ArrayList<>();
			List<ProjectBudgetDto> projectBudgetDto = budgetControlServiceClient
					.getProjectMonthlyBudgetsDetails(rtInputDto.getProjectId());
			List<TAssociateDeAllocationDto> tAssociateDeallocationList = new ArrayList<>();
			//TAssociateDeAllocationDto tAssociateDeallocationDto = new TAssociateDeAllocationDto();

			Map<String, ProjectBudgetDto> projectBudgets = projectBudgetDto.stream().collect(HashMap::new,
					(m, v) -> m.put(v.getMonth(), v), HashMap::putAll);
			ResourceRequirementDto resourceRequirementDto = bapServiceClient
					.getRequirementDetailByReqId(rtInputDto.getRequirementId());
			List<Long> roleId = new ArrayList<>();
			roleId.add(rtInputDto.getRoleId());
			List<Long> transactionHistoryIdList = new ArrayList<>();
			//Commented and added below by Mrunal Marne for storing supervisor id as primary PM
			//List<PrimaryUsersDto> primaryUserList = bapServiceClient.getRoleBasedPrimaryOwnersList(rtInputDto.getProjectId(), roleId);
			Long primaryPMLookUpValueId = adminServiceClient.getLookuIdByTypeAndDescr(ResourceManagementConstant.ROLE_TYPE, ResourceManagementConstant.PROJECT_MANAGER);
			List<PrimaryUsersDto> primaryUserList = bapServiceClient.getRoleBasedPrimaryOwnersList(rtInputDto.getProjectId(), List.of(primaryPMLookUpValueId));
			// End by Mrunal Marne
			if (null != primaryUserList) {
				for (RTResourceDto resource : resourceList) {
					TAssociateDeAllocationDto tAssociateDeallocationDto = new TAssociateDeAllocationDto();
					TAssociateAllocation tAssociateAlloaction = tAssociateAllocationRepository
							.getCurrentProjectAllocationId(resource.getEmpId(),
									resource.getCurrentProjectDetails().getRequirementId(),
									rtInputDto.getCurrentProjectId(), statusIdForActive, approvedWrkflwStatusIdList);
					transactionHistoryIdList.add(tAssociateAlloaction.getAssociateAllocationId());
					TAssociateProject tAssociateProjectForTarget = createProjectObjForCurrentAndTarget(rtInputDto,
							resource, statusIdForActive, true, tAssociateAlloaction.getAssociateAllocationId(),
							primaryUserList);
					// tAssociateProjectForTarget.getTAssociateAllocation().setWorkflowStatusId(workflowStatusIdSaved);
					TAssociateProjectDto tAssociateProjectDto = tAssociateProjectMapper
							.tAssociateProjectToTAssociateProjectDto(tAssociateProjectForTarget);
					tAssociateProjectDtoListForTarget.add(tAssociateProjectDto);
					tAssociateProjectListForTarget.add(tAssociateProjectForTarget);
					if (resource.getTargetProjectDetails().getProjectUtilization() != resource
							.getCurrentProjectDetails().getProjectUtilization()) {
						TAssociateAllocation tAssociateProjectForCurrent = createAssoObjForCurrent(rtInputDto, resource,
								resource.getEmpId());
						tAssociateProjectListForCurrent.add(tAssociateProjectForCurrent);
					}
					//Commented by Mrunal Marne
					setDeallocationODC(rtInputDto, deAllocationStatusId, deAllocationApproStatusId, moduleStatusDto,
							tAssociateDeallocationList, tAssociateDeallocationDto, tAssociateAlloaction);
				}
			}
			Long lookupIdForNb = adminServiceClient.getLookuIdByTypeAndDescr(
					ResourceManagementConstant.PROJECT_BILLABLE_TYPE, ResourceManagementConstant.Non_Billable);
			Long projectBillableIdbyProjectId = adminServiceClient
					.getProjectBillableIdbyProjectId(rtInputDto.getProjectId());
			if (projectBillableIdbyProjectId.equals(lookupIdForNb)) {
				for (TAssociateProject project : tAssociateProjectListForTarget) {
					tAssociateProjectRepository.save(project);
				}
				// tAssociateProjectRepository.saveAll(tAssociateProjectListForTarget);
				if (!CollectionUtils.isEmpty(tAssociateProjectListForCurrent))
					tAssociateAllocationRepository.saveAll(tAssociateProjectListForCurrent);
				resourceAllocationServiceImpl.updateBudget(projectBudgets);
				deAllocateSourceRecordODCAndProjectAndBU(tAssociateDeallocationList);
			} else {
				if (rtInputDto.getRoleName().equalsIgnoreCase(ResourceManagementConstant.ADMIN_ROLE_NAME)
						|| rtInputDto.getRoleName().equalsIgnoreCase(ResourceManagementConstant.TAG_ROLE_NAME)) {
					/*&& resourceAllocationServiceImpl.performBudgetControlCheck(resourceRequirementDto,
							tAssociateProjectDtoListForTarget, projectBudgets))*/
					if (rtInputDto.getBudgetAndCostCheck()) {
						if (resourceAllocationServiceImpl.performBudgetControlCheck(resourceRequirementDto,
								tAssociateProjectDtoListForTarget, projectBudgets)) {
							resourceAllocationServiceImpl.updateBudget(projectBudgets);
						}
					}

					List<TAssociateAllocation> associateAllocList = new ArrayList<>();
					for (TAssociateProject project : tAssociateProjectListForTarget) {
						TAssociateProject tAssoProject = tAssociateProjectRepository.save(project);
						associateAllocList.add(tAssoProject.getTAssociateAllocation());
						// Added by Mrunal Marne for milestone selection while resource transfer
						bAllocationMilestoneList.addAll(prepareMilestoneDetailsForSaveRTWithinODCAndProjectAndBU(tAssoProject, resourceListDtoMap, projectCommercialTypeId, fixedPriceStatusIdList, projectBillableIdbyProjectId, lookupIdForNb));
					}
					// tAssociateProjectRepository.saveAll(tAssociateProjectListForTarget);
					if (!CollectionUtils.isEmpty(tAssociateProjectListForCurrent))
						tAssociateAllocationRepository.saveAll(tAssociateProjectListForCurrent);
					// resourceAllocationServiceImpl.updateBudget(projectBudgets);
					deAllocateSourceRecordODCAndProjectAndBU(tAssociateDeallocationList);
					performUpdateBudgetAndDeactivateAdminOrTag(transactionHistoryIdList, rtInputDto,
							associateAllocList);
					// added by devAk
					rtInputDto.setUserName(rtInputDto.getRoleName());
					rtInputDto.setRequestType(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE);
					rtInputDto.setUserId(userId);
					String wrkflwCode = resourceManagementServiceImpl.setWrkflwCode(rtInputDto.getRequestType(), rtInputDto.getRoleName());
					sendMailHelperServiceObj.sendEmailForFinalApprovalConfirmation(rtInputDto, wrkflwCode,
							associateAllocList.get(0).getAssociateAllocationId());
					/*
					 * for (TAssociateAllocation talloc : associateAllocList) {
					 * log.info("talloc:"+talloc.getAssociateAllocationId());
					 * sendMailHelperServiceObj.sendEmailForFinalApprovalConfirmation(rtInputDto,
					 * wrkflwCode, talloc.getAssociateAllocationId()); }
					 */
					//ended
				} else {
					if (rtInputDto.getBudgetAndCostCheck()) {
						if (resourceAllocationServiceImpl.performBudgetControlCheck(resourceRequirementDto,
								tAssociateProjectDtoListForTarget, projectBudgets)) {
							/*
							 * for (TAssociateProject project : tAssociateProjectListForTarget) {
							 * tAssociateProjectRepository.save(project); }
							 */ List<TAssociateProject> associateProjectAllocation = tAssociateProjectMapper
									.tAssociateProjectDtoToTAssociateProject(tAssociateProjectDtoListForTarget);
							for (TAssociateProject tAssociateProject : associateProjectAllocation) {
								tAssociateProject.getTAssociateAllocation().setTAssociateProject(tAssociateProject);
								for (TAssociateAllocationBudget tAssociateAllocationBudget : tAssociateProject
										.getTAssociateAllocation().getTAssociateAllocationBudget()) {
									tAssociateAllocationBudget
											.setTAssociateAllocation(tAssociateProject.getTAssociateAllocation());
								}
								TAssociateProject tAssociateProjectReference = tAssociateProjectRepository.save(tAssociateProject);
								// Added by Mrunal Marne for milestone selection while resource transfer
								bAllocationMilestoneList.addAll(prepareMilestoneDetailsForSaveRTWithinODCAndProjectAndBU(tAssociateProjectReference, resourceListDtoMap, projectCommercialTypeId, fixedPriceStatusIdList, projectBillableIdbyProjectId, lookupIdForNb));
							}

							// tAssociateProjectRepository.saveAll(tAssociateProjectListForTarget);
							if (!CollectionUtils.isEmpty(tAssociateProjectListForCurrent))
								tAssociateAllocationRepository.saveAll(tAssociateProjectListForCurrent);
							resourceAllocationServiceImpl.updateBudget(projectBudgets);
							deAllocateSourceRecordODCAndProjectAndBU(tAssociateDeallocationList);
						}
					} else {
						for (TAssociateProject project : tAssociateProjectListForTarget) {
							TAssociateProject tAssociateProjectReference = tAssociateProjectRepository.save(project);
							// Added by Mrunal Marne for milestone selection while resource transfer
							bAllocationMilestoneList.addAll(prepareMilestoneDetailsForSaveRTWithinODCAndProjectAndBU(tAssociateProjectReference, resourceListDtoMap, projectCommercialTypeId, fixedPriceStatusIdList, projectBillableIdbyProjectId, lookupIdForNb));
						}
						// tAssociateProjectRepository.saveAll(tAssociateProjectListForTarget);
						if (!CollectionUtils.isEmpty(tAssociateProjectListForCurrent))
							tAssociateAllocationRepository.saveAll(tAssociateProjectListForCurrent);
						resourceAllocationServiceImpl.updateBudget(projectBudgets);
						deAllocateSourceRecordODCAndProjectAndBU(tAssociateDeallocationList);
					}

				}
			}
			// Added by Mrunal Marne for milestone selection while resource transfer
			if (!bAllocationMilestoneList.isEmpty()) {
				bapServiceClient.savePoAndMilestoneDetailsDuringAllocation(bAllocationMilestoneList);
			}
			// End by Mrunal Marne
		}
		log.info("Just before leaving ResourceTransferServiceImpl.saveRTWithinODCAndProjectAndBU method:");
	}

	// Added by Mrunal Marne for milestone selection while resource allocation
	public List<BAllocationMilestoneDto> prepareMilestoneDetailsForSaveRTWithinODCAndProjectAndBU(TAssociateProject tAssociateProjectReference, Map<Long, RTResourceDto> resourceListDtoMap, 
			Long projectCommercialTypeId, List<Long> fixedPriceStatusIdList, Long projectBillableIdbyProjectId, Long lookupIdForNb) {
		log.info("Entered ResourceTransferServiceImpl.prepareMilestoneDetailsForSaveRTWithinODCAndProjectAndBU method:");
		List<BAllocationMilestoneDto> bAllocationMilestoneList = new ArrayList<>();
		Long size = 0L;
		if (!projectBillableIdbyProjectId.equals(lookupIdForNb)) {
			if (Objects.nonNull(projectCommercialTypeId) && fixedPriceStatusIdList.contains(projectCommercialTypeId)) {
				try {
					size = resourceListDtoMap.containsKey(tAssociateProjectReference.getEmployeeId()) ? 
							resourceListDtoMap.get(tAssociateProjectReference.getEmployeeId()).getPoMilestoneIdList().size() : 0L;
				} catch (Exception e) {
					size = 0L;
				}
			} else
				size = 1L;
		}
		for (int i = 0; i < size; i++) {
			BAllocationMilestoneDto bAllocationMilestone = new BAllocationMilestoneDto();
			bAllocationMilestone.setAssociateAllocationId(tAssociateProjectReference.
					getTAssociateAllocation().getAssociateAllocationId());	
			bAllocationMilestone.setEmployeeId(tAssociateProjectReference.getEmployeeId());
			bAllocationMilestone.setProjectId(tAssociateProjectReference.getProjectId());
			bAllocationMilestone.setBapPaymentScheduleKey(resourceListDtoMap.containsKey(tAssociateProjectReference.getEmployeeId()) ? 
					resourceListDtoMap.get(tAssociateProjectReference.getEmployeeId()).getPoMilestoneIdList().isEmpty() ? null : 
						resourceListDtoMap.get(tAssociateProjectReference.getEmployeeId()).getPoMilestoneIdList().get(i) : null);	//milestone id
			bAllocationMilestone.setPoInvoiceKey(resourceListDtoMap.containsKey(tAssociateProjectReference.getEmployeeId()) ? 
					resourceListDtoMap.get(tAssociateProjectReference.getEmployeeId()).getPuchaseOrderId() : null);		//po id
			bAllocationMilestone.setCreatedBy(tAssociateProjectReference.getTAssociateAllocation().getCreatedBy());
			bAllocationMilestone.setLastUpdatedBy(tAssociateProjectReference.getTAssociateAllocation().getLastUpdatedBy());
			bAllocationMilestoneList.add(bAllocationMilestone);
		}
		log.info("Leaving ResourceTransferServiceImpl.prepareMilestoneDetailsForSaveRTWithinODCAndProjectAndBU method:");
		return bAllocationMilestoneList;
	}

	public List<BAllocationMilestoneDto> prepareMilestoneDetailsForSaveResourceTransferInSameProject(Map<Long, TransferResourceListDto> requirementMap, 
			Map<Long, TAssociateAllocation> associateProjectMap, Long projectCommercialTypeId, List<Long> fixedPriceStatusIdList, 
			Long projectBillableIdbyProjectId, Long lookupIdForNb) {
		log.info("Entered ResourceTransferServiceImpl.prepareMilestoneDetailsForSaveResourceTransferInSameProject method:");
		BAllocationMilestoneDto bAllocationMilestone = new BAllocationMilestoneDto();
		List<BAllocationMilestoneDto> bAllocationMilestoneList = new ArrayList<>();
		for (Map.Entry<Long, TAssociateAllocation> entry : associateProjectMap.entrySet()) {
			TAssociateAllocation allocationEntry = entry.getValue();
			TAssociateProject tAssociateProjectReference = tAssociateProjectRepository.findByAssociateProjectId(allocationEntry.getTAssociateProject().getAssociateProjectId());
			Long size = 0L;
			if (!projectBillableIdbyProjectId.equals(lookupIdForNb)) {
				if(Objects.nonNull(projectCommercialTypeId) && fixedPriceStatusIdList.contains(projectCommercialTypeId)) {
					try {
						size = requirementMap.containsKey(tAssociateProjectReference.getEmployeeId()) ? 
								requirementMap.get(tAssociateProjectReference.getEmployeeId()).getPoMilestoneIdList().size() : 0L;
					} catch (Exception e) {
						size = 0L;
					}
				} else
					size = 1L;
			}
			for (int i = 0; i < size; i++) {
				bAllocationMilestone.setAssociateAllocationId(allocationEntry.getAssociateAllocationId());
				bAllocationMilestone.setEmployeeId(tAssociateProjectReference.getEmployeeId());
				bAllocationMilestone.setProjectId(tAssociateProjectReference.getProjectId());
				bAllocationMilestone.setBapPaymentScheduleKey(requirementMap.containsKey(tAssociateProjectReference.getEmployeeId()) ? 
						requirementMap.get(tAssociateProjectReference.getEmployeeId()).getPoMilestoneIdList().isEmpty() ? null :
							requirementMap.get(tAssociateProjectReference.getEmployeeId()).getPoMilestoneIdList().get(i) : null);	//milestone id
				bAllocationMilestone.setPoInvoiceKey(requirementMap.containsKey(tAssociateProjectReference.getEmployeeId()) ? 
						requirementMap.get(tAssociateProjectReference.getEmployeeId()).getPuchaseOrderId() : null);		//po id
				bAllocationMilestone.setCreatedBy(allocationEntry.getCreatedBy());
				bAllocationMilestone.setLastUpdatedBy(allocationEntry.getLastUpdatedBy());
				bAllocationMilestoneList.add(bAllocationMilestone);
			}
		}
		log.info("Leaving ResourceTransferServiceImpl.prepareMilestoneDetailsForSaveResourceTransferInSameProject method:");
		return bAllocationMilestoneList;
	}
	// End by Mrunal Marne

	private List<Long> getListOfAssociateAlredyAllocated(Long targetRequirmentId, Long targetprojectId,
			List<Long> employeeIdList, HashBasedTable<String, String, Long> getallModuleData) {
		Long statusId = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long workFlowStatuForAllocApproved = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long workFlowStatuForAllocsaved = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.SAVED);
		Long workFlowStatuForTransferSaved = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.SAVED);
		Long workFlowStatuForTransferSubitted = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.SUBMITTED);
		List<Long> listOfWorkFlowIds = new ArrayList<>();
		listOfWorkFlowIds.add(workFlowStatuForTransferSubitted);
		listOfWorkFlowIds.add(workFlowStatuForAllocsaved);
		listOfWorkFlowIds.add(workFlowStatuForTransferSaved);
		listOfWorkFlowIds.add(workFlowStatuForAllocApproved);
		return tAssociateAllocationRepository.getAllocatedResOnSameReqForTransfer(employeeIdList, statusId,
				listOfWorkFlowIds, targetprojectId, targetRequirmentId);

	}

	private void setDeallocationODC(RMApprovalInputDto rtInputDto, Long deAllocationStatusId,
			Long deAllocationApproStatusId, ModuleStatusDto moduleStatusDto,
			List<TAssociateDeAllocationDto> tAssociateDeallocationList,
			TAssociateDeAllocationDto tAssociateDeallocationDto, TAssociateAllocation tAssociateAlloaction) {
		tAssociateDeallocationDto.setAssociateAllocationId(tAssociateAlloaction.getAssociateAllocationId());
		tAssociateDeallocationDto.setProjectId(rtInputDto.getCurrentProjectId());
		tAssociateDeallocationDto.setEmployeeId(tAssociateAlloaction.getTAssociateProject().getEmployeeId());
		tAssociateDeallocationDto.setCreatedBy(rtInputDto.getUserId());
		if (rtInputDto.getRoleName().equalsIgnoreCase(ResourceManagementConstant.ADMIN_ROLE_NAME)
				|| rtInputDto.getRoleName().equalsIgnoreCase(ResourceManagementConstant.TAG_ROLE_NAME)) {
			tAssociateDeallocationDto.setWorkflowStatusId(deAllocationApproStatusId);
		} else {
			tAssociateDeallocationDto.setWorkflowStatusId(deAllocationStatusId);
		}
		tAssociateDeallocationDto.setRequirementId(rtInputDto.getCurrentRequirementId());
		tAssociateDeallocationDto
				.setFtePercent(rtInputDto.getResourceList().get(0).getTargetProjectDetails().getProjectUtilization());
		tAssociateDeallocationDto.setDeallocationReasonId(1l);
		tAssociateDeallocationDto.setWorkflowReasonId(1L);
		tAssociateDeallocationDto.setStatusId(moduleStatusDto.getModuleId());
		tAssociateDeallocationDto.setLastUpdatedBy(rtInputDto.getUserId());
		tAssociateDeallocationDto.setCreatedDate(new Date());
		tAssociateDeallocationDto.setLastUpdatedDate(new Date());
		tAssociateDeallocationDto.setEffectiveEndDate(new Date());
		tAssociateDeallocationList.add(tAssociateDeallocationDto);
	}

	public TAssociateProject createProjectObjForCurrentAndTarget(RMApprovalInputDto rtInputDto,
			RTResourceDto resourceDetail, Long statusIdForActive, boolean isCreatingObjectForTarget,
			Long currentProjectAlloId, List<PrimaryUsersDto> primaryUserList) throws ResourceManagementException {
		TAssociateProject tAssociateProject = new TAssociateProject();
		tAssociateProject.setEmployeeId(resourceDetail.getEmpId());
		tAssociateProject.setStatusId(statusIdForActive);
		tAssociateProject.setIsPrimaryProject(0l);
		tAssociateProject.setCreatedBy(rtInputDto.getUserId());
		tAssociateProject.setCreatedDate(new Date());
		tAssociateProject.setLastUpdatedBy(rtInputDto.getUserId());
		tAssociateProject.setLastUpdatedDate(new Date());
		tAssociateProject.setEffectiveStartDate(new Date());
		tAssociateProject.setEffectiveEndDate(new Date());
		tAssociateProject.setSupervisorId(tAssociateAllocationRepository.getEmployeeId(primaryUserList.get(0).getEmpId()));
		if (isCreatingObjectForTarget) {
			tAssociateProject.setProjectId(rtInputDto.getProjectId());
			tAssociateProject.setTAssociateAllocation(
					createAssoObjForTarget(rtInputDto,statusIdForActive,
							currentProjectAlloId, tAssociateProject, primaryUserList, resourceDetail.getTargetProjectDetails()));
		}

		return tAssociateProject;
	}

	public TAssociateAllocation createAssoObjForTarget(RMApprovalInputDto rtInputDto, Long statusIdForActive,
			Long currentProjectAlloId, TAssociateProject tAssociateProject,
			List<PrimaryUsersDto> primaryUserList, RTProjectDto currOrTarProject) throws ResourceManagementException {

		HashBasedTable<String, String, Long> getallModuleData = allocatedResourceHelperClass.getallModuleData();
		// Long statusIdForActive =
		// getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
		// ResourceManagementConstant.ACTIVATE);
		Long wrkflwStatusTransferApproved = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long workflowStatusIdSaved = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.SAVED);
		AllocationTypeStatusDto allocationTypeStatus = adminServiceClient
				.getAllocationTypeStatus(ResourceManagementConstant.RESOURCE_ALLOCATION_TYPE_STATUS);
		// Long wrkflwStatusTransferApproved =
		// resourceManagementServiceImpl.getModuleStatusId(
		// ResourceManagementConstant.RESOURCE_ALLOCATION,
		// ResourceManagementConstant.APPROVED_ACTION);
		// Long workflowStatusIdSaved = resourceManagementServiceImpl
		// .getModuleStatusId(ResourceManagementConstant.RESOURCE_TRANSFER,
		// ResourceManagementConstant.SAVED);
		// Long projectBillableIdbyProjectId = adminServiceClient
		// .getProjectBillableIdbyProjectId(rtInputDto.getProjectId());
		// LookupValueDto lookupValue =
		// adminServiceClient.getLookUpById(projectBillableIdbyProjectId);
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		tAssociateAllocation.setBillableStatusId(currOrTarProject.getAssociateBillableTypeId());
		tAssociateAllocation.setBillableStatusReasonId(currOrTarProject.getBillableStatusReasonId());
		tAssociateAllocation.setTAssociateProject(tAssociateProject);
		tAssociateAllocation.setCreatedBy(rtInputDto.getUserId());
		tAssociateAllocation.setCreatedDate(new Date());
		tAssociateAllocation.setLastUpdatedBy(rtInputDto.getUserId());
		tAssociateAllocation.setLastUpdatedDate(new Date());
		tAssociateAllocation.setStatusId(statusIdForActive);
		tAssociateAllocation.setTransactionHistoryId(currentProjectAlloId);
		tAssociateAllocation.setEffectiveEndDate(new Date());
		//Commented and added below by Mrunal Marne for storing supervisor id as primary PM
		// tAssociateAllocation.setSupervisorId(tAssociateProject.getSupervisorId());
		tAssociateAllocation.setSupervisorId(primaryUserList.get(0).getEmpId());
		// End by Mrunal Marne
		tAssociateAllocation.setRemarks(rtInputDto.getApproverComments());
		tAssociateAllocation.setServiceLineId(currOrTarProject.getServiceLineId());
		ResourceRequirementDto resourceRequirementDto = null;
		tAssociateAllocation.setEffectiveStartDate(currOrTarProject.getAllocationDate());
		tAssociateAllocation.setActualAllocationStartDate(currOrTarProject.getAllocationDate());
		tAssociateAllocation.setEstAllocationEndDate(currOrTarProject.getEstimatedReleaseDate());
		tAssociateAllocation.setFtePercent(currOrTarProject.getProjectUtilization());
		tAssociateAllocation.setRequirementId(rtInputDto.getRequirementId());
		if (rtInputDto.getRoleName().equalsIgnoreCase(ResourceManagementConstant.ADMIN_ROLE_NAME)
				|| rtInputDto.getRoleName().equalsIgnoreCase(ResourceManagementConstant.TAG_ROLE_NAME)) {
			tAssociateAllocation.setWorkflowStatusId(wrkflwStatusTransferApproved);

		} else {
			tAssociateAllocation.setWorkflowStatusId(workflowStatusIdSaved);
		}
		resourceRequirementDto = bapServiceClient.getRequirementDetailByReqId(rtInputDto.getRequirementId());

		double shoreWorkHour = 0.00;
		if (resourceRequirementDto.getShore().equalsIgnoreCase(ResourceManagementConstant.ONSHORE))
			shoreWorkHour = 8;
		else
			shoreWorkHour = resourceRequirementDto.getProjectBillingHours();
		tAssociateAllocation.setRoleId(resourceRequirementDto.getResourceRequirementLocationId());
		tAssociateAllocation.setWorkLocationId(resourceRequirementDto.getResourceRequirementLocationId());
		tAssociateAllocation.setBaseHours(shoreWorkHour);
		tAssociateAllocation.setSkillId(currOrTarProject.getSkillId());
		tAssociateAllocation.setStdCost(currOrTarProject.getStdCost());
		tAssociateAllocation.setAllocationTypeId(allocationTypeStatus.getAllocationTypeId());
		return tAssociateAllocation;
	}

	public TAssociateAllocation createAssoObjForCurrent(RMApprovalInputDto rtInputDto, RTResourceDto currOrTarProject,
			Long empid) throws ResourceManagementException {
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		HashBasedTable<String, String, Long> getallModuleData = allocatedResourceHelperClass.getallModuleData();
		Long wrkflwStatusTransferApproved = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long activeStatusIdForProject = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long workflowStatusIdSaved = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.SAVED);
		TAssociateProject tAssociateProject = tAssociateProjectRepository.getByEmpIdAndProjId(
				rtInputDto.getCurrentProjectId(), empid, activeStatusIdForProject, wrkflwStatusTransferApproved);

		Date startDate = currOrTarProject.getTargetProjectDetails().getAllocationDate();
		Date endDate = currOrTarProject.getTargetProjectDetails().getEstimatedReleaseDate();
		if (null != tAssociateProject) {
			tAssociateAllocation.setCreatedBy(tAssociateProject.getTAssociateAllocation().getCreatedBy());
			tAssociateAllocation.setTAssociateProject(tAssociateProject);
			tAssociateAllocation.setCreatedDate(tAssociateProject.getTAssociateAllocation().getCreatedDate());
			tAssociateAllocation.setLastUpdatedBy(rtInputDto.getUserId());
			tAssociateAllocation.setLastUpdatedDate(new Date());
			tAssociateAllocation.setStatusId(tAssociateProject.getTAssociateAllocation().getStatusId());
			tAssociateAllocation
					.setTransactionHistoryId(tAssociateProject.getTAssociateAllocation().getTransactionHistoryId());
			tAssociateAllocation.setEffectiveEndDate(tAssociateProject.getTAssociateAllocation().getEffectiveEndDate());
			tAssociateAllocation.setEffectiveStartDate(startDate);
			tAssociateAllocation.setActualAllocationStartDate(startDate);
			tAssociateAllocation
					.setEstAllocationEndDate(tAssociateProject.getTAssociateAllocation().getEstAllocationEndDate());
			tAssociateAllocation.setFtePercent(tAssociateProject.getTAssociateAllocation().getFtePercent()
					- currOrTarProject.getTargetProjectDetails().getProjectUtilization());
			tAssociateAllocation.setRequirementId(tAssociateProject.getTAssociateAllocation().getRequirementId());
			tAssociateAllocation.setAllocationTypeId(tAssociateProject.getTAssociateAllocation().getAllocationTypeId());
			tAssociateAllocation.setRoleId(tAssociateProject.getTAssociateAllocation().getRoleId());
			tAssociateAllocation.setWorkLocationId(tAssociateProject.getTAssociateAllocation().getWorkLocationId());
			tAssociateAllocation.setBaseHours(tAssociateProject.getTAssociateAllocation().getBaseHours());
			tAssociateAllocation.setSupervisorId(tAssociateProject.getTAssociateAllocation().getSupervisorId());
			tAssociateAllocation.setServiceLineId(tAssociateProject.getTAssociateAllocation().getServiceLineId());
			tAssociateAllocation.setRemarks(rtInputDto.getApproverComments());
			if (rtInputDto.getRoleName().equalsIgnoreCase(ResourceManagementConstant.ADMIN_ROLE_NAME)
					|| rtInputDto.getRoleName().equalsIgnoreCase(ResourceManagementConstant.TAG_ROLE_NAME)) {
				tAssociateAllocation.setWorkflowStatusId(wrkflwStatusTransferApproved);

			} else {
				tAssociateAllocation.setWorkflowStatusId(workflowStatusIdSaved);
			}

			tAssociateAllocation.setBillableStatusId(tAssociateProject.getTAssociateAllocation().getBillableStatusId());
			tAssociateAllocation.setStdCost(tAssociateProject.getTAssociateAllocation().getStdCost());
			tAssociateAllocation.setSkillId(tAssociateProject.getTAssociateAllocation().getSkillId());
		}
		return tAssociateAllocation;

	}

	@Override
	public void rejectRTWithinODCAndProjectAndBU(List<RMApprovalInputDto> rtInputDtoList) throws ResourceManagementException {
		log.info("Entered into ResourceTransferServiceImpl.rejectRTWithinODCAndProjectAndBU method:");

		HashBasedTable<String, String, Long> getallModuleData = allocatedResourceHelperClass.getallModuleData();
		Long statusIdForActive = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long workflowStatusId = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.SAVED);
		Long statusIdForRejection = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.REJECTED);
		Long workflowStatusIdForAllocationAproved = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long workflowStatusIdDeallocRejected = getallModuleData.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
				ResourceManagementConstant.REJECTED);

		for (RMApprovalInputDto rtInputDto : rtInputDtoList) {
			List<Long> savedWrkflwStatusId = new ArrayList<>();
			savedWrkflwStatusId.add(workflowStatusIdForAllocationAproved);
			List<RTResourceDto> resourceList = rtInputDto.getResourceList();
			List<Long> empIdList = new ArrayList<>();
			List<Long> projectIdList = new ArrayList<>();
			projectIdList.add(rtInputDto.getCurrentProjectId());
			projectIdList.add(rtInputDto.getProjectId());
			List<Long> savedWrkflwStatusIdForTransfer = new ArrayList<>();
			savedWrkflwStatusIdForTransfer.add(workflowStatusId);
			List<Long> transactionIdList = new ArrayList<>();
			List<Long> targetAssociateAllocationIdList = new ArrayList<>();
			List<Long> sourceTargetAssociateAllocationIdList = new ArrayList<>();
			List<Long> targetAssociateProjectIdList = new ArrayList<>();
			List<Long> targetProjectRequirementList = new ArrayList<>();
			List<Long> sourceProjectRequirementList = new ArrayList<>();
			List<TAssociateAllocation> tAssoAlloCurrentList = new ArrayList<>();
			boolean budgetCheck = resourceAllocationServiceImpl.getBudgetAndCostCheck(rtInputDto.getProjectId());
			for (RTResourceDto resource : resourceList) {
				empIdList.add(resource.getEmpId());
				targetProjectRequirementList.add(resource.getTargetProjectDetails().getRequirementId());
				sourceProjectRequirementList.add(resource.getCurrentProjectDetails().getRequirementId());

				List<TAssociateAllocation> tAssoAlloTargetList = new ArrayList<>();
				TAssociateAllocation currentAssociateAllocation = tAssociateAllocationRepository
						.getCurrentProjectAllocationId(resource.getEmpId(),
								resource.getCurrentProjectDetails().getRequirementId(), rtInputDto.getCurrentProjectId(),
								statusIdForActive, savedWrkflwStatusId);
				tAssoAlloCurrentList.add(currentAssociateAllocation);
				TAssociateAllocation targetAssociateAllocation = tAssociateAllocationRepository
						.getTargetProjectAllocationId(resource.getEmpId(),
								resource.getTargetProjectDetails().getRequirementId(), rtInputDto.getProjectId(),
								statusIdForActive, savedWrkflwStatusIdForTransfer);
				tAssoAlloTargetList.add(targetAssociateAllocation);
				if (budgetCheck) {
					resourceManagementServiceImpl.releaseAllocatedBudgetForAlloc(tAssoAlloTargetList,
							rtInputDto.getProjectId(), resource.getTargetProjectDetails().getRequirementId());
				}
				transactionIdList.add(currentAssociateAllocation.getAssociateAllocationId());
				//Added by Mrunal Marne for removing records for RM transfer saved on rejection by Project Manager
				targetAssociateAllocationIdList.add(targetAssociateAllocation.getAssociateAllocationId());
				sourceTargetAssociateAllocationIdList.add(targetAssociateAllocation.getAssociateAllocationId());
				targetAssociateProjectIdList.add(targetAssociateAllocation.getTAssociateProject().getAssociateProjectId());
				if((resource.getCurrentProjectDetails().getProjectUtilization() - resource.getTargetProjectDetails().getProjectUtilization()) > 0) {
					sourceTargetAssociateAllocationIdList.add(currentAssociateAllocation.getAssociateAllocationId());
				}
				//Commented by Mrunal Marne as need to delete the record and not change the status
				/*tAssociateAllocationRepository.updatepartialRecordForSourceProj(statusIdForRejection,
						rtInputDto.getCurrentProjectId(), resource.getEmpId(),
						resource.getCurrentProjectDetails().getRequirementId(), workflowStatusId);*/
				// End by Mrunal Marne
			}
			/*tAssociateAllocationRepository.rejectRMSavedResourcesForTransfer(statusIdForRejection, empIdList, projectIdList,
					transactionIdList, statusIdForActive, statusIdForRejection);
			tAssociateDeAllocationRepository.updateWorkflowStaforTransfer(transactionIdList,
					workflowStatusIdDeallocRejected);
			resourceManagementServiceImpl.updateProjectStatus(rtInputDto.getCurrentProjectId());*/
			//Added by Mrunal Marne for removing records for RM transfer saved on rejection by Project Manager
			if (rtInputDto.getCurrentProjectId() == rtInputDto.getProjectId()) {
				// for rejecting request for transfer within same project
				bapServiceClient.removePoAndMilestoneDetailsForTransferRejection(targetAssociateAllocationIdList);
				tAssociateDeAllocationRepository.removeSavedResourcesForTransfer(transactionIdList);
				associateAllocationBudgetRepository.removeSavedBudgetDetailsForTransfer(targetAssociateAllocationIdList);
				resourceWorkflowRepository.deleteWorkflowRecords(targetAssociateAllocationIdList);
				tAssociateAllocationRepository.removeRMSavedResourcesForTransfer(empIdList, projectIdList, workflowStatusId, statusIdForActive, targetProjectRequirementList);
				setEstAndActualEndDateForSourceRecord(tAssoAlloCurrentList);
			} else {
				// for rejecting request for transfer within diff projects/ODC/BU
				List<Long> sourceTargetProjectRequirementList = new ArrayList<>();
				sourceTargetProjectRequirementList.addAll(sourceProjectRequirementList);
				sourceTargetProjectRequirementList.addAll(targetProjectRequirementList);
				bapServiceClient.removePoAndMilestoneDetailsForTransferRejection(targetAssociateAllocationIdList);
				tAssociateDeAllocationRepository.removeSavedResourcesForTransfer(transactionIdList);
				associateAllocationBudgetRepository.removeSavedBudgetDetailsForTransfer(targetAssociateAllocationIdList);
				resourceWorkflowRepository.deleteWorkflowRecords(targetAssociateAllocationIdList);
				tAssociateAllocationRepository.removeRMSavedResourcesForTransfer(empIdList, projectIdList, workflowStatusId, statusIdForActive, sourceTargetProjectRequirementList);
				associateProjectRepository.removeSavedResourceFromTransfer(targetAssociateProjectIdList);
			}
			// End by Mrunal Marne
		}
		log.info("Just before leaving ResourceTransferServiceImpl.rejectRTWithinODCAndProjectAndBU method:");
	}

	//Added by Mrunal Marne for removing records for RM transfer saved on rejection by Project Manager
	public void setEstAndActualEndDateForSourceRecord(List<TAssociateAllocation> tAssoAlloCurrentList) throws ResourceManagementException {
		log.info("Entered into ResourceTransferServiceImpl.setEstAndActualEndDateForSourceRecord method:");
		for (TAssociateAllocation tAssoAlloCurrent : tAssoAlloCurrentList) {
			tAssoAlloCurrent.setEstAllocationEndDate(tAssoAlloCurrent.getActualAllocationEndDate());
			try {
				tAssoAlloCurrent.setActualAllocationEndDate(sdf.parse(ResourceManagementConstant.DEFAULT_EFFECTIVE_END_DATE));
				tAssociateAllocationRepository.save(tAssoAlloCurrent);
			} catch (ParseException e) {
				throw new ResourceManagementException(ResourceManagementConstant.DATE_PARSE_EXCEPTION, e);
			}
		}
		log.info("Just before leaving ResourceTransferServiceImpl.setEstAndActualEndDateForSourceRecord method:");
	}
	// End by Mrunal Marne

	@Override
	public ResourceRequirementAndFteDto getAllocatedResourceFTE(long projectId, String transferType)
			throws ResourceManagementException {

		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		List<EmployeeDto> empList = getAllocatedResource(projectId);
		if (transferType.equalsIgnoreCase(ResourceManagementConstant.SWITCH_WITHIN_ODC)) {
			resourceRequirementAndFteDto.setEmployeeList(empList);
		} else if (transferType.equalsIgnoreCase(ResourceManagementConstant.TRANSFER_BETWEEN_PHASES)) {
			Double totalAllocatedBillableFte = tAssociateAllocationRepository
					.getTotalAllocatedBillbleFteForTransfer(projectId);
			Double totalAllocatedEBRFte = tAssociateAllocationRepository.getTotalAllocatedEBRFteForTransfer(projectId);
			resourceRequirementAndFteDto = bapServiceClient.getProjectFte(projectId);
			resourceRequirementAndFteDto.setEmployeeList(empList);
			if (null != totalAllocatedBillableFte) {
				resourceRequirementAndFteDto.setTotalAllocatedBillableFte(totalAllocatedBillableFte);
			}
			if (null != totalAllocatedEBRFte) {
				resourceRequirementAndFteDto.setTotalAllocatedEBRFte(totalAllocatedEBRFte);
			}
		} else if (transferType.equalsIgnoreCase(ResourceManagementConstant.SWITCH_WITHIN_BU)) {
			ProjectDto intransitProject = bapServiceClient.getIntransitProjectId(projectId);
			if (null != intransitProject) {
				List<EmployeeDto> newempList = getAllocatedResource(intransitProject.getProjectId());
				if (null != newempList) {
					newempList.stream()
							.forEach(employeeDto -> employeeDto.setProjectName(intransitProject.getProjectName()));
					resourceRequirementAndFteDto.setEmployeeList(newempList);
				}
			}
		}
		if (resourceAllocationServiceImpl.getBudgetAndCostCheck(projectId)) {
			resourceRequirementServiceImpl.setBudgetDetailsinRR(projectId, resourceRequirementAndFteDto);
		}
		return resourceRequirementAndFteDto;
	}

	public List<EmployeeDto> getAllocatedResource(long projectId) throws ResourceManagementException {
		List<ResourceRequirementDto> newRequirement = bapServiceClient.getResourceRequiremetList(projectId);
		List<Long> requirementIds = newRequirement.stream().map(ResourceRequirementDto::getReqId)
				.collect(Collectors.toList());
		List<ServiceLineDto> serviceListDto = getServiceLineDto(projectId);
		Boolean normalAllocationFlag = Boolean.TRUE;
		// List<AllocatedResourceProjection> allocatedEmployeeList =
		// allocatedResourceHelperClass.getAllocatedEmployeeList(projectId,
		// requirementIds,lookupIdForNorAlloc);
		List<AllocatedResourceProjection> allocatedEmployeeList = allocatedResourceHelperClass
				.getNewAllocatedEmployeeList(projectId, requirementIds, normalAllocationFlag);
		List<EmployeeDto> employeeList = new ArrayList<>();
		if (null != allocatedEmployeeList) {
			List<Long> empIds = allocatedEmployeeList.stream().map(AllocatedResourceProjection::getEmployeeId)
					.distinct().collect(Collectors.toList());
			List<Long> skillIdList = allocatedEmployeeList.stream().map(AllocatedResourceProjection::getdefaultSkillId)
					.distinct().collect(Collectors.toList());
			Map<Long, EmployeeDto> employeeMap = getPractiseDetails(empIds);
			Map<Long, ResourceRequirementDto> resourceRequirementMap = newRequirement.stream().collect(Collectors
					.toMap(ResourceRequirementDto::getReqId, resourceRequirementDto -> resourceRequirementDto));
			Map<Long, SkillTaxonomyDto> defaultSkillMap = getDefaultSkillForTransfer(skillIdList);
			Map<Long, EmployeeSkillDto> skillFamilyMap = resourceAllocationServiceImpl
					.getSkillFamilyForAssociate(empIds);

			allocatedEmployeeList.forEach(allocatedResourceProjection -> {
				EmployeeDto empDto = new EmployeeDto();
				empDto.setAssociateAllocationId(allocatedResourceProjection.getAssociateAllocationId());
				empDto.setEmployeeId(allocatedResourceProjection.getEmployeeId());
				EmployeeDto newempDto = employeeMap.get(allocatedResourceProjection.getEmployeeId());
				setPractiseDetails(empDto, newempDto);
				ResourceRequirementDto resourceRequirementDto = resourceRequirementMap
						.get(allocatedResourceProjection.getRequirementId());
				setRequirementDetails(empDto, resourceRequirementDto);
				empDto.setEmployeeProjectId(allocatedResourceProjection.getProjectId());
				empDto.setActualAllocationDate(allocatedResourceProjection.getActualStartDate());
				empDto.setEstimatedEndDate(allocatedResourceProjection.getEstEndDate());
				empDto.setRequirementId(allocatedResourceProjection.getRequirementId());
				empDto.setProjectId(allocatedResourceProjection.getProjectId());
				empDto.setEmployeeCostRate(allocatedResourceProjection.getemployeeCostRate());
				empDto.setFte_percent(allocatedResourceProjection.getFtePercent());
				empDto.setServiceName(resourceRequirementDto.getServiceName());
				//start by mounika
				empDto.setServiceLineId(allocatedResourceProjection.getServiceLineId());
				empDto.setServiceLineName(allocatedResourceProjection.getServiceLineName());
				//end by mounika
				if (null != defaultSkillMap) {
					setDefaultSkillMap(empDto, allocatedResourceProjection, defaultSkillMap);
				}
				setSkillFamilyForResource(empDto, skillFamilyMap);
				empDto.setServiceLineDto(serviceListDto);
				Integer billingStatusId = allocatedResourceProjection.getBillableStatusId();
				setBillingStatus(empDto, billingStatusId);
				employeeList.add(empDto);
			});
		}
		return employeeList;

	}

	private List<ServiceLineDto> getServiceLineDto(long projectId) throws ResourceManagementException {
		List<Long> serviceLineIds = tAssociateAllocationRepository.getProjectServiceLineIdbyProjectId(projectId);
		if (!serviceLineIds.stream().allMatch(o -> o == null)) {
			return adminServiceClient.getServiceLineList(serviceLineIds);
		}
		return Collections.emptyList();
	}

	private void setBillingStatus(EmployeeDto empDto, Integer billingStatusId) {

		Long billingStsId = Long.valueOf(billingStatusId);

		Map<String, Long> lookupMap = new HashMap<String, Long>();
		try {
			if (null != billingStatusId) {
				lookupMap = resourceRequirementServiceImpl.getLookupValue();

				if (billingStsId.equals(lookupMap.get(ResourceManagementConstant.Billable))) {
					empDto.setBillingStatus(ResourceManagementConstant.Billable);
				} else if (billingStsId.equals(lookupMap.get(ResourceManagementConstant.Ebr))) {
					empDto.setBillingStatus(ResourceManagementConstant.Ebr);
				} else if (billingStsId.equals(lookupMap.get(ResourceManagementConstant.Non_Billable))) {
					empDto.setBillingStatus(ResourceManagementConstant.Non_Billable);
				} else if (billingStsId.equals(lookupMap.get(ResourceManagementConstant.POOL))) {
					empDto.setBillingStatus(ResourceManagementConstant.POOL);
				} else {
					empDto.setBillingStatus(ResourceManagementConstant.InTransit);
				}
			}
		} catch (ResourceManagementException e) {
			log.debug(e.getMessage());
		}
	}


	private void setRequirementDetails(EmployeeDto empDto, ResourceRequirementDto resourceRequirementDto) {
		if (null != resourceRequirementDto) {
			empDto.setResourceRequirementLocation(resourceRequirementDto.getResourceRequirementLocation());
			//start by mounika
			if(resourceRequirementDto.getServiceLineName() != null ) {
				empDto.setServiceLineName(resourceRequirementDto.getServiceLineName());
			}
			else {
				empDto.setServiceLineName(ResourceManagementConstant.NOT_AVAILABLE);
			}
			//end by mounika
			empDto.setLocationType(resourceRequirementDto.getShore());
			empDto.setBillingRateInUSD(resourceRequirementDto.getBillingRateInUSD());
			empDto.setRole(resourceRequirementDto.getRequirementRole());
			empDto.setEmployeeLocation(resourceRequirementDto.getResourceRequirementLocation());
			empDto.setLocationTypeId(resourceRequirementDto.getResourceRequirementLocationId());
			empDto.setProjectName(resourceRequirementDto.getProjectName());
		}
	}

	private void setPractiseDetails(EmployeeDto empDto, EmployeeDto newempDto) {
		if (null != newempDto) {
			empDto.setEmployeeName(newempDto.getEmployeeName());
			empDto.setPracticeName(newempDto.getPracticeName());
			empDto.setSkills(newempDto.getSkills());
			empDto.setBand(newempDto.getBand());
			empDto.setEmployeeNumber(newempDto.getEmployeeNumber());
		}
	}

	public Map<Long, EmployeeDto> getPractiseDetails(List<Long> empIds) throws ResourceManagementException {
		List<EmployeeDto> practiseDetails = adminServiceClient.getAssociatesDetailsbyEmpIds(empIds);
		return practiseDetails.stream()
				.collect(Collectors.toMap(EmployeeDto::getEmployeeId, employeemap -> employeemap));
	}

	@Override
	public List<ProjectDto> getProjectfromSameOdc(long userId, long roleId, long targetPojectId)
			throws ResourceManagementException {
		return bapServiceClient.getProjectWithinSameOdc(targetPojectId, userId, roleId);
	}

	@Override
	public EmployeeDto getResourceFromIntransitProject(long projectId, String empIdOrName)
			throws ResourceManagementException {
		EmployeeDto newempDto = null;
		ProjectDto intransitProject = bapServiceClient.getIntransitProjectId(projectId);
		Long statusIdForActivate = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
		Long statusIdForApproved = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED);
		if (null != intransitProject) {
			EmployeeDto empDto = adminServiceClient.getEmployeeByNameOrId(empIdOrName);
			if (null != empDto) {
				Long intransitProjectId = intransitProject.getProjectId();
				empDto.setProjectName(intransitProject.getProjectName());
				AllocatedResourceProjection allocatedResourceProjection = tAssociateAllocationRepository
						.getIntrnsitProjectResource(intransitProjectId, empDto.getEmployeeId(), statusIdForActivate,
								statusIdForApproved);
				List<Long> empIdList = new ArrayList<>();
				if (allocatedResourceProjection != null) {
					Long employeeId = allocatedResourceProjection.getEmployeeId();
					if (employeeId != null) {
						empIdList.add(employeeId);
					}
					List<Long> defaultSkillIdList = new ArrayList<>();
					defaultSkillIdList.add(allocatedResourceProjection.getdefaultSkillId());
					Map<Long, SkillTaxonomyDto> defaultSkillMap = getDefaultSkillForTransfer(defaultSkillIdList);
					Map<Long, EmployeeSkillDto> skillFamilyMap = resourceAllocationServiceImpl
							.getSkillFamilyForAssociate(empIdList);

					List<String> bands=List.of(ResourceManagementConstant.BAND_S0,ResourceManagementConstant.BAND_R0);

					if (!bands.contains(empDto.getBand())) {
						if (null == skillFamilyMap || skillFamilyMap.isEmpty()) {
							throw new ResourceManagementException("No Skill (L1 to L4) information is found so please ask the associate to update it in T@Z and get the same approved by your 1-Up Manager. The approved skill information will then be reflected in ZF next day.");
						}
					}

					
					if (null != allocatedResourceProjection) {
						empDto.setActualAllocationDate(allocatedResourceProjection.getActualStartDate());
						empDto.setEstimatedEndDate(allocatedResourceProjection.getEstEndDate());
						empDto.setAssociateAllocationId(allocatedResourceProjection.getEmployeeId());
						empDto.setFte_percent(allocatedResourceProjection.getFtePercent());
						empDto.setRequirementId(allocatedResourceProjection.getRequirementId());
						empDto.setProjectId(allocatedResourceProjection.getProjectId());
						empDto.setEmployeeCostRate(allocatedResourceProjection.getemployeeCostRate());
						Integer billableStatus = allocatedResourceProjection.getBillableStatusId();
						if (null != billableStatus && billableStatus.equals(1)) {
							empDto.setBillable(true);
						}
						if (null != defaultSkillMap) {
							setDefaultSkillMap(empDto, allocatedResourceProjection, defaultSkillMap);
						}
						setSkillFamilyForResource(empDto, skillFamilyMap);

						ResourceRequirementDto resourceRequirementDto = bapServiceClient
								.getRequirementDetailByReqId(allocatedResourceProjection.getRequirementId());
						setRequirementDetails(empDto, resourceRequirementDto);
					}
					newempDto = empDto;

				} else
					throw new ResourceManagementException(ResourceManagementConstant.SWITCH_WITHIN_BU_MSG);
			}
		}

		return newempDto;
	}

	private void setSkillFamilyForResource(EmployeeDto empDto, Map<Long, EmployeeSkillDto> skillFamilyMap) {
		if (skillFamilyMap != null && !skillFamilyMap.isEmpty()) {
			EmployeeSkillDto empSkillDto = skillFamilyMap.get(empDto.getEmployeeId());
			if (null != empSkillDto) {
				List<SkillTaxonomyDto> skillFamilyList = empSkillDto.getSkillFamilyList();
				empDto.setSkilltaxanomyList(skillFamilyList);
			}
		}
	}

	private void setDefaultSkillMap(EmployeeDto empDto, AllocatedResourceProjection allocatedResourceProjection,
			Map<Long, SkillTaxonomyDto> defaultSkillMap) {
		if (!defaultSkillMap.isEmpty()) {
			SkillTaxonomyDto skillFamilDto = defaultSkillMap.get(allocatedResourceProjection.getdefaultSkillId());
			if (null != skillFamilDto) {
				empDto.setDefaultSkillFamilyDto(skillFamilDto);
				String skill4Name= skillFamilDto.getL4skillName() != null?skillFamilDto.getL4skillName(): ResourceManagementConstant.NOT_AVAILABLE;
				empDto.setDefaultL4SkillId(skillFamilDto.getL4SkillId());
			    empDto.setDefaultL4SkillName(skill4Name);
			}else {
				 empDto.setDefaultL4SkillName(ResourceManagementConstant.NOT_AVAILABLE);
			}
		}
	}

	@Override
	public void approveOrRejectRTApproval(List<RMApprovalInputDto> rtApproveOrRejectDtlsList)
			throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.approveOrRejectRTApproval method:");
		List<Long> statusIdList = new ArrayList<>();
		statusIdList.add(0L);
		for (RMApprovalInputDto rtApproveOrRejectDtls : rtApproveOrRejectDtlsList) {
			List<Long> empIdList = new ArrayList<>();
			if ((rtApproveOrRejectDtls.getRequestType()).equals(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)
					&& (rtApproveOrRejectDtls.getApproverAction().equals(ResourceManagementConstant.APPROVED_ACTION)
							|| rtApproveOrRejectDtls.getApproverAction()
									.equals(ResourceManagementConstant.REJECTED_ACTION))) {
				rtApproveOrRejectDtls.getResourceList().forEach(resource -> {
					empIdList.add(resource.getEmpId());
				});
				rtApproveOrRejectDtls.setEmployeeIdList(empIdList);
				if (rtApproveOrRejectDtls.getRequestType()
						.equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
					List<TAssociateAllocation> tAllocationDtlsListObj = tAssociateAllocationRepository
							.getRAllocationDetails(rtApproveOrRejectDtls.getProjectId(),
									resourceManagementServiceImpl.getModuleStatusId(
											ResourceManagementConstant.RESOURCE_ALLOCATION,
											ResourceManagementConstant.ACTIVATE),
									rtApproveOrRejectDtls.getEmployeeIdList(),
									rtApproveOrRejectDtls.getRequirementId(),resourceManagementServiceImpl.getModuleStatusId(
											ResourceManagementConstant.RESOURCE_TRANSFER,
											ResourceManagementConstant.SUBMITTED));

					if (CollectionUtils.isNotEmpty(tAllocationDtlsListObj)) {
						if (rtApproveOrRejectDtls.getApproverAction().equalsIgnoreCase("APPROVED")) {
							approveRTApprovalReqForAlloc(tAllocationDtlsListObj, rtApproveOrRejectDtls, statusIdList);
						} else {
							rejectRTApprovalReqForAlloc(tAllocationDtlsListObj, rtApproveOrRejectDtls, statusIdList);
						}
					}
				}
			} else {
				throw new ResourceManagementException(ResourceManagementConstant.INVALID_REQUEST_TYPE);
			}
		}
		log.info("Just before leaving ResourceManagementServiceImpl.approveOrRejectRTApproval method:");
	}

	private void approveRTApprovalReqForAlloc(List<TAssociateAllocation> tAllocationDtlsListObj,
			RMApprovalInputDto rtApproveDtls, List<Long> statusIdList) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.approveRMApprovalReqForAlloc method:");
		ResourceWorkflow rsrcWrkflwObj = null;
		String wrkflwCode = resourceManagementServiceImpl.setWrkflwCode(rtApproveDtls.getRequestType(), rtApproveDtls.getRoleName());
		Long tagRoleId = adminServiceClient.getLookuIdByTypeAndDescr(ResourceManagementConstant.ROLE_TYPE, ResourceManagementConstant.TAG_TEAM);
		long allocApprovedStatusId = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.APPROVED);
		RMApprovalInputDto rmApprovalDtls = createRMApprovalInputDtoObj(rtApproveDtls);
		List<Long> transactionHistoryIdList = new ArrayList<>();
		List<Long> allocationTranscIdList = tAllocationDtlsListObj.stream()
				.map(TAssociateAllocation::getAssociateAllocationId).distinct().collect(Collectors.toList());
		for (TAssociateAllocation tAssociateAllocationObj : tAllocationDtlsListObj) {
			transactionHistoryIdList.add(tAssociateAllocationObj.getTransactionHistoryId());
			rsrcWrkflwObj = resourceWorkflowRepository.getRowDataOfDefaultStatus(
					tAssociateAllocationObj.getAssociateAllocationId(), statusIdList, rtApproveDtls.getUserId(),
					rtApproveDtls.getRoleId());
			List<Long> empNumbers= adminServiceClient.getEmployeeNumber(List.of(tAssociateAllocationObj.getCreatedBy()));
			
			if(empNumbers.get(0).equals(rtApproveDtls.getUserId()) && rtApproveDtls.getRoleName().equals(ResourceManagementConstant.PROJECT_MANAGER) ) {
				if (rsrcWrkflwObj != null && rsrcWrkflwObj.getResourceWrkflwId() > 0) {
					rsrcWrkflwObj.setStatusId(allocApprovedStatusId);
					rsrcWrkflwObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
					rsrcWrkflwObj.setLastUpdatedBy(rtApproveDtls.getUserId());
					rsrcWrkflwObj.setComment(rtApproveDtls.getApproverComments());
					resourceWorkflowRepository.save(rsrcWrkflwObj);
				} else {
					rsrcWrkflwObj = resourceWorkflowRepository.getRowData(
							tAssociateAllocationObj.getAssociateAllocationId(), rtApproveDtls.getUserId(),
							rtApproveDtls.getRoleId());
					rsrcWrkflwObj.setNextUserId(97440l);
					rsrcWrkflwObj.setNextRoleId(tagRoleId);
					ResourceWorkflow createRsrcWrkflwDataObject = resourceManagementServiceImpl.createRsrcWrkflwDataObject(
							rsrcWrkflwObj, tAssociateAllocationObj.getAssociateAllocationId(), rmApprovalDtls,
									ResourceManagementConstant.APPROVAL_CONSTANT);
					createRsrcWrkflwDataObject.setStatusId(allocApprovedStatusId);
					createRsrcWrkflwDataObject.setComment(rtApproveDtls.getApproverComments());
					resourceWorkflowRepository.save(createRsrcWrkflwDataObject);
				}
			}
			else {
				if (rsrcWrkflwObj != null && rsrcWrkflwObj.getResourceWrkflwId() > 0) {
					rsrcWrkflwObj.setStatusId(allocApprovedStatusId);
					rsrcWrkflwObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
					rsrcWrkflwObj.setLastUpdatedBy(rtApproveDtls.getUserId());
					rsrcWrkflwObj.setComment(rtApproveDtls.getApproverComments());
					resourceWorkflowRepository.save(rsrcWrkflwObj);
				} else {
					rsrcWrkflwObj = resourceWorkflowRepository.getRowData(
							tAssociateAllocationObj.getAssociateAllocationId(), rtApproveDtls.getUserId(),
							rtApproveDtls.getRoleId());
					ResourceWorkflow createRsrcWrkflwDataObject = resourceManagementServiceImpl.createRsrcWrkflwDataObject(
							rsrcWrkflwObj, tAssociateAllocationObj.getAssociateAllocationId(), rmApprovalDtls,
									ResourceManagementConstant.APPROVAL_CONSTANT);
					createRsrcWrkflwDataObject.setStatusId(allocApprovedStatusId);
					createRsrcWrkflwDataObject.setComment(rtApproveDtls.getApproverComments());
					resourceWorkflowRepository.save(createRsrcWrkflwDataObject);
				}
			}
		}
		if (rsrcWrkflwObj != null) {
			long nextUsrId = rsrcWrkflwObj.getNextUserId();
			long nextRoleId = rsrcWrkflwObj.getNextRoleId();
			if (nextUsrId > 0 && nextRoleId > 0) {
				log.info("Approval process still exist:");
				sendMailHelperServiceObj.sendEmailForApprovalConfirmation(rmApprovalDtls, wrkflwCode);
				sendMailHelperServiceObj.sendEmailForApproveOrRejectionPending(rmApprovalDtls, wrkflwCode,
						tAllocationDtlsListObj.get(0).getAssociateAllocationId());
			} else {
				log.info("Current user is final  approver, Approval process completed:");
				long allocApprovedStatusIdForAlloc = resourceManagementServiceImpl.getModuleStatusId(
						ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED);
				performUpdateBudgetAndDeactivateFinalApproval(tAllocationDtlsListObj, transactionHistoryIdList,
						rtApproveDtls);
				tAssociateAllocationRepository.updateWorkflowStatus(allocationTranscIdList,
						allocApprovedStatusIdForAlloc);
				sendMailHelperServiceObj.sendEmailForFinalApprovalConfirmation(rmApprovalDtls, wrkflwCode,
						tAllocationDtlsListObj.get(0).getAssociateAllocationId());
			}
		}
		log.info("Just before leaving ResourceManagementServiceImpl.approveRMApprovalReqForAlloc method:");
	}

	private void rejectRTApprovalReqForAlloc(List<TAssociateAllocation> tAllocationDtlsListObj,
			RMApprovalInputDto rtRejectDtls, List<Long> statusIdList) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.rejectRMApprovalReqForAlloc method:");
		String wrkflwCode = resourceManagementServiceImpl.setWrkflwCode(rtRejectDtls.getRequestType(), rtRejectDtls.getRoleName());
		HashBasedTable<String, String, Long> getallModuleData = allocatedResourceHelperClass.getallModuleData();
		Long statusIdForRejection = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.REJECTED);
		Long workflowStatusIdDeallocRejected = getallModuleData.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
				ResourceManagementConstant.REJECTED);
		Long workflowStatusId = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.SAVED);
		Long workFlowStatusIdForActivate = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long workFlowStatusIdForTransferSubmitted = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.SUBMITTED);
		ResourceWorkflow rsrcWrkflwPrevObj = resourceWorkflowRepository.getPreviousRowData(
				tAllocationDtlsListObj.get(0).getAssociateAllocationId(), rtRejectDtls.getUserId(),
				rtRejectDtls.getRoleId());
		long allocRejectedStatusId = resourceManagementServiceImpl
				.getModuleStatusId(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.REJECTED);
		RMApprovalInputDto rmApprovalRejectionDtls = createRMApprovalInputDtoObj(rtRejectDtls);
		List<Long> transactionHistoryIdList = new ArrayList<>();
		List<Long> actualAllocationIdList = new ArrayList<>();

		for (TAssociateAllocation tAssociateAllocationObj : tAllocationDtlsListObj) {
			transactionHistoryIdList.add(tAssociateAllocationObj.getTransactionHistoryId());
			actualAllocationIdList.add(tAssociateAllocationObj.getAssociateAllocationId());
			ResourceWorkflow rsrcWrkflwCrrntObj = resourceWorkflowRepository.getRowDataOfDefaultStatus(
					tAssociateAllocationObj.getAssociateAllocationId(), statusIdList, rtRejectDtls.getUserId(),
					rtRejectDtls.getRoleId());
			if (rsrcWrkflwCrrntObj != null && rsrcWrkflwCrrntObj.getResourceWrkflwId() > 0) {
				rsrcWrkflwCrrntObj.setStatusId(allocRejectedStatusId);
				rsrcWrkflwCrrntObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
				rsrcWrkflwCrrntObj.setLastUpdatedBy(rtRejectDtls.getUserId());
				rsrcWrkflwCrrntObj.setComment(rtRejectDtls.getApproverComments());
				resourceWorkflowRepository.save(rsrcWrkflwCrrntObj);
			}
			//Commented by Mrunal Marne for adding next approvers record when request is rejected
			/*else {
				rsrcWrkflwCrrntObj = resourceWorkflowRepository.getRowData(
						tAssociateAllocationObj.getAssociateAllocationId(), rtRejectDtls.getUserId(),
						rtRejectDtls.getRoleId());
				ResourceWorkflow createRsrcWrkflwDataObject = resourceManagementServiceImpl.createRsrcWrkflwDataObject(
						rsrcWrkflwCrrntObj, tAssociateAllocationObj.getAssociateAllocationId(), rmApprovalRejectionDtls,
						ResourceManagementConstant.APPROVAL_CONSTANT);
				createRsrcWrkflwDataObject.setStatusId(allocRejectedStatusId);
				createRsrcWrkflwDataObject.setComment(rtRejectDtls.getApproverComments());
				resourceWorkflowRepository.save(createRsrcWrkflwDataObject);
			}*/

			//Added by Mrunal Marne for adding next approvers record when request is rejected
			if (rsrcWrkflwPrevObj != null) {
				Long primaryPMLookUpValueId = adminServiceClient.getLookuIdByTypeAndDescr(ResourceManagementConstant.ROLE_TYPE, ResourceManagementConstant.PROJECT_MANAGER);
				List<RMApproversDto> rmApproversList = resourceManagementServiceImpl.getRMApproversList(rmApprovalRejectionDtls.getCurrentProjectId(), rmApprovalRejectionDtls.getUserId(),
						primaryPMLookUpValueId, rmApprovalRejectionDtls.getRequestType(), true);
				Map<String, RMApproversDto> rmApproversMap = rmApproversList.stream().collect(Collectors.toMap(RMApproversDto::getRoleName, Function.identity()));
				List<RMApproversDto> rmApproversListNew = new ArrayList<>();
				ResourceWorkflow resourceWorkflowRecordToDuplicate = null;
				/*if(rmApprovalRejectionDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.PROJECT_MANAGER) && 
						rsrcWrkflwPrevObj != null) {	
					rmApproversListNew.add(rmApproversMap.containsKey(ResourceManagementConstant.PROJECT_MANAGER) ? 
							rmApproversMap.get(ResourceManagementConstant.PROJECT_MANAGER) : null);				
				}*/
				if (rmApprovalRejectionDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.TAG_ROLE_NAME)) {
					rmApproversListNew.add(rmApproversMap.containsKey(ResourceManagementConstant.PROJECT_MANAGER) ? 
							rmApproversMap.get(ResourceManagementConstant.PROJECT_MANAGER) : null);
					rmApproversListNew.add(rmApproversMap.containsKey(ResourceManagementConstant.TAG_ROLE_NAME) ? 
							rmApproversMap.get(ResourceManagementConstant.TAG_ROLE_NAME) : null);				
				}
				for (RMApproversDto rmApproverDto : rmApproversListNew) {
					/*if(rmApprovalRejectionDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.PROJECT_MANAGER)) {
						List<ResourceWorkflow> resourceWorkflowRecordToDuplicateList = resourceWorkflowRepository.getRowDataForPMRole(
							tAssociateAllocationObj.getAssociateAllocationId(), rmApproverDto.getUserId(),
							rmApproverDto.getRoleId());
						if(Objects.nonNull(resourceWorkflowRecordToDuplicateList) && !resourceWorkflowRecordToDuplicateList.isEmpty()) {
							resourceWorkflowRecordToDuplicateList.forEach(resourceWorkflowRecord -> {
								resourceManagementServiceImpl.duplicateResourceWorkflowObjectDuringRejection(resourceWorkflowRecord, rmApproverDto.getUserId());
							});
						}
					} else {
						resourceWorkflowRecordToDuplicate = resourceWorkflowRepository.getRowDataForTagRole(
								tAssociateAllocationObj.getAssociateAllocationId(), rmApproverDto.getUserId(),
								rmApproverDto.getRoleId());
						if(Objects.nonNull(resourceWorkflowRecordToDuplicate))
							resourceManagementServiceImpl.duplicateResourceWorkflowObjectDuringRejection(resourceWorkflowRecordToDuplicate, rmApproverDto.getUserId());
					}*/
					if(rmApprovalRejectionDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.TAG_ROLE_NAME)) {
						Boolean isPrimaryPM = Boolean.FALSE;
						Long pmApprovedUserId;
						//check if PM is primary
						if(rmApproverDto.getRoleId() == primaryPMLookUpValueId) {
							pmApprovedUserId = resourceWorkflowRepository.getUserIdForPMApproved(tAssociateAllocationObj.getAssociateAllocationId(),rmApproverDto.getRoleId());
							isPrimaryPM = getIsPrimaryOwner(pmApprovedUserId, rmApproverDto.getRoleId(), rmApprovalRejectionDtls.getCurrentProjectId());
							if(isPrimaryPM) {
								resourceWorkflowRecordToDuplicate = resourceWorkflowRepository.getRowDataForTagRole(
										tAssociateAllocationObj.getAssociateAllocationId(), rmApproverDto.getUserId(),
										rmApproverDto.getRoleId());
								if (Objects.nonNull(resourceWorkflowRecordToDuplicate))
									resourceManagementServiceImpl.duplicateResourceWorkflowObjectDuringRejection(resourceWorkflowRecordToDuplicate, rmApproverDto.getUserId());
							} else {
								resourceWorkflowRecordToDuplicate = resourceWorkflowRepository.getRowDataForTagRole(
										tAssociateAllocationObj.getAssociateAllocationId(), pmApprovedUserId,
										rmApproverDto.getRoleId());
								resourceWorkflowRecordToDuplicate.setCurrentUserId(rmApproverDto.getUserId());
								if (Objects.nonNull(resourceWorkflowRecordToDuplicate))
									resourceManagementServiceImpl.duplicateResourceWorkflowObjectDuringRejection(resourceWorkflowRecordToDuplicate, rmApproverDto.getUserId());
								resourceWorkflowRecordToDuplicate.setCurrentUserId(pmApprovedUserId);
							}
						} else {
							resourceWorkflowRecordToDuplicate = resourceWorkflowRepository.getRowDataForTagRole(
									tAssociateAllocationObj.getAssociateAllocationId(), rmApproverDto.getUserId(),
									rmApproverDto.getRoleId());
							if (Objects.nonNull(resourceWorkflowRecordToDuplicate))
								resourceManagementServiceImpl.duplicateResourceWorkflowObjectDuringRejection(resourceWorkflowRecordToDuplicate, rmApproverDto.getUserId());
						}
						/*if (Objects.nonNull(resourceWorkflowRecordToDuplicate))
							resourceManagementServiceImpl.duplicateResourceWorkflowObjectDuringRejection(resourceWorkflowRecordToDuplicate, rmApproverDto.getUserId());*/
					}
				}
			}
			// End by Mrunal Marne
		}
		// if (rtRejectDtls.getProjectId() == rtRejectDtls.getCurrentProjectId()) {}
		if (rsrcWrkflwPrevObj != null) {
			long prevUsrId = rsrcWrkflwPrevObj.getCurrentUserId();
			long prevRoleId = rsrcWrkflwPrevObj.getCurrentRoleId();
			if (prevUsrId > 0 && prevRoleId > 0) {
				log.info("Rejection process still exist:");
					// Added by Mrunal Marne to update workflow status id to submitted if target PM rejects
					if(rmApprovalRejectionDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.PROJECT_MANAGER)) {
					resourceWorkflowRepository.deleteRowsOfDefaultStatus(actualAllocationIdList, statusIdList);
					tAssociateAllocationRepository.updateWorkflowStatus(actualAllocationIdList, workflowStatusId);
				}
				sendMailHelperServiceObj.sendEmailForApproveOrRejectionPending(rmApprovalRejectionDtls, wrkflwCode,
						tAllocationDtlsListObj.get(0).getAssociateAllocationId());
			}
		} else {
			log.info("Current user is final  Reject, Rejection process completed:");
			List<Long> rmTrnsctnIdListObj = tAllocationDtlsListObj.stream()
					.map(TAssociateAllocation::getAssociateAllocationId).collect(Collectors.toList());
			boolean budgetAndCostCheck = resourceAllocationServiceImpl
					.getBudgetAndCostCheck(rtRejectDtls.getProjectId());
			for (RTResourceDto resource : rtRejectDtls.getResourceList()) {
				tAssociateAllocationRepository.updatepartialRecordForSourceProj(statusIdForRejection,
						rtRejectDtls.getCurrentProjectId(), resource.getEmpId(),
						resource.getCurrentProjectDetails().getRequirementId(), workflowStatusId);
				if (budgetAndCostCheck) {
					TAssociateAllocation targetAssociateAllocation = tAssociateAllocationRepository
							.getTargetProjectAllocationId(resource.getEmpId(),
										resource.getTargetProjectDetails().getRequirementId(),
										rtRejectDtls.getProjectId(), workFlowStatusIdForActivate,
										List.of(workFlowStatusIdForTransferSubmitted));
					List<TAssociateAllocation> tAssoAlloTargetList = new ArrayList<>();
					tAssoAlloTargetList.add(targetAssociateAllocation);
					resourceManagementServiceImpl.releaseAllocatedBudgetForAlloc(tAssoAlloTargetList,
							rtRejectDtls.getProjectId(), resource.getTargetProjectDetails().getRequirementId());
				}
			}
			tAssociateAllocationRepository.updateStatusAndEffectiveEndDate(
					resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
							ResourceManagementConstant.REJECTED),
						rmTrnsctnIdListObj, new Date(System.currentTimeMillis()), resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
								ResourceManagementConstant.DEACTIVATE), tAssociateAllocationRepository.getEmployeeId(rtRejectDtls.getUserId()));
			resourceManagementServiceImpl.updateProjectStatus(rtRejectDtls.getProjectId());
			tAssociateDeAllocationRepository.updateWorkflowStaforTransfer(transactionHistoryIdList,
					workflowStatusIdDeallocRejected);
			sendMailHelperServiceObj.sendEmailForRejectionConfirmation(rmApprovalRejectionDtls, wrkflwCode);
		}
		log.info("Just before leaving ResourceManagementServiceImpl.rejectRMApprovalReqForAlloc method:");
	}
	
	public Boolean getIsPrimaryOwner(Long userId, Long roleId, Long projectId) throws ResourceManagementException{
		List<PrimaryUsersDto> primaryPMList = bapServiceClient.getRoleBasedPrimaryOwnersList(projectId, List.of(roleId));
		if(Objects.nonNull(primaryPMList) && primaryPMList.get(0).getUserId() == userId)
			return Boolean.TRUE;
		return Boolean.FALSE;
	}

	public RMApprovalInputDto createRMApprovalInputDtoObj(RMApprovalInputDto rtInputDto) {
		RMApprovalInputDto rmApprovalInputDto = new RMApprovalInputDto();
		rmApprovalInputDto.setUserId(rtInputDto.getUserId());
		rmApprovalInputDto.setRoleId(rtInputDto.getRoleId());
		rmApprovalInputDto.setEmployeeIdList(rtInputDto.getEmployeeIdList());
		rmApprovalInputDto.setRoleName(rtInputDto.getRoleName());
		rmApprovalInputDto.setUserName(rtInputDto.getUserName());
		rmApprovalInputDto.setRequestType(rtInputDto.getRequestType());
		rmApprovalInputDto.setRmApproversList(rtInputDto.getRmApproversList());
		rmApprovalInputDto.setRequirementId(rtInputDto.getRequirementId());
		rmApprovalInputDto.setProjectId(rtInputDto.getProjectId());
		rmApprovalInputDto.setApproverAction(rtInputDto.getApproverAction());
		rmApprovalInputDto.setApproverComments(rtInputDto.getApproverComments());
		rmApprovalInputDto.setCurrentProjectId(rtInputDto.getCurrentProjectId());
		rmApprovalInputDto.setResourceList(rtInputDto.getResourceList());
		return rmApprovalInputDto;
	}

	private void performUpdateBudgetAndDeactivateFinalApproval(List<TAssociateAllocation> tAllocationDtlsListObj,
			List<Long> transactionHistoryIdList, RMApprovalInputDto rtApproveDtls) throws ResourceManagementException {
		HashBasedTable<String, String, Long> getallModuleData = allocatedResourceHelperClass.getallModuleData();
		Long workflowApprovedStatus = getallModuleData.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long activeStatusIdForProject = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long statusForAllocApproved = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long workflowStatusIdForTransferSaved = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.SAVED);
		Long allocDeactiveStatusId = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.DEACTIVATE);

		List<RTResourceDto> resourceList = rtApproveDtls.getResourceList();
		List<TAssociateAllocation> currentProjectDetailsList = new ArrayList<>();
		Map<Long, Date> endDateMap = tAllocationDtlsListObj.stream().collect(HashMap::new,
				(m, v) -> m.put(v.getTransactionHistoryId(), v.getActualAllocationStartDate()), HashMap::putAll);
		// Deactivate source project and allocation record.
		for (Long transactionId : transactionHistoryIdList) {
			Date actualEndDate = endDateMap.get(transactionId);
			LocalDateTime localDateTime = actualEndDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime()
					.minusDays(1);
			// Updated date check below by Mrunal Marne
			boolean isTransferFromSameDay = DateUtils.isSameDay(actualEndDate, new Date());
			// if(actualEndDate.equals(new Date())) {

			
//			if(isTransferFromSameDay) {
			if (sdf.format(actualEndDate).equals(LocalDate.now().toString())) {
				tAssociateAllocationRepository.deactivateResourceAllocationForSourceRecSWithStatusId(transactionId,
						tAssociateAllocationRepository.getEmployeeId(rtApproveDtls.getUserId()), localDateTime, workflowApprovedStatus,allocDeactiveStatusId);
			}
			tAssociateAllocationRepository.deactivateResourceAllocationForSourceRec(transactionId,
					tAssociateAllocationRepository.getEmployeeId(rtApproveDtls.getUserId()), localDateTime, workflowApprovedStatus);
		}

		for (RTResourceDto resource : resourceList) {
			List<TAssociateAllocation> currentProjectDetails = new ArrayList<>();
			Long requirementId = resource.getCurrentProjectDetails().getRequirementId();
			Double targetutilization = resource.getTargetProjectDetails().getProjectUtilization();
			Double currentUtilization = tAssociateAllocationRepository.getCurrentProjectUtilizatioonForTransfer(
					requirementId, rtApproveDtls.getCurrentProjectId(), resource.getEmpId(), transactionHistoryIdList, activeStatusIdForProject);
			//Double currentUtilization = resource.getCurrentProjectDetails().getProjectUtilization();
			if (!targetutilization.equals(currentUtilization)) {
				tAssociateAllocationRepository.updatepartialRecordForSourceProj(statusForAllocApproved,
						rtApproveDtls.getCurrentProjectId(), resource.getEmpId(), requirementId,
						workflowStatusIdForTransferSaved);
			}
			if ((currentUtilization == resource.getTargetProjectDetails()
					.getProjectUtilization())
					|| (rtApproveDtls.getProjectId() == rtApproveDtls.getCurrentProjectId())) {
				TAssociateAllocation currentProjectData = tAssociateAllocationRepository
						.getCurrentProjectDataForTransfer(requirementId, rtApproveDtls.getCurrentProjectId(),
								resource.getEmpId(), List.of(workflowApprovedStatus), activeStatusIdForProject,
								transactionHistoryIdList);
				// Added by Mrunal Marne for source budget release
				currentProjectData.setTargetFtePercent(resource.getTargetProjectDetails().getProjectUtilization());
				// End by Mrunal Marne
				currentProjectDetails.add(currentProjectData);
			} else {
				TAssociateAllocation currentProjectData = tAssociateAllocationRepository
						.getCurrentProjectDataForTransfer(requirementId, rtApproveDtls.getCurrentProjectId(),
								resource.getEmpId(), List.of(workflowApprovedStatus, statusForAllocApproved),
								activeStatusIdForProject, transactionHistoryIdList);
				// Added by Mrunal Marne for source budget release
				currentProjectData.setTargetFtePercent(resource.getTargetProjectDetails().getProjectUtilization());
				// End by Mrunal Marne
				currentProjectData.setFtePercent(currentProjectData.getFtePercent()
						- resource.getTargetProjectDetails().getProjectUtilization());
				currentProjectDetails.add(currentProjectData);
			}
			// Release source budget
			boolean budgetCheck = resourceAllocationServiceImpl
					.getBudgetAndCostCheck(rtApproveDtls.getCurrentProjectId());
			if (budgetCheck) {
				releaseAllocatedBudgetForAllocTransfer(currentProjectDetails, rtApproveDtls.getCurrentProjectId(),
						rtApproveDtls.getCurrentRequirementId());
			}
			// end budget
			currentProjectDetailsList.addAll(currentProjectDetails);
		}
		// Insert record of source deallocation
		deAllocateSourceRecords(currentProjectDetailsList, rtApproveDtls);
		// deactivate source project if for 100% transfer
		rtApproveDtls.getResourceList().forEach(res -> {
			if (res.getCurrentProjectDetails().getProjectUtilization() == res.getTargetProjectDetails()
					.getProjectUtilization()) {
				try {
					resourceManagementServiceImpl.updateProjectStatus(rtApproveDtls.getCurrentProjectId());
				} catch (ResourceManagementException e) {
					Lombok.sneakyThrow(e);
				}
			}
		});
	}

	private void deAllocateSourceRecords(List<TAssociateAllocation> previousDataByTransactionHistoryId,
			RMApprovalInputDto rtApproveDtls) throws ResourceManagementException {
		List<TAssociateDeAllocation> associateDeAllocationList = new ArrayList<>();

		for (TAssociateAllocation allocation : previousDataByTransactionHistoryId) {
			TAssociateDeAllocation deAllocation = new TAssociateDeAllocation();
			//Commented by Mrunal Marne
//			deAllocation.setProjectId(rtApproveDtls.getProjectId());
//			deAllocation.setRequirementId(rtApproveDtls.getRequirementId());
			deAllocation.setProjectId(rtApproveDtls.getCurrentProjectId());
			deAllocation.setRequirementId(rtApproveDtls.getCurrentRequirementId());
			deAllocation.setAssociateAllocationId(allocation.getAssociateAllocationId());
			deAllocation.setEmployeeId(allocation.getTAssociateProject().getEmployeeId());
			// deAllocation.setDeallocationReasonId(1l);
			// deAllocation.setWorkflowReasonId(1L);
			deAllocation.setFtePercent(allocation.getFtePercent());

			for (RTResourceDto rtresource : rtApproveDtls.getResourceList()) {
				if ((rtresource.getEmpId()) == allocation.getTAssociateProject().getEmployeeId()) {
					deAllocation.setDeallocationDate(rtresource.getTargetProjectDetails().getAllocationDate());
					deAllocation.setEffectiveStartDate(rtresource.getTargetProjectDetails().getAllocationDate());
				}
			}
			long deAllocationStatusId = resourceManagementServiceImpl.getModuleStatusId(
					ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.DEACTIVATE);
			long deallocationWrkflwStatusId = resourceManagementServiceImpl.getModuleStatusId(
					ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.APPROVED);
			deAllocation.setWorkflowStatusId(deallocationWrkflwStatusId);
			deAllocation.setStatusId(deAllocationStatusId);
			deAllocation.setCreatedBy(rtApproveDtls.getUserId());
			deAllocation.setLastUpdatedBy(rtApproveDtls.getUserId());
			deAllocation.setCreatedDate(new Date());
			deAllocation.setLastUpdatedDate(new Date());
			deAllocation.setEffectiveEndDate(new Date());
			associateDeAllocationList.add(deAllocation);
		}
		tAssociateDeAllocationRepository.saveAll(associateDeAllocationList);
	}

	public void deAllocateSourceRecordODCAndProjectAndBU(List<TAssociateDeAllocationDto> tAssociateDeallocationDto) {
		List<TAssociateDeAllocation> associateDeallocation = asssociateDeallocationMapper
				.associateDeallocationDtoToAssociateDeallocations(tAssociateDeallocationDto);
		tAssociateDeAllocationRepository.saveAll(associateDeallocation);

	}

	public Map<Long, SkillTaxonomyDto> getDefaultSkillForTransfer(List<Long> skillIds)
			throws ResourceManagementException {
		Map<Long, SkillTaxonomyDto> defaultSkillMap = null;
		List<SkillTaxonomyDto> associateSkillList = adminServiceClient.getSkillFamilyByskillId(skillIds);
		if (null != associateSkillList) {
			defaultSkillMap = associateSkillList.stream()
					.collect(Collectors.toMap(SkillTaxonomyDto::getL4SkillId, newskillFamilyMap -> newskillFamilyMap));
		}
		return defaultSkillMap;
	}

	private void performUpdateBudgetAndDeactivateAdminOrTag(List<Long> transactionHistoryIdList,
			RMApprovalInputDto rtApproveDtls, List<TAssociateAllocation> associateAllocList)
			throws ResourceManagementException {

		HashBasedTable<String, String, Long> getallModuleData = allocatedResourceHelperClass.getallModuleData();
		Long workflowApprovedStatus = getallModuleData.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long activeStatusIdForProject = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		Long statusForAllocApproved = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		Long workflowStatusIdForTransferSaved = getallModuleData.get(ResourceManagementConstant.RESOURCE_TRANSFER,
				ResourceManagementConstant.SAVED);
		Long allocDeactiveStatusId = getallModuleData.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.DEACTIVATE);

		List<RTResourceDto> resourceList = rtApproveDtls.getResourceList();
		List<TAssociateAllocation> currentProjectDetailsList = new ArrayList<>();

		Map<Long, Date> endDateMap = associateAllocList.stream().collect(HashMap::new,
				(m, v) -> m.put(v.getTransactionHistoryId(), v.getActualAllocationStartDate()), HashMap::putAll);
		// Deactivate source project and allocation record.
		for (Long transactionId : transactionHistoryIdList) {
			Date actualEndDate = endDateMap.get(transactionId);
			LocalDateTime localDateTime = actualEndDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime()
					.minusDays(1);
			if (sdf.format(actualEndDate).equals(LocalDate.now().toString())) {
//			if(actualEndDate.equals(new Date())) {
				tAssociateAllocationRepository.deactivateResourceAllocationForSourceRecSWithStatusId(transactionId,
						rtApproveDtls.getUserId(), localDateTime, workflowApprovedStatus, allocDeactiveStatusId);
			}
			tAssociateAllocationRepository.deactivateResourceAllocationForSourceRec(transactionId,
					rtApproveDtls.getUserId(), localDateTime, workflowApprovedStatus);
		}
		for (RTResourceDto resource : resourceList) {
			List<TAssociateAllocation> currentProjectDetails = new ArrayList<>();
			Long requirementId = resource.getCurrentProjectDetails().getRequirementId();
			Double targetutilization = resource.getTargetProjectDetails().getProjectUtilization();
			Double currentUtilization = tAssociateAllocationRepository.getCurrentProjectUtilizatioonForTransfer(
					requirementId, rtApproveDtls.getCurrentProjectId(), resource.getEmpId(), transactionHistoryIdList, activeStatusIdForProject);
			//Double currentUtilization = resource.getCurrentProjectDetails().getProjectUtilization();
			if (!targetutilization.equals(currentUtilization)) {
				tAssociateAllocationRepository.updatepartialRecordForSourceProj(statusForAllocApproved,
						rtApproveDtls.getCurrentProjectId(), resource.getEmpId(), requirementId,
						workflowStatusIdForTransferSaved);
			}
			if ((currentUtilization == resource.getTargetProjectDetails()
					.getProjectUtilization())
					|| (rtApproveDtls.getProjectId() == rtApproveDtls.getCurrentProjectId())) {
				TAssociateAllocation currentProjectData = tAssociateAllocationRepository
						.getCurrentProjectDataForTransfer(requirementId, rtApproveDtls.getCurrentProjectId(),
								resource.getEmpId(), List.of(workflowApprovedStatus), activeStatusIdForProject,
								transactionHistoryIdList);
				// Added by Mrunal Marne for source budget release
				currentProjectData.setTargetFtePercent(resource.getTargetProjectDetails().getProjectUtilization());
				// End by Mrunal Marne
				currentProjectDetails.add(currentProjectData);
			} else {
				TAssociateAllocation currentProjectData = tAssociateAllocationRepository
						.getCurrentProjectDataForTransfer(requirementId, rtApproveDtls.getCurrentProjectId(),
								resource.getEmpId(), List.of(workflowApprovedStatus, statusForAllocApproved),
								activeStatusIdForProject, transactionHistoryIdList);
				// Added by Mrunal Marne for source budget release
				currentProjectData.setTargetFtePercent(resource.getTargetProjectDetails().getProjectUtilization());
				// End by Mrunal Marne
				currentProjectData.setFtePercent(currentProjectData.getFtePercent()
						- resource.getTargetProjectDetails().getProjectUtilization());
				currentProjectDetails.add(currentProjectData);
			}
			// Release source budget
			boolean budgetCheck = resourceAllocationServiceImpl
					.getBudgetAndCostCheck(rtApproveDtls.getCurrentProjectId());
			if (budgetCheck) {
				releaseAllocatedBudgetForAllocTransfer(currentProjectDetails, rtApproveDtls.getCurrentProjectId(),
						rtApproveDtls.getCurrentRequirementId());
			}

			currentProjectDetailsList.addAll(currentProjectDetails);
		}
		// Insert record of source deallocation
		deAllocateSourceRecords(currentProjectDetailsList, rtApproveDtls);
		// deactivate source project if for 100% transfer
		rtApproveDtls.getResourceList().forEach(res -> {
			if (res.getCurrentProjectDetails().getProjectUtilization() == res.getTargetProjectDetails()
					.getProjectUtilization()) {
				try {
					resourceManagementServiceImpl.updateProjectStatus(rtApproveDtls.getCurrentProjectId());
				} catch (ResourceManagementException e) {
					Lombok.sneakyThrow(e);
				}
			}
		});
	}

	public void releaseAllocatedBudgetForAllocTransfer(List<TAssociateAllocation> tAllocationDtlsListObj,
			Long projectId, long requirementId) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.releaseAllocatedBudget method:");
		List<ProjectBudgetDto> projectBudgetDto = budgetControlServiceClient.getProjectMonthlyBudgetsDetails(projectId);
		ResourceRequirementDto rsrcRqrmntDtoObj = bapServiceClient.getRequirementDetailByReqId(requirementId);
		if (CollectionUtils.isNotEmpty(projectBudgetDto)) {
			Map<String, ProjectBudgetDto> projectBudgets = projectBudgetDto.stream().collect(HashMap::new,
					(m, v) -> m.put(v.getMonth(), v), HashMap::putAll);
			for (TAssociateAllocation tAllocationDtlsObj : tAllocationDtlsListObj) {
				calculateAllocatedBudgetForTransfer(tAllocationDtlsObj, projectBudgets, rsrcRqrmntDtoObj);
			}
			resourceAllocationServiceImplObj.updateBudget(projectBudgets);
		}
		log.info("Just before leaving ResourceManagementServiceImpl.releaseAllocatedBudget method:");
	}

	public void calculateAllocatedBudgetForTransfer(TAssociateAllocation tAllocationDtlsObj,
			Map<String, ProjectBudgetDto> projectBudgets, ResourceRequirementDto rsrcRqrmntDtoObj)
			throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.calculateAllocatedBudget method:");
		try {
			String convertedDate = new SimpleDateFormat("yyyy-MM-dd").format(tAllocationDtlsObj.getActualAllocationEndDate());
			Date dt = new SimpleDateFormat("yyyy-MM-dd").parse(convertedDate);
			Calendar c = Calendar.getInstance();
			c.setTime(dt);
			c.add(Calendar.DATE, 1);
			dt = c.getTime();
			tAllocationDtlsObj.setActualAllocationEndDate(dt);
			Map<String, Long> monthlyResourceAllocationDetail = RMBudgetControlUtil.monthWiseNoOfDays(
					tAllocationDtlsObj.getActualAllocationEndDate(), tAllocationDtlsObj.getEstAllocationEndDate());
			double shoreWorkHour = 0.00;
			if (rsrcRqrmntDtoObj.getShore().equalsIgnoreCase(ResourceManagementConstant.ONSHORE))
				shoreWorkHour = 8;
			else
				shoreWorkHour = rsrcRqrmntDtoObj.getProjectBillingHours();
			List<String> months = monthlyResourceAllocationDetail.keySet().stream().collect(Collectors.toList());
			for (String month : months) {
				// Commented and Added below by Mrunal Marne for source budget release
				/*double deAllocCost = monthlyResourceAllocationDetail.get(month) * ((tAllocationDtlsObj.getStdCost())
						* shoreWorkHour * (tAllocationDtlsObj.getFtePercent() / 100));*/
				double deAllocCost = monthlyResourceAllocationDetail.get(month) * ((tAllocationDtlsObj.getStdCost())
						* shoreWorkHour * (tAllocationDtlsObj.getTargetFtePercent() / 100));
				List<TAssociateAllocationBudget> allocationBudget = associateAllocationBudgetRepository
						.findByAssociateAllocationIdAndBudgetAllocationMonth(
								tAllocationDtlsObj.getAssociateAllocationId(), month);
				resourceManagementServiceImpl.checkBudgetToRelease(projectBudgets, deAllocCost, allocationBudget);
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		log.info("Just before leaving ResourceManagementServiceImpl.calculateAllocatedBudget method:");
	}

}