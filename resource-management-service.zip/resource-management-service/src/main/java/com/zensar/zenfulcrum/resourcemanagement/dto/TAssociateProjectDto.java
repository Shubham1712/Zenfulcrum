package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class TAssociateProjectDto implements Serializable { 
	private static final long serialVersionUID = 6941105388790187987L;
	
	private Long associateProjectId;

	private Long employeeId;
		
	private Long srfId;
	
	private Long projectId;
	
	private Long supervisorId;

	private Long isPrimaryProject;
		
	private Long statusId;
	
	private Long createdBy;
		
	private Long lastUpdatedBy;
		
	private Date createdDate;
	
	private Date lastUpdatedDate;
		
	private Date effectiveStartDate;
	
	private Date effectiveEndDate;
	
	private long userId;

	private long roleId;
	
	private String roleName;
	
	private String userName;
	
	private long targetProjectId;
	
	private long targetRequirementId;
	
    private Boolean budgetAndCostCheck;

	
	private TAssociateAllocationDto tAssociateAllocation;  

}
