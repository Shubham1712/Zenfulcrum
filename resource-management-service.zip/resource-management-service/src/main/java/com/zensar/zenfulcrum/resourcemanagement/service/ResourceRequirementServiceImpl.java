package com.zensar.zenfulcrum.resourcemanagement.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.HashBasedTable;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.NewLookUpDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ReasonForDeallocation;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ServiceLineDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.AllocatedResourceHelperClass;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.GetResourceReqProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.ReservedAssociateProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceRequirementRepositary;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

import lombok.extern.slf4j.Slf4j;

@Service   
@Slf4j
@Transactional
public class ResourceRequirementServiceImpl implements ResourceRequirementService {

	@Autowired
	private BAPServiceClient bapServiceClient;

	@Autowired 
	private AdminServiceClient adminServiceClient;

	@Autowired
	private TAssociateAllocationRepository allocationRepository;

	@Autowired
	private TAssociateDeAllocationRepository repo;

	@Autowired
	private BudgetControlServiceClient budgetControlServiceClient;

	@Autowired
	private TAssociateAllocationRepository tAssociateAllocationRepository;
	
	@Autowired
	AllocatedResourceHelperClass allocatedResourceHelperClass;
	
	@Autowired 
	private ResourceAllocationServiceImpl resourceAllocationServiceImpl;
	
	@Autowired 
	private ResourceRequirementRepositary resourceRequirementRepository;
	

  
	@Override 
	public ResourceRequirementAndFteDto getRRforAllocation(long projectId) 
			throws ResourceManagementException {
		
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = bapServiceClient.getProjectFte(projectId);
		if (null != resourceRequirementAndFteDto) {
			List<ResourceRequirementDto> resourceRequirementAllocation = bapServiceClient
					.getResourceRequiremetList(projectId);
			
			//code by mounika--start
			List<NewLookUpDto>  newEbrReasonList=new ArrayList<>();
			List<LookupValueDto> ebrReasonList= adminServiceClient.getLookupValueByLookupType("EBR_REASON");
			ebrReasonList.forEach(lookupValueDto->{
				NewLookUpDto dto=new NewLookUpDto(lookupValueDto.getLookUpId(),lookupValueDto.getLookupValueCode(),lookupValueDto.getLookupValueDescription());
				newEbrReasonList.add(dto);
			});
			//code by mounika--end
			
			setBudgetDetailsinRR(projectId, resourceRequirementAndFteDto);
			//start by Srinivasulu s
		Double sumTotalResourceQty=	resourceRequirementAllocation.stream()
			.mapToDouble(ResourceRequirementDto::getTotalResourceQty).sum();
		resourceRequirementAndFteDto.setTotalBapFte(sumTotalResourceQty);
		//end by Srinivasulu s
			if (null != resourceRequirementAllocation) {  
				HashBasedTable<String, String, Long> wfStatsTable = allocatedResourceHelperClass.getallModuleData();
				Long wfStatusIdForActivate = wfStatsTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
				Long wfStatisIdForApproved =  wfStatsTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED);
                Long wfStatisIdForSaveed =  wfStatsTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.SAVED);
                Long wfStatisIdForSubmited =  wfStatsTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.SUBMITTED);
                Long wfStatisIdForTxSubmitted =  wfStatsTable.get(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SUBMITTED);
                Long wfStatisIdForTxSAved =  wfStatsTable.get(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SAVED);
                List<Long> wfStatuId =new ArrayList<>();
                wfStatuId.add(wfStatisIdForApproved);
                wfStatuId.add(wfStatisIdForSaveed);
                wfStatuId.add(wfStatisIdForSubmited);
                wfStatuId.add(wfStatisIdForTxSubmitted);
                wfStatuId.add(wfStatisIdForTxSAved);
                if(resourceRequirementAndFteDto.getProjectBillingType().equalsIgnoreCase("Billable"))
			  { 
                getActualMargin(resourceRequirementAndFteDto,resourceRequirementAllocation, projectId,wfStatusIdForActivate,wfStatisIdForApproved);
			  }	
                List<Long> requirmentIdList = resourceRequirementAllocation.stream()
						.map(ResourceRequirementDto::getReqId).collect(Collectors.toList());
				Map<String, Long> lookupMap = getLookupValue();
				Long billableStatusID = lookupMap.get("Billable");
				Long ebrStatusId = lookupMap.get("EBR");
				Long nonBillable = lookupMap.get("Non Billable");
				List<Long> billableList = new ArrayList<Long>();
				billableList.add(billableStatusID);
				billableList.add(nonBillable);
				Double totalAllocatedBillableFte = tAssociateAllocationRepository.getTotalAllocatedBillbleFteForProject(requirmentIdList, projectId, wfStatusIdForActivate, billableList, wfStatisIdForApproved);
				Double totalAllocatedEBRFte = tAssociateAllocationRepository.getTotalAllocatedEBRFteForProject(requirmentIdList, projectId,wfStatusIdForActivate, ebrStatusId, wfStatisIdForApproved);
				Double totalAllocatedFte = tAssociateAllocationRepository.getTotalAllocatedBillableOrNonBillableFteForProject(requirmentIdList, projectId, wfStatusIdForActivate,wfStatisIdForApproved);
				List<GetResourceReqProjection> listofallocatedResource = tAssociateAllocationRepository
						.getAllAllocatedResourceByRequirementId(requirmentIdList, projectId,wfStatusIdForActivate,wfStatuId);
				Map<Long, Double> listofallocatedResource1 = listofallocatedResource.stream().collect(HashMap::new,
						(m, v) -> m.put(v.getRequirementId(), v.getAllocatedFte()), HashMap::putAll);
				setTotalAllocatedFtefForRequirement(resourceRequirementAllocation, listofallocatedResource1,newEbrReasonList);
				List<GetResourceReqProjection> listofBillableFteforRequirement = tAssociateAllocationRepository
						.getBillableFTEForRequirementId(requirmentIdList, projectId,wfStatusIdForActivate,billableStatusID);
				Map<Long, Double> mapofBillableFteforRequirment = listofBillableFteforRequirement.stream().collect(
						HashMap::new, (m, v) -> m.put(v.getRequirementId(), v.getAllocatedFte()), HashMap::putAll);
				setBillableFteForRequirement(resourceRequirementAllocation, mapofBillableFteforRequirment);
		//		Map<Long,SkillTaxonomyDto> skillFamilyMap = getSkillFamilyByRequirmentId(requirmentIdList);
          //      setSkillTaxanomyForRequirment(resourceRequirementAllocation, skillFamilyMap);	
				
				resourceRequirementAndFteDto.setResourceRequirementDto(resourceRequirementAllocation);
				if (null != totalAllocatedBillableFte) {
					resourceRequirementAndFteDto.setTotalAllocatedBillableFte(totalAllocatedBillableFte);
				}
				if (null != totalAllocatedEBRFte) {
					resourceRequirementAndFteDto.setTotalAllocatedEBRFte(totalAllocatedEBRFte);
				}
				setAvailableBillableOrEbrFte(resourceRequirementAndFteDto, totalAllocatedBillableFte,
						totalAllocatedEBRFte,totalAllocatedFte);
			}
		}
		return resourceRequirementAndFteDto;

	}

	/*
	 * private void setSkillTaxanomyForRequirment(List<ResourceRequirementDto>
	 * resourceRequirementAllocation, Map<Long, SkillTaxonomyDto> skillFamilyMap) {
	 * for( ResourceRequirementDto resourceRequirment:resourceRequirementAllocation)
	 * { setSkillFamilyDetails(skillFamilyMap, resourceRequirment); } }
	 */

	@Override
	public List<ResourceRequirementDto> getRRforDeallocation(long projectId)
			throws ResourceManagementException {
		 return getResourceRequirementList(projectId);
		

	}

	@Override
	public ResourceRequirementAndFteDto getRRforTransfer(long projectId)
			throws ResourceManagementException {
		boolean budgetAndCostCheck = resourceAllocationServiceImpl.getBudgetAndCostCheck(projectId);
		List<ResourceRequirementDto> newResourceRequirement = getResourceRequirementList(projectId);
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = bapServiceClient.getProjectFte(projectId);
		resourceRequirementAndFteDto.setResourceRequirementDto(newResourceRequirement);
		
		//code by mounika--start
		List<NewLookUpDto>  newEbrReasonList=new ArrayList<>();
		List<LookupValueDto> ebrReasonList= adminServiceClient.getLookupValueByLookupType("EBR_REASON");
		ebrReasonList.forEach(lookupValueDto->{
			NewLookUpDto dto=new NewLookUpDto(lookupValueDto.getLookUpId(),lookupValueDto.getLookupValueCode(),lookupValueDto.getLookupValueDescription());
			newEbrReasonList.add(dto);
		});
		for(ResourceRequirementDto requirementDto : newResourceRequirement) {
			if(requirementDto.getBillingStatus().equals("EBR")) {
				requirementDto.setEbrReasonList(newEbrReasonList);
			}
		}
		//code by mounika--end
		
		//start by Srinivasulu s
		Double sumTotalResourceQty=	newResourceRequirement.stream()
			.mapToDouble(ResourceRequirementDto::getTotalResourceQty).sum();
		resourceRequirementAndFteDto.setTotalBapFte(sumTotalResourceQty);
		//end by Srinivasulu s
		for(ResourceRequirementDto req:newResourceRequirement) {
			req.setBudgetAndCostCheck(budgetAndCostCheck);
		}
		resourceRequirementAndFteDto.setBudgetAndCostCheck(budgetAndCostCheck);
		setBudgetDetailsinRR(projectId, resourceRequirementAndFteDto);
		List<ResourceRequirementDto> resourceRequiremetList = bapServiceClient.getResourceRequiremetList(projectId);
		if (null != resourceRequiremetList) {
			List<Long> requirmentIdList = resourceRequiremetList.stream().map(ResourceRequirementDto::getReqId)
					.collect(Collectors.toList());
			HashBasedTable<String, String, Long> wfStatsTable = allocatedResourceHelperClass.getallModuleData();
			Long wfStatusIdForActivate = wfStatsTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
            Long wfStatisIdForApproved =  wfStatsTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED);
			Map<String, Long> lookupMap = getLookupValue();
			Long billableStausId = lookupMap.get("Billable");
			Long ebrStatuId =  lookupMap.get("EBR");
			Long nonBillable = lookupMap.get("Non Billable");
			List<Long> billableList = new ArrayList<Long>();
			billableList.add(billableStausId);
			billableList.add(nonBillable);
			Double totalAllocatedBillableFte = tAssociateAllocationRepository
					.getTotalAllocatedBillbleFteForProject(requirmentIdList, projectId,wfStatusIdForActivate,billableList, wfStatisIdForApproved);
			Double totalAllocatedEBRFte = tAssociateAllocationRepository
					.getTotalAllocatedBillbleFteForProject(requirmentIdList, projectId,wfStatusIdForActivate,List.of(ebrStatuId), wfStatisIdForApproved);
			Double totalAllocatedFte = tAssociateAllocationRepository.getTotalAllocatedBillableOrNonBillableFteForProject(requirmentIdList, projectId, wfStatusIdForActivate,wfStatisIdForApproved);

			if (null != totalAllocatedBillableFte) {
				resourceRequirementAndFteDto.setTotalAllocatedBillableFte(totalAllocatedBillableFte);
			}
			if (null != totalAllocatedEBRFte) {
				resourceRequirementAndFteDto.setTotalAllocatedEBRFte(totalAllocatedEBRFte);
			}
			setAvailableBillableOrEbrFte(resourceRequirementAndFteDto, totalAllocatedBillableFte, totalAllocatedEBRFte,totalAllocatedFte);

		}

		return resourceRequirementAndFteDto;

	}
  
  
	public List<ResourceRequirementDto> getResourceRequirementList(long projectId) throws ResourceManagementException {
		log.info("Start get getResourceRequirementList in Serviceimpl");
		List<ResourceRequirementDto> newRequirement = bapServiceClient.getResourceRequiremetList(projectId);
		List<Long> reqIds = newRequirement.stream().map(ResourceRequirementDto::getReqId).collect(Collectors.toList());
		Boolean normalAllocFlg=Boolean.TRUE;
		List<AllocatedResourceProjection> associateList = allocatedResourceHelperClass
				.getNewAllocatedEmployeeList(projectId, reqIds,normalAllocFlg);  
		String buForProject = adminServiceClient.getBuForProject(projectId).getBuName();
		HashBasedTable<String, String, Long> wfStatsTable = allocatedResourceHelperClass.getallModuleData();
		Long wfStatusIdForActivate = wfStatsTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);
		List<Long> workflowStatusIds = List.of(
				wfStatsTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.SAVED),
				wfStatsTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.SUBMITTED),
				wfStatsTable.get(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SAVED),
				wfStatsTable.get(ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SUBMITTED));
		List<Long> workflowStatusIdsDealloc = List.of(
				wfStatsTable.get(ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.SAVED),
				wfStatsTable.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.SUBMITTED));  
			Map<Long, EmployeeDto> practiseDetailsMap = getPractiseDetails(associateList);
		Map<Long, Double> allocatedReourceMap = getNumberOfAllocatedResources(projectId, reqIds, wfStatusIdForActivate);
		Map<Long, Double> mapofBillableFteforRequirment = getBillableFTEforRequirment(projectId, reqIds,
				wfStatusIdForActivate);
		setBillableFteForRequirement(newRequirement, mapofBillableFteforRequirment);
		Map<Long, Integer> reservetFte = getReservedFteForAllocation(workflowStatusIds, wfStatusIdForActivate, reqIds);
		Map<Long, Integer> deallocationreservetFte = getReservedFteForDeallocation(reqIds, workflowStatusIdsDealloc);
		List<ReasonForDeallocation> reasonForDeallocationList = adminServiceClient.getReasonForDeallocation();
		List<ServiceLineDto> serviceLineDto = getServiceLineDto(projectId);
		if (!newRequirement.isEmpty()) {
			newRequirement.forEach(resourceRequirementDto -> {
				resourceRequirementDto.setReservedQtyForAllocation(0);
				Integer reservedQtyForAllocation = reservetFte.get(resourceRequirementDto.getReqId());
				if (reservedQtyForAllocation != null) {
					resourceRequirementDto.setReservedQtyForAllocation(reservedQtyForAllocation);
				}
				resourceRequirementDto.setReservedQtyForDeallocation(0);
				Integer reservedQtyForDeallocation = deallocationreservetFte.get(resourceRequirementDto.getReqId());
				if (null != reservedQtyForDeallocation) {
					resourceRequirementDto.setReservedQtyForDeallocation(reservedQtyForDeallocation);
				}
				resourceRequirementDto.setBuForProject(buForProject);
				List<EmployeeDto> employeelist = new ArrayList<>();
				associateList.forEach(allocatedResourceProjection -> {
					if (allocatedResourceProjection.getRequirementId() == resourceRequirementDto.getReqId()) {
						EmployeeDto employeeDto = new EmployeeDto();
						try {
							employeeDto = adminServiceClient
									.getEmployeeDetailsByEmpId(allocatedResourceProjection.getEmployeeId());
						} catch (ResourceManagementException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						employeeDto.setBillingStatus(resourceRequirementDto.getBillingStatus());
						setPractiseDetails(practiseDetailsMap, allocatedResourceProjection, employeeDto);
						setAllocatedResourceQty(allocatedReourceMap, resourceRequirementDto);
						setProjectDetails(allocatedResourceProjection, employeeDto);
						employeeDto.setReasonForDeallocationList(reasonForDeallocationList);
						//Added by Shubham, serviceline dto
						if(employeeDto.getServiceLineName()==null||employeeDto.getServiceLineName().equalsIgnoreCase("NOT AVAILABLE")) {
								employeeDto.setServiceLineDto(serviceLineDto);
						}else {
							employeeDto.setServiceLineId(resourceRequirementDto.getServiceLineId());
							employeeDto.setServiceLineName(resourceRequirementDto.getServiceLineName());
						}
						employeelist.add(employeeDto);
					}
				});
				resourceRequirementDto.setEmployeeList(employeelist);
				if(resourceRequirementDto.getServiceLineName()==null||resourceRequirementDto.getServiceLineName().equalsIgnoreCase("NOT AVAILABLE")) 
				resourceRequirementDto.setServiceLineDto(serviceLineDto);
			});
		}
		log.info("End getResourceRequirementList");
		return newRequirement;
	}

	private List<ServiceLineDto> getServiceLineDto(long projectId) throws ResourceManagementException {
		List<Long> serviceLineIds = tAssociateAllocationRepository.getProjectServiceLineIdbyProjectId(projectId);
		if (!serviceLineIds.stream().allMatch(o -> o == null)) {
			return adminServiceClient.getServiceLineList(serviceLineIds);
		}
		return Collections.emptyList();
	}

	/*
	 * private void setSkillFamilyDetails(Map<Long, SkillTaxonomyDto>
	 * skillFamilyMap, ResourceRequirementDto resourceRequirementDto) {
	 * if(!skillFamilyMap.isEmpty()) { SkillTaxonomyDto skillFamilDto =
	 * skillFamilyMap.get(resourceRequirementDto.getReqId()); if (null !=
	 * skillFamilDto ) { resourceRequirementDto.setSkillfamily(skillFamilDto); } } }
	 */
   
	/*
	 * private void setDefaultSkillName(Map<Long, SkillTaxonomyDto> defaultSkillMap,
	 * AllocatedResourceProjection allocatedResourceProjection, EmployeeDto
	 * employeeDto) { if(!defaultSkillMap.isEmpty()) {
	 * if(allocatedResourceProjection.getdefaultSkillId() != null) {
	 * SkillTaxonomyDto defaultSkillFamily =
	 * defaultSkillMap.get(allocatedResourceProjection.getdefaultSkillId()); if
	 * (null != defaultSkillFamily) {
	 * employeeDto.setDefaultL4SkillId(defaultSkillFamily.getL4SkillId());
	 * employeeDto.setDefaultL4SkillName(defaultSkillFamily.getL4skillName()); } } }
	 * }
	 */
  
	   private void setProjectDetails(AllocatedResourceProjection allocatedResourceProjection, EmployeeDto employeeDto) {
		employeeDto.setEmployeeId(allocatedResourceProjection.getEmployeeId());
		employeeDto.setEstimatedEndDate(allocatedResourceProjection.getEstEndDate());
		employeeDto.setActualAllocationDate(allocatedResourceProjection.getActualStartDate());
		employeeDto.setFte_percent(allocatedResourceProjection.getFtePercent());
		employeeDto.setAssociateAllocationId(allocatedResourceProjection.getAssociateAllocationId());
		employeeDto.setEmployeeProjectId(allocatedResourceProjection.getProjectId());
		employeeDto.setPrimaryProjectStatusId(allocatedResourceProjection.getIsPrimaryProject());
		employeeDto.setEmployeeCostRate(allocatedResourceProjection.getemployeeCostRate());
	//	Integer billableStatus = allocatedResourceProjection.getBillableStatusId();
	//	if (null != billableStatus && billableStatus.equals(ResourceManagementConstant.BILLABLE)) {
	//		employeeDto.setBillable(true);
	//	}
	//(employeeDto, billableStatus);
	}

	private Map<Long, Double> getNumberOfAllocatedResources(long projectId, List<Long> reqIds,long wfStatusIdForActivate) {
		List<GetResourceReqProjection> numberOfAllocatedResource = getAllocatedResourceForRequirement(reqIds,
				projectId,wfStatusIdForActivate);
		return numberOfAllocatedResource.stream().collect(HashMap::new,
				(m, v) -> m.put(v.getRequirementId(), v.getAllocatedFte()), HashMap::putAll);
		
	}

	private Map<Long, Double> getBillableFTEforRequirment(long projectId, List<Long> reqIds,long wfStatusIdForActivate) throws ResourceManagementException {
		Map<String, Long> lookupMap = getLookupValue();
		Long billableStatusID = lookupMap.get("Billable");
		List<GetResourceReqProjection> listofBillableFteforRequirement = allocationRepository
				.getBillableFTEForRequirementId(reqIds, projectId,wfStatusIdForActivate,billableStatusID);
		return listofBillableFteforRequirement.stream().collect(HashMap::new,
				(m, v) -> m.put(v.getRequirementId(), v.getAllocatedFte()), HashMap::putAll);
		
	}

	private Map<Long, Integer> getReservedFteForDeallocation(List<Long> reqIds,List<Long> workflowStatusIdsDealloc) {
		List<ReservedAssociateProjection> deallocationReservedAssociateList = repo
				.getReservedAssociateForDeallocation(reqIds,workflowStatusIdsDealloc);

		return deallocationReservedAssociateList.stream().collect(HashMap::new,
				(m, v) -> m.put(v.getrequirementId(), v.getreservedAssociateCount()), HashMap::putAll);
		
	}

	private Map<Long, Integer> getReservedFteForAllocation(List<Long> workflowStausIds,Long wfStatusIdForActivate,List<Long> reqIds) {
		List<ReservedAssociateProjection> reservedAssociateList = allocationRepository
				.getReservedAssociateForAllocation(workflowStausIds,wfStatusIdForActivate,reqIds);

	 return  reservedAssociateList.stream().collect(HashMap::new,
				(m, v) -> m.put(v.getrequirementId(), v.getreservedAssociateCount()), HashMap::putAll);
	
	}

	private void setPractiseDetails(Map<Long, EmployeeDto> map, AllocatedResourceProjection allocatedResourceProjection,
			EmployeeDto employeeDto) {
		Long empId = allocatedResourceProjection.getEmployeeId();
	if (null != empId && !map.isEmpty()) {  
			EmployeeDto newEmployeeDto = map.get(empId);
			if (null != newEmployeeDto) {
				employeeDto.setEmployeeName(newEmployeeDto.getEmployeeName());
				employeeDto.setEmployeePracticeId(newEmployeeDto.getEmployeePracticeId());
				employeeDto.setPracticeName(newEmployeeDto.getPracticeName());
				employeeDto.setRole(newEmployeeDto.getRole());
				employeeDto.setBand(newEmployeeDto.getBand());
				employeeDto.setEmployeeLocationId(newEmployeeDto.getEmployeeLocationId());
				employeeDto.setEmployeeLocation(newEmployeeDto.getEmployeeLocation());
				employeeDto.setEmployeeRoleId(newEmployeeDto.getEmployeeRoleId());
				employeeDto.setSkills(newEmployeeDto.getSkills());
			}
		}

	}  
    
	public void setAllocatedResourceQty(Map<Long, Double> allocatedReourceMap,
			ResourceRequirementDto resourceRequirementDto) {
		Long requirementId = resourceRequirementDto.getReqId();
		if (null != requirementId && !allocatedReourceMap.isEmpty()) {
			Double allocatedFte = allocatedReourceMap.get(requirementId);
			if (null != allocatedFte) {
				resourceRequirementDto.setAllocateResourceQty(allocatedFte);
			}
		}
	}

	private void setBillableFteForRequirement(List<ResourceRequirementDto> resourceRequiremetList,
			Map<Long, Double> mapofBillableFteforRequirment) {
		if (!resourceRequiremetList.isEmpty()) {
			resourceRequiremetList.forEach(resourceRequirementDto -> {
				if (!mapofBillableFteforRequirment.isEmpty()) {
					Double billableFteforRequirment = mapofBillableFteforRequirment
							.get(resourceRequirementDto.getReqId());

					if (null != billableFteforRequirment) {
						resourceRequirementDto.setBillable(billableFteforRequirment);
					}
				}
			});
		}
	}

	Map<Long, EmployeeDto> getPractiseDetails(List<AllocatedResourceProjection> associateList)
			throws ResourceManagementException {
		List<Long> empIds = associateList.stream().map(AllocatedResourceProjection::getEmployeeId)
				.collect(Collectors.toList());
		List<EmployeeDto> practiseDetails = adminServiceClient.getAssociatesDetails(empIds);
		return practiseDetails.stream()
				.collect(Collectors.toMap(EmployeeDto::getEmployeeId, employeemap -> employeemap));

	}

	public List<GetResourceReqProjection> getAllocatedResourceForRequirement(List<Long> requirementIds, Long projectId,Long wfStatusIdForActivate)

	{
		return allocationRepository.getAllocatedResourceByRequirementId(requirementIds, projectId,wfStatusIdForActivate);

	}

	public void setBudgetDetailsinRR(long projectId, ResourceRequirementAndFteDto resourceRequirementAndFteDto)
			throws ResourceManagementException {
		try {
			List<ProjectBudgetDto> projectBudget = budgetControlServiceClient
					.getProjectMonthlyBudgetsDetails(projectId);
			if (null != projectBudget) {
				Map<String, ProjectBudgetDto> projectBudgets = projectBudget.stream().collect(HashMap::new,
						(m, v) -> m.put(v.getMonth(), v), HashMap::putAll);
				if (null != projectBudgets) {
					// ProjectBudgetDto projectBudgetDto = projectBudgets
					// .get(RMBudgetControlUtil.getCurrentYearAndMonth());
                   Double availableBudget = projectBudget.stream()
							.filter(newprojectBudgetDto -> newprojectBudgetDto != null)
							// && projectBudgetDto.getAvailableBudget() != null)
							.mapToDouble(ProjectBudgetDto::getAvailableBudget).sum();
                   Double consumedBudget = projectBudget.stream()
							.filter(newprojectBudgetDto -> newprojectBudgetDto != null)
							// && projectBudgetDto.getTotalConsumption() != null)
							.mapToDouble(ProjectBudgetDto::getTotalConsumption).sum();
					Double totalBudget = projectBudget.stream()
							.filter(newprojectBudgetDto -> newprojectBudgetDto != null)
							// && projectBudgetDto.getTotalMonthlyBudget() != null)
							.mapToDouble(ProjectBudgetDto::getTotalMonthlyBudget).sum();
					resourceRequirementAndFteDto.setProjectAvailableBudget(availableBudget);
					resourceRequirementAndFteDto.setConsumedBudget(consumedBudget);
					resourceRequirementAndFteDto.setTotalBudget(totalBudget);

				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	private void setAvailableBillableOrEbrFte(ResourceRequirementAndFteDto resourceRequirementAndFteDto,
			Double totalAllocatedBillableFte, Double totalAllocatedEBRFte,Double totalAllocatedFte) {
		if (null != totalAllocatedBillableFte && null != totalAllocatedEBRFte) {
			Double totalallocatedFte = totalAllocatedBillableFte + totalAllocatedEBRFte;
			Double availableFte = resourceRequirementAndFteDto.getTotalBapFte() - totalallocatedFte;
			if (availableFte > 0) {
				resourceRequirementAndFteDto.setTotalAvailableFTEBillableorEBR(availableFte);
			}
		} else if (null != totalAllocatedBillableFte) {
			Double totalallocatedFte = totalAllocatedBillableFte;
			Double availableFte = resourceRequirementAndFteDto.getTotalBapFte() - totalallocatedFte;
			if (availableFte > 0) {
				resourceRequirementAndFteDto.setTotalAvailableFTEBillableorEBR(availableFte);
			}
		} else if (null != totalAllocatedEBRFte) {
			Double totalallocatedFte = totalAllocatedEBRFte;
			Double availableFte = resourceRequirementAndFteDto.getTotalBapFte() - totalallocatedFte;
			if (availableFte > 0) {
				resourceRequirementAndFteDto.setTotalAvailableFTEBillableorEBR(availableFte);
			}
		} else if (resourceRequirementAndFteDto.getProjectBillingType().equalsIgnoreCase("Non Billable")) {
			Double availableFte = resourceRequirementAndFteDto.getTotalBapFte() - totalAllocatedFte;
			if (availableFte > 0) {
				resourceRequirementAndFteDto.setTotalAvailableFTEBillableorEBR(availableFte);
			}
		}
	}

	/*
	 * private void setBillingStatus(EmployeeDto empDto, Integer billingStatusId) {
	 * if (null != billingStatusId) { if
	 * (billingStatusId.equals(ResourceManagementConstant.BILLABLE)) {
	 * empDto.setBillingStatus(ResourceManagementConstant.Billable); } else if
	 * (billingStatusId.equals(ResourceManagementConstant.EBR)) {
	 * empDto.setBillingStatus(ResourceManagementConstant.Ebr); } else {
	 * empDto.setBillingStatus(ResourceManagementConstant.NonBillibale); } } }
	 */

	private void setTotalAllocatedFtefForRequirement(List<ResourceRequirementDto> resourceRequiremetList,
			Map<Long, Double> listofallocatedResource1,List<NewLookUpDto> newEbrReasonList) {
		if (!resourceRequiremetList.isEmpty()) {   
			resourceRequiremetList.forEach(resourceRequirementDto -> {
				if (!listofallocatedResource1.isEmpty()) {
					Double allocatedResourceQty = listofallocatedResource1.get(resourceRequirementDto.getReqId());

					if (null != allocatedResourceQty) {
						resourceRequirementDto.setAllocateResourceQty(allocatedResourceQty);
					}
				}
				//code by mounika--start
				if(resourceRequirementDto.getBillingStatus().equals("EBR")) {
					resourceRequirementDto.setEbrReasonList(newEbrReasonList);
				}
				//end by Mounika
			});
		}
	} 
	
	

	/*
	 * public Map<Long, SkillTaxonomyDto> getSkillFamilyByRequirmentId(List<Long>
	 * reqIds) throws ResourceManagementException {
	 * 
	 * Map<Long, SkillTaxonomyDto> skillFamilyForRequirment = null;
	 * List<SkillTaxonomyDto> skillFamilyList =
	 * bapServiceClient.getSkillFamilyByReqId(reqIds); if (null != skillFamilyList)
	 * { skillFamilyForRequirment = skillFamilyList.stream()
	 * .collect(Collectors.toMap(SkillTaxonomyDto::getRequirmentId, skillFamilyMap
	 * -> skillFamilyMap)); } return skillFamilyForRequirment;
	 * 
	 * }
	 */
		public Map<Long, SkillTaxonomyDto> getDefaultSkillForAllocatedEmployee(List<Long> skillIds)
				throws ResourceManagementException {
			Map<Long, SkillTaxonomyDto> defaultSkillMap = null;
			List<SkillTaxonomyDto> associateSkillList = adminServiceClient.getSkillFamilyByskillId(skillIds);
			if (null != associateSkillList) {
				defaultSkillMap = associateSkillList.stream().collect(
						Collectors.toMap(SkillTaxonomyDto::getL4SkillId, newskillFamilyMap -> newskillFamilyMap));
			}
			return defaultSkillMap;
		}
		   
		public void getActualMargin(ResourceRequirementAndFteDto resourceRequirementAndFteDto,
				List<ResourceRequirementDto> resourcereqList, Long projectId,Long wfStatusIdForActivate,Long wfStatisIdForApproved) {
			double totalRevenue = resourceRequirementAndFteDto.getPoOrderValue();
			List<Long> reqIds = resourcereqList.stream().map(ResourceRequirementDto::getReqId)
					.collect(Collectors.toList());
			List<AllocatedResourceProjection> allocatedResourceList = allocationRepository
					.getAssociatesByRequirementId(reqIds, projectId,wfStatusIdForActivate,wfStatisIdForApproved);
			List<Double> totalRevenueForProject = new ArrayList<>();
			List<Double> totalCostForProject = new ArrayList<>();
			List<Double> totalProjectedCostList = new ArrayList<>();
			totalRevenueForProject.add(0.00);
			totalCostForProject.add(0.00);
			totalProjectedCostList.add(0.00);
			for (ResourceRequirementDto rrList : resourcereqList) {
				Double reqBillrate = rrList.getBillingRateInUSD();
				Double reqCostRate = rrList.getRequirmentCostRate();
				long shoreWorkHour = ResourceManagementConstant.ONSHORE.equalsIgnoreCase(rrList.getShore()) ? 8 : 9;
				List<Double> totalRevenueForAllocation = new ArrayList<>();
				totalRevenueForAllocation.add(0.00);
				List<Double> totalCostForAllocation = new ArrayList<>();
				totalCostForAllocation.add(0.00);
				Double requirmentEffortHrs = rrList.getRequirmentEffortsHours();
				List<Long> totalrequirmentEffortsHrs = new ArrayList<>();
				for (AllocatedResourceProjection resourceList : allocatedResourceList) {
					if (rrList.getReqId() == resourceList.getRequirementId()) {
						Double costForAllocation=0d;
						Date startDate = resourceList.getActualStartDate();
						Date endDate = resourceList.getEstEndDate();
						int workingdays = getWorkingDaysBetweenTwoDates(startDate, endDate);
						Double employeeCostRate = resourceList.getemployeeCostRate();
						Long allocationEffortsHrs = workingdays * shoreWorkHour;
						Double revenueForAllocation = allocationEffortsHrs * reqBillrate;
						if(allocationEffortsHrs!=null && employeeCostRate!=null)
							costForAllocation = allocationEffortsHrs * employeeCostRate;
						totalRevenueForAllocation.add(revenueForAllocation);
						totalCostForAllocation.add(costForAllocation);
						totalrequirmentEffortsHrs.add(allocationEffortsHrs);
                    }
				}
				Long sumOfTotalreqHrs = totalrequirmentEffortsHrs.stream().mapToLong(b -> b).sum();
				double totalRevenueForRequirment = totalRevenueForAllocation.stream().mapToDouble(a -> a).sum();
				double totalCostRateForAllocation = totalCostForAllocation.stream().mapToDouble(b -> b).sum();
				totalRevenueForProject.add(totalRevenueForRequirment);
				totalCostForProject.add(totalCostRateForAllocation);
				if(requirmentEffortHrs > sumOfTotalreqHrs)
				{	
				double remainingEffortHours = requirmentEffortHrs - sumOfTotalreqHrs;
				double projectedCostForRequirment = remainingEffortHours * reqCostRate;
				totalProjectedCostList.add(projectedCostForRequirment);
				}else {
					totalProjectedCostList.add(0.00);
				}
             }
			double projectRevenue = totalRevenueForProject.stream().mapToDouble(a -> a).sum();
			double projectCost = totalCostForProject.stream().mapToDouble(b -> b).sum();
			double totalProjectedCost = totalProjectedCostList.stream().mapToDouble(b -> b).sum();
			double totalResourceCost = projectCost + totalProjectedCost;
			if(projectRevenue != 0.00)
			{	 
			double actualMargin = ((projectRevenue - projectCost) / projectRevenue) * 100;
			double a = allocatedResourceHelperClass.getRoundedOffValue(actualMargin);
            resourceRequirementAndFteDto.setActualMargin(a);
			}else
			{
	            resourceRequirementAndFteDto.setActualMargin(0.00);
            }
			if (totalRevenue != 0) {
				double projectedmargin = ((totalRevenue - totalResourceCost) / totalRevenue) * 100;
				double p = allocatedResourceHelperClass.getRoundedOffValue(projectedmargin);
				resourceRequirementAndFteDto.setProjectedMargin(p);

			} else {
				resourceRequirementAndFteDto.setProjectedMargin(0.00);

			}
		}

		public  int getWorkingDaysBetweenTwoDates(Date startDate, Date endDate) {
			Calendar startCal = Calendar.getInstance();
			startCal.setTime(startDate);

			Calendar endCal = Calendar.getInstance();
			endCal.setTime(endDate);

			int workDays = 0;

			// Return 0 if start and end are the same
			if (startCal.getTimeInMillis() == endCal.getTimeInMillis()) {
				return 0;
			}

			if (startCal.getTimeInMillis() > endCal.getTimeInMillis()) {
				startCal.setTime(endDate);
				endCal.setTime(startDate);
			}
   
			do {
				// excluding start date
				//startCal.add(Calendar.DAY_OF_MONTH, 1); // Included start date by Mrunal Marne
				if (startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
						&& startCal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
					++workDays;
				}
				startCal.add(Calendar.DAY_OF_MONTH, 1);
			} while (startCal.getTimeInMillis() <= endCal.getTimeInMillis()); // excluding end date //Included end date by Mrunal Marne

			return workDays;
		}
		
	public 	Map<String, Long>  getLookupValue() throws ResourceManagementException
	{
		List<LookupValueDto> newLookuPList = adminServiceClient.getLookupValueByLookupType("RESOURCE_BILLABLE_TYPE");
	     return newLookuPList.stream().collect(HashMap::new,
				(m, v) -> m.put(v.getLookupType(), v.getLookUpId()), HashMap::putAll);
	
	}
	
	public ResourceRequirementAndFteDto getMargins(long projectId)
			throws ResourceManagementException {
		log.info("Start getMargins() method ");

		ResourceRequirementAndFteDto resourceRequirementAndFteDto = bapServiceClient.getProjectFte(projectId);
		if (null != resourceRequirementAndFteDto) {
			List<ResourceRequirementDto> resourceRequirementAllocation = bapServiceClient
					.getResourceRequiremetList(projectId);
			//start by Srinivasulu s
			Double sumTotalResourceQty=	resourceRequirementAllocation.stream()
				.mapToDouble(ResourceRequirementDto::getTotalResourceQty).sum();
			resourceRequirementAndFteDto.setTotalBapFte(sumTotalResourceQty);
			//end by Srinivasulu s
			setBudgetDetailsinRR(projectId, resourceRequirementAndFteDto);
			if (null != resourceRequirementAllocation) {
				HashBasedTable<String, String, Long> wfStatsTable = allocatedResourceHelperClass.getallModuleData();
				Long wfStatusIdForActivate = wfStatsTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
                Long wfStatisIdForApproved =  wfStatsTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED);
			    
                getActualMargin(resourceRequirementAndFteDto,resourceRequirementAllocation, projectId,wfStatusIdForActivate,wfStatisIdForApproved);
			    log.info("Actual Margin{}",resourceRequirementAndFteDto.getActualMargin());
			}
			} 
		return resourceRequirementAndFteDto;
	}
	
	//Added by Mrunal Marne for fetching SO billing hours
	public Long getSOBillingHours(String projectName) throws ResourceManagementException {
		log.info("Start getSOBillingHours() method for project name : " + projectName);
		Long billingHoursLong = 9L;
		Double billingHoursDouble = resourceRequirementRepository.getProjectBillingHours(projectName);
		if(Objects.nonNull(billingHoursDouble))
			billingHoursLong = billingHoursDouble.longValue();
		log.info("End getSOBillingHours() method for project name : " + projectName);
		return billingHoursLong;
	}
	//End by Mrunal Marne
	
}
