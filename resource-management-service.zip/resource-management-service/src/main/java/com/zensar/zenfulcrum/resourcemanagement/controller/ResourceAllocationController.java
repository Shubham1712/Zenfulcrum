package com.zensar.zenfulcrum.resourcemanagement.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceAllocationService;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementUtil;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Api(tags = "ResourceAllocationResource")
@RestController
@Slf4j
@Validated
@RequestMapping(path = "resourceallocation")
public class ResourceAllocationController {

	@Autowired
	private ResourceAllocationService resourceAllocationService;

	/**
	 * get the earmarked associates.
	 * 
	 * @param projectId    
	 * @return
	 * @throws ResourceManagementException
	 */
	@GetMapping(path = "/earmarkedassociate")
	public ResponseEntity<RMResponseDto> getEarmarkedAssociates(@Valid @RequestParam(name = "projectId") Long projectId,
			@Valid @RequestParam(name = "requirementId") Long requirementId) throws ResourceManagementException {
		log.info("Start getEarmarkedAssociates - projectId::{}", projectId);
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<EmployeeDto> earmarkedAssociates = resourceAllocationService.getEarmarkedAssociates(projectId,
				requirementId);
		if (!CollectionUtils.isEmpty(earmarkedAssociates)) {
			List<Object> objectList = new ArrayList<>(earmarkedAssociates);
			ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, objectList);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getEarmarkedAssociates");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}

	/**
	 * @throws ResourceManagementException This method return all po details for the
	 *                                     role. @return @throws
	 * @throws ParseException 
	 */
	@PostMapping
	public ResponseEntity<RMResponseDto> saveResourceAllocations(
			@Valid @RequestParam(name = "projectId") Long projectId,
			@Valid @RequestParam(name = "requirementId") Long requirementId,
			@Valid @RequestBody List<TAssociateProjectDto> tAssociateProjectDto) throws ResourceManagementException, ParseException {
		log.info("Start saveResourceAllocations");
		RMResponseDto rmResponseDto = new RMResponseDto();
		if (CollectionUtils.isNotEmpty(tAssociateProjectDto)) {
			resourceAllocationService.saveResourceAllocations(projectId, requirementId, tAssociateProjectDto);
		} else {
			ResourceManagementUtil.createBadRequest(rmResponseDto, ResourceManagementConstant.PROVIDE_DATA,
					ResourceManagementConstant.VALUE_EMPTY);
			log.debug("Exiting saveResourceAllocations");
			return ResponseEntity.badRequest().body(rmResponseDto);
		}
		log.info("End saveResourceAllocations");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.CREATED);
	}

	/**
	 * get the earmarked associates details for allocation.
	 * 
	 * @param projectId
	 * @param requiremntId
	 * @param employeelist
	 * @return
	 * @throws ResourceManagementException
	 */
	@PostMapping(path = "/associatedetail", consumes = "application/json", produces = "application/json")
	public ResponseEntity<RMResponseDto> getAssociateDetail(@Valid @RequestParam(name = "projectId") long projectId,
			@Valid @RequestParam(name = "requirementId") long requirementId,
			@RequestBody List<EmployeeDto> employeelist) throws ResourceManagementException {
		log.info("Start getAssociateDetail - projectId::{}", projectId, "requirementId::{}", requirementId,
				"employeeList::{}");
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<EmployeeDto> employeedetails = resourceAllocationService.getAssociatesDetails(projectId, requirementId,
				employeelist);
		if (!CollectionUtils.isEmpty(employeedetails)) {
			List<Object> objectList = new ArrayList<>(employeedetails);
			ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, objectList);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getEarmarkedAssociates");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}

	@GetMapping(path = "/associatetraveldetailByIdOrName")
	public ResponseEntity<RMResponseDto> getAssociatesForTravelByIdOrName(@Valid @RequestParam(name = "empIdOrName") String empIdOrName, 
			@Valid @RequestParam(name = "projectId") Long projectId, @Valid @RequestParam(name = "reqId") Long reqId) throws ResourceManagementException {
		log.info("Start getAssociateTravelDetail - projectId::{}", "employeeList::{}");
		RMResponseDto rmResponseDto = new RMResponseDto();
		EmployeeDto employeedetails = resourceAllocationService.getAssociatesForTravelByIdOrName(empIdOrName, projectId, reqId);
		if (null != employeedetails) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, employeedetails);
			log.info("End getAssociateTravelDetail");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
		} else {
			log.info("End getAssociateTravelDetail");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
	}


	
	@PostMapping(path = "/savetravel")
	public ResponseEntity<RMResponseDto> saveResourceTravelAllocations(
			@Valid @RequestBody List<TAssociateProjectDto> tAssociateProjectDto ) throws ResourceManagementException {
		log.info("Start saveResourceTravelAllocations");
		RMResponseDto rmResponseDto = new RMResponseDto();
		if (CollectionUtils.isNotEmpty(tAssociateProjectDto)) {
			resourceAllocationService.saveResourceTravelAllocations(tAssociateProjectDto);
		} else {
			ResourceManagementUtil.createBadRequest(rmResponseDto, ResourceManagementConstant.PROVIDE_DATA,
					ResourceManagementConstant.VALUE_EMPTY);
			log.debug("Exiting saveResourceTravelAllocations");
			return ResponseEntity.badRequest().body(rmResponseDto);
		}
		log.info("End saveResourceTravelAllocations");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.CREATED);
	}
	
	/**
	 * get the earmarked associates details for allocation.
	 * 
	 * @param empIdOrName
	 * @param currIntransitProjectId
	 * @param requirmentId
	 * @return
	 * @throws ResourceManagementException
	 */ 
	
	@GetMapping(path = "/intransitprojectresource")
	public ResponseEntity<RMResponseDto> getpoolToIntransitAllocationDtls(
			@Valid @RequestParam(name = "empIdOrName") String empIdOrName,
         	@Valid @RequestParam(name = "currIntransitProjectId") Long currIntransitProjectId,
        	@Valid @RequestParam(name = "requirmentId") Long requirmentId) throws ResourceManagementException {
		log.info("Start intransitprojectresource - projectId::{}", currIntransitProjectId, "requirementId::{}",
				requirmentId, "employeeList::{}");
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<EmployeeDto> employeedetails = resourceAllocationService.getpoolToIntransitAllocationDtls(empIdOrName,
				currIntransitProjectId, requirmentId);
		if (!CollectionUtils.isEmpty(employeedetails)) {
			if(employeedetails.size() == 1)
				ResourceManagementUtil.setResourceManagementDto(rmResponseDto, employeedetails.get(0));
			else {
				List<Object> objectList = new ArrayList<>(employeedetails);
				ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, objectList);
			}
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End intransitprojectresource");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}

	@GetMapping(path="/skilllistforresource")
	public ResponseEntity<RMResponseDto> getSkillListForResource(@Valid @RequestParam(name = "employeeId")Long employeeId) throws ResourceManagementException {
		log.info("Entered getSkillListForResource");
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<SkillTaxonomyDto> skillsDto = resourceAllocationService.getSkillListForResource(employeeId);
		if (!CollectionUtils.isEmpty(skillsDto)) {
			List<Object> objectList = new ArrayList<>(skillsDto);
			ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, objectList);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getSkillListForResource");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	
	@GetMapping(path="/allocatedftedetails")
	public ResponseEntity<RMResponseDto> getAlllocatedFteRsrcForReq(@Valid @RequestParam(name = "requirementId")Long requirementId) throws ResourceManagementException {
		log.info("Entered getAlllocatedFteRsrcForReq");
		RMResponseDto rmResponseDto = new RMResponseDto();
		List<EmployeeDto> employeeDtoList = resourceAllocationService.getAlllocatedFteRsrcForReq(requirementId);
		if (!CollectionUtils.isEmpty(employeeDtoList)) {
			List<Object> objectList = new ArrayList<>(employeeDtoList);
			ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, objectList);
		} else {
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getAlllocatedFteRsrcForReq");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	
}