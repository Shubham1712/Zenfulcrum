package com.zensar.zenfulcrum.resourcemanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateAllocationMapper;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

@Service
@Transactional
public class PDResourceManagmentServiceImpl implements PDResourceManagmentService{

	@Autowired
	private TAssociateAllocationRepository tAssociateAllocationRepository;
	@Autowired
	private ResourceManagementServiceImpl resourceManagementServiceImpl;
	@Autowired
	private TAssociateAllocationMapper tAssociateAllocationMapper;
	
	@Override
	public List<TAssociateAllocationDto> getAssociateListByProjectId(Long projectId) throws ResourceManagementException {
		Long statusIdForActive = resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE);
		Long approvedWorkFlowId =  resourceManagementServiceImpl.getModuleStatusId(
				ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.APPROVED);
		return tAssociateAllocationMapper.tAssociateAllocationToTAssociateAllocationDto(
				tAssociateAllocationRepository.getAssociateListByProjectId(projectId,statusIdForActive,approvedWorkFlowId));
	}
	
	@Override
	public List<TAssociateAllocationDto> getAssociateList(Long projectId) throws ResourceManagementException {
		return tAssociateAllocationMapper.tAssociateAllocationToTAssociateAllocationDto(
				tAssociateAllocationRepository.getAssociateList(projectId));
	}
	

}
