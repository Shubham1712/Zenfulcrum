package com.zensar.zenfulcrum.resourcemanagement.rest.client;

import static java.util.Optional.ofNullable;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.zensar.zenfulcrum.resourcemanagement.dto.BAllocationMilestoneDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PoAndMilestoneDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PrimaryUsersDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ServiceLineAndPoMilestoneDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.util.HttpRequestUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class BAPServiceClient {

	@Value("${BAP.SERVICE.URL}")
	private String bapBaseUrl;

	@Value("${PROJECT.LIST.REST.URL}")
	private String getProjectListRestURL;

	@Value("${PO.LIST.REST.URL}")
	private String getPOListRestURL;

	@Value("${PHASE.LIST.REST.URL}")
	private String getPhaseListRestURL;

	@Value("${RESOURCEREQUIREMENT.LIST.REST.URL}")
	private String getResourceRequirementRestURL;

	@Value("${PRIMARY.OWNERS.LIST.REST.URL}")
	private String getPrimaryOwnersListRestURL;

	@Value("${SERVICELINE.AND.POMILESTONE.URL}")
	private String getServiceLineAndPOMilestoneRestUrl;

	@Value("${REQUIREMENT.DETAIL.BYREQID.REST.URL}")
	private String requirementDetailByReqIdRestURL;

	@Value("${PROJECTFTE.REST.URL}")
	private String projectFteUrl;

	@Value("${INTRANSIT.REST.URL}")
	private String getIntransitProjectRestURL;

	@Value("${SAMEODC.PROJECT.LIST.REST.URL}")
	private String getProjectFromSameOdcRestURL;

	@Value("${ROLE.BASED.PRIMARY.OWNERS.LIST.REST.URL}")
	private String getRoleBasedPrimaryOwnersListRestURL;

	@Value("${PROJECTDETAIL.REST.URL}")
	private String getProjectDetailRestURL;

	@Value("${PROJECT.BASED.PRIMARY.OWNERS.LIST.REST.URL}")
	private String getProjectBasePrimaryOwnersListRestURL;

	@Value("${LIST.PRIMARY.OWNERS.LIST.REST.URL}")
	private String getListPrimaryOwnersListURL;

	@Value("${REQUIRMENTLIST.BYIDS.RESTURL}")
	private String getResourceRequirmentByListOfIds;

	@Value("${PROJECTLISTBYID.REST.URL}")
	private String getprojectListByIds;

	@Value("${PROJECTDEFINATION.SERVICE.URL}")
	private String projectDefinationBasetUrl;

	@Value("${SKILLFAMILY.BY.REQUIRMENTID.RESTURL}")
	private String getSkillFamilyByReqIdRestUrl;

	@Value("${COSTCARD.RESTURL}")
	private String getCostCardRestUrl;

	@Value("${PROJECT.DETAILS.LIST.REST.URL}")
	private String getProjectDetailListRestURL;

	@Value("${PROJECT.DETAILS.REST.URL}")
	private String getProjectDetails;
	
	@Value("${MPROJECT.DETAILS.REST.URL}")
	private String getMProjectDetails;
	
	@Value("${PROJECTDEFINATION.NEW.SERVICE.URL}")
	private String projectDefinationNewBasetUrl;
	
	@Value("${RMADMIN.SERVICE.BASE.URL}")
	private String getRMAdminRestUrl;
	
	
	@Value("${PO.AND.MILESTONE.LIST.REST.URL}")
	private String getPOAndMilestoneRestUrl;
	
	@Value("${SAVE.PO.AND.MILESTONE.LIST.REST.URL}")
	private String savePOAndMilestoneRestUrl;
	
	@Value("${SALES.ORDER.BY.PROJECTID.REST.URL}")
	private String getSalesOrderInfo;
	
	@Value("${REMOVE.PO.AND.MILESTONE.LIST.REST.URL}")
	private String removePOAndMilestoneRestUrl;
	
	@Value("${PROJECTDETAILS.SERVICE.URL}")
	private String pdDetails;

	@Value("${PROJECTDETAILS.COSTRATE.URL}")
	private String getcostratebyprojectrequrementid;
	
	@Value("${PROJECTDETAILS.PROJECTID.URL}")
	private String getprojectidbyprojectrequirementid;
	
	
	@Autowired
	private RestTemplate restTemplate;

	// working
	public List<ProjectDto> getProjectList(long userId, long roleId) throws ResourceManagementException {

		log.info("Start getProjectList");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<String>(headers);
		String url = projectDefinationBasetUrl
				+ MessageFormat.format(getProjectListRestURL, String.valueOf(userId), String.valueOf(roleId));
		List<ProjectDto> projectList = getProjectInfo(requestEntity, url);
		log.info("End getProjectList");
		return projectList;

	}

	private List<ProjectDto> getProjectInfo(HttpEntity<String> requestEntity, String url)
			throws ResourceManagementException {
		log.info("Start getProjectInfo");

		List<ProjectDto> projectList = null;
		try {
			ResponseEntity<List<ProjectDto>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<ProjectDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<ProjectDto>> projectDtoResponse = ofNullable(response.getBody());
				if (projectDtoResponse.isPresent()) {
					projectList = projectDtoResponse.get();
				}
			}
		} catch (Exception e) {
			log.error("getProjectInfo|url:{}|exception:{}", url, e);
			throw new ResourceManagementException(e);
		}
		return projectList;
	}

	// working
	public List<ResourceRequirementDto> getResourceRequiremetList(long projectId) throws ResourceManagementException {
		log.info("Start getResourceRequirementList");
		String url = projectDefinationBasetUrl
				+ MessageFormat.format(getResourceRequirementRestURL, String.valueOf(projectId));
		return getResourceRequiremetList(url);
	}

	// working
	public List<Long> getPrimaryOwnersList(long projectId) throws ResourceManagementException {
		log.info("Entered into BAPServiceClient.getPrimaryOwnersList method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
	//	String url = projectDefinationBasetUrl
	//			+ MessageFormat.format(getPrimaryOwnersListRestURL, String.valueOf(projectId));
	
		String url = getRMAdminRestUrl
					+ MessageFormat.format(getPrimaryOwnersListRestURL, String.valueOf(projectId));
		
		List<Long> userIdListObj = null;
		try {
			ResponseEntity<List<Long>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET, requestEntityObj,
					new ParameterizedTypeReference<List<Long>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<Long>> usrIdListOptnlObj = ofNullable(responseEntityObj.getBody());
				if (usrIdListOptnlObj.isPresent()) {
					userIdListObj = usrIdListOptnlObj.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getUsrIdListByPrjctId|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getUsrIdListByPrjctId|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving BAPServiceClient.getPrimaryOwnersList method:");
		return userIdListObj;
	}

	/**
	 * get associates Details.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	// not called
	public ServiceLineAndPoMilestoneDto getServiceLineAndPoMilestoneDetail(long projectId, long requirementId)
			throws ResourceManagementException {
		log.info("Start getServiceLineAndPoMilestoneDetail - projectId::{}", projectId, "requirementId ::{}",
				requirementId);
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = projectDefinationBasetUrl
				+ MessageFormat.format(getServiceLineAndPOMilestoneRestUrl, projectId, requirementId);
		ServiceLineAndPoMilestoneDto serviceLineAndPoMilestoneDto = null;
		try {
			ResponseEntity<ServiceLineAndPoMilestoneDto> response = restTemplate.exchange(url, HttpMethod.GET,
					requestEntity, new ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<ServiceLineAndPoMilestoneDto> servicelinepodetails = ofNullable(response.getBody());
				if (servicelinepodetails.isPresent()) {
					serviceLineAndPoMilestoneDto = servicelinepodetails.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getServiceLineAndPoMilestoneDetail|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getServiceLineAndPoMilestoneDetail|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Start getEarmarkedAssociates - projectId::{}", projectId);
		return serviceLineAndPoMilestoneDto;
	}

	/**
	 * Get requirement details by req ID.
	 * 
	 * @param reqId
	 * @return
	 * @throws ResourceManagementException
	 */
	// working
	public ResourceRequirementDto getRequirementDetailByReqId(Long reqId) throws ResourceManagementException {
		log.info("Start getRequirementDetailByReqId");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = projectDefinationBasetUrl + MessageFormat.format(requirementDetailByReqIdRestURL, String.valueOf(reqId));
		ResourceRequirementDto resourceRequirementDto = null;
		try {
			ResponseEntity<ResourceRequirementDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					ResourceRequirementDto.class);
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<ResourceRequirementDto> resourceRequirementResponse = ofNullable(response.getBody());
				if (resourceRequirementResponse.isPresent()) {
					resourceRequirementDto = resourceRequirementResponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getRequirementDetailByReqId|url:{}|exception:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getRequirementDetailByReqId|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getRequirementDetailByReqId");
		return resourceRequirementDto;
	}

	/**
	 * Get requirement BAP FTE Details And Budget Details
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	// working
	public ResourceRequirementAndFteDto getProjectFte(long projectId) throws ResourceManagementException {

		log.info("Start getProjectFte");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = projectDefinationBasetUrl + MessageFormat.format(projectFteUrl, String.valueOf(projectId));
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = null;
		try {
			ResponseEntity<ResourceRequirementAndFteDto> response = restTemplate.exchange(url, HttpMethod.GET,
					requestEntity, ResourceRequirementAndFteDto.class);
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<ResourceRequirementAndFteDto> resourceRequirementAndFteResponse = ofNullable(
						response.getBody());
				if (resourceRequirementAndFteResponse.isPresent()) {
					resourceRequirementAndFteDto = resourceRequirementAndFteResponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getProjectFte|url:{}|exception:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getProjectFte|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getProjectFte");
		return resourceRequirementAndFteDto;
	}

	// working
	public List<PrimaryUsersDto> getRoleBasedPrimaryOwnersList(long projectId, List<Long> roleIdList)
			throws ResourceManagementException {
		log.info("Entered into BAPServiceClient.getRoleBasedPrimaryOwnersList method:");
		List<String> roleIdStrListObj = roleIdList.stream().map(roleId -> String.valueOf(roleId))
				.collect(Collectors.toList());
		String url = projectDefinationBasetUrl + MessageFormat.format(getRoleBasedPrimaryOwnersListRestURL,
				String.valueOf(projectId), String.join(",", roleIdStrListObj));
		return getRoleBasedAndPrimaryOwnersList(url);

	}

	/**
	 * Get intransit ProjectId from BAPService
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	// working
	public ProjectDto getIntransitProjectId(long projectId) throws ResourceManagementException {

		log.info("Start getIntransitProjectId");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = projectDefinationBasetUrl
				+ MessageFormat.format(getIntransitProjectRestURL, String.valueOf(projectId));
		ProjectDto intransitProject = null;
		try {
			ResponseEntity<ProjectDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<ProjectDto>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<ProjectDto> intransitProjectIdresponse = ofNullable(response.getBody());
				if (intransitProjectIdresponse.isPresent()) {
					intransitProject = intransitProjectIdresponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getIntransitProjectId|url:{}|exception:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getIntransitProjectId|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}

		log.info("End getIntransitProjectId");
		return intransitProject;
	}

	/**
	 * Get projectList from sameOdc from BAPService
	 * 
	 * @param projectId
	 * @param roleId
	 * @param userId
	 * @return
	 * @throws ResourceManagementException
	 */
	public List<ProjectDto> getProjectWithinSameOdc(long projectId, long userId, long roleId)
			throws ResourceManagementException {

		log.info("Start getProjectWithinSameOdc");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = projectDefinationBasetUrl + MessageFormat.format(getProjectFromSameOdcRestURL,
				String.valueOf(projectId), String.valueOf(userId), String.valueOf(roleId));
		List<ProjectDto> projectswithinsameodc = null;
		try {
			ResponseEntity<List<ProjectDto>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<ProjectDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<ProjectDto>> projectwithinodcresponse = ofNullable(response.getBody());
				if (projectwithinodcresponse.isPresent()) {
					projectswithinsameodc = projectwithinodcresponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getProjectWithinSameOdc|url:{}|exception:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getProjectWithinSameOdc|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}

		log.info("End getProjectWithinSameOdc");
		return projectswithinsameodc;
	}

	/**
	 * Get ProjectDetail from BAPService
	 * 
	 * @param projectId
	 * @return ProjectDto
	 * @throws ResourceManagementException
	 */
	// working
	public ProjectDto getProjectDetail(long projectId) throws ResourceManagementException {
		log.info("Start getProjectDetail");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = projectDefinationBasetUrl
				+ MessageFormat.format(getProjectDetailRestURL, String.valueOf(projectId));
		ProjectDto singleprojectDetail = null;
		try {
			ResponseEntity<ProjectDto> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<ProjectDto>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<ProjectDto> projectIdresponse = ofNullable(response.getBody());
				if (projectIdresponse.isPresent()) {
					singleprojectDetail = projectIdresponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getProjectDetail|url:{}|exception:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getProjectDetail|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}

		log.info("End getProjectDetail");
		return singleprojectDetail;
	}

	// working
	public List<PrimaryUsersDto> getProjectBasedPrimaryOwnersList(List<Long> projectId, Long roleId)
			throws ResourceManagementException {
		log.info("Entered into BAPServiceClient.getProjectBasedPrimaryOwnersList method:");
		String projectIds = StringUtils.join(projectId, ",");
		String url = projectDefinationBasetUrl
				+ MessageFormat.format(getProjectBasePrimaryOwnersListRestURL, projectIds, roleId);
		return getRoleBasedAndPrimaryOwnersList(url);

	}

	// working
	public List<PrimaryUsersDto> getListPrimaryOwnersList(List<Long> projectId, List<Long> roleId)
			throws ResourceManagementException {
		log.info("Entered into BAPServiceClient.getListPrimaryOwnersList method:");
		String projectIds = StringUtils.join(projectId, ",");
		String roleIds = StringUtils.join(roleId, ",");
		String url = projectDefinationBasetUrl + MessageFormat.format(getListPrimaryOwnersListURL, projectIds, roleIds);
		return getRoleBasedAndPrimaryOwnersList(url);
	}

	// new method combined getListPrimaryOwnersList getProjectBasedPrimaryOwnersList
	public List<PrimaryUsersDto> getRoleBasedAndPrimaryOwnersList(String url) throws ResourceManagementException {
		log.info("Entered into BAPServiceClient.getRoleBasedPrimaryOwnersList method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		List<PrimaryUsersDto> primaryUserDtls = null;
		try {
			ResponseEntity<List<PrimaryUsersDto>> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET,
					requestEntityObj, new ParameterizedTypeReference<List<PrimaryUsersDto>>() {
					});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<PrimaryUsersDto>> primaryUserDtlsOptnlObj = ofNullable(responseEntityObj.getBody());
				if (primaryUserDtlsOptnlObj.isPresent()) {
					primaryUserDtls = primaryUserDtlsOptnlObj.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getRoleBasedPrimaryOwnersList|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getRoleBasedPrimaryOwnersList|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving BAPServiceClient.getRoleBasedPrimaryOwnersList method:");
		return primaryUserDtls;
	}

	// working

	public List<ResourceRequirementDto> getResourceRequiremetList(List<Long> requirmentIds)
			throws ResourceManagementException {
		log.info("Start getResourceRequirementList");
		String requirmentIdList = StringUtils.join(requirmentIds, ",");
		String url = projectDefinationBasetUrl
				+ MessageFormat.format(getResourceRequirmentByListOfIds, requirmentIdList);

		return getResourceRequiremetList(url);
	}

	/**
	 * Get ProjectDetail from BAPService
	 * 
	 * @param projectId
	 * @return ProjectDto
	 * @throws ResourceManagementException
	 */
	// working
	public List<ProjectDto> getProjectDetailByIds(List<Long> projectIds) throws ResourceManagementException {
		log.info("Start getProjectDetail");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String projectIdList = StringUtils.join(projectIds, ",");
		String url = projectDefinationBasetUrl + MessageFormat.format(getProjectDetails, projectIdList);
		List<ProjectDto> projectDetail = getProjectInfo(requestEntity, url);
		log.info("End getProjectDetail");
		return projectDetail;
	}

	// working
	public List<ResourceRequirementDto> getResourceRequiremetList(String url) throws ResourceManagementException {
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		List<ResourceRequirementDto> resourceRequirementList = null;
		try {
			ResponseEntity<List<ResourceRequirementDto>> response = restTemplate.exchange(url, HttpMethod.GET,
					requestEntity, new ParameterizedTypeReference<List<ResourceRequirementDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<ResourceRequirementDto>> projectDtoResponse = ofNullable(response.getBody());
				if (projectDtoResponse.isPresent()) {
					resourceRequirementList = projectDtoResponse.get();
				}
			}
		} catch (Exception e) {
			log.error("geList|url:{}|exception:{}", url, e);
			throw new ResourceManagementException(e);
		}
		log.info("End getProjectList");
		return resourceRequirementList;

	}

	/**
	 * Get SkillList from ProjectDefination service
	 * 
	 * @param reqIds
	 * @return
	 * @throws ResourceManagementException
	 */
	public List<SkillTaxonomyDto> getSkillFamilyByReqId(List<Long> reqIds) throws ResourceManagementException {

		log.info("Start getSkillFamilyByReqId");
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String reqIdList = StringUtils.join(reqIds, ",");

		String url = projectDefinationBasetUrl + MessageFormat.format(getSkillFamilyByReqIdRestUrl, reqIdList);
		List<SkillTaxonomyDto> skillFamilyList = getSkillDetail(requestEntity, url);

		log.info("End getSkillFamilyByReqId");
		return skillFamilyList;
	}

	private List<SkillTaxonomyDto> getSkillDetail(HttpEntity<String> requestEntity, String url)
			throws ResourceManagementException {
		log.info("Start getSkillDetail");

		List<SkillTaxonomyDto> skillFamilyList = null;
		try {
			ResponseEntity<List<SkillTaxonomyDto>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<SkillTaxonomyDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<SkillTaxonomyDto>> projectwithinodcresponse = ofNullable(response.getBody());
				if (projectwithinodcresponse.isPresent()) {
					skillFamilyList = projectwithinodcresponse.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getSkillFamilyByReqId|url:{}|exception:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getSkillFamilyByReqId|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("End getSkillDetail");
		return skillFamilyList;
	}

	//Added by Mrunal Marne for milestone selection while resource allocation
	public List<PoAndMilestoneDetailsDto> getPoAndMilestoneDetailsByProjectId(Long projectId, String allocStartDate, String allocEndDate) throws ResourceManagementException {
		log.info("Start getPoAndMilestoneDetailsByProjectId for  project id " + projectId);
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<String>(headers);
		String url = projectDefinationBasetUrl
				+ MessageFormat.format(getPOAndMilestoneRestUrl, String.valueOf(projectId), allocStartDate, allocEndDate);
		List<PoAndMilestoneDetailsDto> poAndMilestoneList = getPoAndMilestoneDetails(requestEntity, url);
		log.info("End getPoAndMilestoneDetailsByProjectId for  project id " + projectId);
		return poAndMilestoneList;
	}
	
	private List<PoAndMilestoneDetailsDto> getPoAndMilestoneDetails(HttpEntity<String> requestEntity, String url)
			throws ResourceManagementException {
		log.info("Start getPoAndMilestoneDetails");
		List<PoAndMilestoneDetailsDto> poAndMilestoneList = null;
		try {
			ResponseEntity<List<PoAndMilestoneDetailsDto>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<List<PoAndMilestoneDetailsDto>>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<List<PoAndMilestoneDetailsDto>> poAndMilestoneDtoResponse = ofNullable(response.getBody());
				if (poAndMilestoneDtoResponse.isPresent()) {
					poAndMilestoneList = poAndMilestoneDtoResponse.get();
				}
			}
		} catch (Exception e) {
			log.error("getPoAndMilestoneDetails|url:{}|exception:{}", url, e);
			throw new ResourceManagementException(e);
		}
		log.info("End getPoAndMilestoneDetails");
		return poAndMilestoneList;
	}
	
	public Boolean savePoAndMilestoneDetailsDuringAllocation(List<BAllocationMilestoneDto> allocationMilestoneDtoList) throws ResourceManagementException {
		log.info("Entered into BAPServiceClient.savePoAndMilestoneDetailsDuringAllocation method:");
		String url =  projectDefinationBasetUrl + savePOAndMilestoneRestUrl;
		Boolean successFlag = false;
		try {
			successFlag = restTemplate.postForObject(url, allocationMilestoneDtoList, Boolean.class);
			log.info("End BAPServiceClient.savePoAndMilestoneDetailsDuringAllocation method:");
			return successFlag;
		} catch (Exception hcee) {
			log.error("savePoAndMilestoneDetailsDuringAllocation|url:{}|exception:{}", url, hcee);
	          throw new ResourceManagementException(hcee);
		}
	}
	
	public Long getSalesOrderDetailByProjectId(Long projectId) throws ResourceManagementException {
		log.info("Start getSalesOrderDetail for  project id " + projectId);
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<String>(headers);
		String url = projectDefinationBasetUrl
				+ MessageFormat.format(getSalesOrderInfo, String.valueOf(projectId));
		Long soCommercialTypeId = getSalesOrderDetail(requestEntity, url);
		log.info("End getSalesOrderDetail for  project id " + projectId);
		return soCommercialTypeId;
	}
	
	private Long getSalesOrderDetail(HttpEntity<String> requestEntity, String url)
			throws ResourceManagementException {
		log.info("Start getSalesOrderDetail");
		Long soCommercialTypeId = null;
		try {
			ResponseEntity<Long> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					new ParameterizedTypeReference<Long>() {
					});
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<Long> soResponse = ofNullable(response.getBody());
				if (soResponse.isPresent()) {
					soCommercialTypeId = soResponse.get();
				}
			}
		} catch (Exception e) {
			log.error("getSalesOrderDetail|url:{}|exception:{}", url, e);
			throw new ResourceManagementException(e);
		}
		log.info("End getSalesOrderDetail");
		return soCommercialTypeId;
	}
	
	//Added by Mrunal Marne for removing records for RM transfer saved on rejection by Project Manager
	public Boolean removePoAndMilestoneDetailsForTransferRejection(List<Long> associateAllocationIdsList) throws ResourceManagementException {
		log.info("Entered into BAPServiceClient.removePoAndMilestoneDetailsForTransferRejection method:");
		String url =  projectDefinationBasetUrl + removePOAndMilestoneRestUrl;
		String associateAllocationIdsList1 = StringUtils.join(associateAllocationIdsList, ",");
		try {
			restTemplate.delete(url, associateAllocationIdsList1);
			log.info("End BAPServiceClient.removePoAndMilestoneDetailsForTransferRejection method:");
			return true;
		} catch (Exception hcee) {
			log.error("removePoAndMilestoneDetailsForTransferRejection|url:{}|exception:{}", url, hcee);
	          throw new ResourceManagementException(hcee);
		}
	}
	//End by Mrunal Marne
	
	// dev by Ravi
	
	public BigDecimal getprojectdetailsByProjreqId(Long projReqId)
			throws ResourceManagementException {
		log.info("Start getModuleStatus - getlocationCodeBylocationId::{}", projReqId);
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = pdDetails + MessageFormat.format(getcostratebyprojectrequrementid,String.valueOf(projReqId));
		BigDecimal costRate = null;
		try {
			ResponseEntity<BigDecimal> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					BigDecimal.class);
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<BigDecimal> moduleStatus = ofNullable(response.getBody());
				if (moduleStatus.isPresent()) {
					costRate = moduleStatus.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getModuleStatus|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getModuleStatus|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Start getModuleStatus");
		return costRate;
	}
	
	public Long getprojectidbyprojectrequirementid(Long projReqId)
			throws ResourceManagementException {
		log.info("Start getModuleStatus - getprojectIdByprojectRequirementId::{}", projReqId);
		HttpHeaders headers = HttpRequestUtil.getDefaultHttpHeaders();
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		String url = pdDetails + MessageFormat.format(getprojectidbyprojectrequirementid,String.valueOf(projReqId));
		Long projectId = null;
		try {
			ResponseEntity<Long> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					Long.class);
			if (HttpStatus.Series.valueOf(response.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<Long> moduleStatus = ofNullable(response.getBody());
				if (moduleStatus.isPresent()) {
					projectId = moduleStatus.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("getModuleStatus|url:{}| ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getModuleStatus|url:{}| exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Start getModuleStatus");
		return projectId;
	}
	
	//end by Ravi
}
