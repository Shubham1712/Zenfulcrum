package com.zensar.zenfulcrum.resourcemanagement.service;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import org.apache.commons.collections4.CollectionUtils;

import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeallocationInputDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.JVCheckHelperService;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateDeAllocationMapper;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocationBudget;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateDeAllocation;
import com.zensar.zenfulcrum.resourcemanagement.projection.AssociateDeAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.AssociateAllocationBudgetRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.JVDetailsRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.RMBudgetControlUtil;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class ResourceDeAllocationServiceImpl implements ResourceDeAllocationService {

	@Autowired
	private AdminServiceClient adminServiceClient;

	@Autowired
	private TAssociateDeAllocationMapper asssociateDeallocationMapper;

	@Autowired
	private TAssociateDeAllocationRepository repo;

	@Autowired
	private TAssociateDeAllocationRepository tAssociateDeallocationRepository;

	@Autowired
	//---Ak
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Autowired
	private ResourceManagementServiceImpl resourceManagementServiceImpl;

	@Autowired
	private JVDetailsRepository jvDetailsRepository;

	@Autowired
	JVCheckHelperService jvCheckHelperService;

	// code added on 140421
	@Autowired
	private ResourceAllocationServiceImpl resourceAllocationServiceImplObj;
	
	@Autowired
	private BudgetControlServiceClient budgetControlServiceClient;

	@Autowired
	private BAPServiceClient bapServiceClient;
	
	@Autowired
	private AssociateAllocationBudgetRepository associateAllocationBudgetRepository;
	
	@Autowired
	private ResourceSearchServiceImpl resourceSearchServiceImpl;
	
	// code added on 140421
	
	@Override
	@Transactional(readOnly = false)
	public void saveALLResourceDeallocation(TAssociateDeallocationInputDto tassociateDeallocationInputDto)
			throws ResourceManagementException, ParseException {
		log.info("Start of saveALLResourceDeallocation method");
		Long loggedInRoleId = adminServiceClient.getRoleIds(List.of(tassociateDeallocationInputDto.getRoleName())).get(0);
		if(resourceSearchServiceImpl.getOwnerCount(tassociateDeallocationInputDto.getUserId(), tassociateDeallocationInputDto.getTassociateDeAllocationList().get(0).getProjectId(), loggedInRoleId)==0)
			throw new ResourceManagementException(ResourceManagementConstant.NOT_AUTHORIZED);
		Date jvDate = jvDetailsRepository.getWindowEndDate();
		if (null != jvCheckHelperService.isJvCheck(jvDate) && jvCheckHelperService.isJvCheck(jvDate)) {
			throw new ResourceManagementException(ResourceManagementConstant.DEALLOCATION_NOT_POSSIBLE);
		} else {
			List<TAssociateDeAllocationDto> tAssociateDeallocationDto = tassociateDeallocationInputDto
					.getTassociateDeAllocationList();

			ModuleStatusDto moduleStatusDto = adminServiceClient.getModuleStatus(
					ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_DEALLOCATION,
					ResourceManagementConstant.DEACTIVATE);
			long statusId = moduleStatusDto.getModuleStatusId().intValue();

			ModuleStatusDto moduleStatus = adminServiceClient.getModuleStatus(
					ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_DEALLOCATION,
					ResourceManagementConstant.SAVED);
			long workflowStatusId = moduleStatus.getModuleStatusId().intValue();

			ModuleStatusDto moduleStatusAppr = adminServiceClient.getModuleStatus(
					ResourceManagementConstant.RESOURCE_MANAGEMENT, ResourceManagementConstant.RESOURCE_DEALLOCATION,
					ResourceManagementConstant.APPROVED);
			long workflowStatusIdAppr = moduleStatusAppr.getModuleStatusId().intValue();
			if (tassociateDeallocationInputDto.getRoleName()
					.equalsIgnoreCase(ResourceManagementConstant.ADMIN_ROLE_NAME)
					|| tassociateDeallocationInputDto.getRoleName()
							.equalsIgnoreCase(ResourceManagementConstant.TAG_ROLE_NAME)) {
				saveDeallocationByAdminOrTag(tAssociateDeallocationDto, statusId, workflowStatusIdAppr, tassociateDeallocationInputDto.getUserId());
			} else {
				saveDeallocation(tAssociateDeallocationDto, statusId, workflowStatusId);
			}
			log.info("Ending of saveALLResourceDeallocation method");
		}
	}

	private void saveDeallocation(List<TAssociateDeAllocationDto> tAssociateDeallocationDto, long statusId,
			long workflowStatusId) {
		
		List<Long> employeeIds = tAssociateAllocationRepository.getEmployeeIds(List.of(tAssociateDeallocationDto.get(0).getCreatedBy()));

		List<TAssociateDeAllocation> associateDeallocation = asssociateDeallocationMapper
				.associateDeallocationDtoToAssociateDeallocations(tAssociateDeallocationDto);
		for (TAssociateDeAllocation assDeallocation : associateDeallocation) {
			assDeallocation.setWorkflowStatusId(workflowStatusId);
			assDeallocation.setCreatedDate(new Date());
			assDeallocation.setStatusId(statusId);
			assDeallocation.setCreatedBy(employeeIds.get(0));
			assDeallocation.setLastUpdatedBy(employeeIds.get(0));	// Only calls one time.
			assDeallocation.setIsAutoDeallocated(false);
			assDeallocation.setLastUpdatedDate(new Date());
		}
		repo.saveAll(associateDeallocation);
	}

	public void saveDeallocationByAdminOrTag(List<TAssociateDeAllocationDto> tAssociateDeallocationDto, long statusId,
			long workflowStatusIdAppr, Long userId) throws ResourceManagementException {
		log.info("Start of saveALLResourceDeallocationByAdmin method");
		
		List<Long> employeeIds = tAssociateAllocationRepository.getEmployeeIds(List.of(tAssociateDeallocationDto.get(0).getCreatedBy()));
		List<TAssociateDeAllocation> associateDeallocation = asssociateDeallocationMapper
				.associateDeallocationDtoToAssociateDeallocations(tAssociateDeallocationDto);
		long deAllocApprovedStatusId = resourceManagementServiceImpl.getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
				ResourceManagementConstant.APPROVED);
		repo.saveAll(associateDeallocation);
		for (TAssociateDeAllocation assDeallocation : associateDeallocation) {
			assDeallocation.setWorkflowStatusId(workflowStatusIdAppr);
			assDeallocation.setCreatedDate(new Date());
			assDeallocation.setStatusId(statusId);
			assDeallocation.setCreatedBy(employeeIds.get(0));
			assDeallocation.setLastUpdatedBy(employeeIds.get(0));
			List<Long> employeeIdList = tAssociateDeallocationDto.stream().map(TAssociateDeAllocationDto::getEmployeeId)
					.collect(Collectors.toList());
			List<AssociateDeAllocationProjection> tDeAllocationDtlsListObj = tAssociateDeallocationRepository
					.getRDeAllocationRequiredDetails(assDeallocation.getProjectId(),
							resourceManagementServiceImpl.getModuleStatusId(
									ResourceManagementConstant.RESOURCE_DEALLOCATION,
									ResourceManagementConstant.DEACTIVATE),
							employeeIdList, assDeallocation.getRequirementId(),
							resourceManagementServiceImpl.getModuleStatusId(
									ResourceManagementConstant.RESOURCE_ALLOCATION,
									ResourceManagementConstant.ACTIVATE));
			List<Long> rmAllocTrnsctnIdListObj = tDeAllocationDtlsListObj.stream()
					.map(AssociateDeAllocationProjection::getAssociateAllocationId).collect(Collectors.toList());
			tAssociateAllocationRepository.updateStatusAndEffectiveEndDateForDealloc(deAllocApprovedStatusId, 
					rmAllocTrnsctnIdListObj, assDeallocation.getDeallocationDate(), tAssociateAllocationRepository.getEmployeeId(userId));
			resourceManagementServiceImpl.updateProjectStatus(assDeallocation.getProjectId());
			resourceManagementServiceImpl.releaseAllocatedBudgetForDeAlloc(tDeAllocationDtlsListObj,
					assDeallocation.getProjectId(), assDeallocation.getRequirementId());
		}
		log.info("Ending of saveALLResourceDeallocationByAdmin method");
	}
	
	
	// code started-140421
	@Override
	public void budgetReleaseAfterResourceDeallocationsExit(Long projectId,Long employeeId, Long requirementId,Long allocStatusId) throws ResourceManagementException {
		log.info("Entered into ResourceDeAllocationServiceImpl.budgetReleaseAfterResourceDeallocationsExit method:");
		
		
		List<AssociateDeAllocationProjection> tDeAllocationDtoDtlsListObj=tAssociateAllocationRepository.getResourceExitRemainingBudget(projectId, List.of(employeeId), requirementId, allocStatusId);
		
		List<ProjectBudgetDto> projectBudgetDto = budgetControlServiceClient.getProjectMonthlyBudgetsDetails(projectId);
		ResourceRequirementDto rsrcRqrmntDtoObj = bapServiceClient.getRequirementDetailByReqId(requirementId);
		if (CollectionUtils.isNotEmpty(projectBudgetDto)) {
			Map<String, ProjectBudgetDto> projectBudgets = projectBudgetDto.stream().collect(HashMap::new,
					(m, v) -> m.put(v.getMonth(), v), HashMap::putAll);
			for (AssociateDeAllocationProjection tDeAllocationDtoDtlsObj : tDeAllocationDtoDtlsListObj) {
				calculateAllocatedBudget(tDeAllocationDtoDtlsObj, projectBudgets, rsrcRqrmntDtoObj);
			}
			resourceAllocationServiceImplObj.updateBudget(projectBudgets);
		}
		log.info("Just before leaving ResourceDeAllocationServiceImpl.budgetReleaseAfterResourceDeallocationsExit method:");
	}

	public void calculateAllocatedBudget(AssociateDeAllocationProjection tDeAllocationDtoDtlsObj,
			Map<String, ProjectBudgetDto> projectBudgets, ResourceRequirementDto rsrcRqrmntDtoObj)
			throws ResourceManagementException {
		log.info("Entered into ResourceDeAllocationServiceImpl.calculateAllocatedBudget method:");
		Map<String, Long> monthlyResourceAllocationDetail = RMBudgetControlUtil.monthWiseNoOfDays(
				tDeAllocationDtoDtlsObj.getActualAllocationEndDate(), tDeAllocationDtoDtlsObj.getEstAllocationEndDate());
		 double shoreWorkHour = 0.00;
			if (rsrcRqrmntDtoObj.getShore().equalsIgnoreCase(ResourceManagementConstant.ONSHORE))
				shoreWorkHour = 8;
			else
				shoreWorkHour = rsrcRqrmntDtoObj.getProjectBillingHours();		

		List<String> months = monthlyResourceAllocationDetail.keySet().stream().collect(Collectors.toList());
		for (String month : months) {
			ProjectBudgetDto projectBudgetDto = projectBudgets.get(month);
			double deAllocCost = monthlyResourceAllocationDetail.get(month)
					* ((tDeAllocationDtoDtlsObj.getemployeeCostRate() * shoreWorkHour
							* (tDeAllocationDtoDtlsObj.getFtePercent() / 100)));
			// * rsrcRqrmntDtoObj.getZenAccurateCurrency() /
			// projectBudgetDto.getBudgetCurrency());
			List<TAssociateAllocationBudget> allocationBudget = associateAllocationBudgetRepository
					.findByAssociateAllocationIdAndBudgetAllocationMonth(
							tDeAllocationDtoDtlsObj.getAssociateAllocationId(), month);
			resourceManagementServiceImpl.checkBudgetToRelease(projectBudgets, deAllocCost, allocationBudget);
		}
		log.info("Just before leaving ResourceDeAllocationServiceImpl.calculateAllocatedBudget method:");
	}

	// code end here-140421
}
