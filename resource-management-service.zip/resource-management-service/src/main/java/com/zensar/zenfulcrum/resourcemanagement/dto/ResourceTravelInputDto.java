package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;

import lombok.Data;

@Data
public class ResourceTravelInputDto {

	private long userId;
	private long roleId;
	private String roleName;
	private String userName;
	private long targetProjectId;
	private long targetRequirementId;
	private List<TAssociateProjectDto> tassociateProjectdto;
}
