package com.zensar.zenfulcrum.resourcemanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zensar.zenfulcrum.resourcemanagement.model.TSrf;
import com.zensar.zenfulcrum.resourcemanagement.projection.SrfProjection;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

@Repository
public interface TSrfRepository extends JpaRepository<TSrf, Long> {

	
	/*
	 * @Query(value =
	 * "SELECT SRF.CANDIDATE_ID FROM T_SRF SRF WHERE SRF.PROJECT_ID=:projectId AND SRF.RESOURCE_STATUS=:resourceStatus AND SRF.STATUS_ID=:statusId AND SRF.IS_SELECTED=:isSelected AND \r\n"
	 * + "SRF.CANDIDATE_ID NOT IN (SELECT TAP.EMPLOYEE_ID \r\n" +
	 * "FROM T_ASSOCIATE_ALLOCATION TAA INNER JOIN T_ASSOCIATE_PROJECT TAP ON TAA.ASSOCIATE_PROJECT_ID=TAP.ASSOCIATE_PROJECT_ID\r\n"
	 * + "WHERE TAA.STATUS_ID =:statusId\r\n" +
	 * "GROUP BY TAP.EMPLOYEE_ID,TAP.PROJECT_ID HAVING SUM(TAA.FTE_PERCENT)>=100)",
	 * nativeQuery = true) List<Long> getCandidateIds(@Param("projectId") Long
	 * projectId, @Param("resourceStatus") String resourceStatus, @Param("statusId")
	 * Long statusId, @Param("isSelected") boolean isSelected);
	 */
	
	@Query(value = "SELECT SRF.CANDIDATE_ID FROM zf_resourcemanagement.T_SRF SRF WHERE SRF.PROJECT_ID = :projectCode AND SRF.RESOURCE_STATUS= :resourceStatus  AND SRF.STATUS_ID= :statusIdForSrfActive AND SRF.IS_SELECTED= :isSelected AND\r\n" + 
			"SRF.CANDIDATE_ID NOT IN (SELECT `employee_number` FROM `zf_admin`.`M_EMPLOYEE` WHERE `employee_id` IN (SELECT TAP.EMPLOYEE_ID \r\n" + 
			"FROM zf_resourcemanagement.T_ASSOCIATE_ALLOCATION TAA INNER JOIN zf_resourcemanagement.T_ASSOCIATE_PROJECT TAP ON zf_resourcemanagement.TAA.ASSOCIATE_PROJECT_ID=TAP.ASSOCIATE_PROJECT_ID\r\n" + 
			"WHERE TAA.STATUS_ID = :statusId AND TAA.`billable_status_id` != :statusIdForPool AND TAP.EMPLOYEE_ID IN (SELECT `employee_id` FROM `zf_admin`.`M_EMPLOYEE` WHERE `employee_number` IN \r\n" + 
			"(SELECT SRF.CANDIDATE_ID FROM `zf_resourcemanagement`.\r\n" + 
			"T_SRF SRF WHERE SRF.PROJECT_ID = :projectCode AND SRF.RESOURCE_STATUS= :resourceStatus AND SRF.STATUS_ID= :statusIdForSrfActive AND SRF.IS_SELECTED= :isSelected))\r\n" + 
			"GROUP BY TAP.EMPLOYEE_ID,TAP.PROJECT_ID HAVING SUM(TAA.FTE_PERCENT)>=100))", nativeQuery = true)
	List<Long> getCandidateIds(@Param("projectCode") String projectCode, @Param("resourceStatus") String resourceStatus, @Param("statusId") Long statusId, @Param("isSelected") boolean isSelected,@Param("statusIdForSrfActive") Long statusIdForSrfActive,@Param("statusIdForPool") Long statusIdForPool);
	

	
	
	@Query(value = "SELECT srf_id AS SrfId  ,srf_number AS SrfNumber ,candidate_id AS CandidateId FROM T_SRF WHERE candidate_id IN :candidateId AND project_id = :projectId AND status_end_date >= CURDATE()", nativeQuery = true)
       List<SrfProjection> findByCandidateIdIn(List<Long> candidateId , @Param("projectId") Long projectId);

	@Query(value = "SELECT srf_number FROM `T_SRF` WHERE srf_id = :srfId", nativeQuery = true)
    String getSrfNoFromId(@Param("srfId") Long srfId);
	
	@Query(value = "SELECT srf_id AS SrfId  ,srf_number AS SrfNumber ,candidate_id AS CandidateId FROM T_SRF WHERE `srf_id` IN :srfIds", nativeQuery = true)
    List<SrfProjection> findBysrfId(@Param("srfIds") List<Long> srfIds);
	
	@Query(value = "SELECT SRF.CANDIDATE_ID AS CandidateId,SRF.`srf_id` AS SrfId,SRF.`srf_number` AS SrfNumber FROM T_SRF SRF WHERE SRF.PROJECT_ID=:projectCode AND SRF.RESOURCE_STATUS=:resourceStatus AND SRF.STATUS_ID=:statusId AND SRF.IS_SELECTED=:isSelected \r\n", nativeQuery = true)
	List<SrfProjection> getsrfdetails(@Param("projectCode") String projectCode, @Param("resourceStatus") String resourceStatus, @Param("statusId") Long statusId, @Param("isSelected") boolean isSelected);
	
	@Query(value = "SELECT * FROM T_SRF SRF WHERE SRF.CANDIDATE_ID = :employeeId  AND SRF.RESOURCE_STATUS=:resourceStatus AND SRF.STATUS_ID=:statusId AND SRF.IS_SELECTED=:isSelected AND \r\n" + 
			"SRF.CANDIDATE_ID NOT IN (SELECT TAP.EMPLOYEE_ID \r\n" + 
			"FROM T_ASSOCIATE_ALLOCATION TAA INNER JOIN T_ASSOCIATE_PROJECT TAP ON TAA.ASSOCIATE_PROJECT_ID=TAP.ASSOCIATE_PROJECT_ID\r\n" + 
			"WHERE TAA.STATUS_ID =:statusId\r\n" + 
			"GROUP BY TAP.EMPLOYEE_ID,TAP.PROJECT_ID HAVING SUM(TAA.FTE_PERCENT)>=100)", nativeQuery = true)
	List<TSrf> getIntransitEarmarkedResource(@Param("employeeId") Long employeeId,@Param("resourceStatus") String resourceStatus, @Param("statusId") Long statusId, @Param("isSelected") boolean isSelected);
	
	@Query(value = "SELECT bms.module_status_id AS ModuleStatusId  FROM `zf_admin`.M_MODULE module INNER JOIN `zf_admin`.B_MODULE_STATUS bms ON bms.MODULE_ID = module.MODULE_ID\r\n" + 
			"INNER JOIN `zf_admin`.M_LOOKUP_VALUE lval ON bms.LINK_STATUS_ID = lval.LOOKUP_VALUE_ID INNER JOIN \r\n" + 
			"`zf_admin`.M_LOOKUP_TYPE ltyp ON ltyp.LOOKUP_TYPE_ID = lval.LOOKUP_TYPE_ID \r\n" + 
			"WHERE module.module_name = :moduleName AND lval.`lookup_value_code` = :activateAction", nativeQuery = true)
   Long getModuleIdForSrf(@Param("moduleName") String moduleName,@Param("activateAction") String activateAction);

	
	@Query(value = "SELECT HIVE_FLAG FROM "+ResourceManagementConstant.STAGING_SCHEMA+".`PD_HRMS_PRACTICE_DATA` WHERE EMP_ID=:employeeNumber", nativeQuery = true)
	String getHiveFlag(@Param("employeeNumber") Long employeeNumber);


	@Query(value = "SELECT srf_number FROM `T_SRF` WHERE `candidate_id`=:employeeNumber AND project_id=:projectCode ORDER BY last_updated_date DESC LIMIT 1", nativeQuery = true)
	String getSrfNoFromCandidateId(Long employeeNumber, String projectCode);

	
}
