package com.zensar.zenfulcrum.resourcemanagement.rest.client;

import static java.util.Optional.ofNullable;

import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zensar.zenfulcrum.resourcemanagement.dto.WorkflowResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.WrkflwStepDefinitionDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.util.HttpRequestUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class WrkflwEngineServiceClient {

	@Value("${WORKFLOW.ENGINE.SERVICE.URL}")
	private String wrkflwEngineBaseUrl;

	@Value("${WORKFLOW.STEP.DETAILS.REST.URL}")
	private String getWrkflwStepDetailsRestURL;
	
	@Value("${WORKFLOW.STEP.EMAIL.DETAILS.REST.URL}")
	private String getWrkflwStepEmailDetailsRestURL;

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	ObjectMapper objectMapper;

	public List<WrkflwStepDefinitionDto> getWrkflwStepDetails(String wrkflwCode) throws ResourceManagementException {
		log.info("Entered into WrkflwEngineServiceClient.getWrkflwStepDetails method:");
		String url = wrkflwEngineBaseUrl + MessageFormat.format(getWrkflwStepDetailsRestURL, wrkflwCode);
		 return getWrkflwStepEmailDetailsCombined(url);
	}
	
	public List<WrkflwStepDefinitionDto> getWrkflwStepEmailDetails(String wrkflwCode, String wrkflwStepDecision, String uiDisplayFlag, long roleId) throws ResourceManagementException {
		log.info("Entered into WrkflwEngineServiceClient.getWrkflwStepEmailDetails method:");
		String url = wrkflwEngineBaseUrl + MessageFormat.format(getWrkflwStepEmailDetailsRestURL, wrkflwCode, wrkflwStepDecision, uiDisplayFlag, roleId);
		 return getWrkflwStepEmailDetailsCombined(url);
	}
	
	public List<WrkflwStepDefinitionDto> getWrkflwStepEmailDetailsCombined(String url) throws ResourceManagementException {
		log.info("Entered into WrkflwEngineServiceClient.getWrkflwStepEmailDetails method:");
		HttpEntity<String> requestEntityObj = new HttpEntity<>(HttpRequestUtil.getDefaultHttpHeaders());
		List<WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsListObj = null;
		try {
			ResponseEntity<WorkflowResponseDto> responseEntityObj = restTemplate.exchange(url, HttpMethod.GET, requestEntityObj,
					new ParameterizedTypeReference<WorkflowResponseDto>() {});
			if (HttpStatus.Series.valueOf(responseEntityObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<WorkflowResponseDto>  workflowResponseDtoObj = ofNullable(responseEntityObj.getBody());
				if(workflowResponseDtoObj.isPresent() && (workflowResponseDtoObj.get().getWorkflowOutput() != null) && (CollectionUtils.isNotEmpty(workflowResponseDtoObj.get().getWorkflowOutput().getDataObjectList())))
						wrkflwStepDfntnDtlsListObj = objectMapper.convertValue(workflowResponseDtoObj.get().getWorkflowOutput().getDataObjectList(), new TypeReference<List<WrkflwStepDefinitionDto>>() { });
			}
		}catch (ResourceAccessException rae) {
			log.error("getWrkflwStepEmailDetails|url:{}|ResourceAccessException:{}", url, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("getWrkflwStepEmailDetails|url:{}|exception:{}", url, hcee);
			throw new ResourceManagementException(hcee);
		}	
		log.info("Just before leaving WrkflwEngineServiceClient.getWrkflwStepEmailDetails method:");
		return wrkflwStepDfntnDtlsListObj ;
	}
	
	
	
	
	
	
	
	
}


