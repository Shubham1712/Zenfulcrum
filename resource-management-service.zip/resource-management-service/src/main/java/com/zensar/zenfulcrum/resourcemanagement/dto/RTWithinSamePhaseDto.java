package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class RTWithinSamePhaseDto implements Serializable{	
	private static final long serialVersionUID = -3681994629204112791L;
	
	private Long userId;
	
	private Long roleId;
	
	private String roleName;
	
	//Commented by Mrunal Marne as it will no longer be used
	//private Date effectiveStartDate;
	
	private Long projectId;
	
	private List<TransferResourceListDto> requirementList;

}
