package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class ProjectBuDto {
	
	Long projectId;
	Long buId;
	String buName;

}
