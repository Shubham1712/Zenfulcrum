package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;

import lombok.Data;

@Data
public class TAssociateProjectAndAllocationDto {

	private Long projectId;
	private Long employeeId;
	private Long workLocationId;
	private Long billableStatusId;
	private String srfNo;
	private Double utilization;
	private Long roleId;
	private Long requirementId;
	private Long skillId;
	private Double stdCost;
	private Date estAllocationEndDate;
	private Date actualAllocationStartDate;
	private Date actualAllocationEndDate;
	private Double baseHours;
	private Double ftePercent;
	private String remarks;
	private Long workflowStatusId;
	private Long statusId;
	private Date createdDate;
	private Long serviceLineId;
}
