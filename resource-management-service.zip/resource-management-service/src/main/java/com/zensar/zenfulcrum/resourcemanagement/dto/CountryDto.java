package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class CountryDto {

	private Long countryId;
	private String countryCode;
	private String countryName;
	
}
