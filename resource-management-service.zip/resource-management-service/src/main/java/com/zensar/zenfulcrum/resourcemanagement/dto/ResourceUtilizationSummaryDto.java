package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class ResourceUtilizationSummaryDto {

	private BigDecimal totalResourceFTE;
	private BigDecimal deliveryResourceAllocationFTE;
	private BigDecimal billableResourceFTE;
	private BigDecimal nonBillableResourceFTE;
	private BigDecimal ebrResourceFTE;

}
