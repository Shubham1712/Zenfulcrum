package com.zensar.zenfulcrum.resourcemanagement.service;

import java.text.ParseException;
import java.util.List;

import javax.validation.Valid;

import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTWithinSamePhaseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

public interface ResourceTransferService {

	public void updateResTransferInSameProject(RTWithinSamePhaseDto rtWithinSamePhaseDto)
			throws ResourceManagementException, ParseException;

	public void saveRTWithinODCAndProjectAndBU(RMApprovalInputDto rtInputDto)
			throws ResourceManagementException, ParseException;

	public void rejectRTWithinODCAndProjectAndBU(List<RMApprovalInputDto> rtInputDtoList) throws ResourceManagementException;

	public ResourceRequirementAndFteDto getAllocatedResourceFTE(long projectId, String transferType)
			throws ResourceManagementException;

	public List<ProjectDto> getProjectfromSameOdc(long userId, long roleId, long targetPojectId)
			throws ResourceManagementException;

	public EmployeeDto getResourceFromIntransitProject(@Valid long targetProjectId, @Valid String empIdOrName)
			throws ResourceManagementException;

	public void approveOrRejectRTApproval(List<RMApprovalInputDto> rtApproveOrRejectDtlsList)
			throws ResourceManagementException;

}
