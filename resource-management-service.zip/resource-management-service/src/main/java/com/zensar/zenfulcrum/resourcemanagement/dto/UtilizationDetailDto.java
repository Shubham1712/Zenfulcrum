package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;

import lombok.Data;

@Data
public class UtilizationDetailDto {

	private Double averageUtilization;
	private List<UtilizationProjectDetails> projectAllocationDetails;
	private List<UtilizationProjectDetails>  poolAllocationDetails;
	
	
}
