package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class MLocationDto {
	
	private Long locationId;
	private String locationName;
	private Long shoreId;
	private Double infraCost;
	private String locationCode;
	private String shoreName;
	private Boolean isLocal;
	private Boolean isLivex;
	private Boolean isPerDiem;
}
