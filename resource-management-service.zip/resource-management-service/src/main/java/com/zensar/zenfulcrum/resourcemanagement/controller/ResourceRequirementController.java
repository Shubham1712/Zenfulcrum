package com.zensar.zenfulcrum.resourcemanagement.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceRequirementService;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementUtil;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Api(tags = "ResourceRequirementController")
@RestController
@Slf4j
@Validated
@RequestMapping(path = "resourcerequirement")
public class ResourceRequirementController {
	
	
	@Autowired
	ResourceRequirementService resourceRequirementService;
	

	/**
	 * get resourcerequirement allocation details for project.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */

	@GetMapping(path = "/allocation")
	public ResponseEntity<RMResponseDto> getRRforAllocation(@Valid @RequestParam long projectId)
			throws ResourceManagementException {
		log.info("Start getRRforAllocation - projectId::{}", projectId);

		RMResponseDto rmResponseDto = new RMResponseDto();
		ResourceRequirementAndFteDto allocatedResourceAndProjectFte = resourceRequirementService
				.getRRforAllocation(projectId);
		if (null != allocatedResourceAndProjectFte) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, allocatedResourceAndProjectFte);
		} else {
			log.info("Exit getRRforAllocation method");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getRRforAllocation");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * get resourcerequirement deallocation details for project.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	
	
	@GetMapping(path = "/deallocation")
	public ResponseEntity<RMResponseDto> getRRforDeallocation(@Valid @RequestParam long projectId ) throws ResourceManagementException {
		log.info("Start getRRforDeallocation - projectId::{}", projectId);

		RMResponseDto rmResponseDto = new RMResponseDto();
		List<ResourceRequirementDto> resourceRequirement = resourceRequirementService.getRRforDeallocation(projectId);

		if (!CollectionUtils.isEmpty(resourceRequirement)) {
			List<Object> objectList = new ArrayList<>(resourceRequirement);
			ResourceManagementUtil.setResourceManagementDtoList(rmResponseDto, objectList);
		} else {
			log.info("Exit getRRforDeallocation method");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getRRforDeallocation");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
	
	/**
	 * get Tranferresourcerequirement  details for project.
	 * 
	 * @param projectId
	 * @return
	 * @throws ResourceManagementException
	 */
	
	@GetMapping(path = "/transfer")
	public ResponseEntity<RMResponseDto> getRRforTransfer(@Valid @RequestParam long projectId) throws ResourceManagementException {
		log.info("Start getRRforTransfer - projectId::{}", projectId);

		RMResponseDto rmResponseDto = new RMResponseDto();
		ResourceRequirementAndFteDto allocatedResourceAndProjectFte = resourceRequirementService.getRRforTransfer(projectId);
		if (null != allocatedResourceAndProjectFte) {
			ResourceManagementUtil.setResourceManagementDto(rmResponseDto, allocatedResourceAndProjectFte);
		} else {
			log.info("Exit getRRforTransfer method");
			return new ResponseEntity<>(rmResponseDto, HttpStatus.NO_CONTENT);
		}
		log.info("End getRRforTransfer");
		return new ResponseEntity<>(rmResponseDto, HttpStatus.OK);
	}
  
	@GetMapping(path = "/getmargins")
	public ResponseEntity<ResourceRequirementAndFteDto> getMargins(@Valid @RequestParam long projectId) throws ResourceManagementException {
		log.info("Start getMargins - projectId::{}", projectId);

	 
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = resourceRequirementService.getMargins(projectId);
		if (resourceRequirementAndFteDto !=null) {
			log.info("Exit getMargins method");
			return new ResponseEntity<>(resourceRequirementAndFteDto, HttpStatus.OK);
		} else {
			log.info("Exit getMargins method");
			return new ResponseEntity<>(resourceRequirementAndFteDto, HttpStatus.NO_CONTENT);
		}
		 
		
	}

}
