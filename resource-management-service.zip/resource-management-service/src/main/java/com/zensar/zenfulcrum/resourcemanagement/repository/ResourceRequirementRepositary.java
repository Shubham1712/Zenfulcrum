package com.zensar.zenfulcrum.resourcemanagement.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.zensar.zenfulcrum.resourcemanagement.model.AllocatedResource;

public interface ResourceRequirementRepositary extends JpaRepository<AllocatedResource, Long>  {

//	commented as requirment_id is not finalize
//	@Query( value ="SELECT SUM(fte_percent)/100 FROM t_allocation_table WHERE requirement_id = :reqId  AND project_id = :projectId  AND status_id = 1" , nativeQuery = true)
//	String getAllocatedResource(@Param("reqId") long reqId , @Param ("projectId") long projectId);
	
	//Added by Mrunal Marne for fetching SO billing hours
	@Query(value="SELECT tsoi.billing_hr FROM zf_projectdefinition.T_SALES_ORDER tso \r\n"
			+ "INNER JOIN zf_projectdefinition.T_SALES_ORDER_INVOICE tsoi ON tso.sales_order_id = tsoi.sales_order_id \r\n"
			+ "WHERE so_name =:projectName ",nativeQuery = true)
	Double getProjectBillingHours(String projectName);
	
	
}