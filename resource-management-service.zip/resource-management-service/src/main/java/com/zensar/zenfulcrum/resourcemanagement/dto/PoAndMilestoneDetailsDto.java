package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class PoAndMilestoneDetailsDto {
	
	private Long puchaseOrderId;
	private String poSowNumber;
	private String poName;	
	private Date poStartDate;
	private Date poEndDate;
	private Long poId;
	private String poCurrencyId;
	private String poValue;
	private String poMargin;
	private String sowReference;
	private Long statusId;
	private List<MileStoneInformationDto> tPurchaseOrderMileStone;

}
