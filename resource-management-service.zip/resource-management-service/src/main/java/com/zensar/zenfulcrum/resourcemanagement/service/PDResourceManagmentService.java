package com.zensar.zenfulcrum.resourcemanagement.service;

import java.util.List;

import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

public interface PDResourceManagmentService {

	public List<TAssociateAllocationDto> getAssociateListByProjectId(Long projectId) throws ResourceManagementException;

	public List<TAssociateAllocationDto> getAssociateList(Long projectId) throws ResourceManagementException;
	
}
