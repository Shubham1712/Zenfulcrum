package com.zensar.zenfulcrum.resourcemanagement.projection;

import java.util.Date;

public interface ProjectDetailsProjection {

	public Long getProjectId();
	public void setProjectId(Long val);
	public Double getProjectUtilization();
	public void setProjectUtilization(Double val);
	public Long getBillableStatusId();
	public void setBillableStatusId(Long val);
	public Date getActualAllocationStartDate();
	public void setActualAllocationStartDate(Date val);
	public Date getActualAllocationEndDate();
	public void setActualAllocationEndDate(Date val);
	public Date getEstAllocationEndDate();
	public void setEstAllocationEndDate(Date val);
	public Long getWorkLocationId();
	public void setWorkLocationId(Long val);
	public Long getAssociateAllocationId();
	public void setAssociateAllocationId(Long val);
	public String getWorkLocationName();
	public void setWorkLocationName(String workLocationName);
}
