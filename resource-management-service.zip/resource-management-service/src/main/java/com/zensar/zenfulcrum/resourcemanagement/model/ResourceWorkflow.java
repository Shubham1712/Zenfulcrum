package com.zensar.zenfulcrum.resourcemanagement.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "T_RESOURCE_WORKFLOW")
public class ResourceWorkflow {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="resource_workflow_id")
	private Long resourceWrkflwId;
	@Column(name="workflow_type_id")
	private Long wrkflwTypeId;
	@Column(name="transaction_id")
	private Long wrkflwTrnsctnId;
	@Column(name="workflow_definition_id")
	private Long wrkflwDefinitionId;
	@Column(name="status_id")
	private Long statusId;
	@Column(name="created_by")
	private Long createdBy;
	@Column(name="last_updated_by")
	private Long lastUpdatedBy;
	@Column(name="created_date")
	private Date createdDate;
	@Column(name="last_updated_date")
	private Date lastUpdatedDate;
	@Column(name="current_user_id")
	private Long currentUserId;
	@Column(name="current_role_id")
	private Long currentRoleId;
	@Column(name="next_user_id")
	private Long nextUserId;
	@Column(name="next_role_id")
	private Long nextRoleId;
	@Column(name="comment")
	private String comment;
	
}
