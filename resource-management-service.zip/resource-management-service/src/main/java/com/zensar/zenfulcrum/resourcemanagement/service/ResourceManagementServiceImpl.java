package com.zensar.zenfulcrum.resourcemanagement.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.HashBasedTable;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.FYIapproverDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueAndDescDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.MLocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.MailDetail;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PoAndMilestoneDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PrimaryUsersDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBuDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApproversDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TransferApproverResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TransferFYIDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.WrkflwStepDefinitionDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.SendMailHelperService;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateProjectMapper;
import com.zensar.zenfulcrum.resourcemanagement.model.ResourceWorkflow;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocationBudget;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateDeAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateExtension;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateProject;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AssociateDeAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AssociateExtensionProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.AssociateAllocationBudgetRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.AssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceRequirementRepositary;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceWorkflowRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateExtensionRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.WrkflwEngineServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.RMBudgetControlUtil;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.SendMailUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class ResourceManagementServiceImpl implements ResourceManagementService {

	@Autowired
	private BAPServiceClient bapServiceClient;

	@Autowired
	ResourceRequirementRepositary resourceRequirementRepository;

	@Autowired
	private AdminServiceClient adminServiceClient;

	@Autowired
	private WrkflwEngineServiceClient wrkflwEngineServiceClient;

	@Autowired
	ResourceWorkflowRepository resourceWorkflowRepository;

	@Autowired
	private SendMailUtil sendMailUtil;

	@Autowired
	TAssociateDeAllocationRepository tAssociateDeallocationRepository;

	@Autowired
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Autowired
	private BudgetControlServiceClient budgetControlServiceClient;

	@Autowired
	private ResourceAllocationServiceImpl resourceAllocationServiceImplObj;

	@Autowired
	AssociateProjectRepository associateProjectRepository;

	@Autowired
	private SendMailHelperService sendMailHelperServiceObj;

	@Autowired
	AssociateAllocationBudgetRepository associateAllocationBudgetRepository;

	@Autowired
	private TAssociateExtensionRepository tAssociateExtensionRepository;
	
	@Autowired
    private ResourceRequirementServiceImpl resourceRequirementServiceImpl;
	
	@Autowired
	TAssociateProjectMapper projectMapper;
	
	@Autowired
	private TAssociateProjectRepository projRepo;
	
	@Autowired
	private ResourceTransferServiceImpl resourceTransferServiceImpl;
	
	//Added by Mrunal Marne for RMG Tagging
	/*@Autowired
	private TAssociateRmgTagRepository associateRmgTagRepository;
	
	@Autowired
	private TAssociateRmgTagMapper tAssociateRmgTagMapper;
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");*/

	@Override
	public List<ProjectDto> getProjectList(long userId, long roleId) throws ResourceManagementException {
		List<ProjectDto> projectList = bapServiceClient.getProjectList(userId, roleId);
		//Added by Mrunal Marne for handling empty project list
		if(Objects.isNull(projectList))
			throw new ResourceManagementException(ResourceManagementConstant.PROJECT_LIST_EMPTY_ERROR);
		Collections.sort(projectList);
		return projectList;
	}

	@Override
	public List<RMApproversDto> getRMApproversList(long projectId, long userId, long roleId, String requestType, Boolean isRequiredDuringRejection)
			throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.getRMApproversList method:");
		String wrkflwCode = setWrkflwCode(requestType, tAssociateAllocationRepository.getRoleName(roleId));
		List<RMApproversDto> sortedRMApproversListObj = new ArrayList<>();
		List<WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsListObj = wrkflwEngineServiceClient
				.getWrkflwStepDetails(wrkflwCode);
		Map<Long, WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsMap = wrkflwStepDfntnDtlsListObj.stream()
				.collect(HashMap::new, (m, v) -> m.put(v.getRoleId(), v), HashMap::putAll);
		if (!CollectionUtils.isEmpty(wrkflwStepDfntnDtlsListObj)) {
			List<Long> roleIdListObj = wrkflwStepDfntnDtlsListObj.stream().map(WrkflwStepDefinitionDto::getRoleId)
					.collect(Collectors.toList());
			List<LookupValueAndDescDto> lookuIdByTypeAndDescrList = adminServiceClient.getLookuIdByTypeAndDescrList(
					ResourceManagementConstant.ROLE_TYPE,
					List.of(ResourceManagementConstant.PROJECT_MANAGER, ResourceManagementConstant.PROGRAM_MANAGER,ResourceManagementConstant.TAG_TEAM));

			Map<String, Long> lookupDescToIdMap = lookuIdByTypeAndDescrList.stream().collect(Collectors
					.toMap(LookupValueAndDescDto::getLookupValueDescr, LookupValueAndDescDto::getLookupValueId));
 
			List<RMApproversDto> rmApproversListObj = new ArrayList<>();
			
			if (lookupDescToIdMap.get(ResourceManagementConstant.PROJECT_MANAGER).equals(roleId)) {
				if(isRequiredDuringRejection) {
					rmApproversListObj = adminServiceClient.getRMApproversListForRejection(roleIdListObj,
							projectId);
				} else {
					roleIdListObj.remove(lookupDescToIdMap.get(ResourceManagementConstant.PROJECT_MANAGER));
					List<Long> userIdListObj = bapServiceClient.getPrimaryOwnersList(projectId);
					if (!CollectionUtils.isEmpty(userIdListObj) && !CollectionUtils.isEmpty(roleIdListObj)) {
						rmApproversListObj = adminServiceClient.getRMApproversList(roleIdListObj,
								userIdListObj);
					}
				}
				if (!CollectionUtils.isEmpty(rmApproversListObj)) {
					sortedRMApproversListObj = sortRMApproversOPData(rmApproversListObj, wrkflwStepDfntnDtlsListObj);
				}
			} else if (lookupDescToIdMap.get(ResourceManagementConstant.PROGRAM_MANAGER).equals(roleId)) {
				
				WrkflwStepDefinitionDto wfDto = wrkflwStepDfntnDtlsMap.get(lookupDescToIdMap.get(ResourceManagementConstant.TAG_TEAM));
				RMApproversDto rmApproversDtoIntrmObj = new RMApproversDto();
				rmApproversDtoIntrmObj.setRoleName(ResourceManagementConstant.TAG_TEAM);
				rmApproversDtoIntrmObj.setRoleId(lookupDescToIdMap.get(ResourceManagementConstant.TAG_TEAM));
				rmApproversDtoIntrmObj.setUserId(97440);
				rmApproversDtoIntrmObj.setStepId(wfDto.getStepId());
				rmApproversDtoIntrmObj.setUserName(ResourceManagementConstant.TAG_TEAM);
				sortedRMApproversListObj.add(rmApproversDtoIntrmObj);
			}

			//roleIdListObj.removeIf(i -> (i == roleId));
		}
		log.info("Just before leaving ResourceManagementServiceImpl.getRMApproversList method:");
		return sortedRMApproversListObj;
	}
	
	/*public List<RMApproversDto> getRMApproversListForRejection(long projectId, long roleId, String requestType)
			throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.getRMApproversList method:");
		String wrkflwCode = setWrkflwCode(requestType, tAssociateAllocationRepository.getRoleName(roleId));
		List<RMApproversDto> sortedRMApproversListObj = new ArrayList<>();
		List<WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsListObj = wrkflwEngineServiceClient
				.getWrkflwStepDetails(wrkflwCode);
		Map<Long, WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsMap = wrkflwStepDfntnDtlsListObj.stream()
				.collect(HashMap::new, (m, v) -> m.put(v.getRoleId(), v), HashMap::putAll);
		if (!CollectionUtils.isEmpty(wrkflwStepDfntnDtlsListObj)) {
			List<Long> roleIdListObj = wrkflwStepDfntnDtlsListObj.stream().map(WrkflwStepDefinitionDto::getRoleId)
					.collect(Collectors.toList());
			List<LookupValueAndDescDto> lookuIdByTypeAndDescrList = adminServiceClient.getLookuIdByTypeAndDescrList(
					ResourceManagementConstant.ROLE_TYPE,
					List.of(ResourceManagementConstant.PROJECT_MANAGER, ResourceManagementConstant.PROGRAM_MANAGER,ResourceManagementConstant.TAG_TEAM));
	
			Map<String, Long> lookupDescToIdMap = lookuIdByTypeAndDescrList.stream().collect(Collectors
					.toMap(LookupValueAndDescDto::getLookupValueDescr, LookupValueAndDescDto::getLookupValueId));
	
			if (lookupDescToIdMap.get(ResourceManagementConstant.PROJECT_MANAGER).equals(roleId)) {
				if (!CollectionUtils.isEmpty(roleIdListObj)) {
					List<RMApproversDto> rmApproversListObj = adminServiceClient.getRMApproversListForRejection(roleIdListObj,
							projectId);
					if (!CollectionUtils.isEmpty(rmApproversListObj)) {
						sortedRMApproversListObj = sortRMApproversOPData(rmApproversListObj, wrkflwStepDfntnDtlsListObj);
					}
				}  
			} else if (lookupDescToIdMap.get(ResourceManagementConstant.PROGRAM_MANAGER).equals(roleId)) {
				
				WrkflwStepDefinitionDto wfDto = wrkflwStepDfntnDtlsMap.get(lookupDescToIdMap.get(ResourceManagementConstant.TAG_TEAM));
				RMApproversDto rmApproversDtoIntrmObj = new RMApproversDto();
				rmApproversDtoIntrmObj.setRoleName(ResourceManagementConstant.TAG_TEAM);
				rmApproversDtoIntrmObj.setRoleId(lookupDescToIdMap.get(ResourceManagementConstant.TAG_TEAM));
				rmApproversDtoIntrmObj.setUserId(97440);
				rmApproversDtoIntrmObj.setStepId(wfDto.getStepId());
				rmApproversDtoIntrmObj.setUserName(ResourceManagementConstant.TAG_TEAM);
				sortedRMApproversListObj.add(rmApproversDtoIntrmObj);
			}
		}
		log.info("Just before leaving ResourceManagementServiceImpl.getRMApproversList method:");
		return sortedRMApproversListObj;
	}*/

	public List<RMApproversDto> sortRMApproversOPData(List<RMApproversDto> rmApproversListObj,
			List<WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsListObj) {
		log.info("Entered into ResourceManagementServiceImpl.sortRMApproversOPData method:");
		List<RMApproversDto> sortedRMApproversListObj = new ArrayList<>();
		Map<Long, WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsMap = wrkflwStepDfntnDtlsListObj.stream()
				.collect(HashMap::new, (m, v) -> m.put(v.getRoleId(), v), HashMap::putAll);
		for (RMApproversDto rmApproversDto : rmApproversListObj) {
			if (wrkflwStepDfntnDtlsMap.containsKey(rmApproversDto.getRoleId())) {
				RMApproversDto rmApproversDtoIntrmObj = new RMApproversDto();
				rmApproversDto.setStepId(wrkflwStepDfntnDtlsMap.get(rmApproversDto.getRoleId()).getStepId());
				rmApproversDtoIntrmObj = rmApproversDto;
				sortedRMApproversListObj.add(rmApproversDtoIntrmObj);
			}
		}
		Long stepIdForTag = tAssociateAllocationRepository.getLookupValueForTag();
		WrkflwStepDefinitionDto wfDto = wrkflwStepDfntnDtlsMap.get(stepIdForTag);
		setTagTeamDetails(sortedRMApproversListObj, wfDto, stepIdForTag);
		Collections.sort(sortedRMApproversListObj, Comparator.comparing(RMApproversDto::getStepId));
		log.info("Just before leaving ResourceManagementServiceImpl.sortRMApproversOPData method:");
		return sortedRMApproversListObj;
	}

	private void setTagTeamDetails(List<RMApproversDto> sortedRMApproversListObj, WrkflwStepDefinitionDto wfDto,
			Long stepIdForTag) {
		RMApproversDto rmApproversDtoIntrmObj = new RMApproversDto();
		rmApproversDtoIntrmObj.setRoleName(ResourceManagementConstant.TAG_TEAM);
		rmApproversDtoIntrmObj.setRoleId(stepIdForTag);
		rmApproversDtoIntrmObj.setUserId(97440);
		rmApproversDtoIntrmObj.setStepId(wfDto.getStepId());
		rmApproversDtoIntrmObj.setUserName(ResourceManagementConstant.TAG_TEAM);
		sortedRMApproversListObj.add(rmApproversDtoIntrmObj);
	}

	@Override
	public void submitRMApproval(List<RMApprovalInputDto> rmApprovalDtlsList) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.submitRMApproval method:");
		for (RMApprovalInputDto rmApprovalDtls : rmApprovalDtlsList) {
			String wrkflwCode = setWrkflwCode(rmApprovalDtls.getRequestType(), rmApprovalDtls.getRoleName());
			List<WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsListObj = wrkflwEngineServiceClient
					.getWrkflwStepDetails(wrkflwCode);
		   removeStepForPgm(rmApprovalDtls, wrkflwStepDfntnDtlsListObj);
		   //Commented by Mrunal Marne
		   //removeStepForTagForCisco(rmApprovalDtls, wrkflwStepDfntnDtlsListObj);
			if (!CollectionUtils.isEmpty(wrkflwStepDfntnDtlsListObj)) {
				List<ResourceWorkflow> resourceWrkflwListObj = new ArrayList<>();
				Map<Long, RMApproversDto> rmSelectedApproversDtlsMap = new HashMap<>();
				//Added by Mrunal Marne for internally calling the approvers list in case of dashboard
				if(rmApprovalDtls.getRmApproversList() == null || rmApprovalDtls.getRmApproversList().isEmpty()) {
					if(rmApprovalDtls.getRequestType().equals("RALLOCATION") || rmApprovalDtls.getRequestType().equals("RDEALLOCATION")) {
						List<RMApproversDto> allocDeallocApproversList = getRMApproversList(rmApprovalDtls.getProjectId(), rmApprovalDtls.getUserId(),
								rmApprovalDtls.getRoleId(), rmApprovalDtls.getRequestType(), false);
						rmApprovalDtls.setRmApproversList(allocDeallocApproversList);
						rmSelectedApproversDtlsMap = rmApprovalDtls.getRmApproversList().stream()
								.collect(HashMap::new, (m, v) -> m.put(v.getRoleId(), v), HashMap::putAll);
					} else {
						TransferApproverResponseDto rmTransferApproversListObj = getRMTransferApproversList
								(rmApprovalDtls.getCurrentProjectId(), rmApprovalDtls.getProjectId(), rmApprovalDtls.getUserId(), rmApprovalDtls.getRoleId(), rmApprovalDtls.getRequestType());
						rmApprovalDtls.setRmApproversList(rmTransferApproversListObj.getRmSourceApproversListObj());
						rmSelectedApproversDtlsMap = rmApprovalDtls.getRmApproversList().stream()
								.collect(HashMap::new, (m, v) -> m.put(v.getRoleId(), v), HashMap::putAll);
						TransferFYIDto sourceTransferFYIDto = new TransferFYIDto();
						sourceTransferFYIDto.setRoleId(rmTransferApproversListObj.getFyiApproverDto().getSourceFYIapproversList().get(0).getRoleId());	
						sourceTransferFYIDto.setUserId(rmTransferApproversListObj.getFyiApproverDto().getSourceFYIapproversList().get(0).getUserId());
						
						if(Objects.nonNull(rmTransferApproversListObj.getFyiApproverDto().getTargetFYIapproversList())) {
							TransferFYIDto targetTransferFYIDto = new TransferFYIDto();
							targetTransferFYIDto.setRoleId(rmTransferApproversListObj.getFyiApproverDto().getTargetFYIapproversList().get(0).getRoleId());	
							targetTransferFYIDto.setUserId(rmTransferApproversListObj.getFyiApproverDto().getTargetFYIapproversList().get(0).getUserId());
							rmApprovalDtls.setTransferFYIList(List.of(sourceTransferFYIDto, targetTransferFYIDto));
						}else {
							//for transfer within same project
							rmApprovalDtls.setTransferFYIList(List.of(sourceTransferFYIDto));
						}
					}
				} else {
					rmSelectedApproversDtlsMap = rmApprovalDtls.getRmApproversList().stream()
					.collect(HashMap::new, (m, v) -> m.put(v.getRoleId(), v), HashMap::putAll);
				}
				//End by Mrunal Marne
				for (WrkflwStepDefinitionDto wrkflwStepDfntnDtls : wrkflwStepDfntnDtlsListObj) {
					long nextUserId = 0;
					long nextRoleId = wrkflwStepDfntnDtls.getNextRoleId();
					if ((nextRoleId > 0) && (rmSelectedApproversDtlsMap.containsKey(nextRoleId))) {
						nextUserId = rmSelectedApproversDtlsMap.get(nextRoleId).getUserId();
					}
					if (rmSelectedApproversDtlsMap.containsKey(wrkflwStepDfntnDtls.getRoleId())) {
						if (rmApprovalDtls.getRoleId() == wrkflwStepDfntnDtls.getRoleId()
								&& wrkflwStepDfntnDtls.getNextRoleId() == rmApprovalDtls.getRoleId()) {
							resourceWrkflwListObj
									.add(createRsrcWrkflwDataObject(rmApprovalDtls.getRoleId(), rmApprovalDtls.getUserId(),
											nextRoleId, nextUserId, wrkflwStepDfntnDtls.getWrkflwDefinitionId(),
											getWrkflwTypeIdByRequestType(rmApprovalDtls.getRequestType()),
											findSubmitStatusIdByRequestType(rmApprovalDtls.getRequestType())));
						} else {
							resourceWrkflwListObj.add(createRsrcWrkflwDataObject(wrkflwStepDfntnDtls.getRoleId(),
									rmSelectedApproversDtlsMap.get(wrkflwStepDfntnDtls.getRoleId()).getUserId(), nextRoleId,
									nextUserId, wrkflwStepDfntnDtls.getWrkflwDefinitionId(),
									getWrkflwTypeIdByRequestType(rmApprovalDtls.getRequestType()), 0));
						}
					} else {
						resourceWrkflwListObj  
								.add(createRsrcWrkflwDataObject(rmApprovalDtls.getRoleId(), rmApprovalDtls.getUserId(),
										nextRoleId, nextUserId, wrkflwStepDfntnDtls.getWrkflwDefinitionId(),
										getWrkflwTypeIdByRequestType(rmApprovalDtls.getRequestType()),
										findSubmitStatusIdByRequestType(rmApprovalDtls.getRequestType())));
					}
				}
				saveResourceWrkflwData(rmApprovalDtls, resourceWrkflwListObj, wrkflwCode);
			}
		}
		log.info("Just before leaving ResourceManagementServiceImpl.submitRMApproval method:");
	}

	public void removeStepForPgm(RMApprovalInputDto rmApprovalDtls,
			List<WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsListObj) throws ResourceManagementException {
		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList = adminServiceClient.getLookuIdByTypeAndDescrList(
					ResourceManagementConstant.ROLE_TYPE,
					List.of(ResourceManagementConstant.PROJECT_MANAGER, ResourceManagementConstant.PROGRAM_MANAGER));
			Map<String, Long> lookupDescToIdMap = lookuIdByTypeAndDescrList.stream().collect(
					Collectors.toMap(LookupValueAndDescDto::getLookupValueDescr, LookupValueAndDescDto::getLookupValueId));
			if ((lookupDescToIdMap.get(ResourceManagementConstant.PROGRAM_MANAGER).equals(rmApprovalDtls.getRoleId()))
					&& ((rmApprovalDtls.getRequestType().equals(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE))
							|| (rmApprovalDtls.getRequestType()
									.equals(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE)))) {
				for (WrkflwStepDefinitionDto wrkflw : wrkflwStepDfntnDtlsListObj) {
					if (lookupDescToIdMap.get(ResourceManagementConstant.PROJECT_MANAGER).equals(wrkflw.getRoleId())) {
						wrkflwStepDfntnDtlsListObj.remove(wrkflw);
						break;
					}
				}
			}
	}
	
	public void removeStepForTagForCisco(RMApprovalInputDto rmApprovalDtls,
			List<WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsListObj) throws ResourceManagementException {
		ProjectBuDto buForProject = adminServiceClient.getBuForProject(rmApprovalDtls.getProjectId());
		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList = adminServiceClient.getLookuIdByTypeAndDescrList(
					ResourceManagementConstant.ROLE_TYPE,
					List.of(ResourceManagementConstant.PROJECT_MANAGER, ResourceManagementConstant.PROGRAM_MANAGER, ResourceManagementConstant.TAG_TEAM));
			Map<String, Long> lookupDescToIdMap = lookuIdByTypeAndDescrList.stream().collect(
					Collectors.toMap(LookupValueAndDescDto::getLookupValueDescr, LookupValueAndDescDto::getLookupValueId));
			if (buForProject.getBuName().equalsIgnoreCase("Cisco") && ((rmApprovalDtls.getRequestType().equals(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE)))) {
				for (WrkflwStepDefinitionDto wrkflw : wrkflwStepDfntnDtlsListObj) {
					if(lookupDescToIdMap.get(ResourceManagementConstant.PROGRAM_MANAGER).equals(wrkflw.getRoleId())) {
						wrkflw.setNextRoleId(0L);
					}
					if (lookupDescToIdMap.get(ResourceManagementConstant.TAG_TEAM).equals(wrkflw.getRoleId())) {
						wrkflwStepDfntnDtlsListObj.remove(wrkflw);
						break;
					}
				}
			}
	}

	public long getWrkflwTypeIdByRequestType(String requestType) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.getWrkflwTypeIdByRequestType method:");
		String subModule = null;
		if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE)) {
			subModule = ResourceManagementConstant.RESOURCE_ALLOCATION;
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE)) {
			subModule = ResourceManagementConstant.RESOURCE_DEALLOCATION;
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)) {
			subModule = ResourceManagementConstant.RESOURCE_EXTENSION;
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
			subModule = ResourceManagementConstant.RESOURCE_TRANSFER;
		}
		ModuleStatusDto moduleDtlsDto = adminServiceClient
				.getModuleDetails(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModule);
		log.info("Just before leaving ResourceManagementServiceImpl.getWrkflwTypeIdByRequestType method:");
		return moduleDtlsDto.getModuleId();
	}

	public long findSubmitStatusIdByRequestType(String requestType) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.findStatusIdByRequestType method:");
		long statusId = 0;
		if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE)) {
			statusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
					ResourceManagementConstant.SUBMITTED);
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE)) {
			statusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
					ResourceManagementConstant.SUBMITTED);
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
			statusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_TRANSFER,
					ResourceManagementConstant.SUBMITTED);
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)) {
			statusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION,
					ResourceManagementConstant.SUBMITTED);
		}
		log.info("Just before leaving ResourceManagementServiceImpl.findStatusIdByRequestType method:");
		return statusId;
	}

	public long getModuleStatusId(String subModuleName, String actionName) throws ResourceManagementException {
		ModuleStatusDto moduleStatusDto = adminServiceClient
				.getModuleStatus(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModuleName, actionName);
		if (moduleStatusDto != null)
			return moduleStatusDto.getModuleStatusId();
		else
			return 0;
	}

	public Map<String, ModuleStatusDto> getModuleStatusDtlsMap(String actions, String subModulenames)
			throws ResourceManagementException {
		List<String> actionList = Arrays.asList(actions.split(","));
		List<String> subModuleList = Arrays.asList(subModulenames.split(","));
		List<ModuleStatusDto> moduleStatusList = adminServiceClient
				.getModuleStatusList(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModuleList, actionList);
		return moduleStatusList.stream().collect(HashMap::new, (m, v) -> m.put(v.getAction(), v), HashMap::putAll);
	}

	public List<ModuleStatusDto> getModuleStatusDtlsList(String actions, String subModulenames)
			throws ResourceManagementException {
		List<String> actionList = Arrays.asList(actions.split(","));
		List<String> subModuleList = Arrays.asList(subModulenames.split(","));
		return adminServiceClient.getModuleStatusList(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModuleList,
				actionList);
	}

	public long getModuleStatusId(List<ModuleStatusDto> moduleStatusDtlsList, String subModuleName, String actionName)
			throws ResourceManagementException {
		for (ModuleStatusDto moduleStatusDto : moduleStatusDtlsList) {
			if (moduleStatusDto.getSubModule().equalsIgnoreCase(subModuleName)
					&& moduleStatusDto.getAction().equalsIgnoreCase(actionName))
				return moduleStatusDto.getModuleStatusId();
		}
		return 0;
	}

	public ResourceWorkflow createRsrcWrkflwDataObject(long roleId, long userId, long nextRoleId, long nextUserId,
			long wrkflwDefinitionId, long wrkflwTypeId, long statusId) {
		log.info("Entered into ResourceManagementServiceImpl.createRsrcWrkflwDataObject method:");
		ResourceWorkflow resourceWrkflwObj = new ResourceWorkflow();
		resourceWrkflwObj.setCurrentRoleId(roleId);
		resourceWrkflwObj.setCurrentUserId(userId);
		resourceWrkflwObj.setNextRoleId(nextRoleId);
		resourceWrkflwObj.setNextUserId(nextUserId);
		resourceWrkflwObj.setWrkflwDefinitionId(wrkflwDefinitionId);
		resourceWrkflwObj.setWrkflwTypeId(wrkflwTypeId);
		resourceWrkflwObj.setStatusId(statusId);
		log.info("Just before leaving ResourceManagementServiceImpl.createRsrcWrkflwDataObject method:");
		return resourceWrkflwObj;
	}

	public ResourceWorkflow createRsrcWrkflwDataObject(ResourceWorkflow resourceWrkflwObj, long transcId,
			RMApprovalInputDto rmApprovalDtls, String methodType) {
		log.info("Entered into ResourceManagementServiceImpl.createRsrcWrkflwDataObject method:");
		ResourceWorkflow resourceWrkflwIntrmObj = new ResourceWorkflow();
		resourceWrkflwIntrmObj.setCurrentRoleId(resourceWrkflwObj.getCurrentRoleId());
		resourceWrkflwIntrmObj.setCurrentUserId(resourceWrkflwObj.getCurrentUserId());
		resourceWrkflwIntrmObj.setNextRoleId(resourceWrkflwObj.getNextRoleId());
		resourceWrkflwIntrmObj.setNextUserId(resourceWrkflwObj.getNextUserId());
		resourceWrkflwIntrmObj.setWrkflwTypeId(resourceWrkflwObj.getWrkflwTypeId());
		resourceWrkflwIntrmObj.setStatusId(resourceWrkflwObj.getStatusId());
		resourceWrkflwIntrmObj.setWrkflwDefinitionId(resourceWrkflwObj.getWrkflwDefinitionId());
		resourceWrkflwIntrmObj.setWrkflwTrnsctnId(transcId);
		resourceWrkflwIntrmObj.setCreatedBy(rmApprovalDtls.getUserId());
		resourceWrkflwIntrmObj.setCreatedDate(new Date(System.currentTimeMillis()));
		if (methodType.equalsIgnoreCase("SUBMISSION")) {
			if (resourceWrkflwObj.getCurrentRoleId() == rmApprovalDtls.getRoleId()
					&& resourceWrkflwObj.getStatusId() > 0L) {
				resourceWrkflwIntrmObj.setLastUpdatedBy(rmApprovalDtls.getUserId());
				resourceWrkflwIntrmObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
				resourceWrkflwIntrmObj.setComment("OK");

			}
		} else if (methodType.equalsIgnoreCase("APPROVAL")) {
			resourceWrkflwIntrmObj.setLastUpdatedBy(rmApprovalDtls.getUserId());
			resourceWrkflwIntrmObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
			resourceWrkflwIntrmObj.setComment(resourceWrkflwObj.getComment());
		}
		log.info("Just before leaving ResourceManagementServiceImpl.createRsrcWrkflwDataObject method:");
		return resourceWrkflwIntrmObj;
	}

	public void saveResourceWrkflwData(RMApprovalInputDto rmApprovalDtls, List<ResourceWorkflow> resourceWrkflwListObj,
			String wrkflwCode) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.saveResourceWrkflwData method:");
		List<Long> empIdListObj = new ArrayList<>();
		HashBasedTable<String, String, Long> newTable = getallWorkflowStatus();
        if (rmApprovalDtls.getRequestType().equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE)
				|| rmApprovalDtls.getRequestType()
						.equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
			empIdListObj = rmApprovalDtls.getEmployeeIdList();
			Long wrkflwStatusAllocationSubmit = newTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
					ResourceManagementConstant.SUBMITTED);
			List<Long> reqIds = rmApprovalDtls.getRequirmentList();
			Long statusId = newTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
					ResourceManagementConstant.ACTIVATE);
			List<Long> workflowStatusIdforSaved = new ArrayList<>();
			Long allocSaved = newTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
					ResourceManagementConstant.SAVED);
			Long transferSaved = newTable.get(ResourceManagementConstant.RESOURCE_TRANSFER,
					ResourceManagementConstant.SAVED);
			workflowStatusIdforSaved.add(transferSaved);
			workflowStatusIdforSaved.add(allocSaved);
		   List<TAssociateAllocation> rAllocationDtlsListObj = tAssociateAllocationRepository
					.getRAllocationDetailsList(rmApprovalDtls.getProjectId(), statusId, empIdListObj, reqIds,workflowStatusIdforSaved);
			if (CollectionUtils.isNotEmpty(rAllocationDtlsListObj)) {
				for (TAssociateAllocation tAssociateAllocationObj : rAllocationDtlsListObj) {
					for (ResourceWorkflow resourceWrkflwObj : resourceWrkflwListObj) {
						resourceWorkflowRepository.save(createRsrcWrkflwDataObject(resourceWrkflwObj,
								tAssociateAllocationObj.getAssociateAllocationId(), rmApprovalDtls,
								ResourceManagementConstant.SUBMISSION_CONSTANT));
					}

				}
				List<Long> allocationTranscIdList = rAllocationDtlsListObj.stream()
						.map(TAssociateAllocation::getAssociateAllocationId).collect(Collectors.toList());
				if (wrkflwCode.equals("RMA")) {
					tAssociateAllocationRepository.updateWorkflowStatus(allocationTranscIdList,
							wrkflwStatusAllocationSubmit);
				} else if (wrkflwCode.equals("RMT") || wrkflwCode.equals("RMTPG")) {

					tAssociateAllocationRepository.updateWorkflowStatus(allocationTranscIdList, getModuleStatusId(
							ResourceManagementConstant.RESOURCE_TRANSFER, ResourceManagementConstant.SUBMITTED));
				}
				sendMailHelperServiceObj.sendEmailForSubmissionConfirmation(rmApprovalDtls, wrkflwCode);
				sendMailHelperServiceObj.sendEmailForSubmitApprovalPending(rmApprovalDtls, wrkflwCode,
						rAllocationDtlsListObj.get(0).getAssociateAllocationId());
			}
		} else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE)) {
			String actionsStr = ResourceManagementConstant.DEACTIVATE + "," + ResourceManagementConstant.SUBMITTED + ","
					+ ResourceManagementConstant.ACTIVATE;
			String subModuleNames = ResourceManagementConstant.RESOURCE_ALLOCATION + ","
					+ ResourceManagementConstant.RESOURCE_DEALLOCATION;
			List<ModuleStatusDto> moduleStatusDtlsList = getModuleStatusDtlsList(actionsStr, subModuleNames);
			List<Long> deAllocationTranscIdList = new ArrayList<>();
			for (ResourceRequirementDto resourceRequirementDtls : rmApprovalDtls.getResourceRequirementList()) {
				empIdListObj = resourceRequirementDtls.getEmployeeIdList();
			//	HashBasedTable<String, String, Long> newTable = getallWorkflowStatus();
                List<TAssociateDeAllocation> rDeAllocationDtlsListObj = tAssociateDeallocationRepository
						.getRDeAllocationDetails(rmApprovalDtls.getProjectId(),
								newTable.get(ResourceManagementConstant.RESOURCE_DEALLOCATION,
										ResourceManagementConstant.DEACTIVATE),
								empIdListObj, resourceRequirementDtls.getReqId(),
								newTable.get(ResourceManagementConstant.RESOURCE_ALLOCATION,
										ResourceManagementConstant.ACTIVATE));
				if (CollectionUtils.isNotEmpty(rDeAllocationDtlsListObj)) {
					for (TAssociateDeAllocation tAssociateDeAllocationObj : rDeAllocationDtlsListObj) {
						for (ResourceWorkflow resourceWrkflwObj : resourceWrkflwListObj) {
							resourceWorkflowRepository.save(createRsrcWrkflwDataObject(resourceWrkflwObj,
									tAssociateDeAllocationObj.getAssociateDeAllocationId(), rmApprovalDtls,
									ResourceManagementConstant.SUBMISSION_CONSTANT));
						}
					}
					deAllocationTranscIdList.addAll(rDeAllocationDtlsListObj.stream()
							.map(TAssociateDeAllocation::getAssociateDeAllocationId).collect(Collectors.toList()));
				}
			}

			sendMailHelperServiceObj.sendEmailForSubmissionConfirmation(rmApprovalDtls, wrkflwCode);
			sendMailHelperServiceObj.sendEmailForSubmitApprovalPending(rmApprovalDtls, wrkflwCode,
					((CollectionUtils.isNotEmpty(deAllocationTranscIdList)) ? deAllocationTranscIdList.get(0) : 0));
			tAssociateDeallocationRepository.updateWorkflowStatus(deAllocationTranscIdList, getModuleStatusId(
					ResourceManagementConstant.RESOURCE_DEALLOCATION, ResourceManagementConstant.SUBMITTED));

		} else if (rmApprovalDtls.getRequestType()
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)
				|| rmApprovalDtls.getRequestType().equalsIgnoreCase(
						ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD)) {

			for (TAssociateExtension tAssociateAllocationObj : rmApprovalDtls.getTAssociateExtensionList()) {
				for (ResourceWorkflow resourceWrkflwObj : resourceWrkflwListObj) {
					resourceWorkflowRepository.save(createRsrcWrkflwDataObject(resourceWrkflwObj,
							tAssociateAllocationObj.getAssociateExtensionId(), rmApprovalDtls,
							ResourceManagementConstant.SUBMISSION_CONSTANT));
				}
			}
			sendMailHelperServiceObj.sendEmailForSubmissionConfirmation(rmApprovalDtls, wrkflwCode);
			sendMailHelperServiceObj.sendEmailForSubmitApprovalPending(rmApprovalDtls, wrkflwCode,
					rmApprovalDtls.getTAssociateExtensionList().get(0).getAssociateExtensionId());

		}

		log.info("Just before leaving ResourceManagementServiceImpl.saveResourceWrkflwData method:");
	}

	public String setWrkflwCode(String requestType, String roleName) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.setWrkflwCode method:");
		String subModue = null;
		if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE)) {
			subModue = ResourceManagementConstant.RESOURCE_ALLOCATION;
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE)) {
			subModue = ResourceManagementConstant.RESOURCE_DEALLOCATION;
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)) {
			subModue = ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE;
		} else if (requestType.equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE)) {
			subModue = ResourceManagementConstant.RESOURCE_TRANSFER;
		} else if (requestType
				.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD)) {
			subModue = ResourceManagementConstant.RESOURCE_EXTENSION_LOCKINGPERIOD;
		}
		if (subModue != null) {
			if(subModue.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)) {
				return ResourceManagementConstant.NON_LOCKING_EXTENSION;
			} else if(subModue.equalsIgnoreCase(ResourceManagementConstant.RESOURCE_TRANSFER) && roleName.equalsIgnoreCase(ResourceManagementConstant.PROGRAM_MANAGER)){
				return ResourceManagementConstant.RESOURCE_TRANSFER_PGM;
			} else {
			ModuleStatusDto moduleDtlsDto = adminServiceClient
					.getModuleDetails(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModue);
			log.info("Just before leaving ResourceManagementServiceImpl.setWrkflwCode method:");
			return moduleDtlsDto.getModuleCode();
			}
		} else {
			throw new ResourceManagementException(ResourceManagementConstant.INVALID_REQUEST_TYPE);
		}
	}

	@Override
	@Transactional
	public void approveOrRejectRMApproval(List<RMApprovalInputDto> rmApproveOrRejectDtlsList)
			throws ResourceManagementException, ParseException {
		log.info("Entered into ResourceManagementServiceImpl.approveOrRejectRMApproval method:");
		List<Long> statusIdList = new ArrayList<>();
		statusIdList.add(0L);
		for (RMApprovalInputDto rmApproveOrRejectDtls : rmApproveOrRejectDtlsList) {
			if ((rmApproveOrRejectDtls.getRequestType().equals(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE)
					|| rmApproveOrRejectDtls.getRequestType()
							.equals(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE))
					&& (rmApproveOrRejectDtls.getApproverAction().equals(ResourceManagementConstant.APPROVED_ACTION)
							|| rmApproveOrRejectDtls.getApproverAction()
									.equals(ResourceManagementConstant.REJECTED_ACTION))) {
				if (rmApproveOrRejectDtls.getRequestType()
						.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE)) {
					List<TAssociateAllocation> tAllocationDtlsListObj = tAssociateAllocationRepository
							.getRAllocationDetails(rmApproveOrRejectDtls.getProjectId(),
									getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
											ResourceManagementConstant.ACTIVATE),
									rmApproveOrRejectDtls.getEmployeeIdList(),
									rmApproveOrRejectDtls.getRequirementId(),getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
											ResourceManagementConstant.SUBMITTED));
					if (CollectionUtils.isNotEmpty(tAllocationDtlsListObj)) {
						if (rmApproveOrRejectDtls.getApproverAction()
								.equalsIgnoreCase(ResourceManagementConstant.APPROVED_ACTION))
							approveRMApprovalReqForAlloc(tAllocationDtlsListObj, rmApproveOrRejectDtls, statusIdList);
						else
							rejectRMApprovalReqForAlloc(tAllocationDtlsListObj, rmApproveOrRejectDtls, statusIdList);
					}
				} else if (rmApproveOrRejectDtls.getRequestType()
						.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE)) {
					List<AssociateDeAllocationProjection> tDeAllocationDtlsListObj = tAssociateDeallocationRepository
							.getRDeAllocationRequiredDetails(rmApproveOrRejectDtls.getProjectId(),
									getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
											ResourceManagementConstant.DEACTIVATE),
									rmApproveOrRejectDtls.getEmployeeIdList(), rmApproveOrRejectDtls.getRequirementId(),
									getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
											ResourceManagementConstant.ACTIVATE));
					if (CollectionUtils.isNotEmpty(tDeAllocationDtlsListObj)) {
						if (rmApproveOrRejectDtls.getApproverAction()
								.equalsIgnoreCase(ResourceManagementConstant.APPROVED_ACTION))
							approveRMApprovalReqForDeAlloc(tDeAllocationDtlsListObj, rmApproveOrRejectDtls,
									statusIdList);
						else
							rejectRMApprovalReqForDeAlloc(tDeAllocationDtlsListObj, rmApproveOrRejectDtls,
									statusIdList);
					}
				}
			} else {
				throw new ResourceManagementException(ResourceManagementConstant.INVALID_REQUEST_TYPE);
			}
		}
		log.info("Just before leaving ResourceManagementServiceImpl.approveOrRejectRMApproval method:");
	}

	public void approveRMApprovalReqForAlloc(List<TAssociateAllocation> rAllocationDtlsListObj,
			RMApprovalInputDto rmApprovalDtls, List<Long> statusIdList) throws ResourceManagementException, ParseException {
		log.info("Entered into ResourceManagementServiceImpl.approveRMApprovalReqForAlloc method:");
		ResourceWorkflow rsrcWrkflwObj = null;
		String wrkflwCode = setWrkflwCode(rmApprovalDtls.getRequestType(), rmApprovalDtls.getRoleName());
		long allocApprovedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.APPROVED);
		long allocActivateStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
                ResourceManagementConstant.ACTIVATE);
		for (TAssociateAllocation tAssociateAllocationObj : rAllocationDtlsListObj) {
			rsrcWrkflwObj = resourceWorkflowRepository.getRowDataOfDefaultStatus(
					tAssociateAllocationObj.getAssociateAllocationId(), statusIdList, rmApprovalDtls.getUserId(),
					rmApprovalDtls.getRoleId());
			if (rsrcWrkflwObj != null && rsrcWrkflwObj.getResourceWrkflwId() > 0) {
				rsrcWrkflwObj.setStatusId(allocApprovedStatusId);
				rsrcWrkflwObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
				rsrcWrkflwObj.setLastUpdatedBy(rmApprovalDtls.getUserId());
				rsrcWrkflwObj.setComment(rmApprovalDtls.getApproverComments());
				resourceWorkflowRepository.save(rsrcWrkflwObj);
			} else {
				rsrcWrkflwObj = resourceWorkflowRepository.getRowData(
						tAssociateAllocationObj.getAssociateAllocationId(), rmApprovalDtls.getUserId(),
						rmApprovalDtls.getRoleId());
				ResourceWorkflow createRsrcWrkflwDataObject = createRsrcWrkflwDataObject(rsrcWrkflwObj,
						tAssociateAllocationObj.getAssociateAllocationId(), rmApprovalDtls,
						ResourceManagementConstant.APPROVAL_CONSTANT);
				createRsrcWrkflwDataObject.setStatusId(allocApprovedStatusId);
				createRsrcWrkflwDataObject.setComment(rmApprovalDtls.getApproverComments());
				resourceWorkflowRepository.save(createRsrcWrkflwDataObject);
			}
		}
		if (rsrcWrkflwObj != null) {
			long nextUsrId = rsrcWrkflwObj.getNextUserId();
			long nextRoleId = rsrcWrkflwObj.getNextRoleId();
			if (nextUsrId > 0 && nextRoleId > 0) {
				log.info("Approval process still exist:");

				sendMailHelperServiceObj.sendEmailForApprovalConfirmation(rmApprovalDtls, wrkflwCode);
				sendMailHelperServiceObj.sendEmailForApproveOrRejectionPending(rmApprovalDtls, wrkflwCode,
						rAllocationDtlsListObj.get(0).getAssociateAllocationId());

			} else {
				log.info("Current user is final  approver, Approval process completed:");
				List<Long> allocationTranscIdList = rAllocationDtlsListObj.stream()
						.map(TAssociateAllocation::getAssociateAllocationId).collect(Collectors.toList());
			     // FOR POOL ALLOCATION -- BY Akshay T
				log.info("POOL ALLOC STARTED");
				List<Long> empIdsList = rmApprovalDtls.getEmployeeIdList();
				Map<String, Long> lookupMap = resourceRequirementServiceImpl.getLookupValue();
				Long billableStatusID = lookupMap.get(ResourceManagementConstant.Billable_Pool);
				List<AllocatedResourceProjection> poolProjectionList = tAssociateAllocationRepository
						.getProjectionForPool(empIdsList, allocActivateStatusId, allocApprovedStatusId,
								billableStatusID);
				Long userId = rmApprovalDtls.getUserId();
				List<TAssociateProject> tAssociateProjectsStreamedList = rAllocationDtlsListObj.stream()
						.map(TAssociateAllocation::getTAssociateProject).collect(Collectors.toList());
               updatenewPoolrecord(tAssociateProjectsStreamedList, poolProjectionList, allocApprovedStatusId,
						allocActivateStatusId,userId);
				log.info("POOL ALLOC ENDS");
                // POOL ALLOC ENDS
                tAssociateAllocationRepository.updateWorkflowStatus(allocationTranscIdList, allocApprovedStatusId);
				tAssociateAllocationRepository.deactivateSrfStatusBySrfId(allocationTranscIdList);
				tAssociateAllocationRepository.updateffectiveDate(allocationTranscIdList);
				sendMailHelperServiceObj.sendEmailForFinalApprovalConfirmation(rmApprovalDtls, wrkflwCode,
					rAllocationDtlsListObj.get(0).getAssociateAllocationId());
				
				// started by devAk
				List<Long> empIds=rmApprovalDtls.getEmployeeIdList();
				for(Long empId:empIds) {
					//need to add SA related logic
     				Boolean notSAEmployee=adminServiceClient.saStaffCheck(empId);
					if(!notSAEmployee) {
						rmApprovalDtls.setEmployeeIdList(List.of(empId));
						sendMailHelperServiceObj.sendEmailForAssociateFinalConfirmationMail(rmApprovalDtls, wrkflwCode);
						}else {
							log.info("In ResourceManagementServiceImpl.approveRMApprovalReqForAlloc method SA empId: "+empId);
						}
					
					}
				//ended
			}
		}
		log.info("Just before leaving ResourceManagementServiceImpl.approveRMApprovalReqForAlloc method:");
	}
	
	public void updatenewPoolrecord(List<TAssociateProject> tAssociateProjectsStreamedList,
			List<AllocatedResourceProjection> poolProjectionList,Long allocApprovedStatusId,Long allocActivateStatusId,Long userId) throws ResourceManagementException, ParseException {
		Map<Long, TAssociateProject> tAssociateProjectsMap = tAssociateProjectsStreamedList.stream()
				.collect(HashMap::new, (m, v) -> m.put(v.getEmployeeId(), v), HashMap::putAll);
		long statusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.DEACTIVATE);
		
		for (AllocatedResourceProjection poolAlloc : poolProjectionList) {
			double ftePercent = poolAlloc.getFtePercent();
			TAssociateProject tAssociateProject = tAssociateProjectsMap.get(poolAlloc.getEmployeeId());
			double allocFtePercent = tAssociateProject.getTAssociateAllocation().getFtePercent();
			Date allocStartDate = tAssociateProject.getTAssociateAllocation().getActualAllocationStartDate();
			Long associateAllocId = poolAlloc.getAssociateAllocationId();
			Long associateProjectId = poolAlloc.getAssociateProjectId();
			LocalDateTime poolEndDate = allocStartDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime()
					.minusDays(1);
			Calendar cal1 = Calendar.getInstance();
			Calendar cal2 = Calendar.getInstance();
			cal1.setTime(allocStartDate);
			cal2.setTime(new Date(System.currentTimeMillis()));
			boolean sameDay = cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
					&& cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);

			SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
			Date d1 = sdformat.parse(sdformat.format(allocStartDate));
			Date d2 = sdformat.parse(sdformat.format(new Date(System.currentTimeMillis())));
			if (sameDay) {
				if (ftePercent != allocFtePercent) {
					Double newftePercent = ftePercent - allocFtePercent;
					TAssociateProject assoProj = projRepo.findByAssociateProjectId(associateProjectId);
					TAssociateAllocation allocObj = tAssociateAllocationRepository.getAssAllocById(associateAllocId);
					if (assoProj != null && allocObj != null) {
						createAssocProjObj(assoProj, allocObj, allocApprovedStatusId, allocActivateStatusId,
								newftePercent, allocStartDate,userId);
					}
				}
				tAssociateAllocationRepository.deactivateFullRecordForPool(statusId, associateAllocId,
						associateProjectId, poolEndDate,userId);
				if(ftePercent == allocFtePercent)
				{	
				tAssociateAllocationRepository.deactivateFullRecordForPoolInTassProj(statusId, associateProjectId,
						poolEndDate);
				}

			} else if (d1.after(d2)) {
				long statusIdForDeallocApproved = getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.APPROVED);
				if (ftePercent != allocFtePercent) {
					Double newftePercent = ftePercent - allocFtePercent;
					TAssociateProject assoProj = projRepo.findByAssociateProjectId(associateProjectId);
					TAssociateAllocation allocObj = tAssociateAllocationRepository.getAssAllocById(associateAllocId);
					if (assoProj != null && allocObj != null) {
						createAssocProjObj(assoProj, allocObj, allocApprovedStatusId, allocActivateStatusId,
								newftePercent, allocStartDate,userId);
					}
				}
				tAssociateAllocationRepository.deactivatePoolRecordForTAssocAlloc(statusIdForDeallocApproved,
						associateAllocId, associateProjectId, poolEndDate,userId);
			}
		}
	}	
	

	private void createAssocProjObj(TAssociateProject assoProj, TAssociateAllocation allocObj,
			Long allocApprovedStatusId, Long allocActivateStatusId,Double newftePercent,Date allocStartDate,Long userId) {
		
		/*
		 * TAssociateProject tassProj = new TAssociateProject();
		 * tassProj.setCreatedDate(new Date());
		 * tassProj.setEmployeeId(assoProj.getEmployeeId());
		 * tassProj.setEffectiveStartDate(allocStartDate);
		 * tassProj.setIsPrimaryProject(assoProj.getIsPrimaryProject());
		 * tassProj.setStatusId(allocActivateStatusId);
		 * tassProj.setEffectiveEndDate(assoProj.getEffectiveEndDate());
		 * tassProj.setSrfId(assoProj.getSrfId());
		 * tassProj.setSupervisorId(assoProj.getSupervisorId());
		 * tassProj.setProjectId(assoProj.getProjectId());
		 * tassProj.setLastUpdatedBy(assoProj.getLastUpdatedBy());
		 * tassProj.setLastUpdatedDate(new Date());
		 */
     	TAssociateAllocation allocObject = new TAssociateAllocation();
		allocObject.setActualAllocationEndDate(allocObj.getActualAllocationEndDate());
		allocObject.setBillableStatusId(allocObj.getBillableStatusId());
		allocObject.setStatusId(allocActivateStatusId);
		allocObject.setBillableStatusId(allocObj.getBillableStatusId());
		allocObject.setFtePercent(newftePercent);
		allocObject.setWorkflowStatusId(allocApprovedStatusId);
		allocObject.setEffectiveStartDate(allocStartDate);
		allocObject.setActualAllocationStartDate(allocStartDate);
		allocObject.setEffectiveEndDate(allocObj.getEffectiveEndDate());
		allocObject.setEstAllocationEndDate(allocObj.getEstAllocationEndDate());
		allocObject.setCreatedDate(new Date());
		allocObject.setLastUpdatedDate(new Date());
		allocObject.setRequirementId(allocObj.getRequirementId());
		allocObject.setRoleId(allocObj.getRoleId());
		allocObject.setAllocationTypeId(allocObj.getAllocationTypeId());
		allocObject.setSupervisorId(allocObj.getSupervisorId());
		allocObject.setServiceLineId(allocObj.getServiceLineId());
		allocObject.setWorkLocationId(allocObj.getWorkLocationId());
		allocObject.setTAssociateProject(assoProj);
		assoProj.setTAssociateAllocation(allocObject);
		allocObject.setLastUpdatedBy(userId);
		tAssociateAllocationRepository.save(allocObject);
     //   projRepo.save(assoProj);
		
	}

	public void rejectRMApprovalReqForAlloc(List<TAssociateAllocation> tAllocationDtlsListObj,
			RMApprovalInputDto rmApprovalRejectionDtls, List<Long> statusIdList) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.rejectRMApprovalReqForAlloc method:");
		String wrkflwCode = setWrkflwCode(rmApprovalRejectionDtls.getRequestType(), rmApprovalRejectionDtls.getRoleName());
		ResourceWorkflow rsrcWrkflwPrevObj = resourceWorkflowRepository.getPreviousRowData(
				tAllocationDtlsListObj.get(0).getAssociateAllocationId(), rmApprovalRejectionDtls.getUserId(),
				rmApprovalRejectionDtls.getRoleId());
		long allocRejectedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.REJECTED);
		for (TAssociateAllocation tAssociateAllocationObj : tAllocationDtlsListObj) {
			ResourceWorkflow rsrcWrkflwCrrntObj = resourceWorkflowRepository.getRowDataOfDefaultStatus(
					tAssociateAllocationObj.getAssociateAllocationId(), statusIdList,
					rmApprovalRejectionDtls.getUserId(), rmApprovalRejectionDtls.getRoleId());
			if (rsrcWrkflwCrrntObj != null && rsrcWrkflwCrrntObj.getResourceWrkflwId() > 0) {
				rsrcWrkflwCrrntObj.setStatusId(allocRejectedStatusId);
				rsrcWrkflwCrrntObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
				rsrcWrkflwCrrntObj.setLastUpdatedBy(rmApprovalRejectionDtls.getUserId());
				rsrcWrkflwCrrntObj.setComment(rmApprovalRejectionDtls.getApproverComments());
				resourceWorkflowRepository.save(rsrcWrkflwCrrntObj);
			}
			//Commented by Mrunal Marne for adding next approvers record when request is rejected
			/*else {
				rsrcWrkflwCrrntObj = resourceWorkflowRepository.getRowData(
						tAssociateAllocationObj.getAssociateAllocationId(), rmApprovalRejectionDtls.getUserId(),
						rmApprovalRejectionDtls.getRoleId());
				ResourceWorkflow createRsrcWrkflwDataObject = createRsrcWrkflwDataObject(rsrcWrkflwCrrntObj,
						tAssociateAllocationObj.getAssociateAllocationId(), rmApprovalRejectionDtls,
						ResourceManagementConstant.APPROVAL_CONSTANT);
				createRsrcWrkflwDataObject.setStatusId(allocRejectedStatusId);
				createRsrcWrkflwDataObject.setComment(rmApprovalRejectionDtls.getApproverComments());
				resourceWorkflowRepository.save(createRsrcWrkflwDataObject);
			}*/	
			//Added by Mrunal Marne for adding next approvers record when request is rejected
			Long primaryPMLookUpValueId = adminServiceClient.getLookuIdByTypeAndDescr(ResourceManagementConstant.ROLE_TYPE, ResourceManagementConstant.PROJECT_MANAGER);
			Long primaryPGMLookUpValueId = adminServiceClient.getLookuIdByTypeAndDescr(ResourceManagementConstant.ROLE_TYPE, ResourceManagementConstant.PROGRAM_MANAGER);
			List<RMApproversDto> rmApproversList = getRMApproversList(rmApprovalRejectionDtls.getProjectId(), rmApprovalRejectionDtls.getUserId(),
					primaryPMLookUpValueId, rmApprovalRejectionDtls.getRequestType(), true);
			
			//List<RMApproversDto> rmApproversList = getRMApproversListForRejection(rmApprovalRejectionDtls.getProjectId(), primaryPMLookUpValueId, rmApprovalRejectionDtls.getRequestType());
			
			Map<String, RMApproversDto> rmApproversMap = rmApproversList.stream().collect(Collectors.toMap(RMApproversDto::getRoleName, Function.identity()));
			List<RMApproversDto> rmApproversListNew = new ArrayList<>();
			if(rmApprovalRejectionDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.PROGRAM_MANAGER) && 
					rsrcWrkflwPrevObj != null) {	
				rmApproversListNew.add(rmApproversMap.containsKey(ResourceManagementConstant.PROJECT_MANAGER) ? 
						rmApproversMap.get(ResourceManagementConstant.PROJECT_MANAGER) : null);
				rmApproversListNew.add(rmApproversMap.containsKey(ResourceManagementConstant.PROGRAM_MANAGER) ? 
						rmApproversMap.get(ResourceManagementConstant.PROGRAM_MANAGER) : null);
			}
			if(rmApprovalRejectionDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.TAG_ROLE_NAME)) {
				rmApproversListNew.add(rmApproversMap.containsKey(ResourceManagementConstant.PROGRAM_MANAGER) ? 
						rmApproversMap.get(ResourceManagementConstant.PROGRAM_MANAGER) : null);
				rmApproversListNew.add(rmApproversMap.containsKey(ResourceManagementConstant.TAG_ROLE_NAME) ? 
						rmApproversMap.get(ResourceManagementConstant.TAG_ROLE_NAME) : null);
			}
			for (RMApproversDto rmApproverDto : rmApproversListNew) {
				Boolean isPrimaryPM = Boolean.FALSE;
				Long pmApprovedUserId;
				//check if PM is primary
				if(List.of(primaryPMLookUpValueId,primaryPGMLookUpValueId).contains(rmApproverDto.getRoleId())) {
					pmApprovedUserId = resourceWorkflowRepository.getUserIdForPMApproved(tAssociateAllocationObj.getAssociateAllocationId(),rmApproverDto.getRoleId());
					isPrimaryPM = resourceTransferServiceImpl.getIsPrimaryOwner(pmApprovedUserId, rmApproverDto.getRoleId(), rmApprovalRejectionDtls.getProjectId());
					if(isPrimaryPM) {
						ResourceWorkflow resourceWorkflowRecordToDuplicate = resourceWorkflowRepository.getRowData(
								tAssociateAllocationObj.getAssociateAllocationId(), rmApproverDto.getUserId(), rmApproverDto.getRoleId());
						if(Objects.nonNull(resourceWorkflowRecordToDuplicate))
							duplicateResourceWorkflowObjectDuringRejection(resourceWorkflowRecordToDuplicate, rmApproverDto.getUserId());
					} else {
						ResourceWorkflow resourceWorkflowRecordToDuplicate = resourceWorkflowRepository.getRowData(
								tAssociateAllocationObj.getAssociateAllocationId(), pmApprovedUserId, rmApproverDto.getRoleId());
						resourceWorkflowRecordToDuplicate.setCurrentUserId(rmApproverDto.getUserId());
						if(Objects.nonNull(resourceWorkflowRecordToDuplicate))
							duplicateResourceWorkflowObjectDuringRejection(resourceWorkflowRecordToDuplicate, rmApproverDto.getUserId());
						resourceWorkflowRecordToDuplicate.setCurrentUserId(pmApprovedUserId);
					}
				} else {
					ResourceWorkflow resourceWorkflowRecordToDuplicate = resourceWorkflowRepository.getRowData(
							tAssociateAllocationObj.getAssociateAllocationId(), rmApproverDto.getUserId(), rmApproverDto.getRoleId());
					if(Objects.nonNull(resourceWorkflowRecordToDuplicate))
						duplicateResourceWorkflowObjectDuringRejection(resourceWorkflowRecordToDuplicate, rmApproverDto.getUserId());
				}
			}
			//End by Mrunal Marne
		}
		if (rsrcWrkflwPrevObj != null) {
			long prevUsrId = rsrcWrkflwPrevObj.getCurrentUserId();
			long prevRoleId = rsrcWrkflwPrevObj.getCurrentRoleId();
			if (prevUsrId > 0 && prevRoleId > 0) {
				log.info("Rejection process still exist:");

				sendMailHelperServiceObj.sendEmailForApproveOrRejectionPending(rmApprovalRejectionDtls, wrkflwCode,
						tAllocationDtlsListObj.get(0).getAssociateAllocationId());
			}
		} else {
			log.info("Current user is final  Reject, Rejection process completed:");
			List<Long> rmTrnsctnIdListObj = tAllocationDtlsListObj.stream()
					.map(TAssociateAllocation::getAssociateAllocationId).collect(Collectors.toList());
			tAssociateAllocationRepository.updateStatusAndEffectiveEndDate(
					getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
							ResourceManagementConstant.REJECTED), 
					rmTrnsctnIdListObj, new Date(System.currentTimeMillis()), getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
							ResourceManagementConstant.DEACTIVATE), tAssociateAllocationRepository.getEmployeeId(rmApprovalRejectionDtls.getUserId()));
			String projectBudgetStatus = adminServiceClient
					.getProjectBudgetStatus(rmApprovalRejectionDtls.getProjectId());
			if (projectBudgetStatus.equalsIgnoreCase("YES")) {
				releaseAllocatedBudgetForAlloc(tAllocationDtlsListObj, rmApprovalRejectionDtls.getProjectId(),
						rmApprovalRejectionDtls.getRequirementId());
			}
			updateProjectStatus(rmApprovalRejectionDtls.getProjectId());

			sendMailHelperServiceObj.sendEmailForRejectionConfirmation(rmApprovalRejectionDtls, wrkflwCode);

		}
		log.info("Just before leaving ResourceManagementServiceImpl.rejectRMApprovalReqForAlloc method:");
	}
	
	//Added by Mrunal Marne for adding next approvers record when request is rejected
	public ResourceWorkflow duplicateResourceWorkflowObjectDuringRejection(ResourceWorkflow resourceWrkflwObj, long userId) {
		log.info("Entered into ResourceManagementServiceImpl.duplicateRsrcWrkflwDataObject method:");
		ResourceWorkflow resourceWrkflwIntrmObj = new ResourceWorkflow();
		resourceWrkflwIntrmObj.setCurrentRoleId(resourceWrkflwObj.getCurrentRoleId());
		resourceWrkflwIntrmObj.setCurrentUserId(resourceWrkflwObj.getCurrentUserId());
		resourceWrkflwIntrmObj.setNextRoleId(resourceWrkflwObj.getNextRoleId());
		resourceWrkflwIntrmObj.setNextUserId(resourceWrkflwObj.getNextUserId());
		resourceWrkflwIntrmObj.setWrkflwTypeId(resourceWrkflwObj.getWrkflwTypeId());
		resourceWrkflwIntrmObj.setStatusId(0L);
		resourceWrkflwIntrmObj.setWrkflwDefinitionId(resourceWrkflwObj.getWrkflwDefinitionId());
		resourceWrkflwIntrmObj.setWrkflwTrnsctnId(resourceWrkflwObj.getWrkflwTrnsctnId());
		resourceWrkflwIntrmObj.setCreatedBy(userId);
		resourceWrkflwIntrmObj.setCreatedDate(new Date(System.currentTimeMillis()));
		resourceWrkflwIntrmObj.setLastUpdatedBy(null);
		resourceWrkflwIntrmObj.setLastUpdatedDate(null);
		resourceWrkflwIntrmObj.setComment(null);
		resourceWorkflowRepository.save(resourceWrkflwIntrmObj);
		log.info("Just before leaving ResourceManagementServiceImpl.duplicateRsrcWrkflwDataObject method:");
		return resourceWrkflwIntrmObj;
	}
	//End by Mrunal Marne

	public void approveRMApprovalReqForDeAlloc(List<AssociateDeAllocationProjection> rDeAllocationDtlsListObj,
			RMApprovalInputDto rmApprovalDtls, List<Long> statusIdList) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.approveRMApprovalReqForDeAlloc method:");
		String wrkflwCode = setWrkflwCode(rmApprovalDtls.getRequestType(), rmApprovalDtls.getRoleName());
		ResourceWorkflow rsrcWrkflwObj = null;
		long deAllocApprovedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
				ResourceManagementConstant.APPROVED);
		for (AssociateDeAllocationProjection tAssociateDeAllocationObj : rDeAllocationDtlsListObj) {
			rsrcWrkflwObj = resourceWorkflowRepository.getRowDataOfDefaultStatus(
					tAssociateDeAllocationObj.getAssociateDeAllocationId(), statusIdList, rmApprovalDtls.getUserId(),
					rmApprovalDtls.getRoleId());
			if (rsrcWrkflwObj != null && rsrcWrkflwObj.getResourceWrkflwId() > 0) {
				rsrcWrkflwObj.setStatusId(deAllocApprovedStatusId);
				rsrcWrkflwObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
				rsrcWrkflwObj.setLastUpdatedBy(rmApprovalDtls.getUserId());
				rsrcWrkflwObj.setComment(rmApprovalDtls.getApproverComments());
				resourceWorkflowRepository.save(rsrcWrkflwObj);
			} else {
				rsrcWrkflwObj = resourceWorkflowRepository.getRowData(
						tAssociateDeAllocationObj.getAssociateDeAllocationId(), rmApprovalDtls.getUserId(),
						rmApprovalDtls.getRoleId());
				ResourceWorkflow createRsrcWrkflwDataObject = createRsrcWrkflwDataObject(rsrcWrkflwObj,
						tAssociateDeAllocationObj.getAssociateDeAllocationId(), rmApprovalDtls,
						ResourceManagementConstant.APPROVAL_CONSTANT);
				createRsrcWrkflwDataObject.setStatusId(deAllocApprovedStatusId);
				createRsrcWrkflwDataObject.setComment(rmApprovalDtls.getApproverComments());
				resourceWorkflowRepository.save(createRsrcWrkflwDataObject);
			}
		}
		if (rsrcWrkflwObj != null) {
			long nextUsrId = rsrcWrkflwObj.getNextUserId();
			long nextRoleId = rsrcWrkflwObj.getNextRoleId();
			if (nextUsrId > 0 && nextRoleId > 0) {
				log.info("Approval process still exist:");

				sendMailHelperServiceObj.sendEmailForApprovalConfirmation(rmApprovalDtls, wrkflwCode);
				sendMailHelperServiceObj.sendEmailForApproveOrRejectionPending(rmApprovalDtls, wrkflwCode,
						rDeAllocationDtlsListObj.get(0).getAssociateDeAllocationId());
			} else {
				log.info("Current user is final  approver, DeAllocation Approval process completed:");
				List<Long> rmAllocTrnsctnIdListObj = rDeAllocationDtlsListObj.stream()
						.map(AssociateDeAllocationProjection::getAssociateDeAllocationId).collect(Collectors.toList());
				tAssociateDeallocationRepository.updateWorkflowStatus(rmAllocTrnsctnIdListObj, deAllocApprovedStatusId);
				for (AssociateDeAllocationProjection dealloctedResource : rDeAllocationDtlsListObj) {
					tAssociateAllocationRepository.updateDataForDeaalloc(deAllocApprovedStatusId,
							dealloctedResource.getDeallocationDate(), dealloctedResource.getAssociateAllocationId(), tAssociateAllocationRepository.getEmployeeId(rmApprovalDtls.getUserId()));
				}
				updateProjectStatus(rmApprovalDtls.getProjectId());
				boolean budgetandCostCheck = resourceAllocationServiceImplObj
						.getBudgetAndCostCheck(rmApprovalDtls.getProjectId());
				if (budgetandCostCheck) {
					releaseAllocatedBudgetForDeAlloc(rDeAllocationDtlsListObj, rmApprovalDtls.getProjectId(),
							rmApprovalDtls.getRequirementId());
				}
				sendMailHelperServiceObj.sendEmailForFinalApprovalConfirmation(rmApprovalDtls, wrkflwCode,
						rDeAllocationDtlsListObj.get(0).getAssociateDeAllocationId());
			}
		}
		log.info("Just before leaving ResourceManagementServiceImpl.approveRMApprovalReqForDeAlloc method:");
	}

	public void rejectRMApprovalReqForDeAlloc(List<AssociateDeAllocationProjection> tDeAllocationDtlsListObj,
			RMApprovalInputDto rmApprovalRejectionDtls, List<Long> statusIdList) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.rejectRMApprovalReqForDeAlloc method:");
		String wrkflwCode = setWrkflwCode(rmApprovalRejectionDtls.getRequestType(), rmApprovalRejectionDtls.getRoleName());
		ResourceWorkflow rsrcWrkflwCrrntObj = null;
		ResourceWorkflow rsrcWrkflwPrevObj = null;
		long deAllocRejectedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
				ResourceManagementConstant.REJECTED);
		rsrcWrkflwPrevObj = resourceWorkflowRepository.getPreviousRowData(
				tDeAllocationDtlsListObj.get(0).getAssociateDeAllocationId(), rmApprovalRejectionDtls.getUserId(),
				rmApprovalRejectionDtls.getRoleId());
		for (AssociateDeAllocationProjection tAssociateDeAllocationObj : tDeAllocationDtlsListObj) {
			rsrcWrkflwCrrntObj = resourceWorkflowRepository.getRowDataOfDefaultStatus(
					tAssociateDeAllocationObj.getAssociateDeAllocationId(), statusIdList,
					rmApprovalRejectionDtls.getUserId(), rmApprovalRejectionDtls.getRoleId());
			if (rsrcWrkflwCrrntObj != null && rsrcWrkflwCrrntObj.getResourceWrkflwId() > 0) {
				rsrcWrkflwCrrntObj.setStatusId(deAllocRejectedStatusId);
				rsrcWrkflwCrrntObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
				rsrcWrkflwCrrntObj.setLastUpdatedBy(rmApprovalRejectionDtls.getUserId());
				rsrcWrkflwCrrntObj.setComment(rmApprovalRejectionDtls.getApproverComments());
				resourceWorkflowRepository.save(rsrcWrkflwCrrntObj);

			} 
			//Commented by Mrunal Marne for adding next approvers record when request is rejected
			/*else {
				rsrcWrkflwCrrntObj = resourceWorkflowRepository.getRowData(
						tAssociateDeAllocationObj.getAssociateDeAllocationId(), rmApprovalRejectionDtls.getUserId(),
						rmApprovalRejectionDtls.getRoleId());
				ResourceWorkflow createRsrcWrkflwDataObject = createRsrcWrkflwDataObject(rsrcWrkflwCrrntObj,
						tAssociateDeAllocationObj.getAssociateDeAllocationId(), rmApprovalRejectionDtls,
						ResourceManagementConstant.APPROVAL_CONSTANT);
				createRsrcWrkflwDataObject.setStatusId(deAllocRejectedStatusId);
				createRsrcWrkflwDataObject.setComment(rmApprovalRejectionDtls.getApproverComments());
				resourceWorkflowRepository.save(createRsrcWrkflwDataObject);
			}*/
			//Added by Mrunal Marne for adding next approvers record when request is rejected
			Long primaryPMLookUpValueId = adminServiceClient.getLookuIdByTypeAndDescr(ResourceManagementConstant.ROLE_TYPE, ResourceManagementConstant.PROJECT_MANAGER);
			Long primaryPGMLookUpValueId = adminServiceClient.getLookuIdByTypeAndDescr(ResourceManagementConstant.ROLE_TYPE, ResourceManagementConstant.PROGRAM_MANAGER);
			List<RMApproversDto> rmApproversList = getRMApproversList(rmApprovalRejectionDtls.getProjectId(), rmApprovalRejectionDtls.getUserId(),
					primaryPMLookUpValueId, rmApprovalRejectionDtls.getRequestType(), true);
			//List<RMApproversDto> rmApproversList = getRMApproversListForRejection(rmApprovalRejectionDtls.getProjectId(), primaryPMLookUpValueId, rmApprovalRejectionDtls.getRequestType());
			Map<String, RMApproversDto> rmApproversMap = rmApproversList.stream().collect(Collectors.toMap(RMApproversDto::getRoleName, Function.identity()));
			List<RMApproversDto> rmApproversListNew = new ArrayList<>();
			if(rmApprovalRejectionDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.PROGRAM_MANAGER) && 
					rsrcWrkflwPrevObj != null) {	
				rmApproversListNew.add(rmApproversMap.containsKey(ResourceManagementConstant.PROJECT_MANAGER) ? 
						rmApproversMap.get(ResourceManagementConstant.PROJECT_MANAGER) : null);
				rmApproversListNew.add(rmApproversMap.containsKey(ResourceManagementConstant.PROGRAM_MANAGER) ? 
						rmApproversMap.get(ResourceManagementConstant.PROGRAM_MANAGER) : null);
			}
			if(rmApprovalRejectionDtls.getRoleName().equalsIgnoreCase(ResourceManagementConstant.TAG_ROLE_NAME)) {
				rmApproversListNew.add(rmApproversMap.containsKey(ResourceManagementConstant.PROGRAM_MANAGER) ? 
						rmApproversMap.get(ResourceManagementConstant.PROGRAM_MANAGER) : null);
				rmApproversListNew.add(rmApproversMap.containsKey(ResourceManagementConstant.TAG_ROLE_NAME) ? 
						rmApproversMap.get(ResourceManagementConstant.TAG_ROLE_NAME) : null);
			}
			if(!rmApproversListNew.stream().allMatch(record -> record==null)) {
				for (RMApproversDto rmApproverDto : rmApproversListNew) {
					Boolean isPrimaryPM = Boolean.FALSE;
					Long pmApprovedUserId;
					//check if PM is primary
					if(List.of(primaryPMLookUpValueId,primaryPGMLookUpValueId).contains(rmApproverDto.getRoleId())) {
						pmApprovedUserId = resourceWorkflowRepository.getUserIdForPMApproved(tAssociateDeAllocationObj.getAssociateAllocationId(),rmApproverDto.getRoleId());
						isPrimaryPM = resourceTransferServiceImpl.getIsPrimaryOwner(pmApprovedUserId, rmApproverDto.getRoleId(), rmApprovalRejectionDtls.getProjectId());
						if(isPrimaryPM) {
							ResourceWorkflow resourceWorkflowRecordToDuplicate = resourceWorkflowRepository.getRowData(
									tAssociateDeAllocationObj.getAssociateDeAllocationId(), rmApproverDto.getUserId(), rmApproverDto.getRoleId());
							if(Objects.nonNull(resourceWorkflowRecordToDuplicate))
								duplicateResourceWorkflowObjectDuringRejection(resourceWorkflowRecordToDuplicate, rmApproverDto.getUserId());
						} else {
							ResourceWorkflow resourceWorkflowRecordToDuplicate = resourceWorkflowRepository.getRowData(
									tAssociateDeAllocationObj.getAssociateDeAllocationId(), pmApprovedUserId, rmApproverDto.getRoleId());
							resourceWorkflowRecordToDuplicate.setCurrentUserId(rmApproverDto.getUserId());
							if(Objects.nonNull(resourceWorkflowRecordToDuplicate))
								duplicateResourceWorkflowObjectDuringRejection(resourceWorkflowRecordToDuplicate, rmApproverDto.getUserId());
							resourceWorkflowRecordToDuplicate.setCurrentUserId(pmApprovedUserId);
						}
					} else {
						ResourceWorkflow resourceWorkflowRecordToDuplicate = resourceWorkflowRepository.getRowData(
								tAssociateDeAllocationObj.getAssociateDeAllocationId(), rmApproverDto.getUserId(), rmApproverDto.getRoleId());
						if(Objects.nonNull(resourceWorkflowRecordToDuplicate))
							duplicateResourceWorkflowObjectDuringRejection(resourceWorkflowRecordToDuplicate, rmApproverDto.getUserId());
					}
				}
			}
			//End by Mrunal Marne
		}
		if (rsrcWrkflwPrevObj != null) {
			long prevUsrId = rsrcWrkflwPrevObj.getCurrentUserId();
			long prevRoleId = rsrcWrkflwPrevObj.getCurrentRoleId();
			if (prevUsrId > 0 && prevRoleId > 0) {
				log.info("Rejection process still exist:");

				sendMailHelperServiceObj.sendEmailForApproveOrRejectionPending(rmApprovalRejectionDtls, wrkflwCode,
						tDeAllocationDtlsListObj.get(0).getAssociateDeAllocationId());
			}
		} else {
			log.info("Current user is final  Reject, Rejection process completed:");
			List<Long> rmDeAllocTrnsctnIdListObj = tDeAllocationDtlsListObj.stream()
					.map(AssociateDeAllocationProjection::getAssociateDeAllocationId).collect(Collectors.toList());
			tAssociateDeallocationRepository.updateStatusAndEffectiveEndDate(
					getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
							ResourceManagementConstant.REJECTED),
					rmDeAllocTrnsctnIdListObj, new Date(System.currentTimeMillis()));

			sendMailHelperServiceObj.sendEmailForRejectionConfirmation(rmApprovalRejectionDtls, wrkflwCode);
			log.info("Just before leaving ResourceManagementServiceImpl.rejectRMApprovalReqForDeAlloc method:");
		}
	}

	public void releaseAllocatedBudgetForDeAlloc(List<AssociateDeAllocationProjection> tDeAllocationDtoDtlsListObj,
			Long projectId, long requirementId) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.releaseAllocatedBudget method:");
		List<ProjectBudgetDto> projectBudgetDto = budgetControlServiceClient.getProjectMonthlyBudgetsDetails(projectId);
		ResourceRequirementDto rsrcRqrmntDtoObj = bapServiceClient.getRequirementDetailByReqId(requirementId);
		if (CollectionUtils.isNotEmpty(projectBudgetDto)) {
			Map<String, ProjectBudgetDto> projectBudgets = projectBudgetDto.stream().collect(HashMap::new,
					(m, v) -> m.put(v.getMonth(), v), HashMap::putAll);
			for (AssociateDeAllocationProjection tDeAllocationDtoDtlsObj : tDeAllocationDtoDtlsListObj) {
				calculateAllocatedBudget(tDeAllocationDtoDtlsObj, projectBudgets, rsrcRqrmntDtoObj);
			}
			resourceAllocationServiceImplObj.updateBudget(projectBudgets);
		}
		log.info("Just before leaving ResourceManagementServiceImpl.releaseAllocatedBudget method:");
	}

	public void calculateAllocatedBudget(AssociateDeAllocationProjection tDeAllocationDtoDtlsObj,
			Map<String, ProjectBudgetDto> projectBudgets, ResourceRequirementDto rsrcRqrmntDtoObj)
			throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.calculateAllocatedBudget method:");
		Map<String, Long> monthlyResourceAllocationDetail = RMBudgetControlUtil.monthWiseNoOfDays(
				tDeAllocationDtoDtlsObj.getDeallocationDate(), tDeAllocationDtoDtlsObj.getEstAllocationEndDate());
		 double shoreWorkHour = 0.00;
			if (rsrcRqrmntDtoObj.getShore().equalsIgnoreCase(ResourceManagementConstant.ONSHORE))
				shoreWorkHour = 8;
			else
				shoreWorkHour = rsrcRqrmntDtoObj.getProjectBillingHours();		

		List<String> months = monthlyResourceAllocationDetail.keySet().stream().collect(Collectors.toList());
		for (String month : months) {
			ProjectBudgetDto projectBudgetDto = projectBudgets.get(month);
			double deAllocCost = monthlyResourceAllocationDetail.get(month)
					* ((tDeAllocationDtoDtlsObj.getemployeeCostRate() * shoreWorkHour
							* (tDeAllocationDtoDtlsObj.getFtePercent() / 100)));
			// * rsrcRqrmntDtoObj.getZenAccurateCurrency() /
			// projectBudgetDto.getBudgetCurrency());
			List<TAssociateAllocationBudget> allocationBudget = associateAllocationBudgetRepository
					.findByAssociateAllocationIdAndBudgetAllocationMonth(
							tDeAllocationDtoDtlsObj.getAssociateAllocationId(), month);
			checkBudgetToRelease(projectBudgets, deAllocCost, allocationBudget);
		}
		log.info("Just before leaving ResourceManagementServiceImpl.calculateAllocatedBudget method:");
	}

	public void checkBudgetToRelease(Map<String, ProjectBudgetDto> projectBudgets, double deAllocCost,
			List<TAssociateAllocationBudget> allocationBudget) {
		ProjectBudgetDto projectBudgetDto;
		double monthlyAllocatedCost = 0;
		for (TAssociateAllocationBudget budget : allocationBudget) {
			projectBudgetDto = projectBudgets.get(budget.getBudgetAllocationMonth());
			//added by sakshi to resolve budget release issue
            BigDecimal bd = BigDecimal.valueOf(deAllocCost);
            bd = bd.setScale(2, RoundingMode.HALF_UP);
            double deAllocCostConverted = bd.doubleValue();
            //end
            //Commented by Mrunal Marne for source budget release
			/*if (monthlyAllocatedCost == 0)
				monthlyAllocatedCost = budget.getMonthlyBudget() - deAllocCostConverted;
			
			if (budget.getMonthlyUsedBudget() >= monthlyAllocatedCost) {
				double returnAmount = budget.getMonthlyUsedBudget() - monthlyAllocatedCost;
				projectBudgetDto.setAvailableBudget(projectBudgetDto.getAvailableBudget() + returnAmount);
				projectBudgetDto.setConsumedBudget(projectBudgetDto.getConsumedBudget() - returnAmount);
				projectBudgetDto.setTotalConsumption(projectBudgetDto.getConsumedBudget());
				projectBudgets.put(budget.getBudgetAllocatedMonth(), projectBudgetDto);
			
			} else {
				monthlyAllocatedCost = monthlyAllocatedCost - budget.getMonthlyUsedBudget();
			}*/
            //End by Mrunal Marne
			//double returnAmount = budget.getMonthlyUsedBudget() - deAllocCostConverted;
			projectBudgetDto.setAvailableBudget(projectBudgetDto.getAvailableBudget() + deAllocCostConverted);
			projectBudgetDto.setConsumedBudget(projectBudgetDto.getConsumedBudget() - deAllocCostConverted);
			projectBudgetDto.setTotalConsumption(projectBudgetDto.getConsumedBudget());
			projectBudgets.put(budget.getBudgetAllocatedMonth(), projectBudgetDto);
		}
	}

	public void releaseAllocatedBudgetForAlloc(List<TAssociateAllocation> tAllocationDtlsListObj, Long projectId,
			long requirementId) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.releaseAllocatedBudget method:");
		List<ProjectBudgetDto> projectBudgetDto = budgetControlServiceClient.getProjectMonthlyBudgetsDetails(projectId);
		ResourceRequirementDto rsrcRqrmntDtoObj = bapServiceClient.getRequirementDetailByReqId(requirementId);
		if (CollectionUtils.isNotEmpty(projectBudgetDto)) {
			Map<String, ProjectBudgetDto> projectBudgets = projectBudgetDto.stream().collect(HashMap::new,
					(m, v) -> m.put(v.getMonth(), v), HashMap::putAll);
			for (TAssociateAllocation tAllocationDtlsObj : tAllocationDtlsListObj) {
				calculateAllocatedBudget(tAllocationDtlsObj, projectBudgets, rsrcRqrmntDtoObj);
			}
			resourceAllocationServiceImplObj.updateBudget(projectBudgets);
		}
		log.info("Just before leaving ResourceManagementServiceImpl.releaseAllocatedBudget method:");
	}

	public void calculateAllocatedBudget(TAssociateAllocation tAllocationDtlsObj,
			Map<String, ProjectBudgetDto> projectBudgets, ResourceRequirementDto rsrcRqrmntDtoObj)
			throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.calculateAllocatedBudget method:");
		Map<String, Long> monthlyResourceAllocationDetail = RMBudgetControlUtil.monthWiseNoOfDays(
				tAllocationDtlsObj.getActualAllocationStartDate(), tAllocationDtlsObj.getEstAllocationEndDate());
		 double shoreWorkHour = 0.00;
			if (rsrcRqrmntDtoObj.getShore().equalsIgnoreCase(ResourceManagementConstant.ONSHORE))
				shoreWorkHour = 8;
			else
				shoreWorkHour = rsrcRqrmntDtoObj.getProjectBillingHours();		
			List<String> months = monthlyResourceAllocationDetail.keySet().stream().collect(Collectors.toList());
		for (String month : months) {  
			ProjectBudgetDto projectBudgetDto = projectBudgets.get(month);
			double deAllocCost = monthlyResourceAllocationDetail.get(month)
					* ((tAllocationDtlsObj.getStdCost()) * shoreWorkHour
							* (tAllocationDtlsObj.getFtePercent() / 100));
					//* rsrcRqrmntDtoObj.getZenAccurateCurrency()
					//		/ projectBudgetDto.getBudgetCurrency());
			List<TAssociateAllocationBudget> allocationBudget = associateAllocationBudgetRepository
					.findByAssociateAllocationIdAndBudgetAllocationMonth(tAllocationDtlsObj.getAssociateAllocationId(),
							month);
			checkBudgetToRelease(projectBudgets, deAllocCost, allocationBudget);
		}
		log.info("Just before leaving ResourceManagementServiceImpl.calculateAllocatedBudget method:");
	}

	public void callSendEmailUtility(Map<String, List<Long>> userDtlsMap, long projectId)
			throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.callSendEmailUtility method:");
		MailDetail mailDetail = new MailDetail();
		List<String> ccUserDtls = adminServiceClient.getAssociatesEmailAddress(userDtlsMap.get("Cc"));
		if (CollectionUtils.isNotEmpty(ccUserDtls))
			mailDetail.setMailCcAddress(ccUserDtls);
		List<String> toUserDtls = adminServiceClient.getAssociatesEmailAddress(userDtlsMap.get("TO"));
		if (CollectionUtils.isNotEmpty(toUserDtls))
			mailDetail.setMailToAddress(toUserDtls);
		mailDetail.setMailSubject("SAMPLE EMAIL SENDING FOR RM ALLOCATION AND DEALLOCATION FLOW");
		mailDetail.setMailBody(
				"SAMPLE EMAIL SENDING FOR RM ALLOCATION AND DEALLOCATION FLOW FOR PROJECTID:" + projectId + ":");
		sendMailUtil.sendMail(mailDetail);
		log.info("Just before leaving ResourceManagementServiceImpl.rejectRMSavedResources method:");
	}

	@Override
	public void rejectRMSavedResources(List<RMApprovalInputDto> rejectResourceDtlsList) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.rejectRMSavedResources method:");
		long statusId;
		for (RMApprovalInputDto rejectResourceDtls : rejectResourceDtlsList) {
			if (rejectResourceDtls.getRequestType()
					.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE)) {
				statusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
						ResourceManagementConstant.REJECTED);
				List<TAssociateAllocation> rAllocationDtlsListObj = tAssociateAllocationRepository.getRAllocationDetails(
						rejectResourceDtls.getProjectId(),
						getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
								ResourceManagementConstant.ACTIVATE),
						rejectResourceDtls.getEmployeeIdList(), rejectResourceDtls.getRequirementId(),getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
								ResourceManagementConstant.SAVED));
				releaseAllocatedBudgetForAlloc(rAllocationDtlsListObj, rejectResourceDtls.getProjectId(),
						rejectResourceDtls.getRequirementId());
				//Commented and added by Mrunal Marne for removing records for RM Allocation saved on rejection by Project Manager
				/*tAssociateAllocationRepository.rejectRMSavedResources(statusId, rejectResourceDtls.getEmployeeIdList(),
						rejectResourceDtls.getRequirementId(), rejectResourceDtls.getProjectId());
				updateProjectStatus(rejectResourceDtls.getProjectId());*/
				List<Long> targetAssociateAllocationIdList = rAllocationDtlsListObj.stream().map(TAssociateAllocation::getAssociateAllocationId).collect(Collectors.toList());
				bapServiceClient.removePoAndMilestoneDetailsForTransferRejection(targetAssociateAllocationIdList);
				associateAllocationBudgetRepository.removeSavedBudgetDetailsForTransfer(targetAssociateAllocationIdList);
				tAssociateAllocationRepository.removeRMSavedResources(rejectResourceDtls.getEmployeeIdList(),
						rejectResourceDtls.getRequirementId(), rejectResourceDtls.getProjectId());
				associateProjectRepository.removeSavedResourceFromRMAllocation(rejectResourceDtls.getEmployeeIdList(), rejectResourceDtls.getProjectId(),
						getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE));
				//End by Mrunal Marne
			} else if (rejectResourceDtls.getRequestType()
					.equalsIgnoreCase(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE)) {
				statusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
						ResourceManagementConstant.REJECTED);
				for (ResourceRequirementDto resourceRequirementDtls : rejectResourceDtls.getResourceRequirementList()) {
					tAssociateDeallocationRepository.rejectRMSavedResources(statusId,
							resourceRequirementDtls.getEmployeeIdList(), resourceRequirementDtls.getReqId());
				}
			}	
		}
		log.info("Just before leaving ResourceManagementServiceImpl.rejectRMSavedResources method:");
	}

	public void updateProjectStatus(Long projectId) throws ResourceManagementException {
		int count = tAssociateAllocationRepository.getActiveStatusCount(projectId,
				getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION, ResourceManagementConstant.ACTIVATE));
		if (count == 0)
			associateProjectRepository
					.setStatusIdForProject(
							getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
									ResourceManagementConstant.DEACTIVATE),
							projectId, new Date(System.currentTimeMillis()));
	}

	@Override
	public TransferApproverResponseDto getRMTransferApproversList(long sourceProjectId, long targetProjectId,
			long userId, long roleId, String requestType) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.getRMTransferApproversList method:");
		List<Long> projectIdList = new ArrayList<>();
		projectIdList.add(sourceProjectId);
		projectIdList.add(targetProjectId);
		TransferApproverResponseDto transferApproverResponseDto = new TransferApproverResponseDto();
		String wrkflwCode = setWrkflwCode(requestType, tAssociateAllocationRepository.getRoleName(roleId));
		List<RMApproversDto> sortedRMSourceApproversListObj = null;
		List<WrkflwStepDefinitionDto> wrkflwStepDfntnDtlsListObj = wrkflwEngineServiceClient
				.getWrkflwStepDetails(wrkflwCode);
		Long pgmRoleId = adminServiceClient.getLookuIdByTypeAndDescr("ROLE_TYPE", "PROGRAM MANAGER");
		if (!CollectionUtils.isEmpty(wrkflwStepDfntnDtlsListObj)) {
			List<Long> roleIdListObj = wrkflwStepDfntnDtlsListObj.stream().map(WrkflwStepDefinitionDto::getRoleId)
					.collect(Collectors.toList());
			// roleIdListObj.removeIf(i -> (i == roleId));
			// List<Long> userIdListObj =
			// bapServiceClient.getPrimaryOwnersList(sourceProjectId);
			List<Long> userIdListObj = adminServiceClient.getPrimaryOwnerUserIdListByProjectId(sourceProjectId);
			if (!CollectionUtils.isEmpty(userIdListObj) && !CollectionUtils.isEmpty(roleIdListObj)) {
				if(roleIdListObj.contains(pgmRoleId))
					roleIdListObj.remove(pgmRoleId);
				List<RMApproversDto> rmApproversListObj = adminServiceClient.getRMApproversList(roleIdListObj,
						userIdListObj);
				if (!CollectionUtils.isEmpty(rmApproversListObj)) {
					sortedRMSourceApproversListObj = sortRMApproversOPData(rmApproversListObj,
							wrkflwStepDfntnDtlsListObj);
				}
			}
		}
		if(pgmRoleId!=roleId)		//if project manager is submitting
			fyiApprover(pgmRoleId, projectIdList, transferApproverResponseDto, wrkflwCode);
		else {
			Long pmRoleId = adminServiceClient.getLookuIdByTypeAndDescr("ROLE_TYPE", "PROJECT MANAGER");
			Map<Long, Long> projRoleIdMap = new HashMap<>();
			projRoleIdMap.put(pgmRoleId, sourceProjectId);
			projRoleIdMap.put(pmRoleId, targetProjectId);
			fyiApproverPmPgm(projRoleIdMap, projectIdList, transferApproverResponseDto, wrkflwCode);
		}
		transferApproverResponseDto.setRmSourceApproversListObj(sortedRMSourceApproversListObj);
		log.info("Just before leaving ResourceManagementServiceImpl.getRMTransferApproversList method:");
		return transferApproverResponseDto;
	}

	
	private void fyiApproverPmPgm(Map<Long, Long> projRoleIdMap, List<Long> projectIdList,
			TransferApproverResponseDto transferApproverResponseDto, String wrkflwCode) throws ResourceManagementException {
		List<Long> roleIdList = new ArrayList<>();
		FYIapproverDto fYIapproverDto = new FYIapproverDto();
		for (Entry<Long, Long> entry : projRoleIdMap.entrySet()) {
			List<WrkflwStepDefinitionDto> configuredEmailRoles = wrkflwEngineServiceClient.getWrkflwStepEmailDetails(
					wrkflwCode, ResourceManagementConstant.RM_FYI_WRKLFW_DECISION_CODE,
					ResourceManagementConstant.EMAIL_UI_DISPLAY_FLAG_FALSE, entry.getKey());
			if (CollectionUtils.isNotEmpty(configuredEmailRoles))
				roleIdList = configuredEmailRoles.stream().map(WrkflwStepDefinitionDto::getRoleId)
						.collect(Collectors.toList());
			List<PrimaryUsersDto> primaryUserDtls = bapServiceClient.getListPrimaryOwnersList(List.of(entry.getValue()), List.of(entry.getKey()));
			for (PrimaryUsersDto temp : primaryUserDtls) {
				List<PrimaryUsersDto> user = new ArrayList<>();
				if (temp.getProjectId() == projectIdList.get(0)) {
					user.add(temp);
					fYIapproverDto.setSourceFYIapproversList(user);
				} else if (temp.getProjectId() == projectIdList.get(1)) {
					user.add(temp);
					fYIapproverDto.setTargetFYIapproversList(user);
				}
				transferApproverResponseDto.setFyiApproverDto(fYIapproverDto);
			}
		}
	}

	private void fyiApprover(long roleId, List<Long> projectIdList,
			TransferApproverResponseDto transferApproverResponseDto, String wrkflwCode)
			throws ResourceManagementException {
		List<Long> roleIdList = new ArrayList<>();
		FYIapproverDto fYIapproverDto = new FYIapproverDto();
		List<WrkflwStepDefinitionDto> configuredEmailRoles = wrkflwEngineServiceClient.getWrkflwStepEmailDetails(
				wrkflwCode, ResourceManagementConstant.RM_FYI_WRKLFW_DECISION_CODE,
				ResourceManagementConstant.EMAIL_UI_DISPLAY_FLAG_FALSE, roleId);
		if (CollectionUtils.isNotEmpty(configuredEmailRoles))
			roleIdList = configuredEmailRoles.stream().map(WrkflwStepDefinitionDto::getRoleId)
					.collect(Collectors.toList());
		roleIdList.add(roleId);
		List<PrimaryUsersDto> primaryUserDtls = bapServiceClient.getListPrimaryOwnersList(projectIdList, roleIdList);
		for (PrimaryUsersDto temp : primaryUserDtls) {
			List<PrimaryUsersDto> user = new ArrayList<>();
			if (temp.getProjectId() == projectIdList.get(0)) {
				user.add(temp);
				fYIapproverDto.setSourceFYIapproversList(user);
			} else if (temp.getProjectId() == projectIdList.get(1)) {
				user.add(temp);
				fYIapproverDto.setTargetFYIapproversList(user);
			}
			transferApproverResponseDto.setFyiApproverDto(fYIapproverDto);
		}
	}

	@Override
	public void approveOrRejectRMApprovalForExtension(List<RMApprovalInputDto> rmApproveOrRejectDtlsListExtension)
			throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.approveOrRejectRMApproval method:");
		List<Long> statusIdList = new ArrayList<>();
		statusIdList.add(0L);
		Long statusIdforActive = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
				ResourceManagementConstant.ACTIVATE);		
		for (RMApprovalInputDto rmApproveOrRejectDtls : rmApproveOrRejectDtlsListExtension) {
			//Dev by Ravi
			Map<Long,Date> currentEstDate=new HashMap<>();
			rmApproveOrRejectDtls.getEmployeeIdList().forEach(emp->{
				currentEstDate.put(emp, rmApproveOrRejectDtls.getCurrentEstEndDate());
			});
			rmApproveOrRejectDtls.setEmpCurrentEstEndDateMap(currentEstDate);
			//End
			if ((rmApproveOrRejectDtls.getRequestType()
					.equals(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE))
					&& (rmApproveOrRejectDtls.getApproverAction().equals(ResourceManagementConstant.APPROVED_ACTION)
							|| rmApproveOrRejectDtls.getApproverAction()
									.equals(ResourceManagementConstant.REJECTED_ACTION))) {
				if (rmApproveOrRejectDtls.getRequestType()
						.equalsIgnoreCase(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE)) {

					List<AssociateExtensionProjection> tAllocationDtlsListObjExtension = tAssociateExtensionRepository
							.getExtensionResourceList(rmApproveOrRejectDtls.getEmployeeIdList(),
									rmApproveOrRejectDtls.getProjectId(),
									getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION,
											ResourceManagementConstant.SUBMITTED),
									statusIdforActive);
					if (CollectionUtils.isNotEmpty(tAllocationDtlsListObjExtension)) {
						if (rmApproveOrRejectDtls.getApproverAction()
								.equalsIgnoreCase(ResourceManagementConstant.APPROVED))
							approveRMApprovalReqForExtension(tAllocationDtlsListObjExtension, rmApproveOrRejectDtls,
									statusIdList);
						else
							rejectRMApprovalReqForExtension(tAllocationDtlsListObjExtension, rmApproveOrRejectDtls,
									statusIdList);
					} else {
						throw new ResourceManagementException();
					}
				}
			} else {
				throw new ResourceManagementException(ResourceManagementConstant.INVALID_REQUEST_TYPE);
			}
		}
		log.info("Just before leaving ResourceManagementServiceImpl.approveOrRejectRMApproval method:");
	}

	public void approveRMApprovalReqForExtension(List<AssociateExtensionProjection> rAllocationDtlsListObj,
			RMApprovalInputDto rmApprovalDtls, List<Long> statusIdList) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.approveRMApprovalReqForAlloc method:");
		ResourceWorkflow rsrcWrkflwObj = null;
		String wrkflwCode = setWrkflwCode(rmApprovalDtls.getRequestType(), rmApprovalDtls.getRoleName());
		long allocApprovedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION,
				ResourceManagementConstant.APPROVED);
		for (AssociateExtensionProjection tAssociateAllocationObj : rAllocationDtlsListObj) {
			rsrcWrkflwObj = resourceWorkflowRepository.getRowDataOfDefaultStatus(
					tAssociateAllocationObj.getextensionId(), statusIdList, rmApprovalDtls.getUserId(),
					rmApprovalDtls.getRoleId());
			if (rsrcWrkflwObj != null && rsrcWrkflwObj.getResourceWrkflwId() > 0) {
				rsrcWrkflwObj.setStatusId(allocApprovedStatusId);
				rsrcWrkflwObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
				rsrcWrkflwObj.setLastUpdatedBy(rmApprovalDtls.getUserId());
				rsrcWrkflwObj.setComment(rmApprovalDtls.getApproverComments());
				resourceWorkflowRepository.save(rsrcWrkflwObj);
			} else {
				rsrcWrkflwObj = resourceWorkflowRepository.getRowData(tAssociateAllocationObj.getextensionId(),
						rmApprovalDtls.getUserId(), rmApprovalDtls.getRoleId());
				long allocApprovedStatusId1 = getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION,
						ResourceManagementConstant.APPROVED);
				ResourceWorkflow createRsrcWrkflwDataObject = createRsrcWrkflwDataObject(rsrcWrkflwObj,
						tAssociateAllocationObj.getextensionId(), rmApprovalDtls,
						ResourceManagementConstant.APPROVAL_CONSTANT);
				createRsrcWrkflwDataObject.setStatusId(allocApprovedStatusId1);
				createRsrcWrkflwDataObject.setComment(rmApprovalDtls.getApproverComments());
				resourceWorkflowRepository.save(createRsrcWrkflwDataObject);
			}
		}
		if (rsrcWrkflwObj != null) {
			long nextUsrId = rsrcWrkflwObj.getNextUserId();
			long nextRoleId = rsrcWrkflwObj.getNextRoleId();
			if (nextUsrId > 0 && nextRoleId > 0) {
				log.info("Approval process still exist:");

				sendMailHelperServiceObj.sendEmailForApprovalConfirmation(rmApprovalDtls, wrkflwCode);
				sendMailHelperServiceObj.sendEmailForApproveOrRejectionPending(rmApprovalDtls, wrkflwCode,
						rAllocationDtlsListObj.get(0).getextensionId());
			} else {
				log.info("Current user is final  approver, Approval process completed:");
				List<Long> allocationTranscIdList = rAllocationDtlsListObj.stream()
						.map(AssociateExtensionProjection::getallocationId).collect(Collectors.toList());
				Long statusIdforActive = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
						ResourceManagementConstant.ACTIVATE);

				Long wfStausIdForApproved = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
						ResourceManagementConstant.APPROVED);

				for (AssociateExtensionProjection extensionList : rAllocationDtlsListObj) {
					Date endDate = extensionList.getextendedDate();
					tAssociateAllocationRepository.updateEstimatedEndDateforExtension(endDate,
							extensionList.getallocationId(), statusIdforActive, wfStausIdForApproved, tAssociateAllocationRepository.getEmployeeId(rmApprovalDtls.getUserId()));
				}
				Long wfstatusIdForApproved = getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION,
						ResourceManagementConstant.APPROVED);
				Long statusIdForDeactive = getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION,
						ResourceManagementConstant.DEACTIVATE);
				Long wfstatusIdForSubmit = getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION,
						ResourceManagementConstant.SUBMITTED);
				Long statusIdForActive = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
						ResourceManagementConstant.ACTIVATE);
				tAssociateExtensionRepository.updateWorkflowStatusforExtension(wfstatusIdForApproved,
						statusIdForDeactive, wfstatusIdForSubmit, statusIdForActive, allocationTranscIdList);

				sendMailHelperServiceObj.sendEmailForFinalApprovalConfirmation(rmApprovalDtls, wrkflwCode, rAllocationDtlsListObj.get(0).getallocationId());
			}
		}
		log.info("Just before leaving ResourceManagementServiceImpl.approveRMApprovalReqForAlloc method:");
	}

	public void rejectRMApprovalReqForExtension(List<AssociateExtensionProjection> tAllocationDtlsListObj,
			RMApprovalInputDto rmApprovalRejectionDtls, List<Long> statusIdList) throws ResourceManagementException {
		log.info("Entered into ResourceManagementServiceImpl.rejectRMApprovalReqForAlloc method:");
		String wrkflwCode = setWrkflwCode(rmApprovalRejectionDtls.getRequestType(), rmApprovalRejectionDtls.getRoleName());
		ResourceWorkflow rsrcWrkflwPrevObj = resourceWorkflowRepository.getPreviousRowData(
				tAllocationDtlsListObj.get(0).getextensionId(), rmApprovalRejectionDtls.getUserId(),
				rmApprovalRejectionDtls.getRoleId());
		long allocRejectedStatusId = getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION,
				ResourceManagementConstant.REJECTED);
		for (AssociateExtensionProjection tAssociateAllocationObj : tAllocationDtlsListObj) {
			ResourceWorkflow rsrcWrkflwCrrntObj = resourceWorkflowRepository.getRowDataOfDefaultStatus(
					tAssociateAllocationObj.getextensionId(), statusIdList, rmApprovalRejectionDtls.getUserId(),
					rmApprovalRejectionDtls.getRoleId());
			if (rsrcWrkflwCrrntObj != null && rsrcWrkflwCrrntObj.getResourceWrkflwId() > 0) {
				rsrcWrkflwCrrntObj.setStatusId(allocRejectedStatusId);
				rsrcWrkflwCrrntObj.setLastUpdatedDate(new Date(System.currentTimeMillis()));
				rsrcWrkflwCrrntObj.setLastUpdatedBy(rmApprovalRejectionDtls.getUserId());
				rsrcWrkflwCrrntObj.setComment(rmApprovalRejectionDtls.getApproverComments());
				resourceWorkflowRepository.save(rsrcWrkflwCrrntObj);

			} else {
				rsrcWrkflwCrrntObj = resourceWorkflowRepository.getRowData(tAssociateAllocationObj.getextensionId(),
						rmApprovalRejectionDtls.getUserId(), rmApprovalRejectionDtls.getRoleId());
				ResourceWorkflow createRsrcWrkflwDataObject = createRsrcWrkflwDataObject(rsrcWrkflwCrrntObj,
						tAssociateAllocationObj.getextensionId(), rmApprovalRejectionDtls,
						ResourceManagementConstant.APPROVAL_CONSTANT);
				createRsrcWrkflwDataObject.setStatusId(allocRejectedStatusId);
				createRsrcWrkflwDataObject.setComment(rmApprovalRejectionDtls.getApproverComments());
				resourceWorkflowRepository.save(createRsrcWrkflwDataObject);
			}
		}
		if (rsrcWrkflwPrevObj != null) {
			long prevUsrId = rsrcWrkflwPrevObj.getCurrentUserId();
			long prevRoleId = rsrcWrkflwPrevObj.getCurrentRoleId();
			if (prevUsrId > 0 && prevRoleId > 0) {
				log.info("Rejection process still exist:");

				sendMailHelperServiceObj.sendEmailForApproveOrRejectionPending(rmApprovalRejectionDtls, wrkflwCode,
						tAllocationDtlsListObj.get(0).getextensionId());
			}
		} else {
			log.info("Current user is final  Reject, Rejection process completed:");
			List<Long> allocationTranscIdList = tAllocationDtlsListObj.stream()
					.map(AssociateExtensionProjection::getallocationId).collect(Collectors.toList());

			Long wfstatusIdForApproved = getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION,
					ResourceManagementConstant.REJECTED);
			Long statusIdForDeactive = getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION,
					ResourceManagementConstant.DEACTIVATE);
			Long wfstatusIdForSubmit = getModuleStatusId(ResourceManagementConstant.RESOURCE_EXTENSION,
					ResourceManagementConstant.SUBMITTED);
			Long statusIdForActive = getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
					ResourceManagementConstant.ACTIVATE);
			tAssociateExtensionRepository.updateWorkflowStatusforExtension(wfstatusIdForApproved, statusIdForDeactive,
					wfstatusIdForSubmit, statusIdForActive, allocationTranscIdList);

			//sendMailHelperServiceObj.sendEmailForRejectionConfirmation(rmApprovalRejectionDtls, wrkflwCode);
		}

		log.info("Just before leaving ResourceManagementServiceImpl.rejectRMApprovalReqForAlloc method:");
	}
	
	//Edited by Ravi

	@Override
	public CostCardDto getCostCard(CostCardInputDto costCardInputDto) throws ResourceManagementException {
		List<Long> codes=List.of(ResourceManagementConstant.ONSITE_OTHER_1,
				ResourceManagementConstant.ONSITE_OTHER_2,
				ResourceManagementConstant.ONSITE_OTHER_3,
				ResourceManagementConstant.ONSITE_OTHER_4,
				ResourceManagementConstant.ONSITE_OTHER_5);
		
		Long locaionId=costCardInputDto.getLocationId();
		MLocationDto mLocationDto	= adminServiceClient.getlocationCodeBylocationId(locaionId);
		String locationCode = mLocationDto.getLocationCode();
		Long valueOf = Long.valueOf(locationCode);

		if(codes.contains(valueOf)) {
			CostCardDto cardDto=new CostCardDto();
			
			cardDto.setCurrencyName(costCardInputDto.getCurrencyName());
			
			Integer projectCurrency = adminServiceClient.getCurrencyIdByName(cardDto.getCurrencyName());
			Long currencyCode = (long)projectCurrency;
			cardDto.setCurrencyId(currencyCode);
			
			BigDecimal costRate = bapServiceClient.getprojectdetailsByProjreqId(costCardInputDto.getProjectRequirementId());	
			if(costCardInputDto.getProjectBillingHours()==8) {
				cardDto.setEightHrsCostRate(costRate);
			}else {
				cardDto.setNineHrsCostRate(costRate);
			}
			return cardDto;
		}else {
			CostCardDto cardDto= adminServiceClient.getCostCard(costCardInputDto);
			if(null==cardDto.getEightHrsCostRate() && null==cardDto.getNineHrsCostRate()){
				Long projectId = bapServiceClient.getprojectidbyprojectrequirementid(costCardInputDto.getProjectRequirementId());
				boolean budgetandCostCheck = resourceAllocationServiceImplObj
						.getBudgetAndCostCheck(projectId);
				if(budgetandCostCheck) {
					throw new ResourceManagementException(ResourceManagementConstant.STANDARD_COST_RATE);
				}else {
					if(costCardInputDto.getProjectBillingHours()==8) {
						cardDto.setEightHrsCostRate(BigDecimal.ZERO);
					}else {
						cardDto.setNineHrsCostRate(BigDecimal.ZERO);
					}				
					return cardDto;					
				}
			}
			return cardDto;
		}
	}

	//end
	
	public HashBasedTable<String, String, Long> getallWorkflowStatus() throws ResourceManagementException {
		List<ModuleStatusDto> newmoduleList = adminServiceClient
				.getAllModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT);
		HashBasedTable<String, String, Long> workflowtable = HashBasedTable.create();
		for (ModuleStatusDto newtemp : newmoduleList) {
			workflowtable.put(newtemp.getSubModule(), newtemp.getAction(), newtemp.getModuleStatusId());
		}
		return workflowtable;
	}  
	
	
	@Override
	public List<EmployeeDto> getAllEmployeeDetails(String searchParameter) throws ResourceManagementException {
		log.info("Entered into ProjectDefinitionServiceImpl.getAllEmployeeDetails method:");
		return adminServiceClient.getAllEmployeeDetails(searchParameter);
	}  
	
	public static Date getZeroTimeDate(Date dateToConvert) {
	    Date dateToReturn = dateToConvert;
	    Calendar calendar = Calendar.getInstance();

	    calendar.setTime(dateToConvert);
	    calendar.set(Calendar.HOUR_OF_DAY, 0);
	    calendar.set(Calendar.MINUTE, 0);
	    calendar.set(Calendar.SECOND, 0);
	    calendar.set(Calendar.MILLISECOND, 0);

	    dateToReturn = calendar.getTime();

	    return dateToReturn;
	}
	
	/*
	 * public void updatePoolAvailabilityAfterFinalAllocationApproval(Map<Long,
	 * TAssociateProject> poolResourceDetailsMap, Map<Long, TAssociateProject>
	 * tAssociateProjectsMap) throws ResourceManagementException { log.
	 * info("Entered into ResourceManagementServiceImpl.updatePoolAvailabilityAfterFinalAllocationApproval method:"
	 * ); long deactivateStatusId =
	 * getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
	 * ResourceManagementConstant.DEACTIVATE); long deAllocApprovedStatusId =
	 * getModuleStatusId(ResourceManagementConstant.RESOURCE_DEALLOCATION,
	 * ResourceManagementConstant.APPROVED); long allocApprovedStatusId =
	 * getModuleStatusId(ResourceManagementConstant.RESOURCE_ALLOCATION,
	 * ResourceManagementConstant.APPROVED); Date actualApprovalDate = new
	 * Date(System.currentTimeMillis());
	 * 
	 * for (Map.Entry<Long, TAssociateProject> tAssociateProjectDtoEntry :
	 * poolResourceDetailsMap.entrySet()) { Long key =
	 * tAssociateProjectDtoEntry.getKey(); TAssociateProject
	 * poolResourceTAssociateProject = tAssociateProjectDtoEntry.getValue();
	 * TAssociateProject allocationResourceTAssociateProject =
	 * tAssociateProjectsMap.get(key); Date actualAllocationStartDate =
	 * allocationResourceTAssociateProject.getTAssociateAllocation().
	 * getActualAllocationStartDate(); Integer dateCheck =
	 * getZeroTimeDate(actualAllocationStartDate).compareTo(getZeroTimeDate(
	 * actualApprovalDate));
	 * 
	 * if(dateCheck == 0) { //same day allocation
	 * setPoolAvailabilityObject(deactivateStatusId, allocApprovedStatusId,
	 * poolResourceTAssociateProject, allocationResourceTAssociateProject,
	 * actualAllocationStartDate); } else if (dateCheck > 0) { //future allocations
	 * log.
	 * info("Entered into ResourceManagementServiceImpl.updatePoolAvailabilityAfterFinalAllocationApproval method : Future Allocation"
	 * ); if(poolResourceTAssociateProject.getTAssociateAllocation().getFtePercent()
	 * ==
	 * allocationResourceTAssociateProject.getTAssociateAllocation().getFtePercent()
	 * ) { //poolResourceTAssociateProject.setStatusId(deactivateStatusId);
	 * poolResourceTAssociateProject.setEffectiveEndDate(new
	 * Date(actualAllocationStartDate.getTime() -
	 * ResourceManagementConstant.ONE_DAY));
	 * associateProjectRepository.save(poolResourceTAssociateProject);
	 * 
	 * TAssociateAllocation tAssociateAllocation =
	 * poolResourceTAssociateProject.getTAssociateAllocation();
	 * //tAssociateAllocation.setStatusId(deactivateStatusId);
	 * tAssociateAllocation.setWorkflowStatusId(deAllocApprovedStatusId);
	 * tAssociateAllocation.setEffectiveEndDate(new
	 * Date(actualAllocationStartDate.getTime() -
	 * ResourceManagementConstant.ONE_DAY));
	 * tAssociateAllocation.setActualAllocationEndDate(new
	 * Date(actualAllocationStartDate.getTime() -
	 * ResourceManagementConstant.ONE_DAY));
	 * tAssociateAllocationRepository.save(tAssociateAllocation); } else {
	 * TAssociateProject poolResourceTAssociateProjectNew =
	 * createDuplicateAssociateProjectDetails(poolResourceTAssociateProject);
	 * TAssociateAllocation tAssociateAllocationNew =
	 * createDuplicateAssociateAllocationDetails(poolResourceTAssociateProjectNew.
	 * getTAssociateAllocation());
	 * 
	 * //poolResourceTAssociateProject.setStatusId(deactivateStatusId);
	 * poolResourceTAssociateProject.setEffectiveEndDate(new
	 * Date(actualAllocationStartDate.getTime() -
	 * ResourceManagementConstant.ONE_DAY));
	 * associateProjectRepository.save(poolResourceTAssociateProject);
	 * 
	 * TAssociateAllocation tAssociateAllocation =
	 * poolResourceTAssociateProject.getTAssociateAllocation();
	 * //tAssociateAllocation.setStatusId(deactivateStatusId);
	 * tAssociateAllocation.setWorkflowStatusId(deAllocApprovedStatusId);
	 * tAssociateAllocation.setEffectiveEndDate(new
	 * Date(actualAllocationStartDate.getTime() -
	 * ResourceManagementConstant.ONE_DAY));
	 * tAssociateAllocation.setActualAllocationEndDate(new
	 * Date(actualAllocationStartDate.getTime() -
	 * ResourceManagementConstant.ONE_DAY));
	 * tAssociateAllocationRepository.save(tAssociateAllocation);
	 * 
	 * //New Pool record poolResourceTAssociateProjectNew.setEffectiveStartDate(
	 * actualAllocationStartDate); double poolFtePercentage =
	 * poolResourceTAssociateProjectNew.getTAssociateAllocation().getFtePercent();
	 * poolResourceTAssociateProjectNew.setTAssociateAllocation(null);
	 * poolResourceTAssociateProjectNew =
	 * associateProjectRepository.save(poolResourceTAssociateProjectNew);
	 * 
	 * tAssociateAllocationNew.setFtePercent(poolFtePercentage -
	 * allocationResourceTAssociateProject.getTAssociateAllocation().getFtePercent()
	 * ); tAssociateAllocationNew.setEffectiveStartDate(actualAllocationStartDate);
	 * //tAssociateAllocationNew.setWorkflowStatusId(allocApprovedStatusId);
	 * tAssociateAllocationNew.setTAssociateProject(poolResourceTAssociateProjectNew
	 * ); tAssociateAllocationRepository.save(tAssociateAllocationNew); } } else if
	 * (dateCheck < 0) { //backdated allocations
	 * setPoolAvailabilityObject(deactivateStatusId, allocApprovedStatusId,
	 * poolResourceTAssociateProject, allocationResourceTAssociateProject,
	 * actualAllocationStartDate); } } log.
	 * info("Exiting ResourceManagementServiceImpl.updatePoolAvailabilityAfterFinalAllocationApproval method:"
	 * ); }
	 * 
	 * public void setPoolAvailabilityObject(long deactivateStatusId, long
	 * allocApprovedStatusId, TAssociateProject poolResourceTAssociateProject,
	 * TAssociateProject allocationResourceTAssociateProject, Date
	 * actualAllocationStartDate) { log.
	 * info("Entered into ResourceManagementServiceImpl.updatePoolAvailabilityAfterFinalAllocationApproval method : Same day Allocation"
	 * ); if(poolResourceTAssociateProject.getTAssociateAllocation().getFtePercent()
	 * ==
	 * allocationResourceTAssociateProject.getTAssociateAllocation().getFtePercent()
	 * ) { poolResourceTAssociateProject.setStatusId(deactivateStatusId);
	 * poolResourceTAssociateProject.setEffectiveEndDate(new
	 * Date(actualAllocationStartDate.getTime() -
	 * ResourceManagementConstant.ONE_DAY));
	 * associateProjectRepository.save(poolResourceTAssociateProject);
	 * 
	 * TAssociateAllocation tAssociateAllocation =
	 * poolResourceTAssociateProject.getTAssociateAllocation();
	 * tAssociateAllocation.setStatusId(deactivateStatusId);
	 * tAssociateAllocation.setWorkflowStatusId(allocApprovedStatusId);
	 * tAssociateAllocation.setEffectiveEndDate(new
	 * Date(actualAllocationStartDate.getTime() -
	 * ResourceManagementConstant.ONE_DAY));
	 * tAssociateAllocation.setActualAllocationEndDate(new
	 * Date(actualAllocationStartDate.getTime() -
	 * ResourceManagementConstant.ONE_DAY));
	 * tAssociateAllocationRepository.save(tAssociateAllocation); } else {
	 * TAssociateProject poolResourceTAssociateProjectNew =
	 * createDuplicateAssociateProjectDetails(poolResourceTAssociateProject);
	 * TAssociateAllocation tAssociateAllocationNew =
	 * createDuplicateAssociateAllocationDetails(poolResourceTAssociateProjectNew.
	 * getTAssociateAllocation());
	 * 
	 * poolResourceTAssociateProject.setStatusId(deactivateStatusId);
	 * poolResourceTAssociateProject.setEffectiveEndDate(new
	 * Date(actualAllocationStartDate.getTime() -
	 * ResourceManagementConstant.ONE_DAY));
	 * associateProjectRepository.save(poolResourceTAssociateProject);
	 * 
	 * TAssociateAllocation tAssociateAllocation =
	 * poolResourceTAssociateProject.getTAssociateAllocation();
	 * tAssociateAllocation.setStatusId(deactivateStatusId);
	 * tAssociateAllocation.setWorkflowStatusId(allocApprovedStatusId);
	 * tAssociateAllocation.setEffectiveEndDate(new
	 * Date(actualAllocationStartDate.getTime() -
	 * ResourceManagementConstant.ONE_DAY));
	 * tAssociateAllocation.setActualAllocationEndDate(new
	 * Date(actualAllocationStartDate.getTime() -
	 * ResourceManagementConstant.ONE_DAY));
	 * tAssociateAllocationRepository.save(tAssociateAllocation);
	 * 
	 * //New Pool record poolResourceTAssociateProjectNew.setEffectiveStartDate(
	 * actualAllocationStartDate); double poolFtePercentage =
	 * poolResourceTAssociateProjectNew.getTAssociateAllocation().getFtePercent();
	 * poolResourceTAssociateProjectNew.setTAssociateAllocation(null);;
	 * poolResourceTAssociateProjectNew =
	 * associateProjectRepository.save(poolResourceTAssociateProjectNew);
	 * 
	 * tAssociateAllocationNew.setFtePercent(poolFtePercentage -
	 * allocationResourceTAssociateProject.getTAssociateAllocation().getFtePercent()
	 * ); tAssociateAllocationNew.setEffectiveStartDate(actualAllocationStartDate);
	 * tAssociateAllocationNew.setTAssociateProject(poolResourceTAssociateProjectNew
	 * ); tAssociateAllocationRepository.save(tAssociateAllocationNew); } }
	 */
	
	/*
	 * public TAssociateProject
	 * createDuplicateAssociateProjectDetails(TAssociateProject
	 * poolResourceTAssociateProject) { TAssociateProject newAssociateProject = new
	 * TAssociateProject(); newAssociateProject.setAssociateProjectId(null);
	 * newAssociateProject.setEmployeeId(poolResourceTAssociateProject.getEmployeeId
	 * ()); newAssociateProject.setSrfId(poolResourceTAssociateProject.getSrfId());
	 * newAssociateProject.setProjectId(poolResourceTAssociateProject.getProjectId()
	 * ); newAssociateProject.setSupervisorId(poolResourceTAssociateProject.
	 * getSupervisorId());
	 * newAssociateProject.setIsPrimaryProject(poolResourceTAssociateProject.
	 * getIsPrimaryProject());
	 * newAssociateProject.setStatusId(poolResourceTAssociateProject.getStatusId());
	 * newAssociateProject.setCreatedBy(poolResourceTAssociateProject.getCreatedBy()
	 * ); newAssociateProject.setLastUpdatedBy(poolResourceTAssociateProject.
	 * getLastUpdatedBy());
	 * newAssociateProject.setCreatedDate(poolResourceTAssociateProject.
	 * getCreatedDate());
	 * newAssociateProject.setLastUpdatedDate(poolResourceTAssociateProject.
	 * getLastUpdatedDate());
	 * newAssociateProject.setEffectiveStartDate(poolResourceTAssociateProject.
	 * getEffectiveStartDate());
	 * newAssociateProject.setEffectiveEndDate(poolResourceTAssociateProject.
	 * getEffectiveEndDate());
	 * newAssociateProject.setTAssociateAllocation(poolResourceTAssociateProject.
	 * getTAssociateAllocation()); return newAssociateProject; }
	 * 
	 * public TAssociateAllocation
	 * createDuplicateAssociateAllocationDetails(TAssociateAllocation
	 * tAssociateAllocation) { TAssociateAllocation tAssociateAllocationNew = new
	 * TAssociateAllocation();
	 * tAssociateAllocationNew.setAssociateAllocationId(null);
	 * tAssociateAllocationNew.setRoleId(tAssociateAllocation.getRoleId());
	 * tAssociateAllocationNew.setRequirementId(tAssociateAllocation.
	 * getRequirementId());
	 * tAssociateAllocationNew.setWorkLocationId(tAssociateAllocation.
	 * getWorkLocationId());
	 * tAssociateAllocationNew.setBillableStatusId(tAssociateAllocation.
	 * getBillableStatusId());
	 * tAssociateAllocationNew.setBillableStatusReasonId(tAssociateAllocation.
	 * getBillableStatusReasonId());
	 * tAssociateAllocationNew.setWorkflowReasonId(tAssociateAllocation.
	 * getWorkflowReasonId());
	 * tAssociateAllocationNew.setEstAllocationEndDate(tAssociateAllocation.
	 * getEstAllocationEndDate());
	 * tAssociateAllocationNew.setActualAllocationStartDate(tAssociateAllocation.
	 * getActualAllocationStartDate());
	 * tAssociateAllocationNew.setActualAllocationEndDate(tAssociateAllocation.
	 * getActualAllocationEndDate());
	 * tAssociateAllocationNew.setBaseHours(tAssociateAllocation.getBaseHours());
	 * tAssociateAllocationNew.setFtePercent(tAssociateAllocation.getFtePercent());
	 * tAssociateAllocationNew.setRemarks(tAssociateAllocation.getRemarks());
	 * tAssociateAllocationNew.setWorkflowStatusId(tAssociateAllocation.
	 * getWorkflowStatusId());
	 * tAssociateAllocationNew.setStatusId(tAssociateAllocation.getStatusId());
	 * tAssociateAllocationNew.setCreatedBy(tAssociateAllocation.getCreatedBy());
	 * tAssociateAllocationNew.setLastUpdatedBy(tAssociateAllocation.
	 * getLastUpdatedBy());
	 * tAssociateAllocationNew.setCreatedDate(tAssociateAllocation.getCreatedDate())
	 * ; tAssociateAllocationNew.setLastUpdatedDate(tAssociateAllocation.
	 * getLastUpdatedDate());
	 * tAssociateAllocationNew.setEffectiveStartDate(tAssociateAllocation.
	 * getEffectiveStartDate());
	 * tAssociateAllocationNew.setEffectiveEndDate(tAssociateAllocation.
	 * getEffectiveEndDate());
	 * tAssociateAllocationNew.setTransactionHistoryId(tAssociateAllocation.
	 * getTransactionHistoryId());
	 * tAssociateAllocationNew.setAllocationTypeId(tAssociateAllocation.
	 * getAllocationTypeId());
	 * tAssociateAllocationNew.setCapHours(tAssociateAllocation.getCapHours());
	 * tAssociateAllocationNew.setSkillChampionFlag(tAssociateAllocation.
	 * getSkillChampionFlag());
	 * tAssociateAllocationNew.setSupervisorId(tAssociateAllocation.getSupervisorId(
	 * )); tAssociateAllocationNew.setSkillId(tAssociateAllocation.getSkillId());
	 * tAssociateAllocationNew.setSrReference(tAssociateAllocation.getSrReference())
	 * ; tAssociateAllocationNew.setStdCost(tAssociateAllocation.getStdCost());
	 * tAssociateAllocationNew.setServiceLineId(tAssociateAllocation.
	 * getServiceLineId());
	 * tAssociateAllocationNew.setTAssociateProject(tAssociateAllocation.
	 * getTAssociateProject());
	 * tAssociateAllocationNew.setTAssociateAllocationBudget(tAssociateAllocation.
	 * getTAssociateAllocationBudget()); return tAssociateAllocationNew; }
	 */

	//Added by Mrunal Marne for milestone selection while resource allocation
	@Override
	public List<PoAndMilestoneDetailsDto> getPoAndMilestoneDetailsByProjectId(Long projectId, String allocStartDate, String allocEndDate) throws ResourceManagementException {
		if(Objects.isNull(projectId) || projectId == 0)
			throw new ResourceManagementException(ResourceManagementConstant.PROJECT_ID_VALID);
		else
			return bapServiceClient.getPoAndMilestoneDetailsByProjectId(projectId, allocStartDate, allocEndDate);
	}
	
	//Added by Mrunal Marne for RMG Tagging
	/*@Override
	public  List<LookupValueDto> getRMGTypeDetailsDtos() throws ResourceManagementException {		
		return adminServiceClient.getLookupValueByLookupType(ResourceManagementConstant.RMG_TYPE);
	}
	
	@Override
	public TAssociateRmgTagDto getRmgTagging(Long employeeNumber) throws ResourceManagementException {
		Long statusIdForActive = adminServiceClient.getModuleStatusByAction(ResourceManagementConstant.RMG_TAGGING_MODULE,
				ResourceManagementConstant.ACTIVATE);
		TAssociateRmgTagDto associateRmgTagDto = tAssociateRmgTagMapper.associateRmgTagToAssociateRmgTagDto(
				associateRmgTagRepository.getRmgTaggingDetailsForEmployee(employeeNumber, statusIdForActive));
		if(Objects.isNull(associateRmgTagDto))
			throw new ResourceManagementException(ResourceManagementConstant.NO_RMG_TAGGING_DONE);
		return associateRmgTagDto;
	}
	
	@Override
	public TAssociateRmgTagDto saveRmgTagging(TAssociateRmgTagDto rmgTaggingRequestDto) throws ResourceManagementException, ParseException {
		Long statusIdForActive = adminServiceClient.getModuleStatusByAction(ResourceManagementConstant.RMG_TAGGING_MODULE,
				ResourceManagementConstant.ACTIVATE);
		rmgTaggingRequestDto.setEffectiveEndDate(sdf.parse(ResourceManagementConstant.DEFAULT_EFFECTIVE_END_DATE));	
		rmgTaggingRequestDto.setStatusId(statusIdForActive);
		rmgTaggingRequestDto.setLastUpdatedBy(rmgTaggingRequestDto.getCreatedBy());
		rmgTaggingRequestDto.setLastUpdatedDate(rmgTaggingRequestDto.getLastUpdatedDate());
		associateRmgTagRepository.save(tAssociateRmgTagMapper.associateRmgTagDtoToAssociateRmgTag(rmgTaggingRequestDto));
		return null;
	}*/
	//End by Mrunal Marne
	

}
