package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class MailTemplateDto {
	
	private String subject;
	
	private String messageBodyHeader;
	
	private String messageBodyContent;
	
	private String messageBodyFooter;
	
	private String messageBodyTable;
	
	private String tableColumnNames;

}
