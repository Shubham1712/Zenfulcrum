package com.zensar.zenfulcrum.resourcemanagement.rest.client;

import static java.util.Optional.ofNullable;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class AuthServiceClient {

	@Autowired
	private RestTemplate restTemplate;

	@Value("${AUTH.VALIDATE.TOKEN}")
	private String validateAccessTokenRestURL;

	@Value("${AUTH.SERVICE.BASE.URL}")
	private String authServiceBaseUrl;

	public boolean validateAccessToken(String tokenVal, String userId, String userSessionId)throws ResourceManagementException {
		log.info("Entered into AuthServiceClient.validateAccessToken method:");
		HttpHeaders headers = new HttpHeaders();
		headers.add("zfUserId", userId);
		headers.add("zfAccessToken", tokenVal);
		headers.add("zfUserSessionId", userSessionId);
		HttpEntity<String> requestEntityObj = new HttpEntity<>(headers);
		boolean validationResponse = false;
		String url = authServiceBaseUrl + validateAccessTokenRestURL;
		try {
			ResponseEntity<Boolean> validationResponseObj = restTemplate.postForEntity(url, requestEntityObj, Boolean.class);
			if (HttpStatus.Series.valueOf(validationResponseObj.getStatusCode()) == HttpStatus.Series.SUCCESSFUL) {
				Optional<Boolean> validationResponseOptnObj = ofNullable(validationResponseObj.getBody());
				if (validationResponseOptnObj.isPresent()) {
					validationResponse = validationResponseOptnObj.get();
				}
			}
		} catch (ResourceAccessException rae) {
			log.error("validateAccessToken|url:{}|ResourceAccessException:{}", validateAccessTokenRestURL, rae);
			throw new ResourceManagementException(rae);
		} catch (HttpClientErrorException | HttpServerErrorException hcee) {
			log.error("validateAccessToken|url:{}|exception:{}", validateAccessTokenRestURL, hcee);
			throw new ResourceManagementException(hcee);
		}
		log.info("Just before leaving AdminServiceClient.validateAccessToken method:");
		return validationResponse;
	}

}
