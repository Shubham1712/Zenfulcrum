package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class PracticeDto implements Comparable<PracticeDto>{

	private long practiceId;
	private String practiceCode;
	private String practiceName;
	@Override
	public int compareTo(PracticeDto pd) {
		return this.practiceName.compareTo(pd.practiceName);
	}
}
