package com.zensar.zenfulcrum.resourcemanagement.projection;

public interface ReservedAssociateProjection {
	public long getrequirementId();
	public Integer getreservedAssociateCount();
	public void setrequirementId(long i);
	public void setreservedAssociateCount(Integer i);
}
