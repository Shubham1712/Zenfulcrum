package com.zensar.zenfulcrum.resourcemanagement.dto;

import javax.persistence.Column;

import lombok.Data;

@Data
public class MProjectDetailDto {
	
	private Long projectId;
	private Double totalCost;
	private Double totalRevenue;
	private Long fte;
}
