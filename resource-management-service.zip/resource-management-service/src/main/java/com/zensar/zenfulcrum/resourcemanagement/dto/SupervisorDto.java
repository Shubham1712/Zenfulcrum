package com.zensar.zenfulcrum.resourcemanagement.dto;


import java.util.List;

import lombok.Data;

@Data
public class SupervisorDto {

	private Long supervisorId;
	private String supervisorName;
	private Long employeeNumber;
	private Long projectId;
	private List<Long> employeeIds;
}
