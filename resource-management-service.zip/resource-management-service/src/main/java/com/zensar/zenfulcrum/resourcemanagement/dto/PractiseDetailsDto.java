package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;

import lombok.Data;

@Data
public class PractiseDetailsDto {

	private int allocationId;
	private int empId;
	private String employeeName;
	
	private Integer practiseId;
	
	private String practise;
	private String skills;
	
	private Integer employeeRoleId;
	private String role;
	
	private Integer employeeLocationId;
	private String location;
	
	private Date practiceAllocationStartDate;
	private Date practiceAllocationEndDate;
}
