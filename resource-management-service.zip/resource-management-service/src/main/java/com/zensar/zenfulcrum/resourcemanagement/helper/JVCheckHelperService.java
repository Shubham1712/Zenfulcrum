package com.zensar.zenfulcrum.resourcemanagement.helper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JVCheckHelperService {
	
	public Boolean isJvCheck(Date jvDate) throws ResourceManagementException, ParseException {
		log.info("Entered into JVCheckHelperService.isJvCheck method:");
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Boolean check=false;
		Date currentDate = formatter.parse(formatter.format(jvDate));
		LocalDate date = LocalDate.ofInstant(currentDate.toInstant(), ZoneId.systemDefault());
		Date current =new Date();
		if(date.compareTo(java.time.LocalDate.now())==0 && current.getTime() > jvDate.getTime() || current.getTime()==jvDate.getTime()) {
				check=true;
						}
		return check;
	}
	
	public Boolean isJvCheckForSearch(Date jvDate,Date lastEffectiveDate,Date effectiveStartDate) throws ResourceManagementException, ParseException {
		log.info("Entered into JVCheckHelperService.isJvCheck method:");
		Boolean check=false;
		if(effectiveStartDate.after(jvDate)  && effectiveStartDate.after(lastEffectiveDate) ) {
				check=true;
		}
		return check;
	}
}
