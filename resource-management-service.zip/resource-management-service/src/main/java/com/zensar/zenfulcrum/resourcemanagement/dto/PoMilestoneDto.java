package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class PoMilestoneDto {

	private int  poMilestoneId;
	private String poMilestoneName;
}
