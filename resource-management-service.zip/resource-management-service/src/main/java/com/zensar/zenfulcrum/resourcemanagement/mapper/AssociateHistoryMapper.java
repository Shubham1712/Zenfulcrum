package com.zensar.zenfulcrum.resourcemanagement.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateHistoryReportDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ConfluenceAllocData;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocDataProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AssociateHistoryProjecation;

@Mapper(componentModel = "spring")
@Component
public interface AssociateHistoryMapper {

	List<AssociateHistoryReportDto> associateHistoryProjecationToAssociateHistoryReportDto(List<AssociateHistoryProjecation> associateHistoryProjecationList);
	
	List<ConfluenceAllocData> allocDataProjectionToConfluenceAllocData(List<AllocDataProjection> allocDataList);
	
}
