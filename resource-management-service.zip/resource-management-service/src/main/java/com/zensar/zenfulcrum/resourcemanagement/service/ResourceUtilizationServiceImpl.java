package com.zensar.zenfulcrum.resourcemanagement.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDetailsDTO;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.QuarterDetailDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceUtilizationSummaryDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UtilizationDetailDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UtilizationProjectDetails;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.mapper.UtilizationMapper;
import com.zensar.zenfulcrum.resourcemanagement.projection.ProjectDetailsProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.TAssociateProjectAndAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class ResourceUtilizationServiceImpl implements ResourceUtilizationService{

	@Autowired
	private AdminServiceClient adminServiceClient;
	@Autowired
	private BAPServiceClient bAPServiceClient;
	@Autowired
	private TAssociateAllocationRepository tAssociateAllocationRepository;
	@Autowired
	private UtilizationMapper utilizationMapper;
	@Autowired
	TAssociateProjectRepository tAssociateProjectRepository;
	
	SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd"); 
	
	@Override
	public List<QuarterDetailDto> getQuarterDetailsForYear() throws ResourceManagementException, ParseException {
		log.info("Start getQuarterDetailsForYear");
		List<QuarterDetailDto> quarterDetailDtoList = new ArrayList<>();
		List<LookupValueDto> lookupValueDtoList = adminServiceClient.getLookupValueByLookupType(ResourceManagementConstant.Quarter);
		for(LookupValueDto lookupValueDto: lookupValueDtoList) {
			QuarterDetailDto quarterDetailDto = new QuarterDetailDto();
			quarterDetailDto.setQuarterName(lookupValueDto.getLookupValueCode());
			quarterDetailDto.setQuarterId(lookupValueDto.getLookUpId());
			quarterDetailDto.setStartDate(sdformat.parse(lookupValueDto.getLookupValueDescription()));
			quarterDetailDto.setEndDate(sdformat.parse(lookupValueDto.getLookupValueName()));
			quarterDetailDtoList.add(quarterDetailDto);
		}
		log.info("End getQuarterDetailsForYear");
		return quarterDetailDtoList;
	}

	@Override
	public UtilizationDetailDto getResourceUtilization(Long empId, String startDateStr, String endDateStr) throws ResourceManagementException, ParseException {
		log.info("Start getResourceUtilization");
		Date startDate = sdformat.parse(startDateStr);
		Date endDate = sdformat.parse(endDateStr);
		UtilizationDetailDto utilizationDetailDto = new UtilizationDetailDto();
		
		EmployeeDetailsDTO employeeDetails = adminServiceClient.getEmployeeDetailsByEmployeeNumber(empId);
		
		 List<ProjectDetailsProjection> allocatedResourceProjectionList = tAssociateAllocationRepository.findByAllocationDateAndEmpId(employeeDetails.getEmployeeId(),startDate,endDate);
		 List<UtilizationProjectDetails> utilizationProjectDetailsList = utilizationMapper.projectDetailsProjectionListToUtilizationProjectDetails(allocatedResourceProjectionList);
	
		if(CollectionUtils.isNotEmpty(utilizationProjectDetailsList)) {
			List<ProjectDto> projectDtoList = bAPServiceClient.getProjectDetailByIds(utilizationProjectDetailsList.stream().map(UtilizationProjectDetails::getProjectId).collect(Collectors.toList()));
			Map<Long,ProjectDto> projectMap = projectDtoList.stream().collect(HashMap::new, (m,v)->m.put(v.getProjectId(),v), HashMap::putAll);
			
			utilizationProjectDetailsList.stream().forEach(i->i.setProjectCode(projectMap.get(i.getProjectId()).getProjectCode()));
			utilizationProjectDetailsList.stream().forEach(i->i.setProjectName(projectMap.get(i.getProjectId()).getProjectName()));
			
			utilizationDetailDto = adminServiceClient.getUtilizationDetails(utilizationProjectDetailsList);

			utilizationDetailDto.setAverageUtilization(getAverageUtilization(utilizationProjectDetailsList,startDate,endDate));
		}
		log.info("End getResourceUtilization");
		return utilizationDetailDto;
	}

	private Double getAverageUtilization(List<UtilizationProjectDetails> utilizationProjectDetailsList, Date startDate, Date endDate) throws ParseException {
		log.info("Start getAverageUtilization");
		int totalNoOfDays = calculateDaysSubSatSun(startDate,endDate);
		Double sumOfUtilizationOfAllPrjt = 0D;
	   
		SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
		for(UtilizationProjectDetails utilizationProjectDetails:utilizationProjectDetailsList) {
			
			Date date1 = utilizationProjectDetails.getActualAllocationStartDate();
		 	Date date2 = sdformat.parse("1111-11-11");
		 	
		 	if(utilizationProjectDetails.getActualAllocationEndDate().compareTo(date2) != 0){
		 		date2 = utilizationProjectDetails.getActualAllocationEndDate();
		 	}else {
		 		date2 = utilizationProjectDetails.getEstAllocationEndDate();
		 	}
		 	Date sendStartDate;
		 	Date sendEndDate;
		 	
		 	if(startDate.before(date1) ) {
		 		sendStartDate = date1;
		 	}else if (startDate.after(date1)) {
		 		sendStartDate = startDate;
			}else if (startDate.equals(endDate)) {
				sendStartDate = startDate;
			}else {
				sendStartDate = startDate;
			}
		 	
		 	if(endDate.before(date2)) {
		 		sendEndDate = endDate;
		 	}else if (endDate.after(date2)) {
		 		sendEndDate = date2;
			}else if (endDate.equals(date2)) {
				sendEndDate = endDate;
			}else {
				sendEndDate = endDate;
			}
		 	
		    int numberOfDays = calculateDaysSubSatSun(sendStartDate,sendEndDate);
		    double utilizationOfProject = (double)utilizationProjectDetails.getProjectUtilization();
		    int utilizationOfProjectInt = (int)utilizationOfProject;
		    Double utilizationForProject = (double) (utilizationOfProjectInt*numberOfDays);
			sumOfUtilizationOfAllPrjt += utilizationForProject;
		}
		log.info("End getAverageUtilization");
		double avgUtilization =totalNoOfDays!=0&sumOfUtilizationOfAllPrjt!=0?sumOfUtilizationOfAllPrjt/totalNoOfDays:0;
		return (double) Math.round(avgUtilization);
	}
	
	// To get Utilization days substracting saturday and sunday
	private int calculateDaysSubSatSun(Date calStartDate, Date calEndDate) {
		Calendar cal1 = Calendar.getInstance();
	    Calendar cal2 = Calendar.getInstance();
	    cal1.setTime(calStartDate);
	    cal2.setTime(calEndDate);
	    int numberOfDays = 0;
	    while (cal1.before(cal2)) {
	        if ((Calendar.SATURDAY != cal1.get(Calendar.DAY_OF_WEEK))
	           &&(Calendar.SUNDAY != cal1.get(Calendar.DAY_OF_WEEK))) {
	            numberOfDays++;
	        }
	        cal1.add(Calendar.DATE,1);
	    }
	    System.out.println("numberOfDays = "+numberOfDays);
	    return numberOfDays;
	}
	
	@Override
	public ResourceUtilizationSummaryDto getResourceUtilizationSummaryDetails(Long projectId)
			throws ResourceManagementException {
		ResourceUtilizationSummaryDto resourceUtilizationSummaryDto = null;
		List<TAssociateProjectAndAllocationProjection> resourceUtilizationSummaryDetails = tAssociateProjectRepository
				.getResourceUtilizationSummaryDetails(projectId);
		if (resourceUtilizationSummaryDetails != null) {
			Set<Long> billableStatusIds = resourceUtilizationSummaryDetails.stream()
					.filter(data -> data.getbillableStatusId() != null)
					.map(TAssociateProjectAndAllocationProjection::getbillableStatusId).collect(Collectors.toSet());
			if (billableStatusIds != null) {
				List<LookupValueDto> lookUpValueDetailsByIds = adminServiceClient
						.getLookUpValueDetailsByIds(new ArrayList<>(billableStatusIds));
				if (lookUpValueDetailsByIds != null) {
					Map<Long, String> idAndBillableEbrStatus = lookUpValueDetailsByIds.stream()
							.collect(Collectors.toMap(LookupValueDto::getLookUpId, LookupValueDto::getLookupValueCode));

					double billableFTE = resourceUtilizationSummaryDetails.stream()
							.filter(x -> idAndBillableEbrStatus.containsKey(x.getbillableStatusId())
									&& ResourceManagementConstant.VALUE_BILLABLE_STATUS
											.equalsIgnoreCase(idAndBillableEbrStatus.get(x.getbillableStatusId())))
							.mapToDouble(TAssociateProjectAndAllocationProjection::getftePercent).sum();

					double nonBillableFTE = resourceUtilizationSummaryDetails.stream()
							.filter(x -> idAndBillableEbrStatus.containsKey(x.getbillableStatusId())
									&& ResourceManagementConstant.Non_Billable
											.equalsIgnoreCase(idAndBillableEbrStatus.get(x.getbillableStatusId())))
							.mapToDouble(TAssociateProjectAndAllocationProjection::getftePercent).sum();

					double ebrFTE = resourceUtilizationSummaryDetails.stream()
							.filter(x -> idAndBillableEbrStatus.containsKey(x.getbillableStatusId())
									&& ResourceManagementConstant.Ebr
											.equalsIgnoreCase(idAndBillableEbrStatus.get(x.getbillableStatusId())))
							.mapToDouble(TAssociateProjectAndAllocationProjection::getftePercent).sum();

					double totalResourceFTE = resourceUtilizationSummaryDetails.stream()
							.filter(x -> x.getftePercent() != null)
							.mapToDouble(TAssociateProjectAndAllocationProjection::getftePercent).sum();

					resourceUtilizationSummaryDto = new ResourceUtilizationSummaryDto();
					BigDecimal totalResourceFTEValue = BigDecimal.valueOf(totalResourceFTE / 100).setScale(2,
							RoundingMode.HALF_UP);

					resourceUtilizationSummaryDto.setBillableResourceFTE(
							BigDecimal.valueOf(billableFTE / 100).setScale(2, RoundingMode.HALF_UP));
					resourceUtilizationSummaryDto.setNonBillableResourceFTE(
							BigDecimal.valueOf(nonBillableFTE / 100).setScale(2, RoundingMode.HALF_UP));
					resourceUtilizationSummaryDto
							.setEbrResourceFTE(BigDecimal.valueOf(ebrFTE / 100).setScale(2, RoundingMode.HALF_UP));
					resourceUtilizationSummaryDto.setTotalResourceFTE(totalResourceFTEValue);
					resourceUtilizationSummaryDto.setDeliveryResourceAllocationFTE(totalResourceFTEValue);
				}
			}
		}
		return resourceUtilizationSummaryDto;
	}
}
