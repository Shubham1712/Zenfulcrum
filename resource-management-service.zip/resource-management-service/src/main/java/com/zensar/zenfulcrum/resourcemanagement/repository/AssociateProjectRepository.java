package com.zensar.zenfulcrum.resourcemanagement.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateProject;

@Repository
public interface AssociateProjectRepository extends JpaRepository<TAssociateProject, Long>  {


	@Modifying
	@Transactional
	@Query( value ="UPDATE `T_ASSOCIATE_PROJECT` SET STATUS_ID = :statusId, effective_end_date=:effectiveEndDate WHERE PROJECT_ID = :projectId", nativeQuery = true)
	void setStatusIdForProject(@Param("statusId") long statusId,@Param("projectId") long projectId, @Param("effectiveEndDate") Date effectiveEndDate) throws ResourceManagementException;
	
	@Modifying
	@Transactional
	@Query( value ="UPDATE `T_ASSOCIATE_PROJECT` SET STATUS_ID = :statusId, EFFECTIVE_END_DATE = NOW() WHERE PROJECT_ID = :projectId", nativeQuery = true)
	void setStatusFIdForProject(@Param("statusId") long statusId,@Param("projectId") long projectId) throws ResourceManagementException;
	
	//Added by Mrunal Marne for removing records for RM transfer saved on rejection by Project Manager
	@Modifying
	@Transactional
	@Query( value ="DELETE FROM T_ASSOCIATE_PROJECT WHERE `associate_project_id` IN (:targetAssociateProjectIdList)", nativeQuery = true)
	void removeSavedResourceFromTransfer(@Param("targetAssociateProjectIdList") List<Long> targetAssociateProjectIdList) 
			throws ResourceManagementException;
	
	//Added by Mrunal Marne for removing records for RM allocation saved on rejection by Project Manager
	@Modifying
	@Transactional
	@Query( value ="DELETE FROM T_ASSOCIATE_PROJECT WHERE EMPLOYEE_ID IN (:resourceIdList) AND PROJECT_ID =:projectId and status_id = :statusIdForActivate", nativeQuery = true)
	void removeSavedResourceFromRMAllocation(@Param("resourceIdList") List<Long> resourceIdList, 
			@Param("projectId") long projectId, @Param("statusIdForActivate") long statusIdForActivate) 
			throws ResourceManagementException;
	//End by Mrunal
	
}
