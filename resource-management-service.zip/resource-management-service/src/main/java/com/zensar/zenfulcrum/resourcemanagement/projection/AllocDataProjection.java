package com.zensar.zenfulcrum.resourcemanagement.projection;

import java.util.Date;

public interface AllocDataProjection {

	public Long getEmpNum(); 
	public String getEmpName(); 
	public Date getPraEstEndDate(); 
	public Date getPraActStartDate(); 
	public Date getPraActEndDate(); 
	public String getProjectName(); 
	public String getProjectCode(); 
	public String getProjectId();
	
	public void setEmpNum(Long empNum); 
	public void setEmpName(String empName);
	public void setPraEstEndDate(Date praEstEndDate); 
	public void setPraActStartDate(Date praActStartDate);
	public void setPraActEndDate(Date praActEndDate); 
	public void setProjectName(String projectName); 
	public void setProjectCode(String projectCode); 
	public void setProjectId(Long projectId);
	
}
