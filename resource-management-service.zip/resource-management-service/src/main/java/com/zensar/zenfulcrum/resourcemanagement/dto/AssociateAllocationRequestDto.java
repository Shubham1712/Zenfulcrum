package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.List;

import lombok.Data;

@Data
public class AssociateAllocationRequestDto {

	public List<Long> projectIds;
	
}
