package com.zensar.zenfulcrum.resourcemanagement.projection;


public interface GetResourceReqProjection {
	
	public Long getRequirementId();
	public Double getAllocatedFte();
	public void setRequirementId(long l);
	public void setAllocatedFte(double d);

}
