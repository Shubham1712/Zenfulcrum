package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class PhaseDto {
	private long phaseId;
	private String phaseName;
}
