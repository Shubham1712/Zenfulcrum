package com.zensar.zenfulcrum.resourcemanagement.dto;


import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class TAssociateDeAllocationDto implements Serializable{
	private static final long serialVersionUID = 3305162587864873714L;


	private Long associateDeallocationId;
	
    private Long associateAllocationId;
    
	private Long employeeId;
	
    private Long projectId;

    private Long deallocationReasonId;
    
    private Long workflowReasonId;
    
	private Date deallocationNotificationDate;
	
	private Date deallocationDate;
	
    private String remarks;
    
	private Long statusId;
	
    private Long createdBy;
    
    private Long lastUpdatedBy;
    
	private Date createdDate;
	
	private Date lastUpdatedDate;
	
	private Date effectiveStartDate;
	
	private Date effectiveEndDate;
	
	private Long requirementId;
	
	private Long workflowStatusId;

	private double ftePercent;
	
	private double stdCost;


}