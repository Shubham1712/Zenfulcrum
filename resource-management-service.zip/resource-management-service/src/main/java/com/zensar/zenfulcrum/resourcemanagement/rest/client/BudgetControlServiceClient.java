package com.zensar.zenfulcrum.resourcemanagement.rest.client;



import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.stereotype.Component;

import com.zensar.zenfulcrum.resourcemanagement.config.ZenWalletConfig;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.AllocatedResourceHelperClass;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class BudgetControlServiceClient {

	@Value("${BUDGET.CONTROL.SERVICE.URL}")
	private String budgetControlBaseUrl;

	@Value("${PROJECT.MONTHWISE.BUDGETS.REST.URL}")
	private String getProjectMonthWiseBudgetRestURL;
	
	@Value("${UPDATE.BUDGETS.REST.URL}")
	private String updateBudgetsRestURL;
	
	@Value("${ZENWALLET.BASE.URL}")
	private String getZenwalletRestUrl;
	
	@Value("${GETBUDGET.REST.URL}")
	private String getZenWalletBudgetRestUrl;
	
	@Value("${UPDATEBUDGET.REST.URL}")
	private String updateZenwalletBudgetRestURL;
	 

	
	@Autowired
	private AllocatedResourceHelperClass helperClass;
	
	@Autowired 
	private ZenWalletConfig zenwalletConfig;
	
	public List<ProjectBudgetDto> getProjectMonthlyBudgetsDetails(Long projectId) throws ResourceManagementException {
		log.info("Entered into getProjectMonthlyBudgetsDetails method:");
		String projectCode = helperClass.getProjectCode(projectId);
		List<ProjectBudgetDto> projectBudgetDto = zenwalletConfig.getBudget(projectCode);
		if (null != projectBudgetDto) {
			for (ProjectBudgetDto budgetDto : projectBudgetDto) {
				String monthValue = budgetDto.getMonthValue();
				if (monthValue.equalsIgnoreCase(ResourceManagementConstant.December)
						|| monthValue.equalsIgnoreCase(ResourceManagementConstant.November)
						|| monthValue.equalsIgnoreCase(ResourceManagementConstant.October)) {
					String months = budgetDto.getYear() + "-" + budgetDto.getMonthValue();
					budgetDto.setMonth(months);

				} else {
					String months = budgetDto.getYear() + "-0" + budgetDto.getMonthValue();
					budgetDto.setMonth(months);
				}

				budgetDto.setConsumedBudget(budgetDto.getTotalConsumption());
				budgetDto.setBudgetCurrency(10.0);
			}
		}
		log.info("End getBudget method:");
		return projectBudgetDto;
	}
	
	/**
	 * Update Budget
	 * @param budgetToSend
	 * @throws ResourceManagementException
	 */
	public void updateBudget(List<ProjectBudgetDto> projectBudgetList)  throws ResourceManagementException {
		log.info("Entered into updateBudget method:");
		
		if (null != projectBudgetList) {
			for (ProjectBudgetDto budgetDto : projectBudgetList) {
				budgetDto.setRowUpdateUser(ResourceManagementConstant.ROW_UPDATE_USER_ZF);
				budgetDto.setRowUpdateStp(new Date());
			}
	    zenwalletConfig.update(projectBudgetList);
	    log.info("End updateBudget method:");
		}
		}
}
