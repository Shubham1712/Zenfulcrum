package com.zensar.zenfulcrum.resourcemanagement.dto;

import lombok.Data;

@Data
public class PrimaryUsersDto {
	private long userId;
	private String userName;
	private long roleId;
	private String roleName;
	private String roleCode;
	private long projectId;
	private String projectCode;
	private String projectName;
	private String customerCode;
	private String userEmail;
	private Long empId;
	

}
