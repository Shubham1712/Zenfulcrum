package com.zensar.zenfulcrum.resourcemanagement.util;

public class ResourceManagementConstant {

	private ResourceManagementConstant() {

	}
	
	public static final String CONSTRAINT_EXCEPTION = "ConstraintViolationException";
	public static final String INSUFFICIENT_INPUT = "InsufficientInputException";
	public static final String INVALID_INPUT = "InValidInputException";
    

	   //RestClient Constant
		public static final String SLASH = "/";
		public static final String Question = "?";
		public static final String ProjectListUrl = "projectlist";
		public static final String ampersand = "&";
		public static final String equalto = "=";
		
	
		public static final String RM_ALLOCATION_REQUEST_CODE = "RALLOCATION";
		public static final String RM_DEALLOCATION_REQUEST_CODE = "RDEALLOCATION";
		public static final String RM_ALLOCATION_EXTENSION_REQUEST_CODE = "RALLOCATIONEXTENSION";
		public static final String RM_ALLOCATION_EXTENSION_REQUEST_CODE_LOCKINGPERIOD = "REXTENSIONLOCKINGPERIOD";
		public static final String RM_TRANSFER_REQUEST_CODE = "RTRANSFER";


		
		public static final String PROJECT_ID_VALID = "Project ID is mandatory";
		
	
		public static final String VALUE_EMPTY = "Value is empty";
		public static final String PROVIDE_DATA = "Provide data to save or update";
		public static final String INSUFFICIENT_BUDGET_FOR_EMPLOYEE= "In sufficient budget while Processing allocation for Employee - ";
		
		public static final String RESOURCE_MANAGEMENT = "RESOURCE_MANAGEMENT";
		public static final String RESOURCE_ALLOCATION = "RESOURCE_ALLOCATION";
		public static final String RESOURCE_DEALLOCATION = "RESOURCE_DEALLOCATION";
		public static final String RESOURCE_EXTENSION = "RESOURCE_EXTENSION";
		public static final String RESOURCE_EXTENSION_LOCKINGPERIOD = "RESOURCE_EXTENSION_LOCKING_PERIOD";
		public static final String RESOURCE_TRANSFER = "RESOURCE_TRANSFER";
		public static final String ACTIVE_ACTION = "ACTIVE";
		//public static final String SUBMIT_ACTION_FOR_ALLOCATION = "SUBMITTED FOR ALLOCATION";
		//public static final String SUBMIT_ACTION_FOR_DEALLOCATION = "SUBMITTED FOR DEALLOCATION";
		//public static final String SUBMIT_ACTION_FOR_TRANSFER = "SUBMITTED FOR TRANSFER";
		//public static final String SUBMIT_ACTION_FOR_EXTENSION = "SUBMITTED FOR EXTENSION";
		public static final String APPROVED_ACTION = "APPROVED";
		
		public static final String TYPE_BILLABLE_STATUS = "BILLABLE_STATUS";
		public static final String VALUE_BILLABLE_STATUS = "BILLABLE";
		
		public static final String TYPE_BILLABLE_STATUS_REASON = "BILLABLE_STATUS_REASON";
		
		public static final String SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE";

		public static final String REJECTED_ACTION = "REJECTED";
		public static final String DEALLOCATION_ACTION_DEACTIVE = "DEACTIVE";
		public static final String DEALLOCATION_ACTION_SAVED = "SAVED";


		public static final String EARMARKED_STATUS = "Earmarked";
		public static final String COMPARE ="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		public static final String DEACTIVE_ACTION = "DEACTIVE";
		 
		// BILLABLE Status Type
		public static final Integer BILLABLE = 1;
		public static final Integer EBR = 3;
		public static final Integer NON_BILLABLE = 2;
		
		  
		//Transfer Selection Constants
		public static final String TRANSFER_BETWEEN_PHASES = "transferBetweenPhases";
		public static final String IN_VALID_EMPLOYEE = "Not a valid employee. Please enter correct associate staff id";
		public static final String SWITCH_WITHIN_ODC = "switchWithinOdc";
		public static final String SWITCH_WITHIN_BU = "switchWithinBU";
		
		public static final String Ebr = "EBR";
		public static final String NonBillibale = "NON_BILLABLE";
		public static final String Billable_Pool = "POOL";
		public static final String Quarter = "QUARTER";


		public static final String PARAMETER_PROJECTSTARTDATE = "ProjectStartDate";
		public static final String PARAMETER_MONTH = "Month";
		public static final String PARAMETER_ALLOCATION_MONTH = "ALLOCATION_MONTH";
		public static final String PARAMETER_MONTHLY_ALLOCATION_COST = "MonthlyAllocationCost";
		public static final String ONSHORE = "ONSHORE";
		public static final String INSUFFICIENT_BUDGET= "In sufficient budget while Processing allocation";
		public static final String PARAMETER_MONTHSTARTDATE = "MonthStartDate";
		public static final String PARAMETER_MODULESTATUSID = "ModuleStatusId";
		public static final String DATE_PARSE_EXCEPTION = "Date Parse Exception";
		public static final String VALUE_NON_BILLABLE_STATUS = "NON_BILLABLE";


		
		public static final String RM_SUBMIT_WRKLFW_DECISION_CODE = "SUBMIT";
		public static final String RM_FYI_WRKLFW_DECISION_CODE = "FYI";
		
		public static final String RM_APPROVE_WRKFLW_DECISION_CODE = "APPROVE";
		public static final String RM_REJECT_WRKFLW_DECISION_CODE = "REJECT";
		
		public static final String RM_ALLOCATION_SUBMISSION_CNFIRMATION_LIFERAY_URL = "ResourceManagement/ResourceAllocation/RM_ALLOC_SUB_CNF";
		public static final String RM_ALLOCATION_APPROVAL_PENDING_LIFERAY_URL = "ResourceManagement/ResourceAllocation/RM_ALLOC_APPR_PEND";
		public static final String RM_ALLOCATION_APPROVAL_CONFIRMATION_LIFERAY_URL = "ResourceManagement/ResourceAllocation/RM_ALLOC_APPR_CNF";
		public static final String RM_ALLOCATION_FINAL_APPROVAL_CONFIRMATION_LIFERAY_URL = "ResourceManagement/ResourceAllocation/RM_ALLOC_FIN_APPR_CNF";
		public static final String RM_ALLOCATION_REJECTION_CONFIRMATION_LIFERAY_URL = "ResourceManagement/ResourceAllocation/RM_ALLOC_REJ_CNF";
		public static final String RM_ALLOCATION_PENDING_REJECTION_LIFERAY_URL = "ResourceManagement/ResourceAllocation/RM_ALLOC_REJ_PEND";
		
		
		public static final String RM_DEALLOCATION_SUBMISSION_CNFIRMATION_LIFERAY_URL = "ResourceManagement/ResourceDeAllocation/RM_DEALLOC_SUB_CNF";
//		public static final String RM_DEALLOCATION_APPROVAL_PENDING_LIFERAY_URL = "ResourceManagement/ResourceDeAllocation/RM_DEALLOC_PEND";
		public static final String RM_DEALLOCATION_APPROVAL_PENDING_LIFERAY_URL ="ResourceManagement/ResourceDeAllocation/RM_DEALLOC_APPR_PEND";
		public static final String RM_DEALLOCATION_APPROVAL_CONFIRMATION_LIFERAY_URL = "ResourceManagement/ResourceDeAllocation/RM_DEALLOC_APPR_CNF";
		public static final String RM_DEALLOCATION_FINAL_APPROVAL_CONFIRMATION_LIFERAY_URL = "ResourceManagement/ResourceDeAllocation/RM_DEALLOC_FIN_APPR_CNF";
		public static final String RM_DEALLOCATION_REJECTION_CONFIRMATION_LIFERAY_URL = "ResourceManagement/ResourceDeAllocation/RM_DEALLOC_REJ_CNF";
		public static final String RM_DEALLOCATION_PENDING_REJECTION_LIFERAY_URL = "ResourceManagement/ResourceDeAllocation/RM_DEALLOC_REJ_PEND";
		
		public static final String FROM_EMAIL_ADDRESS = "ZenDirector@zensar.com";
		public static final String INSUFFICIENT_EMAIL_PARAMS = "Insufficient Email Input Params";
		public static final String INVALID_REQUEST_TYPE = "Invalid Request Type";
		public static final String EMAIL_PROJECT_NAME_KEY = "PROJECT_NAME";
		public static final String EMAIL_CUSTOMER_NAME_KEY = "CUSTOMER_NAME";
		public static final String EMAIL_USER_ROLE_NAME_KEY = "USER_ROLE_NAME";
		public static final String EMAIL_APPROVER_NAME_KEY = "APPROVER_NAME";
		public static final String EMAIL_REQUIREMENT_NAME_KEY = "REQUIREMENT";
		public static final String EMAIL_TO_USERS = "TO_USERS";
		public static final String EMAIL_CC_USERS = "CC_USERS";
		public static final String EMAIL_BCC_USERS = "BCC_USERS";
		
		public static final String RM_APPROVER_APPROVE_ACTION = "APPROVED";
		public static final String RM_APPROVER_REJECT_ACTION = "REJECTED";
		
		public static final String EMAIL_UI_DISPLAY_FLAG_TRUE = "TRUE";
		public static final String EMAIL_UI_DISPLAY_FLAG_FALSE = "FALSE";
		
		public static final String TRAVEL_ALLOCATION_SRF = "Travel Allocation";
		public static final String TRAVEL_ALLOCATION_PRIMARY_PROJECT = "NO";
		public static final String EMAIL_USER_ROLE = "USER_ROLE";
		public static final String EMAIL_PROJECT_NAME_SOURCE = "PROJECT_NAME_SOURCE";
		public static final String EMAIL_PROJECT_NAME_TARGET = "PROJECT_NAME_TARGET";
		public static final String RM_TRNSFR_APPROVAL_PENDING_LIFERAY_URL="ResourceManagement/ResourceTransfer/RM_TRNSFR_APPR_PEND" ;
		public static final String RM_TRNSFR_APPROVAL_CONFIRMATION_LIFERAY_URL= "ResourceManagement/ResourceTransfer/RM_TRNSFR_APPR_CNF";
		public static final String RM_TRNSFR_SUBMIT_PENDING_LIFERAY_URL= "ResourceManagement/ResourceTransfer/RM_TRNSFR_SUBMIT_PEND";
		public static final String RM_TRNSFR_FINAL_APPROVAL_CNF_LIFERAY_URL= "ResourceManagement/ResourceTransfer/RM_TRNSFR_FIN_APPR_CNF";
		public static final String RM_TRNSFR_REJECTION_CNF_LIFERAY_URL= "ResourceManagement/ResourceTransfer/RM_TRNSFR_REJ_CNF";
		public static final String RM_TRNSFR_REJECTION_PENDING_LIFERAY_URL= "ResourceManagement/ResourceTransfer/RM_TRNSFR_REJ_PEND";
		
		public static final String RM_TRAVEL_ALLOCATION_SUBMISSION_CNFIRMATION_LIFERAY_URL = "ResourceManagement/ResourceTravel/RM_TRAVEL_ALLOC_SUB_CNF";

		public static final String TRAVEL_ALLOCATION_TYPE_STATUS="TRAVEL";
		public static final String RESOURCE_ALLOCATION_TYPE_STATUS="Normal";
		public static final String RESOURCE_BILLABLE_TYPE = "RESOURCE_BILLABLE_TYPE";
		
		public static final String ALLOCATION_ACTION_SAVED = "SAVED";

		public static final String SEARCH_BY = "SEARCH_BY";
		public static final String BY_PRACTICE = "BY_PRACTICE";
		public static final String BY_SKILL = "BY_SKILL";
		public static final String BY_PROJECT = "BY_PROJECT";
		public static final String BY_ASSOCIATE = "BY_ASSOCIATE";
		

	    public static final String RM_EXTNSN_SUBMIT_PENDING_LIFERAY_URL= "ResourceManagement/ResourceExtension/RM_EXTNSN_SUBMIT_PEND";
        public static final String RM_EXTNSN_APPROVAL_PENDING_LIFERAY_URL="ResourceManagement/ResourceExtension/RM_EXTNSN_APPR_PEND" ;
        public static final String RM_EXTENSION_APPR_FINAL_LIFERAY_URL= "ResourceManagement/ResourceExtension/RM_EXTENSION_APPR_FINAL";
        public static final String RM_EXTENSION_APPR_REJECTED_LIFERAY_URL="ResourceManagement/ResourceExtension/RM_EXTENSION_APPR_REJECTED" ;
        public static final String RM_EXTENSION_APPR_CNF_LIFERAY_URL= "ResourceManagement/ResourceExtension/RM_EXTENSION_APPR_FINAL";

		
		public static final String TRANSFER_ACTION_SAVED = "SAVED";

		public static final String PENDING_FOR_APPROVAL = "PENDING_FOR_APPROVAL";
		public static final String PENDING_FOR_SUBMISSION = "PENDING_FOR_SUBMISSION";
		public static final String PENDING_WITH_OTHERS = "PENDING_WITH_OTHERS";
		public static final String PENDING_ALLOCATION_APPROVAL = "PENDING_ALLOCATION_APPROVAL";
		public static final String PENDING_DEALLOCATION_APPROVAL = "PENDING_DEALLOCATION_APPROVAL";
		public static final String PENDING_TRANSFER_APPROVAL = "PENDING_TRANSFER_APPROVAL";
		public static final String PENDING_EXTENSION_APPROVAL = "PENDING_EXTENSION_APPROVAL";
		public static final String PENDING_ALLOCATION_SUBMISSION = "PENDING_ALLOCATION_SUBMISSION";
		public static final String PENDING_DEALLOCATION_SUBMISSION = "PENDING_DEALLOCATION_SUBMISSION";
		public static final String PENDING_TRANSFER_SUBMISSION = "PENDING_TRANSFER_SUBMISSION";
		public static final String PENDING_ALLOCATION_OTHERS = "PENDING_ALLOCATION_OTHERS";
		public static final String PENDING_DEALLOCATION_OTHERS = "PENDING_DEALLOCATION_OTHERS";
		public static final String PENDING_TRANSFER_OTHERS = "PENDING_TRANSFER_OTHERS";
		public static final String PENDING_EXTENSION_OTHERS = "PENDING_EXTENSION_OTHERS";
		
		public static final String SUBMISSION_CONSTANT = "SUBMISSION";
		public static final String APPROVAL_CONSTANT = "APPROVAL";
		public static final String PREVIOUS_APPROVER_STATUS_CHECK_CONSTANT = "PREVIOUS_APPROVER";
		public static final String NEXT_APPROVER_STATUC_CHECK_CONSTANT = "NEXT_APPROVER";
		
		public static final String EMPLOYEE_ALREADY_IN_WORKFLOW= "Selected Employees are already in workflow";
		public static final String RM_FTE_CHANGE_REQUEST_CODE = "RFTECHANGE";
		public static final String SUBMIT_ACTION_FOR_FTE_CHANGE = "SUBMITTED_FOR_FTE_CHANGE";
		public static final String EFFECTIVE_START_DATE = "EFFECTIVE_START_DATE";

		public static final String ADMIN_ROLE_NAME = "ADMIN";
		public static final String TAG_ROLE_NAME = "TAG TEAM";
		public static final String ROLE_DEVELOPER="DEVELOPER";
		
		public static final String Cost_Card_Message = "No matching cost found, Please contact the ZenAccurate admin and add a required cost in Cost Card";
 
 
		public static final String READONLYUSER="ADMIN";
	 

 
 
 
		public static final String ALLOCATION_NOT_POSSIBLE= "ALLOCATION NOT POSSIBLE";
		public static final String DEALLOCATION_NOT_POSSIBLE= "DEALLOCATION NOT POSSIBLE";
		public static final String TRANSFER_NOT_POSSIBLE= "TRANSFER NOT POSSIBLE";
		public static final String EFFECTIVE_DATE_CHECK= "Effective Date shouldn’t be less than JV run Date and last Effective Date";

		public static final String SOUTH_AFRICA = "SOUTH AFRICA";
		
		public static final String SAME_ALLOCATION_REQUIREMENT = "Resource cannot be allocated/transfered again on the same requirement";

		public static final String SAME_TRAVEL_ALLOCATION= "Following Resource is already Travelling for require allocation date";
		public static final String SRF= "SRF";

		
		// NEW WORKFLOW AND STATUS ID
		
		public static final String APPROVED= "APPROVED";
		public static final String REJECTED= "REJECTED";
		public static final String SAVED = "SAVED";
		public static final String SUBMITTED = "SUBMITTED";
		
		public static final String ACTIVATE = "ACTIVATE";
		public static final String DEACTIVATE = "DEACTIVATE";
		
		public static final String STATUS = "STATUS";
		public static final String WORK_ORDER_STATUS_TYPE ="WORK_ORDER_STATUS_TYPE";
   
		public static final String POOL = "POOL";
		public static final String SKILL ="SKILL";
		public static final String SKILL_COMPETANCY ="SKILL_COMPETANCY";
		public static final String PRIMARY ="Primary";
      
		public static final String PROJECT_BILLABLE_TYPE ="PROJECT_BILLABLE_TYPE";
		public static final String Non_Billable ="Non Billable";
		public static final String Billable = "Billable";
		public static final String InTransit = "InTransit";
		public static final String ACTIVATE_STATUS = "ACTIVATE";

		
		public static final String November ="11";
		public static final String December ="12";
		public static final String October ="10";
		public static final String ROW_UPDATE_USER_ZF ="ZEN_FULCRUM";

		public static final String ROLE_TYPE = "ROLE_TYPE";
		public static final String PROJECT_MANAGER = "PROJECT MANAGER";
		public static final String PROGRAM_MANAGER = "PROGRAM MANAGER";
		public static final String TAG_TEAM = "TAG TEAM";
		public static final String NON_LOCKING_EXTENSION = "REN";
		public static final String LOCKING_EXTENSION = "RME";
		public static final String EMPLOYEE_NOT_FOUND = "PRACTISE ALLOCATION NOT DONE OR EMPLOYEE DETAILS NOT UPDATED";



		public static final String NO_TRAVEL_RESOURCE = "Resource cannot be allocated again on the same requirement/project.";
		public static final String NA = "NA";

		public static final Long ONE_DAY = 1000L * 60L * 60L * 24L;

		
		public static final String STAGING_SCHEMA = "zf_staging";
		
		//Added by Mrunal Marne for milestone selection while resource allocation
		public static final String COMMERCIAL_MODEL_FIXED_PRICE = "FIXED PRICE";
		public static final String COMMERCIAL_MODEL_FIXED_PRICE_AMC = "FIXED MONTHLY (AMC)";
		//Added by Mrunal Marne for setting updated cost rate during transfer within same project
		public static final String DEFAULT_EFFECTIVE_END_DATE = "1111-11-11";
		//Added by Mrunal Marne for handling empty project list
		public static final String PROJECT_LIST_EMPTY_ERROR = "There are no projects under selected role.";
		//Added by Mrunal Marne for RMG Tagging
		public static final String RMG_TYPE = "RMG_TYPE";
		public static final String RMG_TAGGING_MODULE = "RESOURCE_RMG_DETAIL";
		public static final String NO_RMG_TAGGING_DONE = "There is no active RMG Tag for the requested associate.";
		
		
		public static final String POOL_RESOURCE = "Travel allocation cannot be done for resources who are on pool.";
		public static final String NO_DATA_FOUND = "No Data found for given employee.";
		
		public static final String EMPLOYEE_MODULE = "EMPLOYEE";
		public static final String RESERVED_ALLOCATION = "RESERVED_ALLOCATION";
		public static final String RESERVED_DEALLOCATION = "RESERVED_DEALLOCATION";
		public static final String APPROVED_ALLOCATION = "APPROVED_ALLOCATION";
		public static final String APPROVED_DEALLOCATION = "APPROVED_DEALLOCATION";
		public static final String TRAVEL_ALLOCATION = "TRAVEL_ALLOCATION";
		public static final String TRACEBILITY_MSG = "Please send resource for approval.";
		public static final String SWITCH_WITHIN_BU_MSG = "Resource is in workflow/Resource not present in intransit project.";
		
		public static final String RESOURCE_TRANSFER_PGM = "RMTPG";
		public static final String NOT_AUTHORIZED = "Not authorized to Edit Allocation Details.";
		
		public static final String ALLOCATION_TYPE="ALLOCATION_TYPE";
		public static final String NORMAL="Normal";
		
		public static final Long ONSITE_OTHER_1=537L;
		public static final Long ONSITE_OTHER_2=538L;
		public static final Long ONSITE_OTHER_3=539L;
		public static final Long ONSITE_OTHER_4=540L;
		public static final Long ONSITE_OTHER_5=541L;
		
		public static final String BAND_R0="R0";
		public static final String BAND_S0="S0";
		
		public static final String STANDARD_COST_RATE="The standard cost rate of the earmarked associate's band & location mapped to the corresponding primary skill is not available in the system. Please contact Pricing Team in order to arrange the corresponding entry in the ZenAccurate Pricing Portal so that the same could have been fetched into ZenFulcrum for budget consumption.";				
		
		public static final String NOT_AVAILABLE = "NOT AVAILABLE";
		public static final String BUDGET_CHECK_FAILED = "Budget validation failed";
		
		//block devAk
		public static final String EMAIL_To_USER_NAME = "TO_USER_NAME";	
		public static final String EMAIL_ASSOCIATE_NAME_KEY = "ASSOCIATE_NAME";
		public static final String RM_ALLOCATION_ASSOCIATE_FINAL_CNFIRMATION_LIFERAY_URL = "ResourceManagement/ResourceAllocation/RM_ALLOC_FIN_ASSOC_CNF";
		
		//
}
