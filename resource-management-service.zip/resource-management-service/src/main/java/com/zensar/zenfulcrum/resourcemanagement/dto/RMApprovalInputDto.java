package com.zensar.zenfulcrum.resourcemanagement.dto;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateExtension;

import lombok.Data;

@Data
public class RMApprovalInputDto {
	private long userId;
	private long roleId;
	private long requirementId;
	private long projectId;
	private String requestType;
	private List<RMApproversDto> rmApproversList;
	private List<Long> employeeIdList;	
	private String approverAction;
	private String approverComments;
	private String userName;
	private String roleName;
	private List<ResourceRequirementDto> resourceRequirementList;
	private long currentProjectId;
	private long currentRequirementId;
	private long fyiTargetProgramManagerId;
	private long fyiCurrentProgramManagerId;
	private List<RTResourceDto> resourceList;
	private List<TAssociateExtension> tAssociateExtensionList;
	private Date proposedEsEndDate;
	private List<Long> requirmentList;
	private Boolean budgetAndCostCheck;
	private List<String> commentsList;
	private List<TransferFYIDto> transferFYIList;
	private String comment;
	//added by ravi
	private Date currentEstEndDate;
	private Map<Long, Date> empCurrentEstEndDateMap;
}
