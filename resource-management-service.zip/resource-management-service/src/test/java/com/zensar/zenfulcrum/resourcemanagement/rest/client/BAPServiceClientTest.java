package com.zensar.zenfulcrum.resourcemanagement.rest.client;

import static org.junit.Assert.assertNotNull;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.zensar.zenfulcrum.resourcemanagement.dto.PoMilestoneDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PrimaryUsersDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ServiceLineAndPoMilestoneDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ServiceLineDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class BAPServiceClientTest {

	@Mock
	private RestTemplate restTemplate;
	@InjectMocks
	private BAPServiceClient bapSrvcClient;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(bapSrvcClient, "bapBaseUrl", "bapBaseUrl");
		ReflectionTestUtils.setField(bapSrvcClient, "getProjectListRestURL", "getProjectListRestURL");
		ReflectionTestUtils.setField(bapSrvcClient, "getPhaseListRestURL", "getPhaseListRestURL");
		ReflectionTestUtils.setField(bapSrvcClient, "getPOListRestURL", "getPOListRestURL");
		ReflectionTestUtils.setField(bapSrvcClient, "getResourceRequirementRestURL", "getResourceRequirementRestURL");
		ReflectionTestUtils.setField(bapSrvcClient, "getPrimaryOwnersListRestURL", "getPrimaryOwnersListRestURL");
		ReflectionTestUtils.setField(bapSrvcClient, "getServiceLineAndPOMilestoneRestUrl",
				"getServiceLineAndPOMilestoneRestUrl");
		ReflectionTestUtils.setField(bapSrvcClient, "requirementDetailByReqIdRestURL",
				"requirementDetailByReqIdRestURL");
		ReflectionTestUtils.setField(bapSrvcClient, "projectFteUrl", "projectFteUrl");
		ReflectionTestUtils.setField(bapSrvcClient, "getIntransitProjectRestURL", "getIntransitProjectRestURL");
		ReflectionTestUtils.setField(bapSrvcClient, "getProjectFromSameOdcRestURL", "getProjectFromSameOdcRestURL");
		ReflectionTestUtils.setField(bapSrvcClient, "getRoleBasedPrimaryOwnersListRestURL",
				"getRoleBasedPrimaryOwnersListRestURL");
		ReflectionTestUtils.setField(bapSrvcClient, "getProjectDetailRestURL", "getProjectDetailRestURL");
		ReflectionTestUtils.setField(bapSrvcClient, "getProjectBasePrimaryOwnersListRestURL",
				"getProjectBasePrimaryOwnersListRestURL");
		ReflectionTestUtils.setField(bapSrvcClient, "getListPrimaryOwnersListURL", "getListPrimaryOwnersListURL");		
		ReflectionTestUtils.setField(bapSrvcClient, "getResourceRequirmentByListOfIds", "getResourceRequirmentByListOfIds");		
		ReflectionTestUtils.setField(bapSrvcClient, "getprojectListByIds", "getprojectListByIds");	
		ReflectionTestUtils.setField(bapSrvcClient, "getSkillFamilyByReqIdRestUrl", "getSkillFamilyByReqIdRestUrl");		
		ReflectionTestUtils.setField(bapSrvcClient, "projectDefinationBasetUrl", "projectDefinationBasetUrl");	
		ReflectionTestUtils.setField(bapSrvcClient, "getProjectDetails", "getProjectDetails");	

		
		
		
	}

	@Test
	public void getProjectListTest() throws ResourceManagementException {
		List<ProjectDto> projectList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");
		projectList.add(projectDto);

		ResponseEntity<List<ProjectDto>> response = new ResponseEntity<List<ProjectDto>>(projectList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenReturn(response);
		List<ProjectDto> newprojectList = bapSrvcClient.getProjectList(12345, 12345);
		assertNotNull(newprojectList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());

	}

	@Test
	public void getProjectListTestNull() throws ResourceManagementException {
		List<ProjectDto> projectList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");
		projectList.add(projectDto);

		ResponseEntity<List<ProjectDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenReturn(response);
		List<ProjectDto> newprojectList = bapSrvcClient.getProjectList(12345, 12345);
		assertNull(newprojectList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());

	}

	@Test
	public void getProjectListTestDiffStatusCode() throws ResourceManagementException {
		List<ProjectDto> projectList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");
		projectList.add(projectDto);

		ResponseEntity<List<ProjectDto>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenReturn(response);
		List<ProjectDto> newprojectList = bapSrvcClient.getProjectList(12345, 12345);
		assertNull(newprojectList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectListTestResourceException() throws ResourceManagementException {
		List<ProjectDto> projectList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");
		projectList.add(projectDto);

		ResponseEntity<List<ProjectDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any()))
						.thenThrow(new ResourceAccessException("Error"));
		List<ProjectDto> newprojectList = bapSrvcClient.getProjectList(12345, 12345);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectListTestHttpServerException() throws ResourceManagementException {
		List<ProjectDto> projectList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");
		projectList.add(projectDto);

		ResponseEntity<List<ProjectDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenThrow(HttpServerErrorException.class);
		List<ProjectDto> newprojectList = bapSrvcClient.getProjectList(12345, 12345);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectListTestHttpClientException() throws ResourceManagementException {
		List<ProjectDto> projectList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");
		projectList.add(projectDto);

		ResponseEntity<List<ProjectDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenThrow(HttpClientErrorException.class);
		List<ProjectDto> newprojectList = bapSrvcClient.getProjectList(12345, 12345);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());

	}

	@Test
	public void getResourceRequirementListTest() throws ResourceManagementException {
		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setAllocateResourceQty(2.0);
		resourceRequirementDto.setBand("A");
		resourceRequirementDto.setBillingEffortsPerHrs(1234);
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setProjectId(40001);
		resourceRequirementDto.setBillingRateInUSD(123);
		resourceRequirementDto.setReqId(20001);
		resourceRequirementDto.setSkills("java");
		resourceRequirementDto.setTotalResourceQty(12);
		resourceRequirementDto.setBillable(1);
		resourceRequirementDto.setResourceRequirementLocation("pune");
		resourceRequirementDto.setBillingStatus("billable");
		resourcerequirementlist.add(resourceRequirementDto);

		ResponseEntity<List<ResourceRequirementDto>> response = new ResponseEntity<List<ResourceRequirementDto>>(
				resourcerequirementlist, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any())).thenReturn(response);
		List<ResourceRequirementDto> newprojectList = bapSrvcClient.getResourceRequiremetList(1234);
		assertNotNull(newprojectList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any());
	}

	@Test
	public void getResourceRequirementListTestNull() throws ResourceManagementException {
		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setAllocateResourceQty(2.0);
		resourceRequirementDto.setBand("A");
		resourceRequirementDto.setBillingEffortsPerHrs(1234);
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setProjectId(40001);
		resourceRequirementDto.setBillingRateInUSD(123);
		resourceRequirementDto.setReqId(20001);
		resourceRequirementDto.setSkills("java");
		resourceRequirementDto.setTotalResourceQty(12);
		resourceRequirementDto.setBillable(1);
		resourceRequirementDto.setResourceRequirementLocation("pune");
		resourceRequirementDto.setBillingStatus("billable");
		resourcerequirementlist.add(resourceRequirementDto);

		ResponseEntity<List<ResourceRequirementDto>> response = new ResponseEntity<>(null, HttpStatus.OK);

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any())).thenReturn(response);
		List<ResourceRequirementDto> newresourcerequirementList = bapSrvcClient.getResourceRequiremetList(1234);
		assertNull(newresourcerequirementList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any());

	}

	@Test
	public void getResourceRequirementListDiffStatus() throws ResourceManagementException {
		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setAllocateResourceQty(2.0);
		resourceRequirementDto.setBand("A");
		resourceRequirementDto.setBillingEffortsPerHrs(1234);
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setProjectId(40001);
		resourceRequirementDto.setBillingRateInUSD(123);
		resourceRequirementDto.setReqId(20001);
		resourceRequirementDto.setSkills("java");
		resourceRequirementDto.setTotalResourceQty(12);
		resourceRequirementDto.setBillable(1);
		resourceRequirementDto.setResourceRequirementLocation("pune");
		resourceRequirementDto.setBillingStatus("billable");
		resourcerequirementlist.add(resourceRequirementDto);

		ResponseEntity<List<ResourceRequirementDto>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any())).thenReturn(response);
		List<ResourceRequirementDto> newresourcerequirementList = bapSrvcClient.getResourceRequiremetList(1234);
		assertNull(newresourcerequirementList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceRequirementListTestResourceException() throws ResourceManagementException {
		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setAllocateResourceQty(2.0);
		resourceRequirementDto.setBand("A");
		resourceRequirementDto.setBillingEffortsPerHrs(1234);
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setProjectId(40001);
		resourceRequirementDto.setBillingRateInUSD(123);
		resourceRequirementDto.setReqId(20001);
		resourceRequirementDto.setSkills("java");
		resourceRequirementDto.setTotalResourceQty(12);
		resourceRequirementDto.setBillable(1);
		resourceRequirementDto.setResourceRequirementLocation("pune");
		resourceRequirementDto.setBillingStatus("billable");
		resourcerequirementlist.add(resourceRequirementDto);

		ResponseEntity<List<ResourceRequirementDto>> response = new ResponseEntity<List<ResourceRequirementDto>>(
				resourcerequirementlist, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any()))
						.thenThrow(new ResourceAccessException("Error"));
		List<ResourceRequirementDto> newprojectList = bapSrvcClient.getResourceRequiremetList(1234);
		assertNotNull(newprojectList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceRequirementListHttpServerException() throws ResourceManagementException {
		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setAllocateResourceQty(2.0);
		resourceRequirementDto.setBand("A");
		resourceRequirementDto.setBillingEffortsPerHrs(1234);
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setProjectId(40001);
		resourceRequirementDto.setBillingRateInUSD(123);
		resourceRequirementDto.setReqId(20001);
		resourceRequirementDto.setSkills("java");
		resourceRequirementDto.setTotalResourceQty(12);
		resourceRequirementDto.setBillable(1);
		resourceRequirementDto.setResourceRequirementLocation("pune");
		resourceRequirementDto.setBillingStatus("billable");
		resourcerequirementlist.add(resourceRequirementDto);

		ResponseEntity<List<ResourceRequirementDto>> response = new ResponseEntity<List<ResourceRequirementDto>>(
				resourcerequirementlist, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		List<ResourceRequirementDto> newprojectList = bapSrvcClient.getResourceRequiremetList(1234);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceRequirementListHttpClientException() throws ResourceManagementException {
		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setAllocateResourceQty(2.0);
		resourceRequirementDto.setBand("A");
		resourceRequirementDto.setBillingEffortsPerHrs(1234);
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setProjectId(40001);
		resourceRequirementDto.setBillingRateInUSD(123);
		resourceRequirementDto.setReqId(20001);
		resourceRequirementDto.setSkills("java");
		resourceRequirementDto.setTotalResourceQty(12);
		resourceRequirementDto.setBillable(1);
		resourceRequirementDto.setResourceRequirementLocation("pune");
		resourceRequirementDto.setBillingStatus("billable");
		resourcerequirementlist.add(resourceRequirementDto);

		ResponseEntity<List<ResourceRequirementDto>> response = new ResponseEntity<List<ResourceRequirementDto>>(
				resourcerequirementlist, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any()))
						.thenThrow(HttpClientErrorException.class);
		List<ResourceRequirementDto> newprojectList = bapSrvcClient.getResourceRequiremetList(1234);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any());

	}

	@Test
	public void getUsrIdListByPrjctIdTest() throws Exception {
		List<Integer> ipUserIdListObj = new ArrayList<>();
		ipUserIdListObj.add(1);
		ResponseEntity<List<Integer>> response = new ResponseEntity<>(ipUserIdListObj, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Integer>>>any())).thenReturn(response);
		List<Long> opUserIdListObj = bapSrvcClient.getPrimaryOwnersList(123);
		assertNotNull(opUserIdListObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Integer>>>any());

	}

	@Test
	public void getUsrIdListByPrjctIdTestNull() throws Exception {
		ResponseEntity<List<Integer>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Integer>>>any())).thenReturn(responseEntityObj);
		List<Long> opUserIdListObj = bapSrvcClient.getPrimaryOwnersList(123);
		assertNull(opUserIdListObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Integer>>>any());
	}

	@Test
	public void getUsrIdListByPrjctIdTestDiffStatusCode() throws Exception {
		ResponseEntity<List<Integer>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Integer>>>any())).thenReturn(responseEntityObj);
		List<Long> opUserIdListObj = bapSrvcClient.getPrimaryOwnersList(123);
		assertNull(opUserIdListObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Integer>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getUsrIdListByPrjctIdTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Integer>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		bapSrvcClient.getPrimaryOwnersList(123);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Integer>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getUsrIdListByPrjctIdTestHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Integer>>>any())).thenThrow(HttpServerErrorException.class);
		bapSrvcClient.getPrimaryOwnersList(123);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Integer>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getUsrIdListByPrjctIdTestHttpClientException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Integer>>>any())).thenThrow(HttpClientErrorException.class);
		bapSrvcClient.getPrimaryOwnersList(123);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Integer>>>any());
	}

	@Test
	public void getServiceLineAndPoMilestoneDtoTest() throws ResourceManagementException {

		List<PoMilestoneDto> pomilestonelist = new ArrayList<>();
		PoMilestoneDto poMileStoneDto = new PoMilestoneDto();
		poMileStoneDto.setPoMilestoneId(12);
		poMileStoneDto.setPoMilestoneName("Milestone1");
		pomilestonelist.add(poMileStoneDto);
		List<ServiceLineDto> servicelinelist = new ArrayList<>();
		ServiceLineDto servicelineDto = new ServiceLineDto();
		servicelineDto.setServiceLineId(123);
		servicelineDto.setServiceLine("ADS");

		ServiceLineAndPoMilestoneDto serviceLineAndPoMilestoneDto = new ServiceLineAndPoMilestoneDto();
		serviceLineAndPoMilestoneDto.setRequirementId(1234);
		serviceLineAndPoMilestoneDto.setRequirementband("E");
		serviceLineAndPoMilestoneDto.setPoMilestoneList(pomilestonelist);
		serviceLineAndPoMilestoneDto.setServiceLineList(servicelinelist);

		ResponseEntity<ServiceLineAndPoMilestoneDto> response = new ResponseEntity<ServiceLineAndPoMilestoneDto>(
				serviceLineAndPoMilestoneDto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>>any())).thenReturn(response);
		ServiceLineAndPoMilestoneDto newservicerequirementlist = bapSrvcClient.getServiceLineAndPoMilestoneDetail(123,
				123);
		assertNotNull(newservicerequirementlist);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>>any());
	}

	@Test
	public void getServiceLineAndPoMilestoneDtoTestNull() throws ResourceManagementException {

		ResponseEntity<ServiceLineAndPoMilestoneDto> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>>any())).thenReturn(response);
		ServiceLineAndPoMilestoneDto newservicerequirementlist = bapSrvcClient.getServiceLineAndPoMilestoneDetail(123,
				123);
		assertNull(newservicerequirementlist);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>>any());
	}

	@Test
	public void getServiceLineAndPoMilestoneDtoTestDiffStatus() throws ResourceManagementException {

		ResponseEntity<ServiceLineAndPoMilestoneDto> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>>any())).thenReturn(response);
		ServiceLineAndPoMilestoneDto newservicerequirementlist = bapSrvcClient.getServiceLineAndPoMilestoneDetail(123,
				123);
		assertNull(newservicerequirementlist);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getServiceLineAndPoMilestoneDtoResourceException() throws ResourceManagementException {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>>any()))
						.thenThrow(new ResourceAccessException("Error"));
		ServiceLineAndPoMilestoneDto newservicerequirementlist = bapSrvcClient.getServiceLineAndPoMilestoneDetail(123,
				123);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getServiceLineAndPoMilestoneDtoHttpServerException() throws ResourceManagementException {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>>any()))
						.thenThrow(HttpServerErrorException.class);
		ServiceLineAndPoMilestoneDto newservicerequirementlist = bapSrvcClient.getServiceLineAndPoMilestoneDetail(123,
				123);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getServiceLineAndPoMilestoneDtoHttpClientException() throws ResourceManagementException {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>>any()))
						.thenThrow(HttpClientErrorException.class);
		ServiceLineAndPoMilestoneDto newservicerequirementlist = bapSrvcClient.getServiceLineAndPoMilestoneDetail(123,
				123);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ServiceLineAndPoMilestoneDto>>any());
	}

	@Test
	public void getRequirementDetailByReqIdTest() throws Exception {
		ResourceRequirementDto resourceRequirement = new ResourceRequirementDto();
		ResponseEntity<ResourceRequirementDto> response = new ResponseEntity<>(resourceRequirement, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementDto>>any())).thenReturn(response);
		ResourceRequirementDto resourceRequirementDto = bapSrvcClient.getRequirementDetailByReqId(123l);
		assertNotNull(resourceRequirementDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementDto>>any());
	}

	@Test
	public void getRequirementDetailByReqIdTestNull() throws Exception {
		ResponseEntity<ResourceRequirementDto> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementDto>>any())).thenReturn(response);
		ResourceRequirementDto resourceRequirement = bapSrvcClient.getRequirementDetailByReqId(123l);
		assertNull(resourceRequirement);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementDto>>any());
	}

	@Test
	public void getRequirementDetailByReqIdTestDiffStatusCode() throws Exception {
		ResponseEntity<ResourceRequirementDto> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementDto>>any())).thenReturn(response);
		ResourceRequirementDto resourceRequirement = bapSrvcClient.getRequirementDetailByReqId(123l);
		assertNull(resourceRequirement);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getRequirementDetailByReqIdTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementDto>>any())).thenThrow(new ResourceAccessException("Error"));
		bapSrvcClient.getRequirementDetailByReqId(123l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getRequirementDetailByReqIdTestHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementDto>>any())).thenThrow(HttpServerErrorException.class);
		bapSrvcClient.getRequirementDetailByReqId(123l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getRequirementDetailByReqIdTestHttpClientException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementDto>>any())).thenThrow(HttpClientErrorException.class);
		bapSrvcClient.getRequirementDetailByReqId(123l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementDto>>any());
	}

	@Test
	public void getProjectFteTest() throws ResourceManagementException {
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		List<ResourceRequirementDto> resourceReqList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(1l);
		resourceRequirementDto.setResourceRequirementLocation("Pune");
		resourceReqList.add(resourceRequirementDto);
		resourceRequirementAndFteDto.setTotalBudget(12345);
		resourceRequirementAndFteDto.setResourceRequirementDto(resourceReqList);

		ResponseEntity<ResourceRequirementAndFteDto> response = new ResponseEntity<ResourceRequirementAndFteDto>(
				resourceRequirementAndFteDto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementAndFteDto>>any())).thenReturn(response);
		ResourceRequirementAndFteDto newesourceRequirementAndFteDto = bapSrvcClient.getProjectFte(1234l);
		assertNotNull(newesourceRequirementAndFteDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<Class<ResourceRequirementAndFteDto>>any());

	}

	@Test
	public void getProjectFteTestNull() throws Exception {
		ResponseEntity<ResourceRequirementAndFteDto> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementAndFteDto>>any())).thenReturn(response);
		ResourceRequirementAndFteDto newesourceRequirementAndFteDto = bapSrvcClient.getProjectFte(1234l);
		assertNull(newesourceRequirementAndFteDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<Class<ResourceRequirementAndFteDto>>any());

	}

	@Test
	public void getProjectFteDiffStatusCode() throws Exception {
		ResponseEntity<ResourceRequirementAndFteDto> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementAndFteDto>>any())).thenReturn(response);
		ResourceRequirementAndFteDto newesourceRequirementAndFteDto = bapSrvcClient.getProjectFte(1234l);
		assertNull(newesourceRequirementAndFteDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<Class<ResourceRequirementAndFteDto>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectFteTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementAndFteDto>>any())).thenThrow(new ResourceAccessException("Error"));
		bapSrvcClient.getProjectFte(1234l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<Class<ResourceRequirementAndFteDto>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectFteHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementAndFteDto>>any())).thenThrow(HttpServerErrorException.class);
		bapSrvcClient.getProjectFte(1234l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<Class<ResourceRequirementAndFteDto>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectFteHttpClientException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ResourceRequirementAndFteDto>>any())).thenThrow(HttpClientErrorException.class);
		bapSrvcClient.getProjectFte(1234l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<Class<ResourceRequirementAndFteDto>>any());

	}

	@Test
	public void getIntransitProjectIdTest() throws ResourceManagementException {

		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(44444);
		projectDto.setProjectName("test-1");
		ResponseEntity<ProjectDto> response = new ResponseEntity<ProjectDto>(projectDto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any())).thenReturn(response);

		ProjectDto newprojectDto = bapSrvcClient.getIntransitProjectId(123L);
		assertNotNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());
	}

	@Test
	public void getIntransitProjectIdNullTest() throws ResourceManagementException {

		ResponseEntity<ProjectDto> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any())).thenReturn(response);
		ProjectDto newprojectDto = bapSrvcClient.getIntransitProjectId(123L);
		assertNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());
	}

	@Test
	public void getIntransitProjectIdDiffStatusCodeTest() throws ResourceManagementException {

		ResponseEntity<ProjectDto> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any())).thenReturn(response);
		ProjectDto newprojectDto = bapSrvcClient.getIntransitProjectId(123L);
		assertNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getIntransitProjectIdResourceExceptionTest() throws ResourceManagementException {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any())).thenThrow(new ResourceAccessException("Error"));
		bapSrvcClient.getIntransitProjectId(123L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getIntransitProjectIdHttpServerExceptionTest() throws ResourceManagementException {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any())).thenThrow(HttpServerErrorException.class);
		bapSrvcClient.getIntransitProjectId(123L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getIntransitProjectIdHttpClientExceptionTest() throws ResourceManagementException {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any())).thenThrow(HttpClientErrorException.class);
		bapSrvcClient.getIntransitProjectId(123L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());
	}

	@Test
	public void getRoleBasedPrimaryOwnersListTest() throws Exception {
		List<PrimaryUsersDto> ipPrimaryUserDtlsList = new ArrayList<>();
		List<Long> roleIds = new ArrayList<>();
		roleIds.add(1L);
		ResponseEntity<List<PrimaryUsersDto>> response = new ResponseEntity<>(ipPrimaryUserDtlsList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any())).thenReturn(response);
		List<PrimaryUsersDto> opPrimaryUserDtlsList = bapSrvcClient.getRoleBasedPrimaryOwnersList(1, roleIds);
		assertNotNull(opPrimaryUserDtlsList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());

	}

	@Test
	public void getRoleBasedPrimaryOwnersListTestNull() throws Exception {
		List<Long> roleIds = new ArrayList<>();
		roleIds.add(1L);
		ResponseEntity<List<PrimaryUsersDto>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any())).thenReturn(responseEntityObj);
		List<PrimaryUsersDto> opPrimaryUserDtlsList = bapSrvcClient.getRoleBasedPrimaryOwnersList(1, roleIds);
		assertNull(opPrimaryUserDtlsList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());
	}

	@Test
	public void getRoleBasedPrimaryOwnersListTestDiffStatusCode() throws Exception {
		List<Long> roleIds = new ArrayList<>();
		roleIds.add(1L);
		ResponseEntity<List<PrimaryUsersDto>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any())).thenReturn(responseEntityObj);
		List<PrimaryUsersDto> opPrimaryUserDtlsList = bapSrvcClient.getRoleBasedPrimaryOwnersList(1, roleIds);
		assertNull(opPrimaryUserDtlsList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getRoleBasedPrimaryOwnersListTestResourceException() throws Exception {
		List<Long> roleIds = new ArrayList<>();
		roleIds.add(1L);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		bapSrvcClient.getRoleBasedPrimaryOwnersList(1, roleIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getRoleBasedPrimaryOwnersListTestHttpServerException() throws Exception {
		List<Long> roleIds = new ArrayList<>();
		roleIds.add(1L);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		bapSrvcClient.getRoleBasedPrimaryOwnersList(1, roleIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getRoleBasedPrimaryOwnersListTestHttpClientException() throws Exception {
		List<Long> roleIds = new ArrayList<>();
		roleIds.add(1L);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any()))
						.thenThrow(HttpClientErrorException.class);
		bapSrvcClient.getRoleBasedPrimaryOwnersList(1, roleIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());
	}

	@Test
	public void getProjectWithinSameOdc() throws ResourceManagementException {
		List<ProjectDto> projectList = new ArrayList<ProjectDto>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(44444);
		projectDto.setProjectName("test-1");
		projectList.add(projectDto);
		ResponseEntity<List<ProjectDto>> response = new ResponseEntity<List<ProjectDto>>(projectList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenReturn(response);

		List<ProjectDto> newprojectDto = bapSrvcClient.getProjectWithinSameOdc(123L, 123L, 123L);
		assertNotNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());
	}

	@Test
	public void getProjectWithinSameOdcNullTest() throws ResourceManagementException {
		ResponseEntity<List<ProjectDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenReturn(response);

		List<ProjectDto> newprojectDto = bapSrvcClient.getProjectWithinSameOdc(123L, 123L, 123L);
		assertNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());
	}

	@Test
	public void getProjectWithinSameOdcDiffSatausTest() throws ResourceManagementException {
		ResponseEntity<List<ProjectDto>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenReturn(response);

		List<ProjectDto> newprojectDto = bapSrvcClient.getProjectWithinSameOdc(123L, 123L, 123L);
		assertNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectWithinSameOdcResourceManagmentExceptionTest() throws ResourceManagementException {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any()))
						.thenThrow(new ResourceAccessException("Error"));
		List<ProjectDto> newprojectDto = bapSrvcClient.getProjectWithinSameOdc(123L, 123L, 123L);
		assertNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectWithinSameOdcHttPServerExceptionTest() throws ResourceManagementException {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenThrow(HttpServerErrorException.class);
		List<ProjectDto> newprojectDto = bapSrvcClient.getProjectWithinSameOdc(123L, 123L, 123L);
		assertNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectWithinSameOdcClientExceptionTest() throws ResourceManagementException {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenThrow(HttpClientErrorException.class);
		List<ProjectDto> newprojectDto = bapSrvcClient.getProjectWithinSameOdc(123L, 123L, 123L);
		assertNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());
	}

	@Test
	public void getProjectDetailTest() throws ResourceManagementException {
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");

		ResponseEntity<ProjectDto> response = new ResponseEntity<ProjectDto>(projectDto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any())).thenReturn(response);
		ProjectDto projectDetails = bapSrvcClient.getProjectDetail(40001);
		assertNotNull(projectDetails);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectDetailExceptionTest() throws ResourceManagementException {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any())).thenThrow(HttpClientErrorException.class);
		ProjectDto projectDetails = bapSrvcClient.getProjectDetail(40001);
		assertNotNull(projectDetails);
	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectDetailResourceAccessExceptionTest() throws ResourceManagementException {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any())).thenThrow(new ResourceAccessException("Error"));
		ProjectDto projectDetails = bapSrvcClient.getProjectDetail(40001);
		assertNotNull(projectDetails);
	}

	@Test
	public void getProjectBasedPrimaryOwnersListTestNull() throws Exception {
		List<Long> projectIds = new ArrayList<>();
		projectIds.add(1L);
		ResponseEntity<List<PrimaryUsersDto>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any())).thenReturn(responseEntityObj);
		List<PrimaryUsersDto> opPrimaryUserDtlsList = bapSrvcClient.getProjectBasedPrimaryOwnersList(projectIds, 1l);
		assertNull(opPrimaryUserDtlsList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());
	}

	@Test
	public void getProjectBasedPrimaryOwnersListTestDiffStatusCode() throws Exception {
		List<Long> projectIds = new ArrayList<>();
		projectIds.add(1L);
		ResponseEntity<List<PrimaryUsersDto>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any())).thenReturn(responseEntityObj);
		List<PrimaryUsersDto> opPrimaryUserDtlsList = bapSrvcClient.getRoleBasedPrimaryOwnersList(1, projectIds);
		assertNull(opPrimaryUserDtlsList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());
	}

	@Test
	public void getListPrimaryOwnersListTest() throws Exception {
		List<PrimaryUsersDto> ipPrimaryUserDtlsList = new ArrayList<>();
		List<Long> projectIds = new ArrayList<>();
		projectIds.add(40001l);
		List<Long> roleIds = new ArrayList<>();
		roleIds.add(1L);
		ResponseEntity<List<PrimaryUsersDto>> response = new ResponseEntity<>(ipPrimaryUserDtlsList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any())).thenReturn(response);
		List<PrimaryUsersDto> opPrimaryUserDtlsList = bapSrvcClient.getListPrimaryOwnersList(projectIds, roleIds);
		assertNotNull(opPrimaryUserDtlsList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());

	}

	@Test
	public void getListPrimaryOwnersListTestNull() throws Exception {
		List<Long> roleIds = new ArrayList<>();
		List<Long> projectIds = new ArrayList<>();
		projectIds.add(40001l);
		roleIds.add(1L);
		ResponseEntity<List<PrimaryUsersDto>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any())).thenReturn(responseEntityObj);
		List<PrimaryUsersDto> opPrimaryUserDtlsList = bapSrvcClient.getListPrimaryOwnersList(projectIds, roleIds);
		assertNull(opPrimaryUserDtlsList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());
	}

	@Test
	public void getListPrimaryOwnersListTestDiffStatusCode() throws Exception {
		List<Long> projectIds = new ArrayList<>();
		projectIds.add(40001l);
		List<Long> roleIds = new ArrayList<>();
		roleIds.add(1L);
		ResponseEntity<List<PrimaryUsersDto>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any())).thenReturn(responseEntityObj);
		List<PrimaryUsersDto> opPrimaryUserDtlsList = bapSrvcClient.getListPrimaryOwnersList(projectIds, roleIds);
		assertNull(opPrimaryUserDtlsList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getListPrimaryOwnersListTestResourceException() throws Exception {
		List<Long> projectIds = new ArrayList<>();
		projectIds.add(40001l);
		List<Long> roleIds = new ArrayList<>();
		roleIds.add(1L);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		bapSrvcClient.getListPrimaryOwnersList(projectIds, roleIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getListPrimaryOwnersListTestHttpServerException() throws Exception {
		List<Long> projectIds = new ArrayList<>();
		projectIds.add(40001l);
		List<Long> roleIds = new ArrayList<>();
		roleIds.add(1L);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		bapSrvcClient.getListPrimaryOwnersList(projectIds, roleIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getListPrimaryOwnersListTestHttpClientException() throws Exception {
		List<Long> projectIds = new ArrayList<>();
		projectIds.add(40001l);
		List<Long> roleIds = new ArrayList<>();
		roleIds.add(1L);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any()))
						.thenThrow(HttpClientErrorException.class);
		bapSrvcClient.getListPrimaryOwnersList(projectIds, roleIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<PrimaryUsersDto>>>any());
	}
	
	
	private List<ResourceRequirementDto> getResourceRequirementDtos()
	{
		List<ResourceRequirementDto> resourceReqList = new ArrayList<ResourceRequirementDto>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(2);
		resourceRequirementDto.setResourceRequirementLocation("Pune");
		resourceRequirementDto.setServiceLineName("AMS");
	    resourceRequirementDto.setShore("DualShpre");
	    resourceRequirementDto.setBillingRateInUSD(1234.0);
		resourceRequirementDto.setRequirementRole("SoftwareEngineer");
		resourceRequirementDto.setVersion("1");
		resourceReqList.add(resourceRequirementDto);
		return resourceReqList;
	}
	
	private List<ProjectDto> getProjectList()
	{
		List<ProjectDto> projectList = new ArrayList<ProjectDto>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(40001);
		projectDto.setProjectName("test1");
		projectList.add(projectDto);
		return projectList;
	}
	
	@Test
	public void getResourceRequiremetListByIdsTest() throws ResourceManagementException
	{
		ResponseEntity<List<ResourceRequirementDto>> response = new ResponseEntity<List<ResourceRequirementDto>>(getResourceRequirementDtos(), HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any())).thenReturn(response);
		List<Long> requirmentId = new ArrayList<Long>();
		requirmentId.add(1l);
		
		List<ResourceRequirementDto> newrequirmentList= bapSrvcClient.getResourceRequiremetList(requirmentId);
		assertNotNull(newrequirmentList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any());
	}
	
	@Test
	public void getResourceRequiremetListByIdsNullTest() throws ResourceManagementException
	{
		ResponseEntity<List<ResourceRequirementDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any())).thenReturn(response);
		List<Long> requirmentId = new ArrayList<Long>();
		requirmentId.add(1l);
		
		List<ResourceRequirementDto> newrequirmentList= bapSrvcClient.getResourceRequiremetList(requirmentId);
		assertNull(newrequirmentList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any());
	}
	
	@Test
	public void getResourceRequiremetListByIdsDiffStatusCodeTest() throws ResourceManagementException
	{
		ResponseEntity<List<ResourceRequirementDto>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any())).thenReturn(response);
		List<Long> requirmentId = new ArrayList<Long>();
		requirmentId.add(1l);
		
		List<ResourceRequirementDto> newrequirmentList= bapSrvcClient.getResourceRequiremetList(requirmentId);
		assertNull(newrequirmentList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getResourceRequiremetListByIdsResourceManagmentEcep() throws ResourceManagementException
	{
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any())).thenThrow(new ResourceAccessException("Error"));
		List<Long> requirmentId = new ArrayList<Long>();
		requirmentId.add(1l);
		bapSrvcClient.getResourceRequiremetList(requirmentId);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getResourceRequiremetListByIdHttpServerException() throws ResourceManagementException
	{
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any())).thenThrow(HttpServerErrorException.class);
		List<Long> requirmentId = new ArrayList<Long>();
		requirmentId.add(1l);
		
		bapSrvcClient.getResourceRequiremetList(requirmentId);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getResourceRequiremetListByIdHttpClientException() throws ResourceManagementException
	{
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any())).thenThrow(HttpClientErrorException.class);
		List<Long> requirmentId = new ArrayList<Long>();
		requirmentId.add(1l);
		
        	bapSrvcClient.getResourceRequiremetList(requirmentId);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ResourceRequirementDto>>>any());
	}
	
	@Test
	public void getprojectListByIdsTest() throws ResourceManagementException
	{
		ResponseEntity<List<ProjectDto>> response = new ResponseEntity<List<ProjectDto>>(getProjectList(), HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenReturn(response);
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
		
		List<ProjectDto> newprojectList= bapSrvcClient.getProjectDetailByIds(projectIds);
		assertNotNull(newprojectList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());
	}
	
	@Test
	public void getprojectListByIdsTestNull() throws ResourceManagementException
	{
		ResponseEntity<List<ProjectDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenReturn(response);
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
		
		List<ProjectDto> newprojectList= bapSrvcClient.getProjectDetailByIds(projectIds);
		assertNull(newprojectList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());
	}
	
	
	@Test
	public void getprojectListByIdsDiffStatusCode() throws ResourceManagementException
	{
		ResponseEntity<List<ProjectDto>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenReturn(response);
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
		
		List<ProjectDto> newprojectList= bapSrvcClient.getProjectDetailByIds(projectIds);
		assertNull(newprojectList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getprojectListByIdsHttpServerException() throws ResourceManagementException
	{
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenThrow(HttpServerErrorException.class);
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
	     bapSrvcClient.getProjectDetailByIds(projectIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getprojectListByIdsHttpClientException() throws ResourceManagementException
	{
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenThrow(HttpClientErrorException.class);
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
	     bapSrvcClient.getProjectDetailByIds(projectIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getprojectListByIdsResourceManagmentException() throws ResourceManagementException
	{
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any())).thenThrow(new ResourceAccessException("Error"));
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
	     bapSrvcClient.getProjectDetailByIds(projectIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());
	}
	
	@Test
	public void getSkillFamilyByReqId() throws ResourceManagementException
	{
		List<SkillTaxonomyDto> listofSkillFamily = new ArrayList<SkillTaxonomyDto>();
		SkillTaxonomyDto skillFamilyDto = new SkillTaxonomyDto();
		skillFamilyDto.setRequirmentId(1l);
		skillFamilyDto.setL1PracticeId(1l);
		listofSkillFamily.add(skillFamilyDto);
		
		ResponseEntity<List<SkillTaxonomyDto>> response = new ResponseEntity<List<SkillTaxonomyDto>>(listofSkillFamily, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any())).thenReturn(response);
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
		
		List<SkillTaxonomyDto> skillFamilyList = bapSrvcClient.getSkillFamilyByReqId(projectIds);
		assertNotNull(skillFamilyList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any());
	}
	
	@Test
	public void getSkillFamilyByReqIdNull() throws ResourceManagementException
	{
	
		
		ResponseEntity<List<SkillTaxonomyDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any())).thenReturn(response);
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
		
		List<SkillTaxonomyDto> skillFamilyList = bapSrvcClient.getSkillFamilyByReqId(projectIds);
		assertNull(skillFamilyList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any());
	}
	
	@Test
	public void getSkillFamilyByReqIdDiffStatusCode() throws ResourceManagementException
	{
	
		
		ResponseEntity<List<SkillTaxonomyDto>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any())).thenReturn(response);
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
		
		List<SkillTaxonomyDto> skillFamilyList = bapSrvcClient.getSkillFamilyByReqId(projectIds);
		assertNull(skillFamilyList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getSkillFamilyByReqIdHttpServerException() throws ResourceManagementException
	{
	
		
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any())).thenThrow(HttpServerErrorException.class);
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
		
		 bapSrvcClient.getSkillFamilyByReqId(projectIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getSkillFamilyByReqIdHttpClientException() throws ResourceManagementException
	{
	
		
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any())).thenThrow(HttpClientErrorException.class);
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
		
		 bapSrvcClient.getSkillFamilyByReqId(projectIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getSkillFamilyByReqIdReasourceMangmentExcp() throws ResourceManagementException
	{
		 
		
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any())).thenThrow(new ResourceAccessException("Error"));
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
		
		 bapSrvcClient.getSkillFamilyByReqId(projectIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any());
	}



}
