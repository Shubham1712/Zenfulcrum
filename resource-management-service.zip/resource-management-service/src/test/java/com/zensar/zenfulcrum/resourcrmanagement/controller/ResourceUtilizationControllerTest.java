package com.zensar.zenfulcrum.resourcrmanagement.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.zensar.zenfulcrum.resourcemanagement.controller.ResourceUtilizationController;
import com.zensar.zenfulcrum.resourcemanagement.dto.QuarterDetailDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceUtilizationSummaryDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UtilizationDetailDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceUtilizationService;

@Ignore
public class ResourceUtilizationControllerTest {

	@InjectMocks
	private ResourceUtilizationController resourceUtilizationController;
	
	@Mock
	private ResourceUtilizationService resourceUtilizationService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
    public void getQuarterDetailsForYearTest() throws ResourceManagementException, ParseException {
		List<QuarterDetailDto> quarterDetailDtoList = new ArrayList<>();
    	when(resourceUtilizationService.getQuarterDetailsForYear()).thenReturn(quarterDetailDtoList);
        ResponseEntity<RMResponseDto> response = resourceUtilizationController.getQuarterDetailsForYear();
        assertNotNull(response);
        verify(resourceUtilizationService, times(1)).getQuarterDetailsForYear();
    }

	@Test
	public void getQuarterDetailsForYearNullTest() throws ResourceManagementException, ParseException {
		when(resourceUtilizationService.getQuarterDetailsForYear()).thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceUtilizationController.getQuarterDetailsForYear();
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceUtilizationService, times(1)).getQuarterDetailsForYear();
	}
	
	@Test
    public void getResourceUtilizationTest() throws ResourceManagementException, ParseException {
		UtilizationDetailDto utilizationDetailDto = new UtilizationDetailDto();
    	when(resourceUtilizationService.getResourceUtilization(Mockito.anyLong(),Mockito.anyString(),Mockito.anyString())).thenReturn(utilizationDetailDto);
        ResponseEntity<RMResponseDto> response = resourceUtilizationController.getResourceUtilization(1L,"test","test");
        assertNotNull(response);
        verify(resourceUtilizationService, times(1)).getResourceUtilization(Mockito.anyLong(),Mockito.anyString(),Mockito.anyString());
    }

	@Test
	public void getResourceUtilizationNullTest() throws ResourceManagementException, ParseException {
		when(resourceUtilizationService.getResourceUtilization(Mockito.anyLong(),Mockito.anyString(),Mockito.anyString())).thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceUtilizationController.getResourceUtilization(1L,"test","test");
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceUtilizationService, times(1)).getResourceUtilization(Mockito.anyLong(),Mockito.anyString(),Mockito.anyString());
	}
	
	@Test
    public void getResourceUtilizationSummaryDetailsTest() throws ResourceManagementException, ParseException {
		ResourceUtilizationSummaryDto utilizationDetailDto = new ResourceUtilizationSummaryDto(); 
		when(resourceUtilizationService.getResourceUtilizationSummaryDetails(Mockito.anyLong())).thenReturn(utilizationDetailDto);
        ResponseEntity<ResourceUtilizationSummaryDto> response = resourceUtilizationController.getResourceUtilizationSummaryDetails(1L);
        assertNotNull(response);
        verify(resourceUtilizationService, times(1)).getResourceUtilizationSummaryDetails(Mockito.anyLong());
    }

	@Test
	public void getResourceUtilizationSummaryDetailsNullTest() throws ResourceManagementException, ParseException {
		when(resourceUtilizationService.getResourceUtilizationSummaryDetails(Mockito.anyLong())).thenReturn(null);
		ResponseEntity<ResourceUtilizationSummaryDto> responseEntityObj = resourceUtilizationController.getResourceUtilizationSummaryDetails(1L);
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceUtilizationService, times(1)).getResourceUtilizationSummaryDetails(Mockito.anyLong());
	}
}
