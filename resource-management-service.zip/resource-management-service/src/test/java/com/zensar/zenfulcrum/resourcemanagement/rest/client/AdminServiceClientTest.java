package com.zensar.zenfulcrum.resourcemanagement.rest.client;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.zensar.zenfulcrum.resourcemanagement.dto.AllocationTypeStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CountryDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LeaveDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueAndDescDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PracticeProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PractiseDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBuDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApproversDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ReasonForDeallocation;
import com.zensar.zenfulcrum.resourcemanagement.dto.RoleDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ServiceLineDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SuperVisiorDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UserDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UtilizationDetailDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UtilizationProjectDetails;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class AdminServiceClientTest {

	@Mock  
	private RestTemplate restTemplate;
	@InjectMocks
	private AdminServiceClient adminSrvcClient;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(adminSrvcClient, "adminBaseUrl", "adminBaseUrl");
		ReflectionTestUtils.setField(adminSrvcClient, "getRMApproversListRestURL", "getRMApproversListRestURL");
		ReflectionTestUtils.setField(adminSrvcClient, "getEarmarkedAssociatesRestURL", "getEarmarkedAssociatesRestURL");
		ReflectionTestUtils.setField(adminSrvcClient, "getLookupValueRestURL", "getLookupValueRestURL");
		ReflectionTestUtils.setField(adminSrvcClient, "getModuleStatusRestURL", "getModuleStatusRestURL");
		ReflectionTestUtils.setField(adminSrvcClient, "getEmailAddressURL", "getEmailAddressURL");
		ReflectionTestUtils.setField(adminSrvcClient, "getModuleDetailsURL", "getModuleDetailsURL");
		ReflectionTestUtils.setField(adminSrvcClient, "getRMTransferApproversList", "getRMTransferApproversList");
		ReflectionTestUtils.setField(adminSrvcClient, "getPractiseDetailsURL", "getPractiseDetailsURL");
		ReflectionTestUtils.setField(adminSrvcClient, "getResourceDtlsListByPracticeName",
				"getResourceDtlsListByPracticeName");
		ReflectionTestUtils.setField(adminSrvcClient, "getEmployeeDetailsURL", "getEmployeeDetailsURL");
		ReflectionTestUtils.setField(adminSrvcClient, "getAllocationTypeStatus", "getAllocationTypeStatus");
		ReflectionTestUtils.setField(adminSrvcClient, "getListOfSkillsURL", "getListOfSkillsURL");
		ReflectionTestUtils.setField(adminSrvcClient, "getResourceDtlsListByRoleName", "getResourceDtlsListByRoleName");
		ReflectionTestUtils.setField(adminSrvcClient, "getListOfRolesURL", "getListOfRolesURL");
		ReflectionTestUtils.setField(adminSrvcClient, "getResourceDtlsListBySkill", "getResourceDtlsListBySkill");
		ReflectionTestUtils.setField(adminSrvcClient, "getLookupByIdRestURL", "getLookupByIdRestURL");
		ReflectionTestUtils.setField(adminSrvcClient, "getResourcePracticeAllocURL", "getResourcePracticeAllocURL");
		ReflectionTestUtils.setField(adminSrvcClient, "getPracticeProjectURL", "getPracticeProjectURL");
	    ReflectionTestUtils.setField(adminSrvcClient, "leaveDetailsURL", "leaveDetailsURL"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getSuperVisiorList", "getSuperVisiorList"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getModuleStatusListRestURL", "getModuleStatusListRestURL"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getListOfLookupValueURL", "getListOfLookupValueURL"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getCountryForResourceURL", "getCountryForResourceURL"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getAllModuleDetailsListURL", "getAllModuleDetailsListURL"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getAdminPDBaseRestUrl", "getAdminPDBaseRestUrl"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getSkillFamilyBySkillId", "getSkillFamilyBySkillId"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getCostCardRestUrl", "getCostCardRestUrl"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getRMAdminRestUrl", "getRMAdminRestUrl"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "projectDefinationBasetUrl", "projectDefinationBasetUrl"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getCountryByLocationIdURL", "getCountryByLocationIdURL"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getEmployeeDetailsByEmpIdURL", "getEmployeeDetailsByEmpIdURL"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getProjectBillableIdURL", "getProjectBillableIdURL"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getProjectByProjectIdURL", "getProjectByProjectIdURL"); 
	    ReflectionTestUtils.setField(adminSrvcClient, "getUtilizationDetails", "getUtilizationDetails");
 
	    ReflectionTestUtils.setField(adminSrvcClient, "looUpDescriptionRestUrl", "looUpDescriptionRestUrl");
		ReflectionTestUtils.setField(adminSrvcClient, "getAllEmployeeDetailsUrl", "getAllEmployeeDetailsUrl");

 
		ReflectionTestUtils.setField(adminSrvcClient, "getProjectBudgetStatus", "getProjectBudgetStatus");
		ReflectionTestUtils.setField(adminSrvcClient, "getModuleStatusByAction", "getModuleStatusByAction");
		ReflectionTestUtils.setField(adminSrvcClient, "getLookUpbyTypeAndDescrUrl", "getLookUpbyTypeAndDescrUrl");
		ReflectionTestUtils.setField(adminSrvcClient, "getPrimaryOwnerUserIdListByProjectId", "getPrimaryOwnerUserIdListByProjectId");
		ReflectionTestUtils.setField(adminSrvcClient, "associateByEmpIdRestUrl", "associateByEmpIdRestUrl");
		ReflectionTestUtils.setField(adminSrvcClient, "getLookuIdByTypeAndDescrListUrl", "getLookuIdByTypeAndDescrListUrl");		
		ReflectionTestUtils.setField(adminSrvcClient, "getBuForProjectRestUrl", "getBuForProjectRestUrl");		
		ReflectionTestUtils.setField(adminSrvcClient, "getLookUpValueDetailsByIds", "getLookUpValueDetailsByIds");
		ReflectionTestUtils.setField(adminSrvcClient, "getServiceLineListRestURL", "getServiceLineListRestURL");
	}
      
	@Test
	public void getRMApproversListTest() throws Exception {
		RMApproversDto rmApproversDtoObj = new RMApproversDto();
		rmApproversDtoObj.setRoleId(1);
		rmApproversDtoObj.setRoleName("PM");
		rmApproversDtoObj.setUserId(1);
		rmApproversDtoObj.setUserName("User-1");
		List<RMApproversDto> ipRMApproversListDtoObj = new ArrayList<>();
		ipRMApproversListDtoObj.add(rmApproversDtoObj);
		List<Long> userIdListObj = new ArrayList<>();
		userIdListObj.add(1L);
		List<Long> roleIdListObj = new ArrayList<>();
		roleIdListObj.add(1L);
		ResponseEntity<List<RMApproversDto>> responseEntityObj = new ResponseEntity<>(ipRMApproversListDtoObj,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RMApproversDto>>>any())).thenReturn(responseEntityObj);
		List<RMApproversDto> opRMApproversListDtoObj = adminSrvcClient.getRMApproversList(roleIdListObj, userIdListObj);
		assertNotNull(opRMApproversListDtoObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RMApproversDto>>>any());

	}

	@Test
	public void getRMApproversListTestNull() throws Exception {
		List<Long> userIdListObj = new ArrayList<>();
		userIdListObj.add(1L);
		List<Long> roleIdListObj = new ArrayList<>();
		roleIdListObj.add(1L);
		ResponseEntity<List<RMApproversDto>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RMApproversDto>>>any())).thenReturn(responseEntityObj);
		List<RMApproversDto> opRMApproversListDtoObj = adminSrvcClient.getRMApproversList(roleIdListObj, userIdListObj);
		assertNull(opRMApproversListDtoObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RMApproversDto>>>any());

	}
  
	@Test
	public void getRMApproversListTestDiffStatusCode() throws Exception {
		List<Long> userIdListObj = new ArrayList<>();
		userIdListObj.add(1L);
		List<Long> roleIdListObj = new ArrayList<>();
		roleIdListObj.add(1L);
		ResponseEntity<List<RMApproversDto>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RMApproversDto>>>any())).thenReturn(responseEntityObj);
		List<RMApproversDto> opRMApproversListDtoObj = adminSrvcClient.getRMApproversList(roleIdListObj, userIdListObj);
		assertNull(opRMApproversListDtoObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RMApproversDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getRMApproversListTestResourceException() throws Exception {
		List<Long> userIdListObj = new ArrayList<>();
		userIdListObj.add(1L);
		List<Long> roleIdListObj = new ArrayList<>();
		roleIdListObj.add(1L);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RMApproversDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getRMApproversList(roleIdListObj, userIdListObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RMApproversDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getRMApproversListTestHttpServerException() throws Exception {
		List<Long> userIdListObj = new ArrayList<>();
		userIdListObj.add(1L);
		List<Long> roleIdListObj = new ArrayList<>();
		roleIdListObj.add(1L);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RMApproversDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getRMApproversList(roleIdListObj, userIdListObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RMApproversDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getRMApproversListTestHttpClientException() throws Exception {
		List<Long> userIdListObj = new ArrayList<>();
		userIdListObj.add(1L);
		List<Long> roleIdListObj = new ArrayList<>();
		roleIdListObj.add(1L);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RMApproversDto>>>any()))
						.thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getRMApproversList(roleIdListObj, userIdListObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RMApproversDto>>>any());
	}

	@Test
	public void getAssociatesDetailsTest() throws Exception {
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(1L);
		employeeDto.setEmployeeName("Test");
		List<EmployeeDto> employeesObj = new ArrayList<>();
		employeesObj.add(employeeDto);
		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<>(employeesObj, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);
		List<Long> empIds = new ArrayList<>();
		empIds.add(1L);
		empIds.add(2L);
		List<EmployeeDto> employees = adminSrvcClient.getAssociatesDetails(empIds);
		assertNotNull(employees);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test
	public void getEarmarkedAssociatesTestNull() throws Exception {
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(1L);
		employeeDto.setEmployeeName("Test");
		List<EmployeeDto> employeesObj = new ArrayList<>();
		employeesObj.add(employeeDto);
		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);
		List<Long> empIds = new ArrayList<>();
		empIds.add(1L);
		empIds.add(2L);
		List<EmployeeDto> employees = adminSrvcClient.getAssociatesDetails(empIds);
		assertNull(employees);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test
	public void getEarmarkedAssociatesTestDiffStatusCode() throws Exception {
		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);
		List<Long> empIds = new ArrayList<>();
		empIds.add(1l);
		empIds.add(2l);
		List<EmployeeDto> employees = adminSrvcClient.getAssociatesDetails(empIds);
		assertNull(employees);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getEarmarkedAssociatesTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(new ResourceAccessException("Error"));
		List<Long> empIds = new ArrayList<>();
		empIds.add(1l);
		empIds.add(2l);
		adminSrvcClient.getAssociatesDetails(empIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getEarmarkedAssociatesTestHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		List<Long> empIds = new ArrayList<>();
		empIds.add(1l);
		empIds.add(2l);
		adminSrvcClient.getAssociatesDetails(empIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getEarmarkedAssociatesTestHttpClientException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(HttpClientErrorException.class);
		List<Long> empIds = new ArrayList<>();
		empIds.add(1l);
		empIds.add(2l);
		adminSrvcClient.getAssociatesDetails(empIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test
	public void getModuleStatus() throws Exception {
		ModuleStatusDto moduleStatus = new ModuleStatusDto();
		moduleStatus.setModuleId(1l);
		ResponseEntity<ModuleStatusDto> response = new ResponseEntity<>(moduleStatus, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any())).thenReturn(response);
		ModuleStatusDto moduleStatusDto = adminSrvcClient.getModuleStatus("RM", "ALLOCATION", "ACTION");
		assertNotNull(moduleStatusDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any());
	}

	@Test
	public void getModuleStatusTestNull() throws Exception {
		ResponseEntity<ModuleStatusDto> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any())).thenReturn(response);
		ModuleStatusDto moduleStatusDto = adminSrvcClient.getModuleStatus("RM", "ALLOCATION", "ACTION");
		assertNull(moduleStatusDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any());
	}

	@Test
	public void getModuleStatusTestDiffStatusCode() throws Exception {
		ResponseEntity<ModuleStatusDto> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any())).thenReturn(response);
		ModuleStatusDto moduleStatusDto = adminSrvcClient.getModuleStatus("RM", "ALLOCATION", "ACTION");
		assertNull(moduleStatusDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getModuleStatusTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any())).thenThrow(new ResourceAccessException("Error"));
		adminSrvcClient.getModuleStatus("RM", "ALLOCATION", "ACTION");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getModuleStatusTestHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getModuleStatus("RM", "ALLOCATION", "ACTION");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getModuleStatusTestHttpClientException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any())).thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getModuleStatus("RM", "ALLOCATION", "ACTION");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any());
	}

	@Test
	public void getLookupValueStatus() throws Exception {
		LookupValueDto moduleStatus = new LookupValueDto();
		moduleStatus.setLookUpId(1l);
		ResponseEntity<LookupValueDto> response = new ResponseEntity<>(moduleStatus, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any())).thenReturn(response);
		LookupValueDto lookupValue = adminSrvcClient.getLookupValue("BILLABLE_STATUS", "BILLABLE");
		assertNotNull(lookupValue);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any());
	}

	@Test
	public void getLookupValueTestNull() throws Exception {
		ResponseEntity<LookupValueDto> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any())).thenReturn(response);
		LookupValueDto lookupValueDto = adminSrvcClient.getLookupValue("BILLABLE_STATUS", "BILLABLE");
		assertNull(lookupValueDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any());
	}

	@Test
	public void getLookupValueTestDiffStatusCode() throws Exception {
		ResponseEntity<LookupValueDto> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any())).thenReturn(response);
		LookupValueDto lookupValueDto = adminSrvcClient.getLookupValue("BILLABLE_STATUS", "BILLABLE");
		assertNull(lookupValueDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getLookupValueTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any())).thenThrow(new ResourceAccessException("Error"));
		adminSrvcClient.getLookupValue("BILLABLE_STATUS", "BILLABLE");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getLookupValueTestHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getLookupValue("BILLABLE_STATUS", "BILLABLE");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any());
	} 
	
	

	@Test(expected = ResourceManagementException.class)
	public void getLookupValueTestHttpClientException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any())).thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getLookupValue("BILLABLE_STATUS", "BILLABLE");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any());
	}

	@Test
	public void getAssociatesEmailAddressTest() throws Exception {
		List<String> emailIds = new ArrayList<>();
		emailIds.add("testMail.zensar.com");
		ResponseEntity<List<String>> response = new ResponseEntity<>(emailIds, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any())).thenReturn(response);
		List<Long> empIds = new ArrayList<>();
		empIds.add(1l);
		empIds.add(3l);
		List<String> emails = adminSrvcClient.getAssociatesEmailAddress(empIds);
		assertNotNull(emails);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getAssociatesEmailAddressResourceExceptionTest() throws Exception {

		List<Long> empIds = new ArrayList<>();
		empIds.add(90L);
		empIds.add(89L);

		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getAssociatesEmailAddress(empIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getAssociatesEmailAddressHttpClientExceptionTest() throws Exception {
		List<Long> empIds = new ArrayList<>();
		empIds.add(90L);
		empIds.add(89L);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any())).thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getAssociatesEmailAddress(empIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any());
	}

	@Test
	public void getReasonForDeallocation() throws ResourceManagementException {
		List<ReasonForDeallocation> reasonList = new ArrayList<>();
		ReasonForDeallocation reasonForDeallocation = new ReasonForDeallocation();
		reasonForDeallocation.setReasonId(1l);
		reasonForDeallocation.setReason("Maternity Leave");  

		ResponseEntity<List<ReasonForDeallocation>> response = new ResponseEntity<List<ReasonForDeallocation>>(
				reasonList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ReasonForDeallocation>>>any())).thenReturn(response);
		List<ReasonForDeallocation> newreasonList = adminSrvcClient.getReasonForDeallocation();
		assertNotNull(newreasonList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());

	}

	@Test
	public void getReasonForDeallocationDiffStatusCode() throws ResourceManagementException {

		ResponseEntity<List<ReasonForDeallocation>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ReasonForDeallocation>>>any())).thenReturn(response);
		List<ReasonForDeallocation> newreasonList = adminSrvcClient.getReasonForDeallocation();
		assertNull(newreasonList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());

	}

	@Test
	public void getReasonForDeallocationNull() throws ResourceManagementException {

		ResponseEntity<List<ReasonForDeallocation>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ReasonForDeallocation>>>any())).thenReturn(response);
		List<ReasonForDeallocation> newreasonList = adminSrvcClient.getReasonForDeallocation();
		assertNull(newreasonList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getReasonForDeallocationResourceTest() throws ResourceManagementException {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ReasonForDeallocation>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getReasonForDeallocation();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getReasonForDeallocationHttpServerExceptionTest() throws ResourceManagementException {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ReasonForDeallocation>>>any()))
						.thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getReasonForDeallocation();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getReasonForDeallocationHttpClientExceptionTest() throws ResourceManagementException {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ReasonForDeallocation>>>any()))
						.thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getReasonForDeallocation();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ProjectDto>>>any());

	}

	@Test
	public void getModuleDetails() throws Exception {
		ModuleStatusDto ipModuleDtls = new ModuleStatusDto();
		ipModuleDtls.setModuleId(1l);
		ipModuleDtls.setModuleCode("RMA");
		ResponseEntity<ModuleStatusDto> response = new ResponseEntity<>(ipModuleDtls, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any())).thenReturn(response);
		ModuleStatusDto opModuleDtls = adminSrvcClient.getModuleDetails("ResourceManagement", "ResourceAllocation");
		assertNotNull(opModuleDtls);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any());
	}

	@Test
	public void getModuleDetailsTestNull() throws Exception {
		ResponseEntity<ModuleStatusDto> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any())).thenReturn(response);
		adminSrvcClient.getModuleDetails("ResourceManagement", "ResourceAllocation");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any());
	}

	@Test
	public void getModuleDetailsTestDiffStatusCode() throws Exception {
		ResponseEntity<ModuleStatusDto> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any())).thenReturn(response);
		adminSrvcClient.getModuleDetails("ResourceManagement", "ResourceAllocation");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getModuleDetailsTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any())).thenThrow(new ResourceAccessException("Error"));
		adminSrvcClient.getModuleDetails("ResourceManagement", "ResourceAllocation");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getModuleDetailsTestHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getModuleDetails("ResourceManagement", "ResourceAllocation");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getModuleDetailsTestHttpClientException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any())).thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getModuleDetails("ResourceManagement", "ResourceAllocation");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<ModuleStatusDto>>any());
	}

	@Test
	public void getEmailRMApproversListTest() throws Exception {

		UserDto userDto = new UserDto();
		userDto.setUserId(52336l);
		userDto.setUserName("user-4");
		List<UserDto> userList = new ArrayList<>();
		userList.add(userDto);
		ResponseEntity<List<UserDto>> response = new ResponseEntity<List<UserDto>>(userList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDto>>>any())).thenReturn(response);
		List<UserDto> userValue = adminSrvcClient.getEmailRMApproversList(40001l, 2);
		assertNotNull(userValue);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDto>>>any());
	}

	@Test
	public void getEmailRMApproversListTestNull() throws Exception {
		ResponseEntity<List<UserDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDto>>>any())).thenReturn(response);
		List<UserDto> userValue = adminSrvcClient.getEmailRMApproversList(40001l, 2);
		assertNull(userValue);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDto>>>any());
	}

	@Test
	public void getEmailRMApproversListDiffStatusCode() throws ResourceManagementException {

		ResponseEntity<List<UserDto>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDto>>>any())).thenReturn(response);
		List<UserDto> userValue = adminSrvcClient.getEmailRMApproversList(40001l, 2);
		assertNull(userValue);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDto>>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getEmailRMApproversListHttpClientExceptionTest() throws ResourceManagementException {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDto>>>any())).thenThrow(HttpClientErrorException.class);
		List<UserDto> userValue = adminSrvcClient.getEmailRMApproversList(40001l, 2);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<UserDto>>>any());

	}

	@Test
	public void getPractiseDetailsTest() throws Exception {
		EmployeeDto employee = new EmployeeDto();
		employee.setEmployeeId(52339l);

		ResponseEntity<EmployeeDto> response = new ResponseEntity<EmployeeDto>(employee, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenReturn(response);

		EmployeeDto newprojectDto = adminSrvcClient.getEmployeeDetails(123l);
		assertNotNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test
	public void getPractiseDetailsTestNull() throws Exception {

		ResponseEntity<EmployeeDto> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenReturn(response);

		EmployeeDto newprojectDto = adminSrvcClient.getEmployeeDetails(123l);
		assertNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test
	public void getPractiseDetailsDiffSatusCodeTest() throws Exception {

		ResponseEntity<EmployeeDto> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenReturn(response);

		EmployeeDto newprojectDto = adminSrvcClient.getEmployeeDetails(123l);
		assertNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getPractiseDetailsResourceManagmentExcetionTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getEmployeeDetails(123l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getPractiseDetailsHttpServerTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getEmployeeDetails(123l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getPractiseDetailsHttpClientTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getEmployeeDetails(123l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test
	public void getResourceDtlsListByPracticeNameTest() throws Exception {

		List<EmployeeDto> employeeDtoList = new ArrayList<>();
		EmployeeDto employee = new EmployeeDto();
		employee.setEmployeeId(52339l);
		employeeDtoList.add(employee);

		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<List<EmployeeDto>>(employeeDtoList,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);

		adminSrvcClient.getResourceDtlsListByPractice(1L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test
	public void getResourceDtlsListByPracticeNameTestNull() throws Exception {

		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);

		adminSrvcClient.getResourceDtlsListByPractice(1L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceDtlsListByPracticeNameHttpServerTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getResourceDtlsListByPractice(1L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceDtlsListByPracticeNameHttpClientTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getResourceDtlsListByPractice(1L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceDtlsListByPracticeNameResourceManagmentExcetionTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getResourceDtlsListByPractice(1L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test
	public void getEmployeeByNameTest() throws Exception {
		EmployeeDto employee = new EmployeeDto();
		employee.setEmployeeName("xyz");

		ResponseEntity<EmployeeDto> response = new ResponseEntity<EmployeeDto>(employee, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenReturn(response);

		EmployeeDto newprojectDto = adminSrvcClient.getEmployeeByNameOrId("xyz");
		assertNotNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test
	public void getEmployeeByNameTestNull() throws Exception {

		ResponseEntity<EmployeeDto> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenReturn(response);

		EmployeeDto newprojectDto = adminSrvcClient.getEmployeeByNameOrId("xyz");
		assertNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test
	public void getEmployeeByNameDiffSatusCodeTest() throws Exception {

		ResponseEntity<EmployeeDto> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenReturn(response);

		EmployeeDto newprojectDto = adminSrvcClient.getEmployeeByNameOrId("xyz");
		assertNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getEmployeeByNameResourceManagmentExcetionTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getEmployeeByNameOrId("xyz");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getEmployeeByNameHttpServerTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getEmployeeByNameOrId("xyz");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getEmployeeByNameHttpClientTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getEmployeeByNameOrId("xyz");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test
	public void getAllocationTypeStatusDetailsTest() throws Exception {
		AllocationTypeStatusDto allocationTypeStatusDto = new AllocationTypeStatusDto();
		allocationTypeStatusDto.setAllocationTypeValue("xyz");
		ResponseEntity<AllocationTypeStatusDto> response = new ResponseEntity<AllocationTypeStatusDto>(
				allocationTypeStatusDto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<AllocationTypeStatusDto>>any())).thenReturn(response);

		AllocationTypeStatusDto allocationTypeStatu = adminSrvcClient.getAllocationTypeStatus("xyz");
		assertNotNull(allocationTypeStatu);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<AllocationTypeStatusDto>>any());
	}

	@Test
	public void getAllocationTypeStatusDetailsNull() throws Exception {

		ResponseEntity<AllocationTypeStatusDto> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<AllocationTypeStatusDto>>any())).thenReturn(response);

		AllocationTypeStatusDto allocationTypeStatu = adminSrvcClient.getAllocationTypeStatus("xyz");
		assertNull(allocationTypeStatu);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<AllocationTypeStatusDto>>any());
	}

	@Test
	public void getAllocationTypeStatusDetailsDiffSatusCodeTest() throws Exception {

		ResponseEntity<AllocationTypeStatusDto> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<AllocationTypeStatusDto>>any())).thenReturn(response);

		AllocationTypeStatusDto newprojectDto = adminSrvcClient.getAllocationTypeStatus("xyz");
		assertNull(newprojectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<AllocationTypeStatusDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getAllocationTypeStatusDetailsResourceManagmentExcetionTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<AllocationTypeStatusDto>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getAllocationTypeStatus("xyz");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<AllocationTypeStatusDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getAllocationTypeStatusDetailsHttpServerTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<AllocationTypeStatusDto>>any()))
						.thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getAllocationTypeStatus("xyz");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<AllocationTypeStatusDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getAllocationTypeStatusDetailsHttpClientTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<AllocationTypeStatusDto>>any()))
						.thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getAllocationTypeStatus("xyz");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<AllocationTypeStatusDto>>any());
	}

	@Test
	public void getListOfSkillsTest() throws Exception {

		List<SkillDto> skillList = new ArrayList<>();
		SkillDto dto1 = new SkillDto();
		dto1.setSkillId(52339l);
		dto1.setSkillName("Java");
		skillList.add(dto1);

		ResponseEntity<List<SkillDto>> response = new ResponseEntity<List<SkillDto>>(skillList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillDto>>>any())).thenReturn(response);

		adminSrvcClient.getListOfSkills();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getListOfSkillsHttpServerTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillDto>>>any())).thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getListOfSkills();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getListOfSkillsHttpClientTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillDto>>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getListOfSkills();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getListOfSkillsResourceManagmentExcetionTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getListOfSkills();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<SkillDto>>>any());
	}

	@Test
	public void getListOfRoleTest() throws Exception {
		List<RoleDto> roleList = new ArrayList<>();
		RoleDto roleDto1 = new RoleDto();
		roleDto1.setRoleId(2l);
		roleDto1.setRoleName("Net");
		roleList.add(roleDto1);
		ResponseEntity<List<RoleDto>> response = new ResponseEntity<List<RoleDto>>(roleList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RoleDto>>>any())).thenReturn(response);
		adminSrvcClient.getListOfRoles();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RoleDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getListOfRolesHttpServerTest() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RoleDto>>>any())).thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getListOfRoles();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RoleDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getListOfRolesHttpClientTest() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RoleDto>>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getListOfRoles();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RoleDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getListOfRolesResourceManagmentExcetionTest() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RoleDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getListOfRoles();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<RoleDto>>>any());
	}

	@Test
	public void getResourceDtlsListByRoleNameTest() throws Exception {

		List<EmployeeDto> employeeDtoList = new ArrayList<>();
		EmployeeDto employee = new EmployeeDto();
		employee.setEmployeeId(52339l);
		employeeDtoList.add(employee);

		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<List<EmployeeDto>>(employeeDtoList,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);

		adminSrvcClient.getResourceDtlsListByRoleName("SOFTWARE ENGINEER ");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test
	public void getResourceDtlsListByRoleNameTestNull() throws Exception {

		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);
		adminSrvcClient.getResourceDtlsListByRoleName("SOFTWARE ENGINEER ");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceDtlsListByRoleNameHttpServerTest() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getResourceDtlsListByRoleName("SOFTWARE ENGINEER ");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceDtlsListByRoleNameHttpClientTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getResourceDtlsListByRoleName("SOFTWARE ENGINEER ");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceDtlsListByRoleNameResourceManagmentExcetionTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getResourceDtlsListByRoleName("SOFTWARE ENGINEER ");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test
	public void getResourceDtlsListBySkillTest() throws Exception {

		List<EmployeeDto> employeeDtoList = new ArrayList<>();
		EmployeeDto employee = new EmployeeDto();
		employee.setEmployeeId(52339l);
		employeeDtoList.add(employee);

		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<List<EmployeeDto>>(employeeDtoList,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);

		adminSrvcClient.getResourceDtlsListBySkill("Java");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test
	public void getResourceDtlsListBySkillTestNull() throws Exception {

		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);

		adminSrvcClient.getResourceDtlsListBySkill("Java");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceDtlsListBySkillHttpServerTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getResourceDtlsListBySkill("Java");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceDtlsListBySkillHttpClientTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getResourceDtlsListBySkill("Java");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceDtlsListBySkillResourceManagmentExcetionTest() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getResourceDtlsListBySkill("Java");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}
	
	@Test
	public void getListOfPracticeNamesTest() throws Exception {
		List<String> practiceNames = new ArrayList<>();
    	practiceNames.add("ADS");
		ResponseEntity<List<String>> response = new ResponseEntity<List<String>>(practiceNames, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any())).thenReturn(response);
		adminSrvcClient.getListOfPractice();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getListOfPracticeNamesHttpServerTest() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any())).thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getListOfPractice();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getListOfPracticeNamesHttpClientTest() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getListOfPractice();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any());
	}
	@Test(expected = ResourceManagementException.class)
	public void getListOfPracticeNamesResourceAccessExceptionTest() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any())).thenThrow(ResourceAccessException.class);
		adminSrvcClient.getListOfPractice();
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<String>>>any());
	}
	

	@Test
	public void getLookUpByIdTest() throws Exception {
		LookupValueDto lookupValueDto = new LookupValueDto();
		lookupValueDto.setLookUpId(1L);
		lookupValueDto.setLookupType("EBR");
		lookupValueDto.setLookupValueCode("EBR");
		
		ResponseEntity<LookupValueDto> response = new ResponseEntity<>(lookupValueDto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any())).thenReturn(response);
		LookupValueDto lookupValue = adminSrvcClient.getLookUpById(1L);
		assertNotNull(lookupValue);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getLookUpByIdHttpClientTest() throws Exception {
		
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getLookUpById(1L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<LookupValueDto>>any());
	}
	@Test(expected = ResourceManagementException.class)
	public void getLookUpByIdResourceAccessExceptionTest() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any())).thenThrow(ResourceAccessException.class);
		adminSrvcClient.getLookUpById(1L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<LookupValueDto>>any());
	}

	@Test
	public void getResourcePracticeAllocByEmpIdTest() throws Exception {
		PractiseDetailsDto practiceDetailDto = new PractiseDetailsDto();
		practiceDetailDto.setEmpId(51436);
		practiceDetailDto.setPractiseId(1);
		practiceDetailDto.setLocation("PUNe");;
		
		ResponseEntity<PractiseDetailsDto> response = new ResponseEntity<>(practiceDetailDto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<PractiseDetailsDto>>any())).thenReturn(response);
		PractiseDetailsDto lookupValue = adminSrvcClient.getResourcePracticeAllocByEmpId(1L);
		assertNotNull(lookupValue);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<PractiseDetailsDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getResourcePracticeAllocByEmpIdHttpClientTest() throws Exception {
		
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<PractiseDetailsDto>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getResourcePracticeAllocByEmpId(51436L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<PractiseDetailsDto>>any());
	}
	@Test(expected = ResourceManagementException.class)
	public void getResourcePracticeAllocByEmpIdResourceAccessExceptionTest() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<PractiseDetailsDto>>any())).thenThrow(ResourceAccessException.class);
		adminSrvcClient.getResourcePracticeAllocByEmpId(51436L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<PractiseDetailsDto>>any());
	}
	
	@Test
	public void getPracticeProjectTest() throws Exception {
		PracticeProjectDto practiceProjectDto = new PracticeProjectDto();
		practiceProjectDto.setPracticeId(1);
		practiceProjectDto.setPracticeProjectId(1);
		practiceProjectDto.setPracticeProjectName("ABC");
		practiceProjectDto.setProjectId(1);
		ResponseEntity<PracticeProjectDto> response = new ResponseEntity<>(practiceProjectDto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<PracticeProjectDto>>any())).thenReturn(response);
		PracticeProjectDto lookupValue = adminSrvcClient.getPracticeProject(1L);
		assertNotNull(lookupValue);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<PracticeProjectDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getPracticeProjectHttpClientTest() throws Exception {
		
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<PracticeProjectDto>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getPracticeProject(51436L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<PracticeProjectDto>>any());
	}
	@Test(expected = ResourceManagementException.class)
	public void getPracticeProjectResourceAccessExceptionTest() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<PracticeProjectDto>>any())).thenThrow(ResourceAccessException.class);
		adminSrvcClient.getPracticeProject(51436L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<PracticeProjectDto>>any());
	}
	
	
// NEW CODE		
	private LeaveDetailsDto getLeaveDeatils()
	{
		LeaveDetailsDto leaveDetailsDto = new LeaveDetailsDto();
		leaveDetailsDto.setEmployeeId(52330l);
		leaveDetailsDto.setLeaveId(1l);
		leaveDetailsDto.setStatus("Approved");
		return  leaveDetailsDto;
	}
	
	
	private List<SuperVisiorDetailsDto> getSupervisiorList()
	{
		List<SuperVisiorDetailsDto> superVisiorDetailsList = new ArrayList<SuperVisiorDetailsDto>();
		SuperVisiorDetailsDto superVisiorDetailsDto  = new SuperVisiorDetailsDto();
		superVisiorDetailsDto.setEmpId(52339l);
		superVisiorDetailsDto.setEmpName("SandepBhai Yadav");
		superVisiorDetailsList.add(superVisiorDetailsDto);
		return superVisiorDetailsList;
	}
	
	
	
	@Test
	public void getLeaveDetailsTest() throws Exception {

		ResponseEntity<LeaveDetailsDto> response = new ResponseEntity<LeaveDetailsDto>(getLeaveDeatils(),
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<LeaveDetailsDto>>any()))
						.thenReturn(response);

		LeaveDetailsDto leaveDetailsDto = adminSrvcClient.getLeaveDetails(123l);
		assertNotNull(leaveDetailsDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<LeaveDetailsDto>>any());
	}
	
	
	@Test
	public void getLeaveDetailsNull() throws Exception {

		ResponseEntity<LeaveDetailsDto> response = new ResponseEntity<>(null,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<LeaveDetailsDto>>any()))
						.thenReturn(response);

		LeaveDetailsDto leaveDetailsDto = adminSrvcClient.getLeaveDetails(123l);
		assertNull(leaveDetailsDto);
	   verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<LeaveDetailsDto>>any());
	}
	
	
	@Test
	public void getLeaveDetailsDiffStatusCode1() throws Exception {

		ResponseEntity<LeaveDetailsDto> response = new ResponseEntity<>(null,
				HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<LeaveDetailsDto>>any()))
						.thenReturn(response);

		LeaveDetailsDto leaveDetailsDto = adminSrvcClient.getLeaveDetails(123l);
		assertNull(leaveDetailsDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<LeaveDetailsDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getLeaveDetailsResoureManagmentException() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<LeaveDetailsDto>>any()))
						.thenThrow(new ResourceAccessException("TestError"));

		adminSrvcClient.getLeaveDetails(123l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<LeaveDetailsDto>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getLeaveDetailsHTTPServerException() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<LeaveDetailsDto>>any()))
						.thenThrow(HttpServerErrorException.class);

		adminSrvcClient.getLeaveDetails(123l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<LeaveDetailsDto>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getLeaveDetailsHTTPClientException() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<LeaveDetailsDto>>any()))
						.thenThrow(HttpClientErrorException.class);
		
		adminSrvcClient.getLeaveDetails(123l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<LeaveDetailsDto>>any());
	}
	
	
	@Test
	public void getsupervisiorListTest() throws Exception {

		ResponseEntity<List<SuperVisiorDetailsDto>> response = new ResponseEntity<List<SuperVisiorDetailsDto>>(getSupervisiorList(),
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<SuperVisiorDetailsDto>>>any()))
						.thenReturn(response);
		List<Long> empIds = new ArrayList<Long>();
		empIds.add(1l);

		List<SuperVisiorDetailsDto> supervisiorList = adminSrvcClient.getSuperVisiorList(empIds);
		assertNotNull(supervisiorList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<SuperVisiorDetailsDto>>>any());
	}
	
	
	@Test
	public void getsupervisiorListNull() throws Exception {

		ResponseEntity<List<SuperVisiorDetailsDto>> response = new ResponseEntity<>(null,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<SuperVisiorDetailsDto>>>any()))
						.thenReturn(response);
		List<Long> empIds = new ArrayList<Long>();
		empIds.add(1l);
        List<SuperVisiorDetailsDto> supervisiorList = adminSrvcClient.getSuperVisiorList(empIds);
		assertNull(supervisiorList);
	   verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<SuperVisiorDetailsDto>>>any());
	}
	
	
	@Test
	public void getsupervisiorDiffStatusCode() throws Exception {

		ResponseEntity<List<SuperVisiorDetailsDto>> response = new ResponseEntity<>(null,
				HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<SuperVisiorDetailsDto>>>any()))
						.thenReturn(response);
		List<Long> empIds = new ArrayList<Long>();
		empIds.add(1l);
        List<SuperVisiorDetailsDto> supervisiorList = adminSrvcClient.getSuperVisiorList(empIds);
		assertNull(supervisiorList);
	   verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<SuperVisiorDetailsDto>>>any());
	}
	
	


	@Test(expected = ResourceManagementException.class)
	public void getsupervisiorResoureManagmentException() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<SuperVisiorDetailsDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		List<Long> empIds = new ArrayList<Long>();
		empIds.add(1l);
		adminSrvcClient.getSuperVisiorList(empIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<SuperVisiorDetailsDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getsupervisiorHTTPServerException() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<SuperVisiorDetailsDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		List<Long> empIds = new ArrayList<Long>();
		empIds.add(1l);
		adminSrvcClient.getSuperVisiorList(empIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<SuperVisiorDetailsDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void  getsupervisiorHTTPClientException() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<SuperVisiorDetailsDto>>>any()))
						.thenThrow(HttpClientErrorException.class);
		List<Long> empIds = new ArrayList<Long>();
		empIds.add(1l);
		adminSrvcClient.getSuperVisiorList(empIds);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<SuperVisiorDetailsDto>>>any());
	}
	
	@Test
	public void getLookUpByIdIntegerTest() throws Exception {
		LookupValueDto lookupValueDto = new LookupValueDto();
		lookupValueDto.setLookUpId(1L);
		lookupValueDto.setLookupType("EBR");
		lookupValueDto.setLookupValueCode("EBR");
		
		ResponseEntity<LookupValueDto> response = new ResponseEntity<>(lookupValueDto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any())).thenReturn(response);
		LookupValueDto lookupValue = adminSrvcClient.getLookUpById(1);
		assertNotNull(lookupValue);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getLookUpByIdIntegerHttpClientTest() throws Exception {
		
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getLookUpById(1);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<LookupValueDto>>any());
	}
	@Test(expected = ResourceManagementException.class)
	public void getLookUpByIdIntegerResourceAccessExceptionTest() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<Class<LookupValueDto>>any())).thenThrow(ResourceAccessException.class);
		adminSrvcClient.getLookUpById(1);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<LookupValueDto>>any());
	}
	
	@Test
	public void getModuleStatusListTest() throws Exception {
		List<String> subModules = new ArrayList<>();
		subModules.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<String> actionNames = new ArrayList<>();
		actionNames.add(ResourceManagementConstant.ACTIVE_ACTION);
		List<ModuleStatusDto> moduleStatusList = new ArrayList<>();
		ModuleStatusDto ModuleStatusDto = new ModuleStatusDto();
		moduleStatusList.add(ModuleStatusDto);		
		ResponseEntity<List<ModuleStatusDto>> responseEntityObj = new ResponseEntity<>(moduleStatusList,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any())).thenReturn(responseEntityObj);
		List<ModuleStatusDto> opModuleStatusList = 	adminSrvcClient.getModuleStatusList(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModules, actionNames);
		assertNotNull(opModuleStatusList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any());

	}

	@Test
	public void getModuleStatusListTestNull() throws Exception {
		List<String> subModules = new ArrayList<>();
		subModules.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<String> actionNames = new ArrayList<>();
		actionNames.add(ResourceManagementConstant.ACTIVE_ACTION);
		ResponseEntity<List<ModuleStatusDto>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any())).thenReturn(responseEntityObj);
		List<ModuleStatusDto> opModuleStatusList = 	adminSrvcClient.getModuleStatusList(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModules, actionNames);
		assertNull(opModuleStatusList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any());

	}

	@Test
	public void getModuleStatusListTestDiffStatusCode() throws Exception {
		List<String> subModules = new ArrayList<>();
		subModules.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<String> actionNames = new ArrayList<>();
		actionNames.add(ResourceManagementConstant.ACTIVE_ACTION);
		ResponseEntity<List<ModuleStatusDto>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any())).thenReturn(responseEntityObj);
		List<ModuleStatusDto> opModuleStatusList = 	adminSrvcClient.getModuleStatusList(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModules, actionNames);
		assertNull(opModuleStatusList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getModuleStatusListTestResourceException() throws Exception {
		List<String> subModules = new ArrayList<>();
		subModules.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<String> actionNames = new ArrayList<>();
		actionNames.add(ResourceManagementConstant.ACTIVE_ACTION);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getModuleStatusList(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModules, actionNames);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getModuleStatusListTestHttpServerException() throws Exception {
		List<String> subModules = new ArrayList<>();
		subModules.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<String> actionNames = new ArrayList<>();
		actionNames.add(ResourceManagementConstant.ACTIVE_ACTION);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getModuleStatusList(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModules, actionNames);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getModuleStatusListTestHttpClientException() throws Exception {
		List<String> subModules = new ArrayList<>();
		subModules.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<String> actionNames = new ArrayList<>();
		actionNames.add(ResourceManagementConstant.ACTIVE_ACTION);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any()))
						.thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getModuleStatusList(ResourceManagementConstant.RESOURCE_MANAGEMENT, subModules, actionNames);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any());
	}
	
	@Test
	public void getLookupValueByLookupTypeTest() throws Exception {
		List<LookupValueDto> lookupValueDto = new ArrayList<>();
		LookupValueDto valueDto = new LookupValueDto();
		valueDto.setLookUpId(1l);
		valueDto.setLookupType("BY_SEARCH");
		valueDto.setLookupValueCode("BY_PRACTICE");
		lookupValueDto.add(valueDto);
		
 		ResponseEntity<List<LookupValueDto>> responseEntityObj = new ResponseEntity<>(lookupValueDto,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any())).thenReturn(responseEntityObj);
		List<LookupValueDto> lookupValueList = 	adminSrvcClient.getLookupValueByLookupType(ResourceManagementConstant.SEARCH_BY);
		assertNotNull(lookupValueList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any());

	}

	@Test
	public void getLookupValueByLookupTypeTestNull() throws Exception {
		List<LookupValueDto> lookupValueDto = new ArrayList<>();
		LookupValueDto valueDto = new LookupValueDto();
		valueDto.setLookUpId(1l);
		valueDto.setLookupType("BY_SEARCH");
		valueDto.setLookupValueCode("BY_PRACTICE");
		lookupValueDto.add(valueDto);
		ResponseEntity<List<LookupValueDto>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any())).thenReturn(responseEntityObj);
		List<LookupValueDto> opModuleStatusList = adminSrvcClient.getLookupValueByLookupType(ResourceManagementConstant.SEARCH_BY);
		assertNull(opModuleStatusList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any());

	}

	@Test
	public void getLookupValueByLookupTypeTestDiffStatusCode() throws Exception {
		List<LookupValueDto> lookupValueDto = new ArrayList<>();
		LookupValueDto valueDto = new LookupValueDto();
		valueDto.setLookUpId(1l);
		valueDto.setLookupType("BY_SEARCH");
		valueDto.setLookupValueCode("BY_PRACTICE");
		lookupValueDto.add(valueDto);
		ResponseEntity<List<LookupValueDto>> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any())).thenReturn(responseEntityObj);
		List<LookupValueDto> opModuleStatusList = adminSrvcClient.getLookupValueByLookupType(ResourceManagementConstant.SEARCH_BY);
		assertNull(opModuleStatusList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getLookupValueByLookupTypeTestResourceException() throws Exception {
		List<LookupValueDto> lookupValueDto = new ArrayList<>();
		LookupValueDto valueDto = new LookupValueDto();
		valueDto.setLookUpId(1l);
		valueDto.setLookupType("BY_SEARCH");
		valueDto.setLookupValueCode("BY_PRACTICE");
		lookupValueDto.add(valueDto);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getLookupValueByLookupType(ResourceManagementConstant.SEARCH_BY);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getLookupValueByLookupTypeTestHttpServerException() throws Exception {
		List<LookupValueDto> lookupValueDto = new ArrayList<>();
		LookupValueDto valueDto = new LookupValueDto();
		valueDto.setLookUpId(1l);
		valueDto.setLookupType("BY_SEARCH");
		valueDto.setLookupValueCode("BY_PRACTICE");
		lookupValueDto.add(valueDto);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getLookupValueByLookupType(ResourceManagementConstant.SEARCH_BY);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getLookupValueByLookupTypeHttpClientException() throws Exception {
		List<LookupValueDto> lookupValueDto = new ArrayList<>();
		LookupValueDto valueDto = new LookupValueDto();
		valueDto.setLookUpId(1l);
		valueDto.setLookupType("BY_SEARCH");
		valueDto.setLookupValueCode("BY_PRACTICE");
		lookupValueDto.add(valueDto);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any()))
						.thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getLookupValueByLookupType(ResourceManagementConstant.SEARCH_BY);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any());
	}
	
	public List<ModuleStatusDto> getModuleList()
	{
		 List<ModuleStatusDto> moduleList = new ArrayList<>();
		 ModuleStatusDto moduleStatusDtoAllocation = new ModuleStatusDto();
		 moduleStatusDtoAllocation.setModuleId(1l);
		 moduleStatusDtoAllocation.setModuleCode("RM");
		 moduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		 moduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		 moduleStatusDtoAllocation.setAction("APPROVED");
		 moduleList.add(moduleStatusDtoAllocation);
		 ModuleStatusDto moduleStatusDtoTransfer = new ModuleStatusDto();
		 moduleStatusDtoTransfer.setModuleId(1l);
		 moduleStatusDtoTransfer.setModuleCode("RM");
		 moduleStatusDtoTransfer.setSubModule("RESOURCE_TRANSFER");
		 moduleStatusDtoTransfer.setParentModule("RESOURCE_TRANSFER");
		 moduleStatusDtoTransfer.setAction("APPROVED");
		 moduleList.add(moduleStatusDtoTransfer);
		
		 ModuleStatusDto moduleStatusDtoDeallocationSved = new ModuleStatusDto();
		 moduleStatusDtoDeallocationSved.setModuleId(1l);
		 moduleStatusDtoDeallocationSved.setModuleCode("RM");
		 moduleStatusDtoDeallocationSved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		 moduleStatusDtoDeallocationSved.setParentModule("RESOURCE_TRANSFER");
		 moduleStatusDtoDeallocationSved.setAction(ResourceManagementConstant.DEALLOCATION_ACTION_SAVED);
		 moduleList.add(moduleStatusDtoDeallocationSved);
		 ModuleStatusDto moduleStatusDtoDeallocationSubmitted = new ModuleStatusDto();
		 moduleStatusDtoDeallocationSubmitted.setModuleId(1l);
		 moduleStatusDtoDeallocationSubmitted.setModuleCode("RM");
		 moduleStatusDtoDeallocationSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		 moduleStatusDtoDeallocationSubmitted.setParentModule("RESOURCE_TRANSFER");
		 moduleStatusDtoDeallocationSubmitted.setAction(ResourceManagementConstant.SUBMITTED);
		 moduleList.add(moduleStatusDtoDeallocationSubmitted);
		 ModuleStatusDto moduleStatusDtoDeallocationApproved = new ModuleStatusDto();
		 moduleStatusDtoDeallocationApproved.setModuleId(1l);
		 moduleStatusDtoDeallocationApproved.setModuleCode("RM");
		 moduleStatusDtoDeallocationApproved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		 moduleStatusDtoDeallocationApproved.setParentModule("RESOURCE_TRANSFER");
		 moduleStatusDtoDeallocationApproved.setAction(ResourceManagementConstant.APPROVED_ACTION);
		 moduleList.add(moduleStatusDtoDeallocationApproved);
		 
		 
		 ModuleStatusDto moduleStatusDtoTansferSved = new ModuleStatusDto();
		 moduleStatusDtoTansferSved.setModuleId(1l);
		 moduleStatusDtoTansferSved.setModuleCode("RM");
		 moduleStatusDtoTansferSved.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		 moduleStatusDtoTansferSved.setParentModule("RESOURCE_TRANSFER");
		 moduleStatusDtoTansferSved.setAction(ResourceManagementConstant.TRANSFER_ACTION_SAVED);
		 moduleList.add(moduleStatusDtoTansferSved);
		 ModuleStatusDto moduleStatusDtoTransferSubmitted = new ModuleStatusDto();
		 moduleStatusDtoTransferSubmitted.setModuleId(1l);
		 moduleStatusDtoTransferSubmitted.setModuleCode("RM");
		 moduleStatusDtoTransferSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		 moduleStatusDtoTransferSubmitted.setParentModule("RESOURCE_TRANSFER");
		 moduleStatusDtoTransferSubmitted.setAction(ResourceManagementConstant.SUBMITTED);
		 moduleList.add(moduleStatusDtoTransferSubmitted);
		 
		 return  moduleList;
	}
	
	@Test
	public void getAllModuleDetailsListTest() throws ResourceManagementException
	{
		//  List<ModuleStatusDto> moduleList = adminServiceClient.getAllModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT);
			ResponseEntity<List<ModuleStatusDto>> responseEntityObj = new ResponseEntity<>(getModuleList(),
					HttpStatus.OK);
			when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any())).thenReturn(responseEntityObj);
			List<ModuleStatusDto> opModuleStatusList = 	adminSrvcClient.getAllModuleDetailsList("RM");
			assertNotNull(opModuleStatusList);
			verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any());
	}
	
	@Test
	public void getAllModuleDetailsListTestNull() throws ResourceManagementException
	{
		//  List<ModuleStatusDto> moduleList = adminServiceClient.getAllModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT);
			ResponseEntity<List<ModuleStatusDto>> responseEntityObj = new ResponseEntity<>(null,
					HttpStatus.OK);
			when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any())).thenReturn(responseEntityObj);
			List<ModuleStatusDto> opModuleStatusList = 	adminSrvcClient.getAllModuleDetailsList("RM");
			assertNull(opModuleStatusList);
			verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any());
	}
	
	@Test
	public void getAllModuleDetailsListTestDiffStatusCode() throws ResourceManagementException
	{
		//  List<ModuleStatusDto> moduleList = adminServiceClient.getAllModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT);
			ResponseEntity<List<ModuleStatusDto>> responseEntityObj = new ResponseEntity<>(null,
					HttpStatus.BAD_REQUEST);
			when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any())).thenReturn(responseEntityObj);
			List<ModuleStatusDto> opModuleStatusList = 	adminSrvcClient.getAllModuleDetailsList("RM");
			assertNull(opModuleStatusList);
			verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getAllModuleDetailsListHttpServerException() throws ResourceManagementException
	{
		//  List<ModuleStatusDto> moduleList = adminServiceClient.getAllModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT);
			ResponseEntity<List<ModuleStatusDto>> responseEntityObj = new ResponseEntity<>(null,
					HttpStatus.BAD_REQUEST);
			when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any())).thenThrow(HttpServerErrorException.class);
			List<ModuleStatusDto> opModuleStatusList = 	adminSrvcClient.getAllModuleDetailsList("RM");
			assertNull(opModuleStatusList);
			verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getAllModuleDetailsListHttpClientException() throws ResourceManagementException
	{
		//  List<ModuleStatusDto> moduleList = adminServiceClient.getAllModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT);
			ResponseEntity<List<ModuleStatusDto>> responseEntityObj = new ResponseEntity<>(null,
					HttpStatus.BAD_REQUEST);
			when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any())).thenThrow(HttpClientErrorException.class);
			List<ModuleStatusDto> opModuleStatusList = 	adminSrvcClient.getAllModuleDetailsList("RM");
			assertNull(opModuleStatusList);
			verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
	public void getAllModuleDetailsListRMException() throws ResourceManagementException
	{
		//  List<ModuleStatusDto> moduleList = adminServiceClient.getAllModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT);
			ResponseEntity<List<ModuleStatusDto>> responseEntityObj = new ResponseEntity<>(null,
					HttpStatus.BAD_REQUEST);
			when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any())).thenThrow(new ResourceAccessException("TestError"));
			List<ModuleStatusDto> opModuleStatusList = 	adminSrvcClient.getAllModuleDetailsList("RM");
			assertNull(opModuleStatusList);
			verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<ModuleStatusDto>>>any());
	}
	
	@Test
	public void getSkillFamilyByskillIdTest() throws ResourceManagementException
	{
		List<SkillTaxonomyDto> skillTaxanomyList = new ArrayList<SkillTaxonomyDto>();
		SkillTaxonomyDto skillTaxonomyDto = new SkillTaxonomyDto();
		skillTaxonomyDto.setL4SkillId(1l);
		skillTaxonomyDto.setEmployeeId(5233l); 
		skillTaxonomyDto.setL1PracticeId(1l);
		skillTaxonomyDto.setNicheSkillFlag(true);
		skillTaxonomyDto.setL4skillName("TEST");
		skillTaxanomyList.add(skillTaxonomyDto); 
        List<Long> reqIdList = new ArrayList<>();
		reqIdList.add(123L);
		//  List<ModuleStatusDto> moduleList = adminServiceClient.getAllModuleDetailsList(ResourceManagementConstant.RESOURCE_MANAGEMENT);
				ResponseEntity<List<SkillTaxonomyDto>> responseEntityObj = new ResponseEntity<>(skillTaxanomyList,
						HttpStatus.OK);
				when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
						Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any())).thenReturn(responseEntityObj);
				List<SkillTaxonomyDto> newskillTaxanomyList = 	adminSrvcClient.getSkillFamilyByskillId(reqIdList);
				assertNotNull(newskillTaxanomyList);
				verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
						Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any());
  }
	
	
	@Test
	public void getSkillFamilyByskillIdNullTest() throws ResourceManagementException
	{
		  List<Long> reqIdList = new ArrayList<>();
			reqIdList.add(123L);
				ResponseEntity<List<SkillTaxonomyDto>> responseEntityObj = new ResponseEntity<>(null,
						HttpStatus.OK);
				when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
						Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any())).thenReturn(responseEntityObj);
				List<SkillTaxonomyDto> newskillTaxanomyList = 	adminSrvcClient.getSkillFamilyByskillId(reqIdList);
				assertNull(newskillTaxanomyList);
				verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
						Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any());
  }
	
	@Test
	public void getSkillFamilyByskillIdDiffStatusCode() throws ResourceManagementException
	{
		  List<Long> reqIdList = new ArrayList<>();
			reqIdList.add(123L);
				ResponseEntity<List<SkillTaxonomyDto>> responseEntityObj = new ResponseEntity<>(null,
						HttpStatus.BAD_REQUEST);
				when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
						Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any())).thenReturn(responseEntityObj);
				List<SkillTaxonomyDto> newskillTaxanomyList = 	adminSrvcClient.getSkillFamilyByskillId(reqIdList);
				assertNull(newskillTaxanomyList);
				verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
						Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any());
  }  
	
	
	@Test(expected = ResourceManagementException.class)
	public void getSkillFamilyByskillHttpServerExcp() throws ResourceManagementException
	{
		  List<Long> reqIdList = new ArrayList<>();
			reqIdList.add(123L);
	    	when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
						Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any())).thenThrow(HttpServerErrorException.class);
				List<SkillTaxonomyDto> newskillTaxanomyList = 	adminSrvcClient.getSkillFamilyByskillId(reqIdList);
				assertNull(newskillTaxanomyList);
				verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
						Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any());
  }  
	
	
	@Test(expected = ResourceManagementException.class)
	public void getSkillFamilyByskillHttpClientExcp() throws ResourceManagementException
	{
		  List<Long> reqIdList = new ArrayList<>();
			reqIdList.add(123L);
	    	when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
						Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any())).thenThrow(HttpClientErrorException.class);
				List<SkillTaxonomyDto> newskillTaxanomyList = 	adminSrvcClient.getSkillFamilyByskillId(reqIdList);
				assertNull(newskillTaxanomyList);
				verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
						Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any());
  }  
	
	@Test(expected = ResourceManagementException.class)
	public void getSkillFamilyByskillResourceManagmentExcep() throws ResourceManagementException
	{
		  List<Long> reqIdList = new ArrayList<>();
			reqIdList.add(123L);
	    	when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
						Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any())).thenThrow(new ResourceAccessException("error"));
				List<SkillTaxonomyDto> newskillTaxanomyList = 	adminSrvcClient.getSkillFamilyByskillId(reqIdList);
				assertNull(newskillTaxanomyList);
				verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
						Mockito.<ParameterizedTypeReference<List<SkillTaxonomyDto>>>any());
  }  
	
	
	@Test
	public void getCostCardTest() throws Exception {
		CostCardDto costCardDto = new CostCardDto();
		costCardDto.setCurrencyId(1L);
		costCardDto.setCurrencyId(2L);
		costCardDto.setEightHrsCostRate(new BigDecimal(2L));
		CostCardInputDto costCardInputDto = new CostCardInputDto();
		costCardInputDto.setBandId(1l);
		costCardInputDto.setLocationType("Onshore");

		when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(costCardDto);
		CostCardDto costCardDto1 = adminSrvcClient.getCostCard(costCardInputDto);
		assertNotNull(costCardDto1);
		verify(restTemplate, times(1)).postForObject(Mockito.anyString(), Mockito.any(), Mockito.any());

	}
    
	@Test(expected = ResourceManagementException.class)
	public void getCostCardHttpServerExceptionTest() throws ResourceManagementException {
		CostCardInputDto costCardInputDto = new CostCardInputDto();
		costCardInputDto.setBandId(1l);
		costCardInputDto.setLocationType("Onshore");
		when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getCostCard(costCardInputDto);
		verify(restTemplate, times(1)).postForObject(Mockito.anyString(), Mockito.any(), Mockito.any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getCostCardHttpClientTest() throws Exception {
		CostCardInputDto costCardInputDto = new CostCardInputDto();
		costCardInputDto.setBandId(1l);
		costCardInputDto.setLocationType("Onshore");
		when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getCostCard(costCardInputDto);
		verify(restTemplate, times(1)).postForObject(Mockito.anyString(), Mockito.any(), Mockito.any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getCostCardResourceException() throws Exception {
		CostCardInputDto costCardInputDto = new CostCardInputDto();
		costCardInputDto.setBandId(1l);
		costCardInputDto.setLocationType("Onshore");
		when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenThrow(new ResourceAccessException("error"));
		adminSrvcClient.getCostCard(costCardInputDto);
		verify(restTemplate, times(1)).postForObject(Mockito.anyString(), Mockito.any(), Mockito.any());
	}
	
	@Test
	public void getProjectbyProjectIdTest() throws Exception {
		ProjectDto project = new ProjectDto();
		project.setProjectId(1l);
		project.setProjectName("A");
		
 		ResponseEntity<ProjectDto> responseEntityObj = new ResponseEntity<>(project,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any())).thenReturn(responseEntityObj);
		ProjectDto projectDto = adminSrvcClient.getProjectbyProjectId(1l);
		assertNotNull(projectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());

	}

	@Test
	public void getProjectbyProjectIdTestNull() throws Exception {
		ProjectDto project = new ProjectDto();
		project.setProjectId(1l);
		project.setProjectName("A");
		ResponseEntity<ProjectDto> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any())).thenReturn(responseEntityObj);
		ProjectDto projectDto = adminSrvcClient.getProjectbyProjectId(1l);
		assertNull(projectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());

	}

	@Test
	public void getProjectbyProjectIdTestDiffStatusCode() throws Exception {
		ProjectDto project = new ProjectDto();
		project.setProjectId(1l);
		project.setProjectName("A");
		ResponseEntity<ProjectDto> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any())).thenReturn(responseEntityObj);
		ProjectDto projectDto = adminSrvcClient.getProjectbyProjectId(1l);
		assertNull(projectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectbyProjectIdTestResourceException() throws Exception {
		ProjectDto project = new ProjectDto();
		project.setProjectId(1l);
		project.setProjectName("A");
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getProjectbyProjectId(1l);		
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectbyProjectIdTestHttpServerException() throws Exception {
		ProjectDto project = new ProjectDto();
		project.setProjectId(1l);
		project.setProjectName("A");
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any()))
						.thenThrow(HttpServerErrorException.class);
		ProjectDto projectDto = adminSrvcClient.getProjectbyProjectId(1l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectbyProjectIdHttpClientException() throws Exception {
		ProjectDto project = new ProjectDto();
		project.setProjectId(1l);
		project.setProjectName("A");
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any()))
						.thenThrow(HttpClientErrorException.class);
		ProjectDto projectDto = adminSrvcClient.getProjectbyProjectId(1l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectDto>>any());
	}
	
	
	@Test
	public void getCountryByLocationIdTest() throws Exception {
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName("A");
		
 		ResponseEntity<CountryDto> responseEntityObj = new ResponseEntity<>(countryDto,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<CountryDto>>any())).thenReturn(responseEntityObj);
		CountryDto projectDto = adminSrvcClient.getCountryByLocationId(1l);
		assertNotNull(projectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<CountryDto>>any());

	}

	@Test
	public void getCountryByLocationIdTestNull() throws Exception {
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName("A");
		ResponseEntity<CountryDto> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<CountryDto>>any())).thenReturn(responseEntityObj);
		CountryDto projectDto = adminSrvcClient.getCountryByLocationId(1l);
		assertNull(projectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<CountryDto>>any());

	}

	@Test
	public void getCountryByLocationIdTestDiffStatusCode() throws Exception {
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName("A");
		ResponseEntity<CountryDto> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<CountryDto>>any())).thenReturn(responseEntityObj);
		CountryDto projectDto = adminSrvcClient.getCountryByLocationId(1l);
		assertNull(projectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<CountryDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getCountryByLocationIdestResourceException() throws Exception {
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName("A");
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<CountryDto>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getCountryByLocationId(1l);		
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<CountryDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getCountryByLocationIdTestHttpServerException() throws Exception {
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName("A");
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<CountryDto>>any()))
						.thenThrow(HttpServerErrorException.class);
		CountryDto projectDto = adminSrvcClient.getCountryByLocationId(1l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<CountryDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getCountryByLocationIdHttpClientException() throws Exception {
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName("A");
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<CountryDto>>any()))
						.thenThrow(HttpClientErrorException.class);
		CountryDto projectDto = adminSrvcClient.getCountryByLocationId(1l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<CountryDto>>any());
	}
	
	
	@Test
	public void getProjectBillableIdbyProjectIdTest() throws Exception {
		Long l = 1l;
		
 		ResponseEntity<Long> responseEntityObj = new ResponseEntity<>(l,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any())).thenReturn(responseEntityObj);
		Long projectDto = adminSrvcClient.getProjectBillableIdbyProjectId(1l);
		assertNotNull(projectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any());

	}

	@Test
	public void getProjectBillableIdbyProjectIdTestNull() throws Exception {
		Long l = 1l;
		ResponseEntity<Long> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any())).thenReturn(responseEntityObj);
		Long projectDto = adminSrvcClient.getProjectBillableIdbyProjectId(1l);
		assertNull(projectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any());

	}

	@Test
	public void getProjectBillableIdbyProjectIdTestDiffStatusCode() throws Exception {
		Long l = 1l;
		ResponseEntity<Long> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any())).thenReturn(responseEntityObj);
		Long projectDto = adminSrvcClient.getProjectBillableIdbyProjectId(1l);
		assertNull(projectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectBillableIdbyProjectIdResourceException() throws Exception {
		Long l = 1l;
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getProjectBillableIdbyProjectId(1l);		
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectBillableIdbyProjectIdTestHttpServerException() throws Exception {
		Long l = 1l;
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any()))
						.thenThrow(HttpServerErrorException.class);
		Long projectDto = adminSrvcClient.getProjectBillableIdbyProjectId(1l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectBillableIdbyProjectIdHttpClientException() throws Exception {
		Long l = 1l;
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any()))
						.thenThrow(HttpClientErrorException.class);
		Long projectDto = adminSrvcClient.getProjectBillableIdbyProjectId(1l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any());
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////
	@Test
	public void getEmployeeDetailsByEmpIdTest() throws Exception {
		EmployeeDto empDto = new EmployeeDto();
		empDto.setEmployeeNumber(12345l);
		empDto.setEmployeeId(1l);
		empDto.setEmployeeName("QA");
		
 		ResponseEntity<EmployeeDto> responseEntityObj = new ResponseEntity<>(empDto,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenReturn(responseEntityObj);
		EmployeeDto projectDto = adminSrvcClient.getEmployeeDetailsByEmpId(1l);
		assertNotNull(projectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());

	}

	@Test
	public void getEmployeeDetailsByEmpIdTestNull() throws Exception {
		EmployeeDto empDto = new EmployeeDto();
		empDto.setEmployeeNumber(12345l);
		empDto.setEmployeeId(1l);
		empDto.setEmployeeName("QA");
		ResponseEntity<EmployeeDto> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenReturn(responseEntityObj);
		EmployeeDto projectDto = adminSrvcClient.getEmployeeDetailsByEmpId(1l);
		assertNull(projectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());

	}

	@Test
	public void getEmployeeDetailsByEmpIdTestDiffStatusCode() throws Exception {
		EmployeeDto empDto = new EmployeeDto();
		empDto.setEmployeeNumber(12345l);
		empDto.setEmployeeId(1l);
		empDto.setEmployeeName("QA");
		ResponseEntity<EmployeeDto> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any())).thenReturn(responseEntityObj);
		EmployeeDto projectDto = adminSrvcClient.getEmployeeDetailsByEmpId(1l);
		assertNull(projectDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getEmployeeDetailsByEmpIdestResourceException() throws Exception {
		EmployeeDto empDto = new EmployeeDto();
		empDto.setEmployeeNumber(12345l);
		empDto.setEmployeeId(1l);
		empDto.setEmployeeName("QA");
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getEmployeeDetailsByEmpId(1l);		
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getEmployeeDetailsByEmpIdTestHttpServerException() throws Exception {
		EmployeeDto empDto = new EmployeeDto();
		empDto.setEmployeeNumber(12345l);
		empDto.setEmployeeId(1l);
		empDto.setEmployeeName("QA");
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any()))
						.thenThrow(HttpServerErrorException.class);
		EmployeeDto projectDto = adminSrvcClient.getEmployeeDetailsByEmpId(1l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getEmployeeDetailsByEmpIdHttpClientException() throws Exception {
		EmployeeDto empDto = new EmployeeDto();
		empDto.setEmployeeNumber(12345l);
		empDto.setEmployeeId(1l);
		empDto.setEmployeeName("QA");
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any()))
						.thenThrow(HttpClientErrorException.class);
		EmployeeDto projectDto = adminSrvcClient.getEmployeeDetailsByEmpId(1l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<EmployeeDto>>any());
	}
	
	@Test
	public void getUtilizationDetailsTest() throws Exception {
		UtilizationDetailDto utilizationDetailDto = new UtilizationDetailDto();
		List<UtilizationProjectDetails> utilizationProjectDetailsList = new ArrayList<>();
		when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(utilizationDetailDto);
		adminSrvcClient.getUtilizationDetails(utilizationProjectDetailsList);
		verify(restTemplate, times(1)).postForObject(Mockito.anyString(), Mockito.any(), Mockito.any());

	}
    
	@Test(expected = ResourceManagementException.class)
	public void getUtilizationDetailsHttpServerExceptionTest() throws ResourceManagementException {
		List<UtilizationProjectDetails> utilizationProjectDetailsList = new ArrayList<>();
		when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getUtilizationDetails(utilizationProjectDetailsList);
		verify(restTemplate, times(1)).postForObject(Mockito.anyString(), Mockito.any(), Mockito.any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getUtilizationDetailsHttpClientTest() throws Exception {
		List<UtilizationProjectDetails> utilizationProjectDetailsList = new ArrayList<>();
		when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getUtilizationDetails(utilizationProjectDetailsList);
		verify(restTemplate, times(1)).postForObject(Mockito.anyString(), Mockito.any(), Mockito.any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getUtilizationDetailsResourceException() throws Exception {
		List<UtilizationProjectDetails> utilizationProjectDetailsList = new ArrayList<>();
		when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenThrow(new ResourceAccessException("error"));
		adminSrvcClient.getUtilizationDetails(utilizationProjectDetailsList);
		verify(restTemplate, times(1)).postForObject(Mockito.anyString(), Mockito.any(), Mockito.any());
	}
 
	
	@Test
	public void getLookupValueDescriptionTest() throws ResourceManagementException {
		
		LookupValueDto lookupValueDto= new LookupValueDto();
		lookupValueDto.setLookupValueDescription("Test");
		
 
			ResponseEntity<LookupValueDto> response = new ResponseEntity<>(lookupValueDto, HttpStatus.OK);
			when(restTemplate.exchange(Mockito.anyString(),Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<LookupValueDto>>any())).thenReturn(response);

			adminSrvcClient.getLookupValueDescription(1L) ;
			verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any());
			 
				 
	}
	
	
	@Test(expected = ResourceManagementException.class)
	public void getLookupValueDescriptionExceptionTest() throws ResourceManagementException {
		
		LookupValueDto lookupValueDto= new LookupValueDto();
		lookupValueDto.setLookupValueDescription("Test");
		
 
			ResponseEntity<LookupValueDto> response = new ResponseEntity<>(lookupValueDto, HttpStatus.OK);
			when(restTemplate.exchange(Mockito.anyString(),Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<LookupValueDto>>any())).thenThrow(new ResourceAccessException("error"));
			adminSrvcClient.getLookupValueDescription(1L) ;
			verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any());
			 
				 
	}
	@Test(expected = ResourceManagementException.class)
	public void getLookupValueDescriptionHttpServerExceptionTest() throws ResourceManagementException {
		
		LookupValueDto lookupValueDto= new LookupValueDto();
		lookupValueDto.setLookupValueDescription("Test");
		
 
			ResponseEntity<LookupValueDto> response = new ResponseEntity<>(lookupValueDto, HttpStatus.OK);
			when(restTemplate.exchange(Mockito.anyString(),Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<LookupValueDto>>any())).thenThrow(HttpClientErrorException.class);

			adminSrvcClient.getLookupValueDescription(1L) ;
			verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
					Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any());
			 
				 
	}
 
	@Test
	public void getProjectBudgetTestNull() throws Exception {
		ResponseEntity<String> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any())).thenReturn(response);
		String appDto =  adminSrvcClient.getProjectBudgetStatus(22l);

		assertNull(appDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any());

	}
	
	@Test
	public void getProjectBudgetTest() throws Exception {
		ResponseEntity<String> response = new ResponseEntity<>("22", HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any())).thenReturn(response);
		String appDto = adminSrvcClient.getProjectBudgetStatus(22l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectBudgetTestCodeHttpServerException() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any())).thenThrow(HttpServerErrorException.class);
		 adminSrvcClient.getProjectBudgetStatus(22l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectBudgetTestClientException() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any())).thenThrow(HttpClientErrorException.class);
		 adminSrvcClient.getProjectBudgetStatus(22l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any());

	}

	@Test
	public void getProjectBudgetTestDiffStatusCode() throws Exception {
		ResponseEntity<String> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any())).thenReturn(response);
		String appDto = adminSrvcClient.getProjectBudgetStatus(22l);
     	assertNull(appDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getProjectBudgetTestError() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any()))
						.thenThrow(new ResourceAccessException("error"));
		 adminSrvcClient.getProjectBudgetStatus(22l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any());

	}
	
	@Test
	public void getModuleStatusByActionNull() throws Exception {
		ResponseEntity<String> response = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any())).thenReturn(response);
		Long appDto =  adminSrvcClient.getModuleStatusByAction("A","B");

		assertNull(appDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<String>>any());

	}
	
	@Test
	public void getModuleStatusByActionTest() throws Exception {
		ResponseEntity<Long> response = new ResponseEntity<>(29l, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any())).thenReturn(response);
		Long appDto = adminSrvcClient.getModuleStatusByAction("A","B");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getModuleStatusByActionTestCodeHttpServerException() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any())).thenThrow(HttpServerErrorException.class);
		 adminSrvcClient.getModuleStatusByAction("A","B");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getModuleStatusByActionTestClientException() throws Exception {

		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any())).thenThrow(HttpClientErrorException.class);
		 adminSrvcClient.getModuleStatusByAction("A","B");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any());

	}

	@Test
	public void getModuleStatusByActionTestDiffStatusCode() throws Exception {
		ResponseEntity<Long> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any())).thenReturn(response);
		Long appDto = adminSrvcClient.getModuleStatusByAction("A","B");
     	assertNull(appDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any());

	}

	@Test(expected = ResourceManagementException.class)
	public void getModuleStatusByActionTestError() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any()))
						.thenThrow(new ResourceAccessException("error"));
		 adminSrvcClient.getModuleStatusByAction("A","B");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any());

	}
	
	@Test
	public void getLookupTypebyDescr() throws Exception {
		ResponseEntity<Long> response = new ResponseEntity<>(29l, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any())).thenReturn(response);
		Long appDto = adminSrvcClient.getLookuIdByTypeAndDescr("A","B");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<Long>>any());

	}
	
	@Test
	public void getPrimaryOwnerUserIdListByProjectIdTest() throws Exception {
		List<Long> projectIdList = List.of(1L, 2L);
		ResponseEntity<List<Long>> response = new ResponseEntity<>(projectIdList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any())).thenReturn(response);
		adminSrvcClient.getPrimaryOwnerUserIdListByProjectId(1l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getPrimaryOwnerUserIdListByProjectIdTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any())).thenThrow(new ResourceAccessException("Error"));
		adminSrvcClient.getPrimaryOwnerUserIdListByProjectId(1L);
	}

	@Test(expected = ResourceManagementException.class)
	public void getPrimaryOwnerUserIdListByProjectIdTestHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getPrimaryOwnerUserIdListByProjectId(1L);
	}

	@Test
	public void getPrimaryOwnerUserIdListByProjectIdTestMissingBody() throws Exception {
		List<Long> idList = null;
		ResponseEntity<List<Long>> response = new ResponseEntity<>(idList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any())).thenReturn(response);
		adminSrvcClient.getPrimaryOwnerUserIdListByProjectId(1L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any());
	}

	@Test
	public void getPrimaryOwnerUserIdListByProjectIdTestDiffStatusCode() throws Exception {
		ResponseEntity<List<Long>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any())).thenReturn(response);
		adminSrvcClient.getPrimaryOwnerUserIdListByProjectId(1L);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any());
	}
	
	@Test
	public void getAssociatesDetailsTestByEmpIds() throws Exception {
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(1L);
		employeeDto.setEmployeeName("Test");
		List<EmployeeDto> employeesObj = new ArrayList<>();
		employeesObj.add(employeeDto);
		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<>(employeesObj, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);
		List<Long> empIds = new ArrayList<>();
		empIds.add(1L);
		empIds.add(2L);
		List<EmployeeDto> employees = adminSrvcClient.getAssociatesDetailsbyEmpIds(empIds);
		assertNotNull(employees);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}
 
	//////////////////////////////////////////////////////////////////////////////////////////////////////
	
	@Test
	public void getLookuIdByTypeAndDescrListTest() throws Exception {
		List<LookupValueAndDescDto> roleIdList = new ArrayList<>();
		LookupValueAndDescDto dto = new LookupValueAndDescDto();
		dto.setLookupValueId(452l);
		dto.setLookupValueDescr("PM");
		roleIdList.add(dto);
		ResponseEntity<List<LookupValueAndDescDto>> response = new ResponseEntity<>(roleIdList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueAndDescDto>>>any())).thenReturn(response);
		adminSrvcClient.getLookuIdByTypeAndDescrList("ROLE_TyPE",List.of("PM","PGM"));
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getLookuIdByTypeAndDescrListTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueAndDescDto>>>any())).thenThrow(new ResourceAccessException("Error"));
		adminSrvcClient.getLookuIdByTypeAndDescrList("ROLE_TyPE",List.of("PM","PGM"));
	}

	@Test(expected = ResourceManagementException.class)
	public void getLookuIdByTypeAndDescrListTestHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueAndDescDto>>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getLookuIdByTypeAndDescrList("ROLE_TyPE",List.of("PM","PGM"));
	}

	@Test
	public void getLookuIdByTypeAndDescrListTestMissingBody() throws Exception {
		List<LookupValueAndDescDto> idList = null;
		ResponseEntity<List<LookupValueAndDescDto>> response = new ResponseEntity<>(idList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueAndDescDto>>>any())).thenReturn(response);
		adminSrvcClient.getLookuIdByTypeAndDescrList("ROLE_TyPE",List.of("PM","PGM"));
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueAndDescDto>>>any());
	}

	@Test
	public void getLookuIdByTypeAndDescrListTestDiffStatusCode() throws Exception {
		ResponseEntity<List<LookupValueAndDescDto>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueAndDescDto>>>any())).thenReturn(response);
		adminSrvcClient.getLookuIdByTypeAndDescrList("ROLE_TyPE",List.of("PM","PGM"));
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueAndDescDto>>>any());
	}
	
	
	@Test
	public void getBuForProject() throws Exception {
		
		ProjectBuDto pbudto = new ProjectBuDto();
		pbudto.setBuId(1l);
		pbudto.setBuName("CISCO");
		pbudto.setProjectId(1l);
		
		ResponseEntity<ProjectBuDto> response = new ResponseEntity<>(pbudto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectBuDto>>any())).thenReturn(response);
		adminSrvcClient.getBuForProject(1l);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any());
	}
	
	@Test(expected = ResourceManagementException.class)
public void getBuForProjectRaeTest() throws Exception {
		
			when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectBuDto>>any())).thenThrow(new ResourceAccessException("Error"));
		adminSrvcClient.getBuForProject(1l);
		
	}
	
	@Test(expected = ResourceManagementException.class)

	public void getBuForProjectHttpServerTest() throws Exception {
		
			when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<ProjectBuDto>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getBuForProject(1l);
		
	}
	

	// --------------start for getLookUpValueDetailsByIds -----
	@Test
	public void getLookUpValueDetailsByIdsTest() throws Exception {
		List<LookupValueDto> dataDtos = new ArrayList<>();
		ResponseEntity<List<LookupValueDto>> response = new ResponseEntity<>(dataDtos, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any())).thenReturn(response);
		adminSrvcClient.getLookUpValueDetailsByIds(List.of(1l,2l));
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getLookUpValueDetailsByIdsTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any())).thenThrow(new ResourceAccessException("Error"));
		adminSrvcClient.getLookUpValueDetailsByIds(List.of(1l,2l));
	}

	@Test(expected = ResourceManagementException.class)
	public void getLookUpValueDetailsByIdsTestHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any())).thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getLookUpValueDetailsByIds(List.of(1l,2l));
	}

	@Test
	public void getLookUpValueDetailsByIdsTestMissingBody() throws Exception {
		List<LookupValueDto> dataDtos = null;
		ResponseEntity<List<LookupValueDto>> response = new ResponseEntity<>(dataDtos, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any())).thenReturn(response);
		adminSrvcClient.getLookUpValueDetailsByIds(List.of(1l,2l));
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any());
	}

	@Test
	public void getLookUpValueDetailsByIdsTestDiffStatusCode() throws Exception {
		ResponseEntity<List<LookupValueDto>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<LookupValueDto>>>any())).thenReturn(response);
		adminSrvcClient.getLookUpValueDetailsByIds(List.of(1l,2l));
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<Long>>>any());
	}
	// --------------end for getLookUpValueDetailsByIds -----
	
	
	@Test(expected = ResourceManagementException.class)
	public void getAllEmployeeDetailsResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(new ResourceAccessException("Error"));
		adminSrvcClient.getAllEmployeeDetails("1234");
	}
	@Test(expected = ResourceManagementException.class)
	public void getAllEmployeeDetailsHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getAllEmployeeDetails("2432");
	}

	@Test
	public void getAllEmployeeDetailsMissingBody() throws Exception {
		List<EmployeeDto> employeeList = null;
		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<>(employeeList, HttpStatus.OK);

		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);
		adminSrvcClient.getAllEmployeeDetails("hello");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}

	@Test
	public void getAllEmployeeDetailsDiffStatusCodeTest() throws Exception {
		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);
		adminSrvcClient.getAllEmployeeDetails("seriously??");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}
	
	@Test
	public void getAllEmployeeDetailTest() throws Exception {
		List<EmployeeDto> empList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeNumber(1L);
		empList.add(employeeDto);
		ResponseEntity<List<EmployeeDto>> response = new ResponseEntity<>(empList, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any())).thenReturn(response);
		adminSrvcClient.getAllEmployeeDetails("TEST");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<EmployeeDto>>>any());
	}
	
	//----------Start getServiceLineList------------
	@Test
	public void getServiceLineListTest() throws Exception {

		List<ServiceLineDto> serviceLineList = new ArrayList<>();
		ServiceLineDto dto1 = new ServiceLineDto();
		dto1.setServiceLineId(1);
		dto1.setServiceLine("CORPORATE");
		serviceLineList.add(dto1);
		List<Long> idList = new ArrayList<>();
		idList.add(1l);

		ResponseEntity<List<ServiceLineDto>> response = new ResponseEntity<List<ServiceLineDto>>(serviceLineList,
				HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ServiceLineDto>>>any())).thenReturn(response);

		adminSrvcClient.getServiceLineList(idList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ServiceLineDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getServiceLineListHttpServerTest() throws Exception {
		List<Long> idList = new ArrayList<>();
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ServiceLineDto>>>any()))
						.thenThrow(HttpClientErrorException.class);
		adminSrvcClient.getServiceLineList(idList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ServiceLineDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getServiceLineListHttpClientTest() throws Exception {
		List<Long> idList = new ArrayList<>();
		idList.add(1l);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ServiceLineDto>>>any()))
						.thenThrow(HttpServerErrorException.class);
		adminSrvcClient.getServiceLineList(idList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ServiceLineDto>>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getServiceLineListResourceManagmentExcetionTest() throws Exception {
		List<Long> idList = new ArrayList<>();
		when(restTemplate.exchange(Mockito.anyString(), Mockito.<HttpMethod>any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ServiceLineDto>>>any()))
						.thenThrow(new ResourceAccessException("TestError"));
		adminSrvcClient.getServiceLineList(idList);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(), Mockito.<HttpEntity<String>>any(),
				Mockito.<ParameterizedTypeReference<List<ServiceLineDto>>>any());
	}
	//------End getServiceLineList-------------------
}
