package com.zensar.zenfulcrum.resourcemanagement.service;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateAllocationMapper;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class PDResourceManagmentServiceTest {

	@InjectMocks
	private PDResourceManagmentServiceImpl pdResourceManagmentServiceImpl;
	
	@Mock
	private TAssociateAllocationRepository tAssociateAllocationRepository;
	
	@Mock
	private ResourceManagementServiceImpl resourceManagementServiceImpl;
	
	@Mock
	private TAssociateAllocationMapper tAssociateAllocationMapper;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void getAssociateListByProjectId() throws ResourceManagementException {
		List<TAssociateAllocation> tAssociateAllocationList = new ArrayList<>();
		when(tAssociateAllocationRepository.getAssociateListByProjectId(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(tAssociateAllocationList);
		pdResourceManagmentServiceImpl.getAssociateListByProjectId(1L);
		verify(tAssociateAllocationRepository,times(1)).getAssociateListByProjectId(Mockito.anyLong(),Mockito.anyLong(), Mockito.anyLong());
	}
}

