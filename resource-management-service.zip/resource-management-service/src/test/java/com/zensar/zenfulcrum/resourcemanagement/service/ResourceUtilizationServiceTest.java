package com.zensar.zenfulcrum.resourcemanagement.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.projection.ProjectionFactory;
import org.springframework.data.projection.SpelAwareProxyProjectionFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceUtilizationSummaryDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UtilizationDetailDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UtilizationProjectDetails;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.mapper.UtilizationMapper;
import com.zensar.zenfulcrum.resourcemanagement.projection.ProjectDetailsProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.TAssociateProjectAndAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceUtilizationServiceTest {

	@InjectMocks
	private ResourceUtilizationServiceImpl resourceUtilizationServiceImpl;

	@Mock
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Mock
	private AdminServiceClient adminServiceClient;
	
	@Mock
	private UtilizationMapper utilizationMapper;
	
	@Mock
	private BAPServiceClient bAPServiceClient;
	
	@Mock
	private TAssociateProjectRepository tAssociateProjectRepository;

	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");
	ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
	
	@Test
	public void getQuarterDetailsForYearTest() throws ResourceManagementException, ParseException {
		List<LookupValueDto> lookupValueDtoList = new ArrayList<>();
		LookupValueDto lookupValueDto = new LookupValueDto();
		lookupValueDto.setLookUpId(1L);
		lookupValueDto.setLookupType("Active");
		lookupValueDto.setLookupValueCode("Active");
		lookupValueDto.setLookupValueDescription("2020-05-09");
		lookupValueDto.setLookupValueName("2020-08-09");
		lookupValueDtoList.add(lookupValueDto);
		when(adminServiceClient.getLookupValueByLookupType(Mockito.anyString())).thenReturn(lookupValueDtoList);
		resourceUtilizationServiceImpl.getQuarterDetailsForYear();
		verify(adminServiceClient, times(1)).getLookupValueByLookupType(Mockito.anyString());
	}
	
	@Test
	public void getResourceUtilizationTest() throws ResourceManagementException, ParseException {
		List<ProjectDetailsProjection> allocatedResourceProjectionList = new ArrayList<>();
		ProjectDetailsProjection projectDetailsProjection = factory.createProjection(ProjectDetailsProjection.class);
		allocatedResourceProjectionList.add(projectDetailsProjection);
		List<UtilizationProjectDetails> utilizationProjectDetailsList = new ArrayList<>();
		UtilizationProjectDetails utilizationProjectDetails = new UtilizationProjectDetails();
		utilizationProjectDetails.setProjectId(1L);
		utilizationProjectDetails.setProjectUtilization(50D);
		utilizationProjectDetails.setBillableStatusId(1L);
		utilizationProjectDetails.setActualAllocationStartDate(sdformat.parse("2020-07-08"));
		utilizationProjectDetails.setActualAllocationEndDate(sdformat.parse("2020-07-08"));
		utilizationProjectDetailsList.add(utilizationProjectDetails);
		List<ProjectDto> projectDtoList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1L);
		projectDto.setProjectCode("project code");
		projectDto.setProjectName("project name");
		projectDtoList.add(projectDto);
		UtilizationDetailDto utilizationDetailDto = new UtilizationDetailDto();
		utilizationDetailDto.setAverageUtilization(1D);
		when(tAssociateAllocationRepository.findByAllocationDateAndEmpId(Mockito.anyLong(),Mockito.any(),Mockito.any())).thenReturn(allocatedResourceProjectionList);
		when(utilizationMapper.projectDetailsProjectionListToUtilizationProjectDetails(Mockito.any())).thenReturn(utilizationProjectDetailsList);
		when(bAPServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(projectDtoList);
		when(adminServiceClient.getUtilizationDetails(Mockito.any())).thenReturn(utilizationDetailDto);
		resourceUtilizationServiceImpl.getResourceUtilization(1L,"2020-09-08","2020-09-08");
		verify(tAssociateAllocationRepository, times(1)).findByAllocationDateAndEmpId(1L,sdformat.parse("2020-09-08"),sdformat.parse("2020-09-08"));
	}
	
	@Test
	public void getResourceUtilizationNullTest() throws ResourceManagementException, ParseException {
		List<ProjectDetailsProjection> allocatedResourceProjectionList = new ArrayList<>();
		ProjectDetailsProjection projectDetailsProjection = factory.createProjection(ProjectDetailsProjection.class);
		allocatedResourceProjectionList.add(projectDetailsProjection);
		List<UtilizationProjectDetails> utilizationProjectDetailsList = new ArrayList<>();
		UtilizationProjectDetails utilizationProjectDetails = new UtilizationProjectDetails();
		utilizationProjectDetailsList.add(utilizationProjectDetails);
		List<ProjectDto> projectDtoList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDtoList.add(projectDto);
		UtilizationDetailDto utilizationDetailDto = new UtilizationDetailDto();

		when(tAssociateAllocationRepository.findByAllocationDateAndEmpId(Mockito.anyLong(),Mockito.any(),Mockito.any())).thenReturn(allocatedResourceProjectionList);
		when(bAPServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(projectDtoList);
		when(adminServiceClient.getUtilizationDetails(Mockito.any())).thenReturn(utilizationDetailDto);
		resourceUtilizationServiceImpl.getResourceUtilization(1L,"2020-09-08","2020-09-08");
		verify(tAssociateAllocationRepository, times(1)).findByAllocationDateAndEmpId(1L,sdformat.parse("2020-09-08"),sdformat.parse("2020-09-08"));
	}
	
	@Test
	public void getResourceUtilizationDateRangeTest() throws ResourceManagementException, ParseException {
		List<ProjectDetailsProjection> allocatedResourceProjectionList = new ArrayList<>();
		ProjectDetailsProjection projectDetailsProjection = factory.createProjection(ProjectDetailsProjection.class);
		allocatedResourceProjectionList.add(projectDetailsProjection);
		List<UtilizationProjectDetails> utilizationProjectDetailsList = new ArrayList<>();
		UtilizationProjectDetails utilizationProjectDetails = new UtilizationProjectDetails();
		utilizationProjectDetails.setProjectId(1L);
		utilizationProjectDetails.setProjectUtilization(50D);
		utilizationProjectDetails.setBillableStatusId(1L);
		utilizationProjectDetails.setActualAllocationStartDate(sdformat.parse("2020-12-08"));
		utilizationProjectDetails.setActualAllocationEndDate(sdformat.parse("2020-11-08"));
		utilizationProjectDetailsList.add(utilizationProjectDetails);
		List<ProjectDto> projectDtoList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1L);
		projectDto.setProjectCode("project code");
		projectDto.setProjectName("project name");
		projectDtoList.add(projectDto);
		UtilizationDetailDto utilizationDetailDto = new UtilizationDetailDto();
		utilizationDetailDto.setAverageUtilization(1D);
		when(tAssociateAllocationRepository.findByAllocationDateAndEmpId(Mockito.anyLong(),Mockito.any(),Mockito.any())).thenReturn(allocatedResourceProjectionList);
		when(utilizationMapper.projectDetailsProjectionListToUtilizationProjectDetails(Mockito.any())).thenReturn(utilizationProjectDetailsList);
		when(bAPServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(projectDtoList);
		when(adminServiceClient.getUtilizationDetails(Mockito.any())).thenReturn(utilizationDetailDto);
		resourceUtilizationServiceImpl.getResourceUtilization(1L,"2020-09-08","2020-09-18");
		verify(tAssociateAllocationRepository, times(1)).findByAllocationDateAndEmpId(1L,sdformat.parse("2020-09-08"),sdformat.parse("2020-09-18"));
	}
	
	@Test
	public void getResourceUtilizationSameDateRangeTest() throws ResourceManagementException, ParseException {
		List<ProjectDetailsProjection> allocatedResourceProjectionList = new ArrayList<>();
		ProjectDetailsProjection projectDetailsProjection = factory.createProjection(ProjectDetailsProjection.class);
		allocatedResourceProjectionList.add(projectDetailsProjection);
		List<UtilizationProjectDetails> utilizationProjectDetailsList = new ArrayList<>();
		UtilizationProjectDetails utilizationProjectDetails = new UtilizationProjectDetails();
		utilizationProjectDetails.setProjectId(1L);
		utilizationProjectDetails.setProjectUtilization(50D);
		utilizationProjectDetails.setBillableStatusId(1L);
		utilizationProjectDetails.setActualAllocationStartDate(sdformat.parse("2020-09-08"));
		utilizationProjectDetails.setActualAllocationEndDate(sdformat.parse("2020-09-08"));
		utilizationProjectDetailsList.add(utilizationProjectDetails);
		List<ProjectDto> projectDtoList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1L);
		projectDto.setProjectCode("project code");
		projectDto.setProjectName("project name");
		projectDtoList.add(projectDto);
		UtilizationDetailDto utilizationDetailDto = new UtilizationDetailDto();
		utilizationDetailDto.setAverageUtilization(1D);
		when(tAssociateAllocationRepository.findByAllocationDateAndEmpId(Mockito.anyLong(),Mockito.any(),Mockito.any())).thenReturn(allocatedResourceProjectionList);
		when(utilizationMapper.projectDetailsProjectionListToUtilizationProjectDetails(Mockito.any())).thenReturn(utilizationProjectDetailsList);
		when(bAPServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(projectDtoList);
		when(adminServiceClient.getUtilizationDetails(Mockito.any())).thenReturn(utilizationDetailDto);
		resourceUtilizationServiceImpl.getResourceUtilization(1L,"2020-09-08","2020-09-08");
		verify(tAssociateAllocationRepository, times(1)).findByAllocationDateAndEmpId(1L,sdformat.parse("2020-09-08"),sdformat.parse("2020-09-08"));
	}
	
	@Test
	public void getResourceUtilizationSummaryDetailsTest() throws ResourceManagementException, ParseException {
		ResourceUtilizationSummaryDto utilizationSummaryDto = new ResourceUtilizationSummaryDto();
		BigDecimal valueOf = BigDecimal.valueOf(10.00);
		utilizationSummaryDto.setBillableResourceFTE(valueOf);
		utilizationSummaryDto.setNonBillableResourceFTE(valueOf);
		utilizationSummaryDto.setEbrResourceFTE(valueOf);
		utilizationSummaryDto.setTotalResourceFTE(valueOf);
		utilizationSummaryDto.setDeliveryResourceAllocationFTE(valueOf);
		
		List<TAssociateProjectAndAllocationProjection> projections = new ArrayList<>();
		TAssociateProjectAndAllocationProjection projectDetailsProjection = factory.createProjection(TAssociateProjectAndAllocationProjection.class);
		projectDetailsProjection.setftePercent(10.00);
		projectDetailsProjection.setbillableStatusId(123l);
		projectDetailsProjection.setprojectId(111l);
		projections.add(projectDetailsProjection);
		
		List<LookupValueDto> list = new ArrayList<>();
		LookupValueDto valueDto = new LookupValueDto();
		valueDto.setLookUpId(123l);
		valueDto.setLookupType("Billable");
		valueDto.setLookupValueCode("Billable");
		list.add(valueDto);
		when(tAssociateProjectRepository.getResourceUtilizationSummaryDetails(Mockito.anyLong())).thenReturn(projections);
		when(adminServiceClient.getLookUpValueDetailsByIds(Mockito.anyList())).thenReturn(list);
		ResourceUtilizationSummaryDto dto = resourceUtilizationServiceImpl.getResourceUtilizationSummaryDetails(1L);
		assertNotNull(dto);

	}
}
