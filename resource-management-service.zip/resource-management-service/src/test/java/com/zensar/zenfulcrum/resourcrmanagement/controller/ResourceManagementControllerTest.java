package com.zensar.zenfulcrum.resourcrmanagement.controller;

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.zensar.zenfulcrum.resourcemanagement.controller.ResourceManagementController;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApproversDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TransferApproverResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceManagementService;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceManagementControllerTest {

	@InjectMocks
	private ResourceManagementController rsrcMgmntCntrllr;

	@Mock
	private ResourceManagementService rsrcMgmntSrvc;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getprojectListTest() throws ResourceManagementException {
		List<ProjectDto> projectList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");
		projectList.add(projectDto);
		when(rsrcMgmntSrvc.getProjectList(Mockito.anyLong(), Mockito.anyLong())).thenReturn(projectList);
		ResponseEntity<RMResponseDto> response = rsrcMgmntCntrllr.getProjectList(Mockito.anyLong(), Mockito.anyLong());
		assertNotNull(response);
		verify(rsrcMgmntSrvc, times(1)).getProjectList(Mockito.anyLong(), Mockito.anyLong());
	}

	@Test
	public void getProjectListTestForNoContent() throws ResourceManagementException {
		when(rsrcMgmntSrvc.getProjectList(123, 123)).thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = rsrcMgmntCntrllr.getProjectList(Long.valueOf(123),
				Long.valueOf(123));
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(rsrcMgmntSrvc, times(1)).getProjectList(123, 123);
	}

	@Test
	public void getRMApproversListTest() throws ResourceManagementException {
		RMApproversDto rmApproversDtoObj = new RMApproversDto();
		rmApproversDtoObj.setRoleId(1);
		rmApproversDtoObj.setRoleName("PM");
		rmApproversDtoObj.setUserId(1);
		rmApproversDtoObj.setUserName("User-1");
		List<RMApproversDto> rmApproversListDtoObj = new ArrayList<>();
		rmApproversListDtoObj.add(rmApproversDtoObj);
		when(rsrcMgmntSrvc.getRMApproversList(10, 1, 1, "ALLOCATION",false)).thenReturn(rmApproversListDtoObj);
		ResponseEntity<RMResponseDto> responseEntityObj = rsrcMgmntCntrllr.getRMApproversList(10, 1, 1, "ALLOCATION");
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		assertNotNull(responseEntityObj);
		verify(rsrcMgmntSrvc, times(1)).getRMApproversList(10, 1, 1, "ALLOCATION",false);
	}

	@Test
	public void getRMApproversListTestForNoContent() throws ResourceManagementException {
		when(rsrcMgmntSrvc.getRMApproversList(10, 1, 1, "ALLOCATION",false)).thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = rsrcMgmntCntrllr.getRMApproversList(10, 1, 1, "ALLOCATION");
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(rsrcMgmntSrvc, times(1)).getRMApproversList(10, 1, 1, "ALLOCATION",false);
	}

	@Test
	public void submitRMApprovalTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		doNothing().when(rsrcMgmntSrvc).submitRMApproval(List.of(rmApprovalInputDtoObj));
		ResponseEntity<RMResponseDto> responseEntityObj = rsrcMgmntCntrllr.submitRMApproval(List.of(rmApprovalInputDtoObj));
		assertEquals(201, responseEntityObj.getStatusCodeValue());
		assertNotNull(responseEntityObj);
		verify(rsrcMgmntSrvc, times(1)).submitRMApproval(List.of(rmApprovalInputDtoObj));
	}

	@Test
	public void approveOrRejectRMApprovalTest() throws ResourceManagementException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		/*
		 * doNothing().when(rsrcMgmntSrvc).approveOrRejectRMApproval(
		 * RMApprovalInputDtlsList); ResponseEntity<RMResponseDto> responseEntityObj =
		 * rsrcMgmntCntrllr .approveOrRejectRMApproval(RMApprovalInputDtlsList);
		 * assertEquals(201, responseEntityObj.getStatusCodeValue());
		 * assertNotNull(responseEntityObj); verify(rsrcMgmntSrvc,
		 * times(1)).approveOrRejectRMApproval(RMApprovalInputDtlsList);
		 */
	}

	@Test
	public void rejectRMSavedResourcesTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		doNothing().when(rsrcMgmntSrvc).rejectRMSavedResources(List.of(rmApprovalInputDtoObj));
		ResponseEntity<RMResponseDto> responseEntityObj = rsrcMgmntCntrllr
				.rejectRMSavedResources(List.of(rmApprovalInputDtoObj));
		assertEquals(201, responseEntityObj.getStatusCodeValue());
		assertNotNull(responseEntityObj);
		verify(rsrcMgmntSrvc, times(1)).rejectRMSavedResources(List.of(rmApprovalInputDtoObj));
	}

	@Test
	public void getRMTransferApproversList() throws ResourceManagementException {
		RMApproversDto rmApproversDtoObj = new RMApproversDto();
		TransferApproverResponseDto tApproverResponseDto = new TransferApproverResponseDto();

		rmApproversDtoObj.setRoleId(1);
		rmApproversDtoObj.setRoleName("PM");
		rmApproversDtoObj.setUserId(1);
		rmApproversDtoObj.setUserName("User-1");
		rmApproversDtoObj.setStepId(14);
		List<RMApproversDto> rmApproversListDtoObj = new ArrayList<>();
		rmApproversListDtoObj.add(rmApproversDtoObj);
		when(rsrcMgmntSrvc.getRMTransferApproversList(40001, 40002, 52336, 1, "ALLOCATION"))
				.thenReturn(tApproverResponseDto);
		ResponseEntity<RMResponseDto> responseEntityObj = rsrcMgmntCntrllr.getRMTransferApproversList(40001, 40002,
				52336, 1, "ALLOCATION");
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		assertNotNull(responseEntityObj);
		verify(rsrcMgmntSrvc, times(1)).getRMTransferApproversList(40001, 40002, 52336, 1, "ALLOCATION");
	}

	@Test
	public void getRMTransferApproversListForNoContent() throws ResourceManagementException {
		when(rsrcMgmntSrvc.getRMTransferApproversList(40001, 40002, 52336, 1, "ALLOCATION")).thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = rsrcMgmntCntrllr.getRMTransferApproversList(40001, 40002,
				52336, 1, "ALLOCATION");
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(rsrcMgmntSrvc, times(1)).getRMTransferApproversList(40001, 40002, 52336, 1, "ALLOCATION");
	}

	@Test
	public void approveOrRejectRMApprovalExtensionTest() throws ResourceManagementException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		doNothing().when(rsrcMgmntSrvc).approveOrRejectRMApprovalForExtension(RMApprovalInputDtlsList);
		ResponseEntity<RMResponseDto> responseEntityObj = rsrcMgmntCntrllr
				.approveOrRejectRMApprovalForExtension(RMApprovalInputDtlsList);
		assertEquals(201, responseEntityObj.getStatusCodeValue());
		assertNotNull(responseEntityObj);
		verify(rsrcMgmntSrvc, times(1)).approveOrRejectRMApprovalForExtension(Mockito.anyList());
	}

	@Test
	public void getCostCardSuccess() throws ResourceManagementException {
		CostCardDto costCardDto = new CostCardDto();
		costCardDto.setCurrencyId(1L);
		costCardDto.setCurrencyId(2L);
		costCardDto.setEightHrsCostRate(new BigDecimal(2L));
		CostCardInputDto costCardInputDto = new CostCardInputDto();
		costCardInputDto.setBandId(1l);

		when(rsrcMgmntSrvc.getCostCard(costCardInputDto)).thenReturn(costCardDto);
		ResponseEntity<CostCardDto> responseEntityObj = rsrcMgmntCntrllr.getCostCard(costCardInputDto);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(rsrcMgmntSrvc, times(1)).getCostCard(costCardInputDto);
	}

	@Rule
	public ExpectedException expectation = ExpectedException.none();

	@Test
	public void getCostCardFailure() throws ResourceManagementException {
		CostCardInputDto costCardInputDto = new CostCardInputDto();
		costCardInputDto.setBandId(1l);
		expectation.expect(ResourceManagementException.class); 
		expectation.expectMessage(ResourceManagementConstant.Cost_Card_Message);
		rsrcMgmntCntrllr.getCostCard(costCardInputDto);
	}
	
	@Test
	public void getAllEmployeeDetailSuccessTest() throws ResourceManagementException {
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employee = new EmployeeDto();
		employee.setEmployeeName("ABC");
		employee.setEmployeeId(1L);
		employeeList.add(employee);

		when(rsrcMgmntSrvc.getAllEmployeeDetails(Mockito.anyString())).thenReturn(employeeList);
		ResponseEntity<RMResponseDto> responseEntityObj = rsrcMgmntCntrllr.getAllEmployeeDetails(Mockito.anyString());
		assertNotNull(responseEntityObj);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(rsrcMgmntSrvc, times(1)).getAllEmployeeDetails(Mockito.anyString());
	}

	@Test
	public void getAllEmployeeDetailsNoContentTest() throws ResourceManagementException {
		when(rsrcMgmntSrvc.getAllEmployeeDetails(Mockito.anyString())).thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = rsrcMgmntCntrllr.getAllEmployeeDetails(Mockito.anyString());
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(rsrcMgmntSrvc, times(1)).getAllEmployeeDetails(Mockito.anyString());
	}

}  