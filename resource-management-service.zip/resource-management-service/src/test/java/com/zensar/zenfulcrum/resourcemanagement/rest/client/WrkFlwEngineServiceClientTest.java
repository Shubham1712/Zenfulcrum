package com.zensar.zenfulcrum.resourcemanagement.rest.client;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.zensar.zenfulcrum.resourcemanagement.dto.WorkflowResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.WrkflwStepDefinitionDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.WorkflowResponseDto.WorkflowData;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.WrkflwEngineServiceClient;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class WrkFlwEngineServiceClientTest {
	
	@Mock
	private RestTemplate restTemplate;
	@InjectMocks
	private WrkflwEngineServiceClient wrkflwEngineSrvcClient;	
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(wrkflwEngineSrvcClient, "wrkflwEngineBaseUrl", "wrkflwEngineBaseUrl");
		ReflectionTestUtils.setField(wrkflwEngineSrvcClient, "getWrkflwStepDetailsRestURL","getWrkflwStepDetailsRestURL");
		ReflectionTestUtils.setField(wrkflwEngineSrvcClient, "getWrkflwStepEmailDetailsRestURL","getWrkflwStepEmailDetailsRestURL");
	}
	
	@Test 
	public void getWrkflwStepDetailsTest() throws Exception {
		
		WorkflowResponseDto workflowResponseDto = new WorkflowResponseDto();		
		WorkflowData workflowData = workflowResponseDto.new WorkflowData();
		workflowData.setDataObjectList(new ArrayList<Object>());;
		workflowResponseDto.setWorkflowOutput(workflowData);
	
		ResponseEntity<WorkflowResponseDto> response = new ResponseEntity<>(workflowResponseDto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any()))
		.thenReturn(response);
		List<WrkflwStepDefinitionDto> opWrkflwStepDfntnListObj = wrkflwEngineSrvcClient.getWrkflwStepDetails("RMA");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<WrkflwStepDefinitionDto>>>any());

	}

	@Test 
	public void getWrkflwStepDetailsTestNull() throws Exception {
		ResponseEntity<WorkflowResponseDto> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any()))
		.thenReturn(responseEntityObj);
		List<WrkflwStepDefinitionDto> opWrkflwStepDfntnListObj = wrkflwEngineSrvcClient.getWrkflwStepDetails("RMA");
		assertNull(opWrkflwStepDfntnListObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<List<WrkflwStepDefinitionDto>>>any());
	}

	@Test 
	public void getWrkflwStepDetailsTestDiffStatusCode() throws Exception {
		ResponseEntity<WorkflowResponseDto> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any()))
		.thenReturn(responseEntityObj);
		List<WrkflwStepDefinitionDto> opWrkflwStepDfntnListObj = wrkflwEngineSrvcClient.getWrkflwStepDetails("RMA");
		assertNull(opWrkflwStepDfntnListObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getWrkflwStepDetailsTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any()))
		.thenThrow(new ResourceAccessException("TestError"));
		wrkflwEngineSrvcClient.getWrkflwStepDetails("RMA");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getWrkflwStepDetailsTestHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any()))
		.thenThrow(HttpServerErrorException.class);
		wrkflwEngineSrvcClient.getWrkflwStepDetails("RMA");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getWrkflwStepDetailsTestHttpClientException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any()))
		.thenThrow(HttpClientErrorException.class);
		wrkflwEngineSrvcClient.getWrkflwStepDetails("RMA");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any());
	}
	
	@Test 
	public void getWrkflwStepEmailDetailsTest() throws Exception {
		WorkflowResponseDto workflowResponseDto = new WorkflowResponseDto();		
		WorkflowData workflowData = workflowResponseDto.new WorkflowData();
		workflowData.setDataObjectList(new ArrayList<Object>());;
		workflowResponseDto.setWorkflowOutput(workflowData);
		ResponseEntity<WorkflowResponseDto> response = new ResponseEntity<>(workflowResponseDto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any()))
		.thenReturn(response);
		List<WrkflwStepDefinitionDto> opWrkflwStepDfntnListObj = wrkflwEngineSrvcClient.getWrkflwStepEmailDetails("RMA","SUBMIT","TRUE",1);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any());
	}

	@Test 
	public void getWrkflwStepEmailDetailsTestNull() throws Exception {
		ResponseEntity<WorkflowResponseDto> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any()))
		.thenReturn(responseEntityObj);
		List<WrkflwStepDefinitionDto> opWrkflwStepDfntnListObj = wrkflwEngineSrvcClient.getWrkflwStepEmailDetails("RMA","SUBMIT","TRUE",1);
		assertNull(opWrkflwStepDfntnListObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any());
	}

	@Test 
	public void getWrkflwStepEmailDetailsTestDiffStatusCode() throws Exception {
		ResponseEntity<WorkflowResponseDto> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any()))
		.thenReturn(responseEntityObj);
		List<WrkflwStepDefinitionDto> opWrkflwStepDfntnListObj = wrkflwEngineSrvcClient.getWrkflwStepEmailDetails("RMA","SUBMIT","TRUE",1);
		assertNull(opWrkflwStepDfntnListObj);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getWrkflwStepEmailDetailsTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any()))
		.thenThrow(new ResourceAccessException("WorkflowEngine-TestError"));
		wrkflwEngineSrvcClient.getWrkflwStepEmailDetails("RMA","SUBMIT","TRUE",1);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getWrkflwStepEmailDetailsTestHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any()))
		.thenThrow(HttpServerErrorException.class);
		wrkflwEngineSrvcClient.getWrkflwStepEmailDetails("RMA","SUBMIT","TRUE",1);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getWrkflwStepEmailDetailsTestHttpClientException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any()))
		.thenThrow(HttpClientErrorException.class);
		wrkflwEngineSrvcClient.getWrkflwStepEmailDetails("RMA","SUBMIT","TRUE",1);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<WorkflowResponseDto>>any());
	}
}
