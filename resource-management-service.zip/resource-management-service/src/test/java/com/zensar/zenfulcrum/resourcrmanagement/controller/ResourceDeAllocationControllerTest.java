package com.zensar.zenfulcrum.resourcrmanagement.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.controller.ResourcesDeAllocationController;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeallocationInputDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceDeAllocationService;

@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceDeAllocationControllerTest {

	@InjectMocks
	private ResourcesDeAllocationController resourceDeallocationController;

	@Mock
	private ResourceDeAllocationService resourceDeallocationService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void saveResourceDeallocationsTest() throws ResourceManagementException, ParseException {
		TAssociateDeAllocationDto deallocationDto = new TAssociateDeAllocationDto();

		List<TAssociateDeAllocationDto> deallocationDtoList = new ArrayList<>();
		deallocationDtoList.add(deallocationDto);
		TAssociateDeallocationInputDto tassociateDeallocationInputDto = new TAssociateDeallocationInputDto();
		tassociateDeallocationInputDto.setTassociateDeAllocationList(deallocationDtoList);
		doNothing().when(resourceDeallocationService).saveALLResourceDeallocation(Mockito.any());
		ResponseEntity<RMResponseDto> responseEntityObj = resourceDeallocationController
				.saveResourceDeallocations(tassociateDeallocationInputDto);
		assertNotNull(responseEntityObj);
		assertEquals(201, responseEntityObj.getStatusCodeValue());
		verify(resourceDeallocationService, times(1)).saveALLResourceDeallocation(Mockito.any());
	}

	@Test
	public void saveResourceDeallocationsNull() throws ResourceManagementException, ParseException {
		ResponseEntity<RMResponseDto> responseEntityObj = resourceDeallocationController
				.saveResourceDeallocations(null);

		assertEquals(400, responseEntityObj.getStatusCodeValue());
	}
}