package com.zensar.zenfulcrum.resourcemanagement.email;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.MailTemplateDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PrimaryUsersDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTResourceDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.WrkflwStepDefinitionDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.SendMailHelperService;
import com.zensar.zenfulcrum.resourcemanagement.model.ResourceWorkflow;
import com.zensar.zenfulcrum.resourcemanagement.projection.ResourceWorkflowProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceWorkflowRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.LiferayServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.WrkflwEngineServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.SendMailUtil;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class SendMailHelperServiceTest {

	@InjectMocks
	private SendMailHelperService sendMailHelperService;

	@Mock
	private WrkflwEngineServiceClient wrkflwEngineSrvcClient;

	@Mock
	private BAPServiceClient bapSrvcClient;

	@Mock
	private AdminServiceClient adminSrvcClient;

	@Mock
	private LiferayServiceClient liferayServiceClient;

	@Mock
	private SendMailUtil sendMailUtil;

	@Mock
	private ResourceWorkflowRepository resourceWrkflwRepository;

	@Test
	public void sendEmailForAllocSubmissionConfirmationTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);

		sendMailHelperService.sendEmailForSubmissionConfirmation(rmApprovalDtls, "RMA");
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForDeAllocSubmissionConfirmationTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		List<Long> empIdList = new ArrayList();
		empIdList.add(1L);
		ResourceRequirementDto rsrcReqDtoObj = new ResourceRequirementDto();
		rsrcReqDtoObj.setEmployeeIdList(empIdList);
		List<ResourceRequirementDto> rsrcReqDtoList = new ArrayList<>();
		rsrcReqDtoList.add(rsrcReqDtoObj);
		rmApprovalDtls.setResourceRequirementList(rsrcReqDtoList);
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);
		sendMailHelperService.sendEmailForSubmissionConfirmation(rmApprovalDtls, "RMA");
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForAllocApprovalConfirmationTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setCurrentProjectId(40002l);
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);
		sendMailHelperService.sendEmailForApprovalConfirmation(rmApprovalDtls, "RMA");
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}
	
	@Test
	public void sendEmailForAllocTransferConfirmationTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setCurrentProjectId(40002l);
		List<RTResourceDto> resourceList = new ArrayList<>();
		RTResourceDto resourceDto = new RTResourceDto();
		resourceDto.setEmpId(1234);
		resourceList.add(resourceDto);
		rmApprovalDtls.setResourceList(resourceList);
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);
		sendMailHelperService.sendEmailForApprovalConfirmation(rmApprovalDtls, "RMT");
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForDeAllocApprovalConfirmationTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setApproverAction("APPROVED");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);
		sendMailHelperService.sendEmailForApprovalConfirmation(rmApprovalDtls, "RMA");
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForAllocRejectionConfirmationTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);
		sendMailHelperService.sendEmailForRejectionConfirmation(rmApprovalDtls, "RMA");
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForDeAllocRejectionConfirmationTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setApproverAction("APPROVED");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);
		sendMailHelperService.sendEmailForRejectionConfirmation(rmApprovalDtls, "RMA");
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForDeAllocApprovalPendingTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		rmApprovalDtls.setApproverAction(ResourceManagementConstant.RM_APPROVER_APPROVE_ACTION);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ResourceWorkflow resourceWrkflwDataObj = new ResourceWorkflow();
		resourceWrkflwDataObj.setNextRoleId(1L);
		List<ResourceWorkflowProjection> rmSelectedApproversIdList = new ArrayList<>();
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(resourceWrkflwRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(resourceWrkflwDataObj);
		when(resourceWrkflwRepository.getAllApproversIdList(Mockito.anyLong())).thenReturn(rmSelectedApproversIdList);
		sendMailHelperService.sendEmailForApproveOrRejectionPending(rmApprovalDtls, "RMA", 123);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForAllocApprovalPendingTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		rmApprovalDtls.setApproverAction(ResourceManagementConstant.RM_APPROVER_APPROVE_ACTION);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ResourceWorkflow resourceWrkflwDataObj = new ResourceWorkflow();
		resourceWrkflwDataObj.setNextRoleId(1L);
		List<ResourceWorkflowProjection> rmSelectedApproversIdList = new ArrayList<>();
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(resourceWrkflwRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(resourceWrkflwDataObj);
		when(resourceWrkflwRepository.getAllApproversIdList(Mockito.anyLong())).thenReturn(rmSelectedApproversIdList);
		sendMailHelperService.sendEmailForApproveOrRejectionPending(rmApprovalDtls, "RMA", 123);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForAllocRejectionPendingTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		rmApprovalDtls.setApproverAction(ResourceManagementConstant.RM_APPROVER_REJECT_ACTION);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ResourceWorkflow resourceWrkflwDataObj = new ResourceWorkflow();
		resourceWrkflwDataObj.setCurrentUserId(123L);
		resourceWrkflwDataObj.setCurrentRoleId(1L);
		List<ResourceWorkflowProjection> rmSelectedApproversIdList = new ArrayList<>();
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(resourceWrkflwRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(resourceWrkflwDataObj);
		when(resourceWrkflwRepository.getAllApproversIdList(Mockito.anyLong())).thenReturn(rmSelectedApproversIdList);
		sendMailHelperService.sendEmailForApproveOrRejectionPending(rmApprovalDtls, "RMA", 123);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForDeAllocRejectionPendingTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		rmApprovalDtls.setApproverAction(ResourceManagementConstant.RM_APPROVER_REJECT_ACTION);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ResourceWorkflow resourceWrkflwDataObj = new ResourceWorkflow();
		resourceWrkflwDataObj.setCurrentUserId(123L);
		resourceWrkflwDataObj.setCurrentRoleId(1L);
		List<ResourceWorkflowProjection> rmSelectedApproversIdList = new ArrayList<>();
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(resourceWrkflwRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(resourceWrkflwDataObj);
		when(resourceWrkflwRepository.getAllApproversIdList(Mockito.anyLong())).thenReturn(rmSelectedApproversIdList);
		sendMailHelperService.sendEmailForApproveOrRejectionPending(rmApprovalDtls, "RMA", 123);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForAllocSubmitApprovalPendingTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ResourceWorkflow resourceWrkflwDataObj = new ResourceWorkflow();
		resourceWrkflwDataObj.setNextRoleId(1L);
		List<ResourceWorkflowProjection> rmSelectedApproversIdList = new ArrayList<>();
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(resourceWrkflwRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(resourceWrkflwDataObj);
		when(resourceWrkflwRepository.getAllApproversIdList(Mockito.anyLong())).thenReturn(rmSelectedApproversIdList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);
		sendMailHelperService.sendEmailForSubmitApprovalPending(rmApprovalDtls, "RMA", 123);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForDeAllocSubmitApprovalPendingTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		List<Long> empIdList = new ArrayList();
		empIdList.add(1L);
		ResourceRequirementDto rsrcReqDtoObj = new ResourceRequirementDto();
		rsrcReqDtoObj.setEmployeeIdList(empIdList);
		List<ResourceRequirementDto> rsrcReqDtoList = new ArrayList<>();
		rsrcReqDtoList.add(rsrcReqDtoObj);
		rmApprovalDtls.setResourceRequirementList(rsrcReqDtoList);
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ResourceWorkflow resourceWrkflwDataObj = new ResourceWorkflow();
		resourceWrkflwDataObj.setNextRoleId(1L);
		List<ResourceWorkflowProjection> rmSelectedApproversIdList = new ArrayList<>();
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(resourceWrkflwRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(resourceWrkflwDataObj);
		when(resourceWrkflwRepository.getAllApproversIdList(Mockito.anyLong())).thenReturn(rmSelectedApproversIdList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);
		sendMailHelperService.sendEmailForSubmitApprovalPending(rmApprovalDtls, "RMA", 123);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForAllocFinalApprovalConfirmationTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ResourceWorkflow resourceWrkflwDataObj = new ResourceWorkflow();
		resourceWrkflwDataObj.setNextRoleId(1L);
		List<ResourceWorkflowProjection> rmSelectedApproversIdList = new ArrayList<>();
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(resourceWrkflwRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(resourceWrkflwDataObj);
		when(resourceWrkflwRepository.getAllApproversIdList(Mockito.anyLong())).thenReturn(rmSelectedApproversIdList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);

		sendMailHelperService.sendEmailForFinalApprovalConfirmation(rmApprovalDtls, "RMA", 123);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForDeAllocFinalApprovalConfirmationTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setApproverAction("APPROVED");
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ResourceWorkflow resourceWrkflwDataObj = new ResourceWorkflow();
		resourceWrkflwDataObj.setNextRoleId(1L);
		List<ResourceWorkflowProjection> rmSelectedApproversIdList = new ArrayList<>();
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(resourceWrkflwRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(resourceWrkflwDataObj);
		when(resourceWrkflwRepository.getAllApproversIdList(Mockito.anyLong())).thenReturn(rmSelectedApproversIdList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);
		sendMailHelperService.sendEmailForFinalApprovalConfirmation(rmApprovalDtls, "RMA", 123);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	@Test
	public void sendEmailForTravelSubmissionConfirmationTest() throws ResourceManagementException {

		TAssociateProjectDto allocationDto = new TAssociateProjectDto();
		List<TAssociateProjectDto> tassociateProjectList = new ArrayList<>();
		TAssociateAllocationDto tAssociateAllocation = new TAssociateAllocationDto();
		tAssociateAllocation.setActualAllocationEndDate(new Date());
		tAssociateAllocation.setActualAllocationStartDate(new Date());
		TAssociateProjectDto tassociateProjectDto = new TAssociateProjectDto();
		tassociateProjectDto.setRoleId(2l);
		tassociateProjectDto.setUserName("xyz");
		tassociateProjectDto.setRoleName("PGM");
		tassociateProjectDto.setTargetProjectId(40002);
		tassociateProjectDto.setTargetRequirementId(2l);
		tassociateProjectDto.setAssociateProjectId(40001l);
		tassociateProjectDto.setEmployeeId(52336l);
		tassociateProjectDto.setTAssociateAllocation(tAssociateAllocation);
		tassociateProjectList.add(tassociateProjectDto);
		List<Long> bccUsersList = new ArrayList<>();
		List<Long> toUsersList = new ArrayList<>();
		List<Long> ccUsersList = new ArrayList<>();
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		userMailIds.add("sandeep.yadav3@zensar.com");
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(40001L);
		projectDto.setProjectName("xyz");
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDto);
		when(bapSrvcClient.getProjectBasedPrimaryOwnersList(Mockito.anyList(), Mockito.anyLong()))
				.thenReturn(primaryUserDtls);
		sendMailHelperService.sendEmailForTravelSubmissionConfirmation(tassociateProjectList);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());

	}
	
	
	@Test
	public void sendEmailForAllocApprovalEctensionConfirmationTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setCurrentProjectId(40002l);
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);
		sendMailHelperService.sendEmailForApprovalConfirmation(rmApprovalDtls, "RMA");
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}
	
	@Test
	public void sendEmailForAllocFinalApprovalExtensionConfirmationTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ResourceWorkflow resourceWrkflwDataObj = new ResourceWorkflow();
		resourceWrkflwDataObj.setNextRoleId(1L);
		List<ResourceWorkflowProjection> rmSelectedApproversIdList = new ArrayList<>();
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(resourceWrkflwRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(resourceWrkflwDataObj);
		when(resourceWrkflwRepository.getAllApproversIdList(Mockito.anyLong())).thenReturn(rmSelectedApproversIdList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);

		sendMailHelperService.sendEmailForFinalApprovalConfirmation(rmApprovalDtls, "RMA", 123);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}
	
	@Test
	public void sendEmailForDeAllocApprovaExtensionlPendingTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		rmApprovalDtls.setApproverAction(ResourceManagementConstant.RM_APPROVER_APPROVE_ACTION);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ResourceWorkflow resourceWrkflwDataObj = new ResourceWorkflow();
		resourceWrkflwDataObj.setNextRoleId(1L);
		List<ResourceWorkflowProjection> rmSelectedApproversIdList = new ArrayList<>();
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(resourceWrkflwRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(resourceWrkflwDataObj);
		when(resourceWrkflwRepository.getAllApproversIdList(Mockito.anyLong())).thenReturn(rmSelectedApproversIdList);
		sendMailHelperService.sendEmailForApproveOrRejectionPending(rmApprovalDtls, "RMA", 123);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}
	
	
	@Test
	public void sendEmailForAllocRejectionExtensionConfirmationTest() throws ResourceManagementException {
		RMApprovalInputDto rmApprovalDtls = new RMApprovalInputDto();
		rmApprovalDtls.setUserId(123);
		rmApprovalDtls.setRoleId(1);
		rmApprovalDtls.setRoleName("test role");
		rmApprovalDtls.setUserName("test user");
		rmApprovalDtls.setRequestType(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);
		List<PrimaryUsersDto> primaryUserDtls = new ArrayList<>();
		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setCustomerCode("CISCO");
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setUserId(123);
		primaryUserDtls.add(primaryUsersDto);
		List<String> userMailIds = new ArrayList<>();
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("Test Message Body");
		mailTemplateDtls.setMessageBodyFooter("Test Message Footer");
		mailTemplateDtls.setMessageBodyHeader("Test Message Header");
		mailTemplateDtls.setSubject("Test Subject");
		mailTemplateDtls.setTableColumnNames("Test column names");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("test employee");
		employeeDto.setEmployeeLocation("test location");
		employeeDto.setBand("F1");
		employeeDtlsList.add(employeeDto);
		ProjectDto projectDetailDto = new ProjectDto();
		projectDetailDto.setProjectId(40001L);
		projectDetailDto.setProjectName("JLP DEV MS FLEX");
		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(primaryUserDtls);
		when(adminSrvcClient.getAssociatesEmailAddress(Mockito.anyList())).thenReturn(userMailIds);
		when(liferayServiceClient.getEmailTemplate(Mockito.anyString())).thenReturn(mailTemplateDtls);
		when(adminSrvcClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		when(bapSrvcClient.getProjectDetail(Mockito.anyLong())).thenReturn(projectDetailDto);
		sendMailHelperService.sendEmailForRejectionConfirmation(rmApprovalDtls, "RMA");
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		verify(liferayServiceClient, times(1)).getEmailTemplate(Mockito.anyString());
	}

	


}
