package com.zensar.zenfulcrum.resourcemanagement.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.projection.ProjectionFactory;
import org.springframework.data.projection.SpelAwareProxyProjectionFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.HashBasedTable;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueAndDescDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceApprovalDashboardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RoleDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TraceabilityApprSummaryDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TraceabilityCurrentStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TraceabilityDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.model.ResourceWorkflow;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateProject;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.ApprovalTraceabilityProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceWorkflowRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateExtensionRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceDashboardServiceImpl;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceManagementServiceImpl;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementUtil;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceDashboardServiceTest {

	@InjectMocks
	private ResourceDashboardServiceImpl resourceDashboardServiceImpl;

	@Mock
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Mock
	private TAssociateDeAllocationRepository tAssociateDeAllocationRepository;

	@Mock
	private TAssociateExtensionRepository tAssociateExtensionRepository;

	@Mock
	private ResourceManagementServiceImpl resourceManagementServiceImpl;

	@Mock
	private ResourceWorkflowRepository resourceWorkflowRepository;

	@Mock
	private AdminServiceClient adminServiceClient;

	@Mock
	private BAPServiceClient bapServiceClient;

	@Mock
	private ResourceManagementUtil resourceManagementUtil;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	@Test
	public void getResourcePendingCountTest() throws ResourceManagementException {

		Map<String, Integer> resourcePendingCountMap = new HashMap<>();
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_ALLOCATION_APPROVAL, 12);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_DEALLOCATION_APPROVAL, 10);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_TRANSFER_APPROVAL, 8);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_EXTENSION_APPROVAL, 6);

		when(tAssociateAllocationRepository.getApprovalPendingResourceCount(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList())).thenReturn(12);
		resourceDashboardServiceImpl.getResourcePendingCount(Mockito.anyLong(), Mockito.anyLong());

		verify(tAssociateAllocationRepository, times(5)).getApprovalPendingResourceCount(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList());
	}

	@Test
	public void getResourcesPendingForApprovalTestForAlloc() throws ResourceManagementException, ParseException {
		List<String> requestTypeList = new ArrayList<>();
		requestTypeList.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<Long> transList = new ArrayList<>();
		transList.add(123L);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		ResourceWorkflow previousApproverData = new ResourceWorkflow();
		ResourceWorkflow previousApproverStatus = new ResourceWorkflow();
		previousApproverStatus.setLastUpdatedDate(dateFormat.parse("2020-08-12"));
		ResourceWorkflow currentApproverData = new ResourceWorkflow();
		currentApproverData.setNextRoleId(1L);
		currentApproverData.setNextUserId(123L);
		currentApproverData.setLastUpdatedDate(dateFormat.parse("2020-08-10"));
		ResourceWorkflow nextApproverStatus = new ResourceWorkflow();
		nextApproverStatus.setLastUpdatedDate(dateFormat.parse("2020-08-11"));
		Map<String, ModuleStatusDto> allocStatusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1L);
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<ModuleStatusDto> workflowTypeIds = new ArrayList<>();
		workflowTypeIds.add(moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.ACTIVATE, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);
		EmployeeDto employeeDetails = new EmployeeDto();
		employeeDetails.setEmployeeName("abc");
		employeeDetails.setEmployeeNumber(123l);
		employeeDetails.setIfPrimaryProjectExists(true);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(previousApproverData);
		when(resourceWorkflowRepository.getRecentPreviousRowData(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList())).thenReturn(previousApproverStatus);
		when(resourceWorkflowRepository.getRecentRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(currentApproverData);
		when(resourceWorkflowRepository.getRecentNextRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList())).thenReturn(nextApproverStatus);
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(allocStatusDtlsMap);
		when(adminServiceClient.getModuleDetailsList(Mockito.anyString(), Mockito.anyList()))
				.thenReturn(workflowTypeIds);
		when(resourceManagementUtil.getListOfRequestTypes()).thenReturn(requestTypeList);
		when(tAssociateAllocationRepository.getActiveUserTransactions(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(transList);
		when(tAssociateAllocationRepository.getAssociatesByAllocationId(Mockito.anyList()))
				.thenReturn(getallocatedResourceProjection());
		when(tAssociateAllocationRepository.getPendingResourceSubmit(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(getallocatedResourceProjection());
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(getResourceRequirementDtos());
		when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(getProjectList());
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(getEmployee());
		when(adminServiceClient.getEmployeeDetailsByEmpId(Mockito.anyLong())).thenReturn(employeeDetails);

		ResourceApprovalDashboardDto resourceDtls = resourceDashboardServiceImpl.getPendingResourceDetails(1L, 1L);
		assertNotNull(resourceDtls);
	}

	@Test
	public void getResourcesPendingForApprovalTestForTransfer() throws ResourceManagementException, ParseException {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<String> requestTypeList = new ArrayList<>();
		requestTypeList.add(ResourceManagementConstant.RESOURCE_TRANSFER);
		List<Long> transList = new ArrayList<>();
		transList.add(123L);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		ResourceWorkflow previousApproverData = new ResourceWorkflow();
		ResourceWorkflow previousApproverStatus = new ResourceWorkflow();
		previousApproverStatus.setLastUpdatedDate(dateFormat.parse("2020-08-12"));
		ResourceWorkflow currentApproverData = new ResourceWorkflow();
		currentApproverData.setNextRoleId(1L);
		currentApproverData.setNextUserId(123L);
		currentApproverData.setLastUpdatedDate(dateFormat.parse("2020-08-10"));
		ResourceWorkflow nextApproverStatus = new ResourceWorkflow();
		nextApproverStatus.setLastUpdatedDate(dateFormat.parse("2020-08-11"));
		Map<String, ModuleStatusDto> allocStatusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1L);
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		List<ModuleStatusDto> workflowTypeIds = new ArrayList<>();
		workflowTypeIds.add(moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.ACTIVATE, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);
		List<AllocatedResourceProjection> sourceAndTargetDetailsList = new ArrayList<>();
		AllocatedResourceProjection resourceAllocExtDtls = factory.createProjection(AllocatedResourceProjection.class);
		resourceAllocExtDtls.setProjectId(1L);
		resourceAllocExtDtls.setEmployeeId(123L);
		resourceAllocExtDtls.setRequirementId(1L);
		resourceAllocExtDtls.setFtePercent(100L);
		resourceAllocExtDtls.setExtEstEndDate(new Date());
		resourceAllocExtDtls.setEstEndDate(new Date());
		resourceAllocExtDtls.setRoleId(1L);
		resourceAllocExtDtls.setTransactionHistoryId(111L);
		resourceAllocExtDtls.setAssociateAllocationId(123L);
		resourceAllocExtDtls.setIsPrimaryProject(true);
		sourceAndTargetDetailsList.add(resourceAllocExtDtls);
		AllocatedResourceProjection resourceAllocExtDtlsTarget = factory
				.createProjection(AllocatedResourceProjection.class);
		resourceAllocExtDtlsTarget.setProjectId(2L);
		resourceAllocExtDtlsTarget.setEmployeeId(123L);
		resourceAllocExtDtlsTarget.setRequirementId(1L);
		resourceAllocExtDtlsTarget.setFtePercent(100L);
		resourceAllocExtDtlsTarget.setExtEstEndDate(new Date());
		resourceAllocExtDtlsTarget.setEstEndDate(new Date());
		resourceAllocExtDtlsTarget.setRoleId(1L);
		resourceAllocExtDtlsTarget.setIsPrimaryProject(true);
		resourceAllocExtDtlsTarget.setTransactionHistoryId(118L);
		resourceAllocExtDtlsTarget.setAssociateAllocationId(111L);
		sourceAndTargetDetailsList.add(resourceAllocExtDtlsTarget);
		List<AllocatedResourceProjection> resourceAllocExtDtlsList = new ArrayList<>();
		resourceAllocExtDtlsList.add(resourceAllocExtDtls);
		when(tAssociateAllocationRepository.getActiveUserTransactions(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(transList);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(previousApproverData);
		when(resourceWorkflowRepository.getRecentPreviousRowData(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList())).thenReturn(previousApproverStatus);
		when(resourceWorkflowRepository.getRecentRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(currentApproverData);
		when(resourceWorkflowRepository.getRecentNextRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList())).thenReturn(nextApproverStatus);
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(allocStatusDtlsMap);
		when(adminServiceClient.getModuleDetailsList(Mockito.anyString(), Mockito.anyList()))
				.thenReturn(workflowTypeIds);
		when(resourceManagementUtil.getListOfRequestTypes()).thenReturn(requestTypeList);
		when(tAssociateAllocationRepository.getSourceAndTargetOfAssociateByAllocationIdList(Mockito.anyList()))
				.thenReturn(sourceAndTargetDetailsList);

		ResourceApprovalDashboardDto resourceDtls = resourceDashboardServiceImpl.getPendingResourceDetails(1L, 1L);
		assertNotNull(resourceDtls);
	}

	@Test
	public void getRsrcApprvlPendingStatusAndDateCheckTestForAlloc()
			throws ResourceManagementException, ParseException {
		List<String> requestTypeList = new ArrayList<>();
		requestTypeList.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<Long> transList = new ArrayList<>();
		transList.add(123L);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		ResourceWorkflow previousApproverData = new ResourceWorkflow();
		ResourceWorkflow previousApproverStatus = new ResourceWorkflow();
		previousApproverStatus.setLastUpdatedDate(dateFormat.parse("2020-08-12"));
		ResourceWorkflow currentApproverData = new ResourceWorkflow();
		currentApproverData.setNextRoleId(1L);
		currentApproverData.setNextUserId(123L);
		currentApproverData.setLastUpdatedDate(dateFormat.parse("2020-08-13"));
		Map<String, ModuleStatusDto> allocStatusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1L);
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<ModuleStatusDto> workflowTypeIds = new ArrayList<>();
		workflowTypeIds.add(moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.ACTIVATE, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);
		when(tAssociateAllocationRepository.getActiveUserTransactions(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(transList);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(previousApproverData);
		when(resourceWorkflowRepository.getRecentPreviousRowData(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList())).thenReturn(previousApproverData);
		when(resourceWorkflowRepository.getRecentRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(currentApproverData);
		when(resourceWorkflowRepository.getRecentNextRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList())).thenReturn(null);
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(allocStatusDtlsMap);
		when(resourceManagementUtil.getListOfRequestTypes()).thenReturn(requestTypeList);
		when(adminServiceClient.getModuleDetailsList(Mockito.anyString(), Mockito.anyList()))
				.thenReturn(workflowTypeIds);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		ResourceApprovalDashboardDto resourceDtls = resourceDashboardServiceImpl.getPendingResourceDetails(1L, 1L);
		assertNotNull(resourceDtls);
	}

	@Test
	public void getRsrcApprvlPendingStatusCheckTestForAlloc() throws ResourceManagementException, ParseException {
		List<String> requestTypeList = new ArrayList<>();
		requestTypeList.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<Long> transList = new ArrayList<>();
		transList.add(123L);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		ResourceWorkflow previousApproverData = new ResourceWorkflow();
		Map<String, ModuleStatusDto> allocStatusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1L);
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<ModuleStatusDto> workflowTypeIds = new ArrayList<>();
		workflowTypeIds.add(moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.ACTIVATE, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);
		when(tAssociateAllocationRepository.getActiveUserTransactions(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(transList);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(previousApproverData);
		when(resourceWorkflowRepository.getRecentPreviousRowData(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList())).thenReturn(null);
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(allocStatusDtlsMap);
		when(resourceManagementUtil.getListOfRequestTypes()).thenReturn(requestTypeList);
		when(adminServiceClient.getModuleDetailsList(Mockito.anyString(), Mockito.anyList()))
				.thenReturn(workflowTypeIds);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		ResourceApprovalDashboardDto resourceDtls = resourceDashboardServiceImpl.getPendingResourceDetails(1L, 1L);
		assertNotNull(resourceDtls);
	}

	@Test
	public void getRsrcApprvlPendingStatusCheckByPassTestForAlloc() throws ResourceManagementException, ParseException {
		List<String> requestTypeList = new ArrayList<>();
		requestTypeList.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<Long> transList = new ArrayList<>();
		transList.add(123L);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		ResourceWorkflow currentApproverData = new ResourceWorkflow();
		currentApproverData.setNextRoleId(0L);
		currentApproverData.setNextUserId(0L);
		currentApproverData.setLastUpdatedDate(dateFormat.parse("2020-08-10"));
		Map<String, ModuleStatusDto> allocStatusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		moduleStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<ModuleStatusDto> workflowTypeIds = new ArrayList<>();
		workflowTypeIds.add(moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.ACTIVATE, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);
		when(tAssociateAllocationRepository.getActiveUserTransactions(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(transList);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(null);
		when(resourceWorkflowRepository.getRecentRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(currentApproverData);
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(allocStatusDtlsMap);
		when(resourceManagementUtil.getListOfRequestTypes()).thenReturn(requestTypeList);
		when(adminServiceClient.getModuleDetailsList(Mockito.anyString(), Mockito.anyList()))
				.thenReturn(workflowTypeIds);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		ResourceApprovalDashboardDto resourceDtls = resourceDashboardServiceImpl.getPendingResourceDetails(1L, 1L);
		assertNotNull(resourceDtls);
	}

	@Test
	public void getResourcesPendingForApprovalTestForDeAlloc() throws ResourceManagementException, ParseException {
		List<String> requestTypeList = new ArrayList<>();
		requestTypeList.add(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		List<Long> transList = new ArrayList<>();
		transList.add(123L);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		ResourceWorkflow previousApproverData = new ResourceWorkflow();
		ResourceWorkflow previousApproverStatus = new ResourceWorkflow();
		previousApproverStatus.setLastUpdatedDate(dateFormat.parse("2020-08-12"));
		ResourceWorkflow currentApproverData = new ResourceWorkflow();
		currentApproverData.setNextRoleId(1L);
		currentApproverData.setNextUserId(123L);
		currentApproverData.setLastUpdatedDate(dateFormat.parse("2020-08-10"));
		ResourceWorkflow nextApproverStatus = new ResourceWorkflow();
		nextApproverStatus.setLastUpdatedDate(dateFormat.parse("2020-08-11"));
		Map<String, ModuleStatusDto> allocStatusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		moduleStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		List<ModuleStatusDto> workflowTypeIds = new ArrayList<>();
		workflowTypeIds.add(moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.ACTIVATE, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);
		EmployeeDto employeeDetails = new EmployeeDto();
		employeeDetails.setEmployeeNumber(123l);
		employeeDetails.setEmployeeName("abc");
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(previousApproverData);
		when(resourceWorkflowRepository.getRecentPreviousRowData(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList())).thenReturn(previousApproverStatus);
		when(resourceWorkflowRepository.getRecentRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(currentApproverData);
		when(resourceWorkflowRepository.getRecentNextRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList())).thenReturn(nextApproverStatus);
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(allocStatusDtlsMap);
		when(adminServiceClient.getModuleDetailsList(Mockito.anyString(), Mockito.anyList()))
				.thenReturn(workflowTypeIds);
		when(resourceManagementUtil.getListOfRequestTypes()).thenReturn(requestTypeList);
		when(tAssociateDeAllocationRepository.getDeallocationpendingForApprovalRecords(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
						.thenReturn(transList);
		when(tAssociateDeAllocationRepository.getDeallocationPendingForSubmissionRecords(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(transList);
		when(tAssociateAllocationRepository.getAssociatesByAllocationId(Mockito.anyList()))
				.thenReturn(getallocatedResourceProjection());
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(getResourceRequirementDtos());
		when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(getProjectList());
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(getEmployee());
		when(adminServiceClient.getEmployeeDetailsByEmpId(Mockito.anyLong())).thenReturn(employeeDetails);
		ResourceApprovalDashboardDto resourceDtls = resourceDashboardServiceImpl.getPendingResourceDetails(1L, 1L);
		assertNotNull(resourceDtls);
	}

	@Test
	public void getResourcesPendingForApprovalTestForExtension() throws ResourceManagementException, ParseException {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<String> requestTypeList = new ArrayList<>();
		requestTypeList.add(ResourceManagementConstant.RESOURCE_EXTENSION);
		AllocatedResourceProjection resourceAllocExtDtls = factory.createProjection(AllocatedResourceProjection.class);
		resourceAllocExtDtls.setAssociateAllocationId(123L);
		resourceAllocExtDtls.setProjectId(1L);
		resourceAllocExtDtls.setEmployeeId(123L);
		resourceAllocExtDtls.setRequirementId(1L);
		resourceAllocExtDtls.setExtEstEndDate(new Date());
		resourceAllocExtDtls.setEstEndDate(new Date());
		List<AllocatedResourceProjection> resourceAllocExtDtlsList = new ArrayList<>();
		resourceAllocExtDtlsList.add(resourceAllocExtDtls);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		ResourceWorkflow previousApproverData = new ResourceWorkflow();
		ResourceWorkflow previousApproverStatus = new ResourceWorkflow();
		previousApproverStatus.setLastUpdatedDate(dateFormat.parse("2020-08-12"));
		ResourceWorkflow currentApproverData = new ResourceWorkflow();
		currentApproverData.setNextRoleId(1L);
		currentApproverData.setNextUserId(123L);
		currentApproverData.setLastUpdatedDate(dateFormat.parse("2020-08-10"));
		ResourceWorkflow nextApproverStatus = new ResourceWorkflow();
		nextApproverStatus.setLastUpdatedDate(dateFormat.parse("2020-08-11"));
		Map<String, ModuleStatusDto> allocStatusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		moduleStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_EXTENSION);
		List<ModuleStatusDto> workflowTypeIds = new ArrayList<>();
		workflowTypeIds.add(moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.ACTIVATE, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);
		when(tAssociateExtensionRepository.getActiveAllocationExtensionDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
						.thenReturn(resourceAllocExtDtlsList);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(previousApproverData);
		when(resourceWorkflowRepository.getRecentPreviousRowData(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList())).thenReturn(previousApproverStatus);
		when(resourceWorkflowRepository.getRecentRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(currentApproverData);
		when(resourceWorkflowRepository.getRecentNextRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList())).thenReturn(nextApproverStatus);
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(allocStatusDtlsMap);
		when(adminServiceClient.getModuleDetailsList(Mockito.anyString(), Mockito.anyList()))
				.thenReturn(workflowTypeIds);
		when(resourceManagementUtil.getListOfRequestTypes()).thenReturn(requestTypeList);
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1L);
		projectDto.setProjectName("TEST-PROJECT");
		List<ProjectDto> projectDtlsList = new ArrayList<>();
		projectDtlsList.add(projectDto);
		when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(projectDtlsList);
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("TEST-EMPLOYEE");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		employeeDtlsList.add(employeeDto);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		ResourceApprovalDashboardDto resourceDtls = resourceDashboardServiceImpl.getPendingResourceDetails(1L, 1L);
		assertNotNull(resourceDtls);
	}

	@Test
	public void getRsrcApprvlPendingStatusAndDateCheckTestForAllocExt()
			throws ResourceManagementException, ParseException {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<String> requestTypeList = new ArrayList<>();
		requestTypeList.add(ResourceManagementConstant.RESOURCE_EXTENSION);
		AllocatedResourceProjection resourceAllocExtDtls = factory.createProjection(AllocatedResourceProjection.class);
		resourceAllocExtDtls.setAssociateAllocationId(123L);
		resourceAllocExtDtls.setProjectId(1L);
		resourceAllocExtDtls.setEmployeeId(123L);
		resourceAllocExtDtls.setRequirementId(1L);
		resourceAllocExtDtls.setExtEstEndDate(new Date());
		resourceAllocExtDtls.setIsPrimaryProject(true);
		resourceAllocExtDtls.setEstEndDate(new Date());
		List<AllocatedResourceProjection> resourceAllocExtDtlsList = new ArrayList<>();
		resourceAllocExtDtlsList.add(resourceAllocExtDtls);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		ResourceWorkflow previousApproverData = new ResourceWorkflow();
		ResourceWorkflow previousApproverStatus = new ResourceWorkflow();
		previousApproverStatus.setLastUpdatedDate(dateFormat.parse("2020-08-12"));
		ResourceWorkflow currentApproverData = new ResourceWorkflow();
		currentApproverData.setNextRoleId(1L);
		currentApproverData.setNextUserId(123L);
		currentApproverData.setLastUpdatedDate(dateFormat.parse("2020-08-13"));
		Map<String, ModuleStatusDto> allocStatusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		moduleStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_EXTENSION);
		List<ModuleStatusDto> workflowTypeIds = new ArrayList<>();
		workflowTypeIds.add(moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.ACTIVATE, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);
		when(tAssociateExtensionRepository.getActiveAllocationExtensionDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
						.thenReturn(resourceAllocExtDtlsList);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(previousApproverData);
		when(resourceWorkflowRepository.getRecentPreviousRowData(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList())).thenReturn(previousApproverData);
		when(resourceWorkflowRepository.getRecentRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(currentApproverData);
		when(resourceWorkflowRepository.getRecentNextRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList())).thenReturn(null);
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(allocStatusDtlsMap);
		when(resourceManagementUtil.getListOfRequestTypes()).thenReturn(requestTypeList);
		when(adminServiceClient.getModuleDetailsList(Mockito.anyString(), Mockito.anyList()))
				.thenReturn(workflowTypeIds);
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1L);
		projectDto.setProjectName("TEST-PROJECT");
		List<ProjectDto> projectDtlsList = new ArrayList<>();
		projectDtlsList.add(projectDto);
		when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(projectDtlsList);
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("TEST-EMPLOYEE");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		employeeDtlsList.add(employeeDto);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		ResourceApprovalDashboardDto resourceDtls = resourceDashboardServiceImpl.getPendingResourceDetails(1L, 1L);
		assertNotNull(resourceDtls);
	}

	@Test
	public void getRsrcApprvlPendingStatusCheckTestForAllocExt() throws ResourceManagementException, ParseException {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<String> requestTypeList = new ArrayList<>();
		requestTypeList.add(ResourceManagementConstant.RESOURCE_EXTENSION);
		AllocatedResourceProjection resourceAllocExtDtls = factory.createProjection(AllocatedResourceProjection.class);
		resourceAllocExtDtls.setAssociateAllocationId(123L);
		resourceAllocExtDtls.setProjectId(1L);
		resourceAllocExtDtls.setEmployeeId(123L);
		resourceAllocExtDtls.setRequirementId(1L);
		resourceAllocExtDtls.setExtEstEndDate(new Date());
		resourceAllocExtDtls.setEstEndDate(new Date());
		resourceAllocExtDtls.setIsPrimaryProject(true);
		List<AllocatedResourceProjection> resourceAllocExtDtlsList = new ArrayList<>();
		resourceAllocExtDtlsList.add(resourceAllocExtDtls);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		ResourceWorkflow previousApproverData = new ResourceWorkflow();
		Map<String, ModuleStatusDto> allocStatusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		moduleStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_EXTENSION);
		List<ModuleStatusDto> workflowTypeIds = new ArrayList<>();
		workflowTypeIds.add(moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.ACTIVATE, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);
		when(tAssociateExtensionRepository.getActiveAllocationExtensionDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
						.thenReturn(resourceAllocExtDtlsList);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(previousApproverData);
		when(resourceWorkflowRepository.getRecentPreviousRowData(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList())).thenReturn(null);
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(allocStatusDtlsMap);
		when(resourceManagementUtil.getListOfRequestTypes()).thenReturn(requestTypeList);
		when(adminServiceClient.getModuleDetailsList(Mockito.anyString(), Mockito.anyList()))
				.thenReturn(workflowTypeIds);
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1L);
		projectDto.setProjectName("TEST-PROJECT");
		List<ProjectDto> projectDtlsList = new ArrayList<>();
		projectDtlsList.add(projectDto);
		when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(projectDtlsList);
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("TEST-EMPLOYEE");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		employeeDtlsList.add(employeeDto);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		ResourceApprovalDashboardDto resourceDtls = resourceDashboardServiceImpl.getPendingResourceDetails(1L, 1L);
		assertNotNull(resourceDtls);
	}

	@Test
	public void getRsrcApprvlPendingStatusCheckByPassTestForAllocExt()
			throws ResourceManagementException, ParseException {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<String> requestTypeList = new ArrayList<>();
		requestTypeList.add(ResourceManagementConstant.RESOURCE_EXTENSION);
		AllocatedResourceProjection resourceAllocExtDtls = factory.createProjection(AllocatedResourceProjection.class);
		resourceAllocExtDtls.setAssociateAllocationId(123L);
		resourceAllocExtDtls.setProjectId(1L);
		resourceAllocExtDtls.setEmployeeId(123L);
		resourceAllocExtDtls.setRequirementId(1L);
		resourceAllocExtDtls.setExtEstEndDate(new Date());
		resourceAllocExtDtls.setEstEndDate(new Date());
		resourceAllocExtDtls.setIsPrimaryProject(true);
		List<AllocatedResourceProjection> resourceAllocExtDtlsList = new ArrayList<>();
		resourceAllocExtDtlsList.add(resourceAllocExtDtls);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		ResourceWorkflow currentApproverData = new ResourceWorkflow();
		currentApproverData.setNextRoleId(0L);
		currentApproverData.setNextUserId(0L);
		currentApproverData.setLastUpdatedDate(dateFormat.parse("2020-08-10"));
		Map<String, ModuleStatusDto> allocStatusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		moduleStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_EXTENSION);
		List<ModuleStatusDto> workflowTypeIds = new ArrayList<>();
		workflowTypeIds.add(moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.ACTIVATE, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);
		when(tAssociateExtensionRepository.getActiveAllocationExtensionDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
						.thenReturn(resourceAllocExtDtlsList);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(null);
		when(resourceWorkflowRepository.getRecentRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(currentApproverData);
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(allocStatusDtlsMap);
		when(resourceManagementUtil.getListOfRequestTypes()).thenReturn(requestTypeList);
		when(adminServiceClient.getModuleDetailsList(Mockito.anyString(), Mockito.anyList()))
				.thenReturn(workflowTypeIds);
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1L);
		projectDto.setProjectName("TEST-PROJECT");
		List<ProjectDto> projectDtlsList = new ArrayList<>();
		projectDtlsList.add(projectDto);
		when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(projectDtlsList);
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(123L);
		employeeDto.setEmployeeName("TEST-EMPLOYEE");
		List<EmployeeDto> employeeDtlsList = new ArrayList<>();
		employeeDtlsList.add(employeeDto);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeDtlsList);
		ResourceApprovalDashboardDto resourceDtls = resourceDashboardServiceImpl.getPendingResourceDetails(1L, 1L);
		assertNotNull(resourceDtls);
	}

	@Test
	public void getApproverStatusCheckListMapTest() throws ResourceManagementException, ParseException {
		List<String> requestTypes = new ArrayList<>();
		requestTypes.add(ResourceManagementConstant.RESOURCE_ALLOCATION);
		requestTypes.add(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		requestTypes.add(ResourceManagementConstant.RESOURCE_EXTENSION);
		Map<String, ModuleStatusDto> statusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		statusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		statusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		statusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(statusDtlsMap);
		for (String requesType : requestTypes) {
			Map<String, List<Long>> statusIdDtlsMap = resourceDashboardServiceImpl
					.getApproverStatusCheckListMap(requesType);
			assertNotNull(statusIdDtlsMap);
		}
	}

	private List<ResourceRequirementDto> getResourceRequirementDtos() {
		List<ResourceRequirementDto> resourceReqList = new ArrayList<ResourceRequirementDto>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(2);
		resourceRequirementDto.setResourceRequirementLocation("Pune");
		resourceRequirementDto.setServiceLineName("AMS");
		resourceRequirementDto.setShore("DualShpre");
		resourceRequirementDto.setBillingRateInUSD(1234.0);
		resourceRequirementDto.setRequirementRole("SoftwareEngineer");
		resourceRequirementDto.setVersion("1");
		resourceReqList.add(resourceRequirementDto);
		return resourceReqList;
	}

	private List<EmployeeDto> getEmployee() throws ParseException {
		List<EmployeeDto> empList = new ArrayList<EmployeeDto>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(51509L);
		// employeeDto.setActualAllocationDate(dateFormat.parse("2020-07-31"));
		employeeDto.setAllocationTypeId(1);
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setAvailibility(30L);
		employeeDto.setBand("B1");
		employeeDto.setBillingStatus("Test");
		employeeDto.setBillable(true);
		employeeDto.setBillingRateInUSD(1234.0);
		employeeDto.setBillingRatePerHour(234.0);
		employeeDto.setBillingStatus("Billable");
		employeeDto.setEbrReason("Billable");
		employeeDto.setEmployeeId(52330L);
		employeeDto.setEbrUtilization(20.0);
		employeeDto.setPrimaryProjectStatusId(true);
		employeeDto.setServiceLineName("Test");
		employeeDto.setPrimaryProjectStatusId(true);
		employeeDto.setBillingStatus("EBR");
		employeeDto.setEbrReason("EBR");
		employeeDto.setProjectUtilization(100);
		empList.add(employeeDto);
		return empList;

	}

	private List<ProjectDto> getProjectList() {
		List<ProjectDto> projectList = new ArrayList<ProjectDto>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(40001);
		projectDto.setProjectName("test1");
		projectList.add(projectDto);
		return projectList;
	}

	private List<AllocatedResourceProjection> getallocatedResourceProjection() {
		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(40001);
		allocatedResourceProjection.setBillableStatusId(1);
		allocatedResourceProjection.setFtePercent(30);
		allocatedResourceProjection.setsuperVisorId(52339l);
		allocatedResourceProjection.setsrfId(1l);
		allocatedResourceProjection.setebrReason(1);
		allocatedResourceProjection.setIsPrimaryProject(true);
		associateList.add(allocatedResourceProjection);

		return associateList;
	}

	@Test
	public void getRMPendingTraceabilityTest() throws ResourceManagementException {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		List<ApprovalTraceabilityProjection> projectionList = new ArrayList<ApprovalTraceabilityProjection>();
		ApprovalTraceabilityProjection projection = factory.createProjection(ApprovalTraceabilityProjection.class);
		projection.setAllocLastUpdatedDate(new Date());
		projection.setComments("A");
		projection.setCurrentRoleId(1l);
		projection.setCurrentUserId(51436l);
		projection.setEmployeeId(51509l);
		projection.setStatusId(1l);
		projection.setWkflowStatusId(13l);
		projection.setWrkflwLastUpdatedDate(new Date());

		projectionList.add(projection);

		TraceabilityDto dto = new TraceabilityDto();

		List<TraceabilityCurrentStatusDto> currentList = new ArrayList<>();
		TraceabilityCurrentStatusDto current1 = new TraceabilityCurrentStatusDto();
		current1.setAction("PENDING");
		current1.setApproverEmpId(51509l);
		current1.setApproverName("AB");
		current1.setRoleName("PM");
		current1.setEmployeeName("XY");
		currentList.add(current1);
		dto.setCurrentStatus(currentList);

		List<TraceabilityApprSummaryDto> summaryList = new ArrayList<>();
		TraceabilityApprSummaryDto summary1 = new TraceabilityApprSummaryDto();
		summary1.setAction(ResourceManagementConstant.APPROVED);
		summary1.setActionDate(new Date());
		summary1.setApproverName("AB");
		summary1.setComments("XY");
		summary1.setRoleName("PGM");
		summaryList.add(summary1);
		dto.setApprovalSummary(summaryList);

		List<RoleDto> roleList = new ArrayList<>();
		RoleDto role1 = new RoleDto();
		role1.setRoleId(1l);
		role1.setRoleName("PM");
		roleList.add(role1);
		
		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList  =new ArrayList<>();
		LookupValueAndDescDto lookupValueAndDescDto = new LookupValueAndDescDto();
		lookupValueAndDescDto.setLookupValueId(1l);
		lookupValueAndDescDto.setLookupValueDescr("PM");
		lookuIdByTypeAndDescrList.add(lookupValueAndDescDto);

		List<ResourceWorkflow> workflowList = new ArrayList<ResourceWorkflow>();
		ResourceWorkflow workflow1 = new ResourceWorkflow();
		workflow1.setResourceWrkflwId(1l);
		workflow1.setWrkflwTrnsctnId(10l);
		workflow1.setStatusId(1l);
		workflow1.setCurrentRoleId(1l);
		workflow1.setCurrentUserId(51436l);
		workflowList.add(workflow1);

		TAssociateAllocation allocation = new TAssociateAllocation();
		allocation.setAssociateAllocationId(10l);
		allocation.setWorkflowStatusId(13l);
		allocation.setLastUpdatedDate(new Date());

		TAssociateProject project = new TAssociateProject();
		project.setAssociateProjectId(1l);
		project.setEmployeeId(51509l);

		allocation.setTAssociateProject(project);

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employee1 = new EmployeeDto();
		employee1.setEmployeeId(51509l);
		employee1.setEmployeeNumber(51509l);
		employee1.setEmployeeName("XY");
		employeeList.add(employee1);

		List<ModuleStatusDto> moduleStatusList = new ArrayList<>();
		ModuleStatusDto statusdto1 = new ModuleStatusDto();
		statusdto1.setModuleId(1l);
		statusdto1.setModuleStatusId(1l);
		statusdto1.setParentModule(ResourceManagementConstant.RESOURCE_MANAGEMENT);
		statusdto1.setSubModule(ResourceManagementConstant.RESOURCE_ALLOCATION);
		statusdto1.setAction(ResourceManagementConstant.APPROVED);
		moduleStatusList.add(statusdto1);

		//when(adminServiceClient.getListOfRoles()).thenReturn(roleList);
		when(adminServiceClient.getLookuIdByTypeAndDescrList(Mockito.anyString(), Mockito.anyList())).thenReturn(lookuIdByTypeAndDescrList);
		when(adminServiceClient.getAssociatesDetailsbyEmpIds(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getModuleStatusList(Mockito.anyString(), Mockito.anyList(), Mockito.anyList()))
				.thenReturn(moduleStatusList);
		when(resourceWorkflowRepository.getAllocationTraceAbilityDetails(Mockito.anyLong())).thenReturn(projectionList);
		// when(resourceWorkflowRepository.findByWrkflwTrnsctnId(Mockito.anyLong())).thenReturn(workflowList);
		// when(tAssociateAllocationRepository.getAllocationByAllocationId(Mockito.anyLong())).thenReturn(allocation);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		resourceDashboardServiceImpl.getRMPendingTraceability(51436l, 1l, 10l,"RALLOCATION");

	}
	
	///////////////////////////////////////////////
	@Test
	public void getRMPendingTraceabilityTransferTest() throws ResourceManagementException {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		List<ApprovalTraceabilityProjection> projectionList = new ArrayList<ApprovalTraceabilityProjection>();
		ApprovalTraceabilityProjection projection = factory.createProjection(ApprovalTraceabilityProjection.class);
		projection.setAllocLastUpdatedDate(new Date());
		projection.setComments("A");
		projection.setCurrentRoleId(1l);
		projection.setCurrentUserId(51436l);
		projection.setEmployeeId(51509l);
		projection.setStatusId(1l);
		projection.setWkflowStatusId(13l);
		projection.setWrkflwLastUpdatedDate(new Date());

		projectionList.add(projection);

		TraceabilityDto dto = new TraceabilityDto();

		List<TraceabilityCurrentStatusDto> currentList = new ArrayList<>();
		TraceabilityCurrentStatusDto current1 = new TraceabilityCurrentStatusDto();
		current1.setAction("PENDING");
		current1.setApproverEmpId(51509l);
		current1.setApproverName("AB");
		current1.setRoleName("PM");
		current1.setEmployeeName("XY");
		currentList.add(current1);
		dto.setCurrentStatus(currentList);

		List<TraceabilityApprSummaryDto> summaryList = new ArrayList<>();
		TraceabilityApprSummaryDto summary1 = new TraceabilityApprSummaryDto();
		summary1.setAction(ResourceManagementConstant.APPROVED);
		summary1.setActionDate(new Date());
		summary1.setApproverName("AB");
		summary1.setComments("XY");
		summary1.setRoleName("PGM");
		summaryList.add(summary1);
		dto.setApprovalSummary(summaryList);

		List<RoleDto> roleList = new ArrayList<>();
		RoleDto role1 = new RoleDto();
		role1.setRoleId(1l);
		role1.setRoleName("PM");
		roleList.add(role1);
		
		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList  =new ArrayList<>();
		LookupValueAndDescDto lookupValueAndDescDto = new LookupValueAndDescDto();
		lookupValueAndDescDto.setLookupValueId(1l);
		lookupValueAndDescDto.setLookupValueDescr("PM");
		lookuIdByTypeAndDescrList.add(lookupValueAndDescDto);

		List<ResourceWorkflow> workflowList = new ArrayList<ResourceWorkflow>();
		ResourceWorkflow workflow1 = new ResourceWorkflow();
		workflow1.setResourceWrkflwId(1l);
		workflow1.setWrkflwTrnsctnId(10l);
		workflow1.setStatusId(1l);
		workflow1.setCurrentRoleId(1l);
		workflow1.setCurrentUserId(51436l);
		workflowList.add(workflow1);

		TAssociateAllocation allocation = new TAssociateAllocation();
		allocation.setAssociateAllocationId(10l);
		allocation.setWorkflowStatusId(13l);
		allocation.setLastUpdatedDate(new Date());

		TAssociateProject project = new TAssociateProject();
		project.setAssociateProjectId(1l);
		project.setEmployeeId(51509l);

		allocation.setTAssociateProject(project);

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employee1 = new EmployeeDto();
		employee1.setEmployeeId(51509l);
		employee1.setEmployeeNumber(51509l);
		employee1.setEmployeeName("XY");
		employeeList.add(employee1);

		List<ModuleStatusDto> moduleStatusList = new ArrayList<>();
		ModuleStatusDto statusdto1 = new ModuleStatusDto();
		statusdto1.setModuleId(1l);
		statusdto1.setModuleStatusId(1l);
		statusdto1.setParentModule(ResourceManagementConstant.RESOURCE_MANAGEMENT);
		statusdto1.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		statusdto1.setAction(ResourceManagementConstant.APPROVED);
		moduleStatusList.add(statusdto1);

		//when(adminServiceClient.getListOfRoles()).thenReturn(roleList);
		when(adminServiceClient.getLookuIdByTypeAndDescrList(Mockito.anyString(), Mockito.anyList())).thenReturn(lookuIdByTypeAndDescrList);
		when(adminServiceClient.getAssociatesDetailsbyEmpIds(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getModuleStatusList(Mockito.anyString(), Mockito.anyList(), Mockito.anyList()))
				.thenReturn(moduleStatusList);
		when(resourceWorkflowRepository.getAllocationTraceAbilityDetails(Mockito.anyLong())).thenReturn(projectionList);
		// when(resourceWorkflowRepository.findByWrkflwTrnsctnId(Mockito.anyLong())).thenReturn(workflowList);
		// when(tAssociateAllocationRepository.getAllocationByAllocationId(Mockito.anyLong())).thenReturn(allocation);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		resourceDashboardServiceImpl.getRMPendingTraceability(51436l, 1l, 10l,"RTRANSFER");

	}

	@Test
	public void getRMPendingTraceabilityDeAllocTest() throws ResourceManagementException {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		List<ApprovalTraceabilityProjection> projectionList = new ArrayList<ApprovalTraceabilityProjection>();
		ApprovalTraceabilityProjection projection = factory.createProjection(ApprovalTraceabilityProjection.class);
		projection.setAllocLastUpdatedDate(new Date());
		projection.setComments("A");
		projection.setCurrentRoleId(1l);
		projection.setCurrentUserId(51436l);
		projection.setEmployeeId(51509l);
		projection.setStatusId(1l);
		projection.setWkflowStatusId(13l);
		projection.setWrkflwLastUpdatedDate(new Date());

		projectionList.add(projection);

		TraceabilityDto dto = new TraceabilityDto();

		List<TraceabilityCurrentStatusDto> currentList = new ArrayList<>();
		TraceabilityCurrentStatusDto current1 = new TraceabilityCurrentStatusDto();
		current1.setAction("PENDING");
		current1.setApproverEmpId(51509l);
		current1.setApproverName("AB");
		current1.setRoleName("PM");
		current1.setEmployeeName("XY");
		currentList.add(current1);
		dto.setCurrentStatus(currentList);

		List<TraceabilityApprSummaryDto> summaryList = new ArrayList<>();
		TraceabilityApprSummaryDto summary1 = new TraceabilityApprSummaryDto();
		summary1.setAction(ResourceManagementConstant.APPROVED);
		summary1.setActionDate(new Date());
		summary1.setApproverName("AB");
		summary1.setComments("XY");
		summary1.setRoleName("PGM");
		summaryList.add(summary1);
		dto.setApprovalSummary(summaryList);

		List<RoleDto> roleList = new ArrayList<>();
		RoleDto role1 = new RoleDto();
		role1.setRoleId(1l);
		role1.setRoleName("PM");
		roleList.add(role1);
		
		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList  =new ArrayList<>();
		LookupValueAndDescDto lookupValueAndDescDto = new LookupValueAndDescDto();
		lookupValueAndDescDto.setLookupValueId(1l);
		lookupValueAndDescDto.setLookupValueDescr("PM");
		lookuIdByTypeAndDescrList.add(lookupValueAndDescDto);

		List<ResourceWorkflow> workflowList = new ArrayList<ResourceWorkflow>();
		ResourceWorkflow workflow1 = new ResourceWorkflow();
		workflow1.setResourceWrkflwId(1l);
		workflow1.setWrkflwTrnsctnId(10l);
		workflow1.setStatusId(1l);
		workflow1.setCurrentRoleId(1l);
		workflow1.setCurrentUserId(51436l);
		workflowList.add(workflow1);

		TAssociateAllocation allocation = new TAssociateAllocation();
		allocation.setAssociateAllocationId(10l);
		allocation.setWorkflowStatusId(13l);
		allocation.setLastUpdatedDate(new Date());

		TAssociateProject project = new TAssociateProject();
		project.setAssociateProjectId(1l);
		project.setEmployeeId(51509l);

		allocation.setTAssociateProject(project);

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employee1 = new EmployeeDto();
		employee1.setEmployeeId(51509l);
		employee1.setEmployeeNumber(51509l);
		employee1.setEmployeeName("XY");
		employeeList.add(employee1);

		List<ModuleStatusDto> moduleStatusList = new ArrayList<>();
		ModuleStatusDto statusdto1 = new ModuleStatusDto();
		statusdto1.setModuleId(1l);
		statusdto1.setModuleStatusId(1l);
		statusdto1.setParentModule(ResourceManagementConstant.RESOURCE_MANAGEMENT);
		statusdto1.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		statusdto1.setAction(ResourceManagementConstant.APPROVED);
		moduleStatusList.add(statusdto1);

		//when(adminServiceClient.getListOfRoles()).thenReturn(roleList);
		when(adminServiceClient.getLookuIdByTypeAndDescrList(Mockito.anyString(), Mockito.anyList())).thenReturn(lookuIdByTypeAndDescrList);
		when(adminServiceClient.getAssociatesDetailsbyEmpIds(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getModuleStatusList(Mockito.anyString(), Mockito.anyList(), Mockito.anyList()))
				.thenReturn(moduleStatusList);
		when(resourceWorkflowRepository.getDeAllocationTraceAbilityDetails(Mockito.anyLong())).thenReturn(projectionList);
		// when(resourceWorkflowRepository.findByWrkflwTrnsctnId(Mockito.anyLong())).thenReturn(workflowList);
		// when(tAssociateAllocationRepository.getAllocationByAllocationId(Mockito.anyLong())).thenReturn(allocation);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		resourceDashboardServiceImpl.getRMPendingTraceability(51436l, 1l, 10l,"RDEALLOCATION");

	}
	
	///////////////////////////////////////////////
	@Test
	public void getRMPendingTraceabilityCurrentStatusTest() throws ResourceManagementException {

		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		List<ApprovalTraceabilityProjection> projectionList = new ArrayList<ApprovalTraceabilityProjection>();
		ApprovalTraceabilityProjection projection = factory.createProjection(ApprovalTraceabilityProjection.class);
		projection.setAllocLastUpdatedDate(new Date());
		projection.setComments("A");
		projection.setCurrentRoleId(1l);
		projection.setCurrentUserId(51436l);
		projection.setEmployeeId(51509l);
		projection.setStatusId(1l);
		projection.setWkflowStatusId(13l);
		projection.setWrkflwLastUpdatedDate(new Date());

		projectionList.add(projection);

		TraceabilityDto dto = new TraceabilityDto();

		List<TraceabilityCurrentStatusDto> currentList = new ArrayList<>();
		TraceabilityCurrentStatusDto current1 = new TraceabilityCurrentStatusDto();
		current1.setAction("PENDING");
		current1.setApproverEmpId(51509l);
		current1.setApproverName("AB");
		current1.setRoleName("PM");
		current1.setEmployeeName("XY");
		currentList.add(current1);
		dto.setCurrentStatus(currentList);

		List<TraceabilityApprSummaryDto> summaryList = new ArrayList<>();
		TraceabilityApprSummaryDto summary1 = new TraceabilityApprSummaryDto();
		summary1.setAction(ResourceManagementConstant.APPROVED);
		summary1.setActionDate(new Date());
		summary1.setApproverName("AB");
		summary1.setComments("XY");
		summary1.setRoleName("PGM");
		summaryList.add(summary1);
		dto.setApprovalSummary(summaryList);

		List<RoleDto> roleList = new ArrayList<>();
		RoleDto role1 = new RoleDto();
		role1.setRoleId(1l);
		role1.setRoleName("PM");
		roleList.add(role1);
		
		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList  =new ArrayList<>();
		LookupValueAndDescDto lookupValueAndDescDto = new LookupValueAndDescDto();
		lookupValueAndDescDto.setLookupValueId(1l);
		lookupValueAndDescDto.setLookupValueDescr("PM");
		lookuIdByTypeAndDescrList.add(lookupValueAndDescDto);

		List<ResourceWorkflow> workflowList = new ArrayList<ResourceWorkflow>();
		ResourceWorkflow workflow1 = new ResourceWorkflow();
		workflow1.setResourceWrkflwId(1l);
		workflow1.setWrkflwTrnsctnId(10l);
		workflow1.setStatusId(1l);
		workflow1.setCurrentRoleId(1l);
		workflow1.setCurrentUserId(51436l);
		workflowList.add(workflow1);

		TAssociateAllocation allocation = new TAssociateAllocation();
		allocation.setAssociateAllocationId(10l);
		allocation.setWorkflowStatusId(13l);
		allocation.setLastUpdatedDate(new Date());

		TAssociateProject project = new TAssociateProject();
		project.setAssociateProjectId(1l);
		project.setEmployeeId(51509l);

		allocation.setTAssociateProject(project);

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employee1 = new EmployeeDto();
		employee1.setEmployeeId(51509l);
		employee1.setEmployeeNumber(51509l);
		employee1.setEmployeeName("XY");
		employeeList.add(employee1);

		List<ModuleStatusDto> moduleStatusList = new ArrayList<>();
		ModuleStatusDto statusdto1 = new ModuleStatusDto();
		statusdto1.setModuleId(1l);
		statusdto1.setModuleStatusId(1l);
		statusdto1.setParentModule(ResourceManagementConstant.RESOURCE_MANAGEMENT);
		statusdto1.setSubModule(ResourceManagementConstant.RESOURCE_ALLOCATION);
		statusdto1.setAction(ResourceManagementConstant.SUBMITTED);
		moduleStatusList.add(statusdto1);

		when(adminServiceClient.getLookuIdByTypeAndDescrList(Mockito.anyString(), Mockito.anyList())).thenReturn(lookuIdByTypeAndDescrList);
		when(adminServiceClient.getAssociatesDetailsbyEmpIds(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getModuleStatusList(Mockito.anyString(), Mockito.anyList(), Mockito.anyList()))
				.thenReturn(moduleStatusList);
		when(resourceWorkflowRepository.getAllocationTraceAbilityDetails(Mockito.anyLong())).thenReturn(projectionList);

		// when(resourceWorkflowRepository.findByWrkflwTrnsctnId(Mockito.anyLong())).thenReturn(workflowList);
		// when(tAssociateAllocationRepository.getAllocationByAllocationId(Mockito.anyLong())).thenReturn(allocation);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		resourceDashboardServiceImpl.getRMPendingTraceability(51436l, 1l, 10l,"RALLOCATION");

	}

	@Test
	public void getResourcesPendingForSubmission() throws ResourceManagementException {
		List<String> requestTypeList = Arrays.asList(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE);
		ResourceApprovalDashboardDto approvalPendingResourceDtls = new ResourceApprovalDashboardDto();
		List<TAssociateAllocation> tAssociateAllocation = new ArrayList<>();

		when(tAssociateAllocationRepository.getListOfRMPendingTransferSubmission(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(tAssociateAllocation);
		resourceDashboardServiceImpl.getResourcesPendingForSubmission(51436l, 1l, requestTypeList, getModuleList());
	}

	@Test
	public void getResourcesPendingForSubmissionDeallocation() throws ResourceManagementException {

		Map<String, ModuleStatusDto> allocStatusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		moduleStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_ALLOCATION);
		List<ModuleStatusDto> workflowTypeIds = new ArrayList<>();
		workflowTypeIds.add(moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.ACTIVATE, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);
		EmployeeDto employee1 = new EmployeeDto();
		employee1.setEmployeeId(51509l);
		employee1.setEmployeeName("XY");
		employee1.setEmployeeNumber(52330l);
		List<Long> pendingForSubmissionList = new ArrayList<Long>();
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(allocStatusDtlsMap);
		when(tAssociateDeAllocationRepository.getDeallocationPendingForSubmissionData(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
						.thenReturn(getallocatedResourceProjection());
		when(adminServiceClient.getEmployeeDetailsByEmpId(Mockito.anyLong())).thenReturn(employee1);

		List<EmployeeDto> empList = resourceDashboardServiceImpl.getpendingForDeallocationSubmission(52330l,
				getModuleList());
		assertNotNull(empList);
	}

	@Test
	public void getResourcesPendingForApprovalTestForDeAllocpass() throws ResourceManagementException, ParseException {
		List<String> requestTypeList = new ArrayList<>();
		requestTypeList.add(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		List<Long> transList = new ArrayList<>();
		transList.add(123L);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		ResourceWorkflow previousApproverData = new ResourceWorkflow();
		ResourceWorkflow previousApproverStatus = new ResourceWorkflow();
		previousApproverStatus.setLastUpdatedDate(dateFormat.parse("2020-08-12"));
		ResourceWorkflow currentApproverData = new ResourceWorkflow();
		currentApproverData.setNextRoleId(1L);
		currentApproverData.setNextUserId(123L);
		currentApproverData.setLastUpdatedDate(dateFormat.parse("2020-08-10"));
		ResourceWorkflow nextApproverStatus = new ResourceWorkflow();
		nextApproverStatus.setLastUpdatedDate(dateFormat.parse("2020-08-11"));
		Map<String, ModuleStatusDto> allocStatusDtlsMap = new HashMap<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		moduleStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		List<ModuleStatusDto> workflowTypeIds = new ArrayList<>();
		workflowTypeIds.add(moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.ACTIVATE, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.SUBMITTED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.APPROVED, moduleStatusDto);
		allocStatusDtlsMap.put(ResourceManagementConstant.REJECTED, moduleStatusDto);

		EmployeeDto employeeDetails = new EmployeeDto();
		employeeDetails.setEmployeeNumber(123l);
		employeeDetails.setEmployeeName("abc");
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(null);
		when(resourceWorkflowRepository.getRecentRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(currentApproverData);
		when(resourceManagementServiceImpl.getModuleStatusDtlsMap(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(allocStatusDtlsMap);
		when(adminServiceClient.getModuleDetailsList(Mockito.anyString(), Mockito.anyList()))
				.thenReturn(workflowTypeIds);
		when(resourceManagementUtil.getListOfRequestTypes()).thenReturn(requestTypeList);
		when(tAssociateDeAllocationRepository.getDeallocationpendingForApprovalRecords(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
						.thenReturn(transList);
		when(tAssociateDeAllocationRepository.getDeallocationPendingForSubmissionRecords(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(transList);
		when(tAssociateAllocationRepository.getAssociatesByAllocationId(Mockito.anyList()))
				.thenReturn(getallocatedResourceProjection());
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(getResourceRequirementDtos());
		when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(getProjectList());
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(getEmployee());
		when(adminServiceClient.getEmployeeDetailsByEmpId(Mockito.anyLong())).thenReturn(employeeDetails);
		ResourceApprovalDashboardDto resourceDtls = resourceDashboardServiceImpl.getPendingResourceDetails(1L, 1L);
		assertNotNull(resourceDtls);
	}

	public HashBasedTable<String, String, Long> getModuleList() {

		List<ModuleStatusDto> moduleList = new ArrayList<>();
		ModuleStatusDto moduleStatusDtoAllocation = new ModuleStatusDto();
		moduleStatusDtoAllocation.setModuleId(1l);
		moduleStatusDtoAllocation.setModuleStatusId(1l);
		moduleStatusDtoAllocation.setModuleCode("RM");
		moduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setAction("APPROVED");
		moduleList.add(moduleStatusDtoAllocation);
		ModuleStatusDto newmoduleStatus2DtoAllocation = new ModuleStatusDto();
		newmoduleStatus2DtoAllocation.setModuleId(2l);
		newmoduleStatus2DtoAllocation.setModuleStatusId(2l);
		newmoduleStatus2DtoAllocation.setModuleCode("RM");
		newmoduleStatus2DtoAllocation.setSubModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setParentModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setAction("DEACTIVE");
		moduleList.add(newmoduleStatus2DtoAllocation);
		ModuleStatusDto newmoduleStatusDtoAllocation = new ModuleStatusDto();

		newmoduleStatusDtoAllocation.setModuleId(2l);
		newmoduleStatusDtoAllocation.setModuleStatusId(1l);
		newmoduleStatusDtoAllocation.setModuleCode("RM");
		newmoduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setAction("ACTIVATE");
		moduleList.add(newmoduleStatusDtoAllocation);

		ModuleStatusDto moduleStatusDtoTransfer = new ModuleStatusDto();
		moduleStatusDtoTransfer.setModuleId(1l);
		moduleStatusDtoTransfer.setModuleStatusId(1l);
		moduleStatusDtoTransfer.setModuleCode("RM");
		moduleStatusDtoTransfer.setSubModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setAction("APPROVED");
		moduleList.add(moduleStatusDtoTransfer);

		ModuleStatusDto moduleStatusDtoDeallocationSved = new ModuleStatusDto();
		moduleStatusDtoDeallocationSved.setModuleId(1l);
		moduleStatusDtoDeallocationSved.setModuleStatusId(1l);

		moduleStatusDtoDeallocationSved.setModuleCode("RM");
		moduleStatusDtoDeallocationSved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSved.setAction(ResourceManagementConstant.SAVED);
		moduleList.add(moduleStatusDtoDeallocationSved);
		ModuleStatusDto moduleStatusDtoDeallocationSubmitted = new ModuleStatusDto();
		moduleStatusDtoDeallocationSubmitted.setModuleId(1l);
		moduleStatusDtoDeallocationSubmitted.setModuleStatusId(1l);
		moduleStatusDtoDeallocationSubmitted.setModuleCode("RM");
		moduleStatusDtoDeallocationSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSubmitted.setAction(ResourceManagementConstant.SUBMITTED);
		moduleList.add(moduleStatusDtoDeallocationSubmitted);
		ModuleStatusDto moduleStatusDtoDeallocationApproved = new ModuleStatusDto();
		moduleStatusDtoDeallocationApproved.setModuleId(1l);
		moduleStatusDtoDeallocationApproved.setModuleCode("RM");
		moduleStatusDtoDeallocationApproved.setModuleStatusId(1l);
		moduleStatusDtoDeallocationApproved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationApproved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationApproved.setAction(ResourceManagementConstant.APPROVED);
		moduleList.add(moduleStatusDtoDeallocationApproved);

		ModuleStatusDto moduleStatusDtoTansferSved = new ModuleStatusDto();
		moduleStatusDtoTansferSved.setModuleId(1l);
		moduleStatusDtoTansferSved.setModuleStatusId(1l);
		moduleStatusDtoTansferSved.setModuleCode("RM");
		moduleStatusDtoTansferSved.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTansferSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTansferSved.setAction(ResourceManagementConstant.SAVED);
		moduleList.add(moduleStatusDtoTansferSved);
		ModuleStatusDto moduleStatusDtoTransferSubmitted = new ModuleStatusDto();
		moduleStatusDtoTransferSubmitted.setModuleId(1l);
		moduleStatusDtoTransferSubmitted.setModuleStatusId(1l);
		moduleStatusDtoTransferSubmitted.setModuleCode("RM");
		moduleStatusDtoTransferSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTransferSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransferSubmitted.setAction(ResourceManagementConstant.SUBMITTED);
		moduleList.add(moduleStatusDtoTansferSved);
		ModuleStatusDto moduleStatusDtoExtension = new ModuleStatusDto();
		moduleStatusDtoExtension.setModuleId(1l);
		moduleStatusDtoExtension.setModuleStatusId(1l);
		moduleStatusDtoExtension.setModuleCode("RM");
		moduleStatusDtoExtension.setSubModule("RESOURCE_EXTENSION");
		moduleStatusDtoExtension.setParentModule("RESOURCE_EXTENSION");
		moduleStatusDtoExtension.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoExtension);

		moduleList.add(moduleStatusDtoTransferSubmitted);

		HashBasedTable<String, String, Long> table = HashBasedTable.create();
		for (ModuleStatusDto temp : moduleList) {
			table.put(temp.getSubModule(), temp.getAction(), temp.getModuleStatusId());
		}
		return table;
	}

}
