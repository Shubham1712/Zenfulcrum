package com.zensar.zenfulcrum.resourcemanagement.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDtlsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceProjectDetailsServiceTest {
	
	
	@InjectMocks
	ResourceProjectDetailsServiceImpl service;
	
 
	
	@Mock
	private AdminServiceClient adminClient;
	
	@Mock
	private BAPServiceClient bapServiceClient;
	
	@Mock
	TAssociateProjectRepository tAssociateProjectRepository;
	
	@Mock
	BudgetControlServiceClient budgetControlServiceClient;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);

	}
	
	@Test
	public void  getProjectIdsByUserId(){
		List<ProjectDto> projectIdsList= new ArrayList<ProjectDto>();
		List<Long> projectList= new ArrayList<Long>();
		projectList.add(1L);
		ProjectDto ProjectDto= new ProjectDto();
		ProjectDto.setStatusId(1L);
		when(tAssociateProjectRepository.getProjectIds(Mockito.anyLong())).thenReturn(projectList);
		List<ProjectDto> projectIdsList1=service.getProjectIdsByUserId(1L);
		assertNotNull(projectIdsList1);
	}
	
	
	@Test
	public void getAllocatedResources() {
		
		ProjectDtlsDto projectDto= new ProjectDtlsDto();
		when(tAssociateProjectRepository.getAllocatedResource(Mockito.anyLong())).thenReturn(1L);
		projectDto=service.getAllocatedResources(1L);
		assertNotNull(projectDto);
	}
	
	 @Test
	 public void getProjectMonthlyBudgetsDetails() throws ResourceManagementException {
		 
		 List<ProjectBudgetDto> dtoList= new ArrayList<ProjectBudgetDto>();
		 ProjectBudgetDto dto= new ProjectBudgetDto();
		 dto.setMonth("Test");
		 when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(dtoList);
		 List<ProjectBudgetDto> res=service.getProjectMonthlyBudgetsDetails(1L);
		 assertNotNull(res);
	 }
}
