package com.zensar.zenfulcrum.resourcemanagement.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.projection.ProjectionFactory;
import org.springframework.data.projection.SpelAwareProxyProjectionFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.HashBasedTable;
import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateSearchDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeSkillDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LeaveDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueAndDescDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PracticeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PracticeProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PractiseDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApproversDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTResourceDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceSearchDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RoleDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SuperVisiorDetailsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SupervisorDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.AllocatedResourceHelperClass;
import com.zensar.zenfulcrum.resourcemanagement.helper.JVCheckHelperService;
import com.zensar.zenfulcrum.resourcemanagement.helper.SendMailHelperService;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateAllocationMapper;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateProjectMapper;
import com.zensar.zenfulcrum.resourcemanagement.model.ResourceWorkflow;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateExtension;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateProject;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateSkill;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AvaibalityProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.SrfProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.JVDetailsRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceWorkflowRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateExtensionRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateSkillRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TSrfRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceExtensionUtils;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.SendMailUtil;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceSearchServiceTest {

	@InjectMocks
	private ResourceSearchServiceImpl resourceSearchServiceImpl;

	@Mock
	AdminServiceClient adminServiceClient;

	@Mock
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Mock
	private TAssociateAllocationMapper tAssociateAllocationMapper;

	@Mock
	private ResourceManagementServiceImpl resourceManagementServiceImpl;

	@Mock
	private BAPServiceClient bapServiceClient;

	@Mock
	private TSrfRepository tsrfRepository;

	@Mock
	private TAssociateProjectRepository tAssociateProjectRepository;

	@Mock
	private TSrfRepository tSrfRepository;
	
	@Mock
	private AllocatedResourceHelperClass allocatedHelperClass;

	@Mock
	private BudgetControlServiceClient budgetControlServiceClient;
	@Mock
	private TAssociateProjectMapper tAssociateProjectMapper;
	@Mock
	private TAssociateSkillRepository tAssociateSkillRepository;

	@Mock
	private ResourceAllocationServiceImpl resourceAllocationServiceImpl;
	@Mock
	private BAPServiceClient bapSrvcClient;

	@Mock
	private TAssociateExtensionRepository tAssociateExtensionRepository;

	@Mock
	private TAssociateDeAllocationRepository tAssociateDeAllocationRepository;
	@Mock
	private ResourceWorkflowRepository resourceWorkflowRepository;

	@Mock
	private SendMailUtil sendMailUtil;
	@Mock
	private SendMailHelperService sendMailHelperServiceObj;
	@Mock
	private JVDetailsRepository jvDetailsRepository;
	@Mock
	JVCheckHelperService jvCheckHelperService;
	
	@Mock
	private ResourceExtensionUtils resourceExtensionUtils;
	
	@Mock
	private ResourceRequirementServiceImpl  resourceRequirementServiceImpl;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	@Test
	public void getAssociateListByProjectIdTest() throws ResourceManagementException, ParseException {

		ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(51509L);
		employeeDto.setActualAllocationDate(dateFormat.parse("2020-07-31"));
		employeeDto.setEstimatedEndDate(dateFormat.parse("2020-07-31"));
		employeeDto.setBillingStatus("Test");
		employeeDto.setPrimaryProjectStatusId(true);
		employeeDto.setServiceLineName("Test");
		employeeDto.setPrimaryProjectStatusId(true);
		employeeDto.setBillingStatus("EBR");
		employeeDto.setEbrReason("EBR");
		employeeDto.setProjectUtilization(100);
		employeeList.add(employeeDto);
		resourceSearchDto.setEmployeeList(employeeList);
		List<TAssociateAllocation> tAssociateAllocationList = new ArrayList<>();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		tAssociateAllocation.setRequirementId(1L);
		TAssociateProject tAssociateProject = new TAssociateProject();
		tAssociateProject.setIsPrimaryProject(1L);
		tAssociateProject.setEmployeeId(52330L);
		tAssociateAllocation.setTAssociateProject(tAssociateProject);
		tAssociateAllocation.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		tAssociateAllocation.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		tAssociateAllocation.setBillableStatusId(1L);
		tAssociateAllocation.setBillableStatusReasonId(1L);
		tAssociateAllocation.setFtePercent(100D);
		tAssociateAllocation.setActualAllocationStartDate(dateFormat.parse("2020-07-31"));

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(1L);
		resourceRequirementDto.setServiceLineName("Test");

		tAssociateAllocationList.add(tAssociateAllocation);
		LookupValueDto lookupValueDto = new LookupValueDto();
		lookupValueDto.setLookUpId(1L);
		lookupValueDto.setLookupType("EBR");
		lookupValueDto.setLookupValueCode("EBR");
		
		List<Long> empNumberList = new ArrayList<Long>();
		empNumberList.add(52330L);

		/*
		 * List<LookupValueDto> lookupValueList = new ArrayList<>(); LookupValueDto
		 * lookupValueDto1 = new LookupValueDto(); lookupValueDto1.setLookUpId(1l);
		 * lookupValueDto1.setLookupType("BY_SEARCH");
		 * lookupValueDto1.setLookupValueCode("BY_PROJECT");
		 * 
		 * lookupValueList.add(lookupValueDto1);
		 * 
		 * when(adminServiceClient.getLookupValueByLookupType(Mockito.anyString())).
		 * thenReturn(lookupValueList);
		 */

		when(adminServiceClient.getEmployeeDetails(Mockito.anyLong())).thenReturn(employeeDto);
		when(adminServiceClient.getLookUpById(Mockito.anyLong())).thenReturn(lookupValueDto);
		when(tAssociateAllocationRepository.getEmpNumbers(Mockito.anyList())).thenReturn(empNumberList);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(getEmployeeList());
		when(bapServiceClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateAllocationRepository.getAssociateListByProjectId(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(tAssociateAllocationList);
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Mockito.anyLong());
		resourceSearchServiceImpl.getResourceDetails("BY_PROJECT", Mockito.anyLong(),54168L,457L);
		// resourceSearchServiceImpl.getAssociateListByProjectId(Mockito.anyLong());
		verify(tAssociateAllocationRepository, times(1)).getAssociateListByProjectId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong());

	}
	
	@Test
	public void getResourceDtlsListByPracticeName() throws ResourceManagementException {

		ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(51509L);
		employeeList.add(employeeDto);
		resourceSearchDto.setEmployeeList(employeeList);
		LookupValueDto lookupValueDto = new LookupValueDto();
		lookupValueDto.setLookUpId(1L);
		lookupValueDto.setLookupType("Billable");
		lookupValueDto.setLookupValueCode("Billable");

		PracticeProjectDto practiceProjectDto = new PracticeProjectDto();
		practiceProjectDto.setPracticeId(1);
		practiceProjectDto.setPracticeProjectId(100001);
		practiceProjectDto.setPracticeProjectName("AMS");
		practiceProjectDto.setProjectId(10001);
		PractiseDetailsDto practiseDetailsDto = new PractiseDetailsDto();
		practiseDetailsDto.setEmpId(52300);

		List<LookupValueDto> lookupValueList = new ArrayList<>();
		LookupValueDto lookupValueDto1 = new LookupValueDto();
		lookupValueDto1.setLookUpId(1l);
		lookupValueDto1.setLookupType("BY_SEARCH");
		lookupValueDto1.setLookupValueCode("BY_PRACTICE");

		lookupValueList.add(lookupValueDto1);

		when(adminServiceClient.getLookupValueByLookupType(Mockito.anyString())).thenReturn(lookupValueList);

		when(adminServiceClient.getResourceDtlsListByPractice(Mockito.anyLong())).thenReturn(employeeList);
		when(adminServiceClient.getLookupValue(Mockito.anyString(), Mockito.anyString())).thenReturn(lookupValueDto);
		when(adminServiceClient.getPracticeProject(Mockito.anyLong())).thenReturn(practiceProjectDto);
		when(adminServiceClient.getResourcePracticeAllocByEmpId(Mockito.anyLong())).thenReturn(practiseDetailsDto);

		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Mockito.anyLong());
		resourceSearchServiceImpl.getResourceDetails("BY_PRACTICE", Mockito.anyLong(),54168L,457L);
		// resourceSearchServiceImpl.getResourceDtlsListByPractice(Mockito.anyLong());
		verify(adminServiceClient, times(1)).getResourceDtlsListByPractice(Mockito.anyLong());

	}

	@Test
	public void getListOfSkillsTest() throws ResourceManagementException {
		List<SkillDto> skillDto = new ArrayList<>();
		SkillDto dto1 = new SkillDto();
		dto1.setSkillId(1l);
		dto1.setSkillName("Java");
		SkillDto dto2 = new SkillDto();
		dto2.setSkillId(2l);
		dto2.setSkillName("Net");
		skillDto.add(dto1);
		skillDto.add(dto2);
		when(adminServiceClient.getListOfSkills()).thenReturn(skillDto);
		resourceSearchServiceImpl.getListOfSkills();
		verify(adminServiceClient, times(1)).getListOfSkills();
	}

	@Test
	public void getListOfRoleTest() throws ResourceManagementException {
		List<RoleDto> roleDto = new ArrayList<>();
		RoleDto roleDto1 = new RoleDto();
		roleDto1.setRoleId(1l);
		roleDto1.setRoleName("xyz");
		RoleDto roleDto2 = new RoleDto();
		roleDto2.setRoleId(2l);
		roleDto2.setRoleName("Net");
		roleDto.add(roleDto1);
		roleDto.add(roleDto2);
		when(adminServiceClient.getListOfRoles()).thenReturn(roleDto);
		resourceSearchServiceImpl.getRoleList();
		verify(adminServiceClient, times(1)).getListOfRoles();
	}

	/*
	 * @Test public void getResourceDtlsListBySkillTest() throws
	 * ResourceManagementException { ResourceSearchDto resourceSearchDto = new
	 * ResourceSearchDto(); resourceSearchDto.setTotalBillableResource(11l);
	 * resourceSearchDto.setTotalEBRResource(10l);
	 * resourceSearchDto.setTotalNonBillableResource(5l);
	 * resourceSearchDto.setTotalResourceAllocated(15l);
	 * resourceSearchDto.setTotalPoolResources(10l); List<EmployeeDto>
	 * employeeDtoList = new ArrayList<>(); EmployeeDto employeeDto = new
	 * EmployeeDto(); employeeDto.setEmployeeId(52330L);
	 * employeeDtoList.add(employeeDto);
	 * resourceSearchDto.setEmployeeList(employeeDtoList);
	 * 
	 * LookupValueDto valuedto1 = new LookupValueDto(); valuedto1.setLookUpId(1l);
	 * valuedto1.setLookupType("BILLABLE");
	 * valuedto1.setLookupValueCode("BILLABLE");
	 * 
	 * LookupValueDto valuedto2 = new LookupValueDto(); valuedto2.setLookUpId(2l);
	 * valuedto2.setLookupType("NON_BILLABLE");
	 * valuedto2.setLookupValueCode("NON_BILLABLE");
	 * 
	 * LookupValueDto valuedto3 = new LookupValueDto(); valuedto3.setLookUpId(3l);
	 * valuedto3.setLookupType("EBR"); valuedto3.setLookupValueCode("EBR");
	 * 
	 * List<SkillDto> skillDto = new ArrayList<>(); SkillDto dto1 = new SkillDto();
	 * dto1.setSkillId(1l); dto1.setSkillName("Java"); SkillDto dto2 = new
	 * SkillDto(); dto2.setSkillId(2l); dto2.setSkillName("Net");
	 * skillDto.add(dto1); skillDto.add(dto2);
	 * 
	 * List<TAssociateAllocation> allocationList = new ArrayList<>();
	 * TAssociateAllocation allocation = new TAssociateAllocation();
	 * allocation.setBillableStatusId(1l); allocation.setFtePercent(100l);
	 * TAssociateProject assocaiteProject = new TAssociateProject();
	 * assocaiteProject.setEmployeeId(52330L);
	 * assocaiteProject.setAssociateProjectId(1l);
	 * allocation.setTAssociateProject(assocaiteProject);
	 * 
	 * TAssociateAllocation allocation1 = new TAssociateAllocation();
	 * allocation1.setBillableStatusId(2l); allocation1.setFtePercent(50l);
	 * TAssociateProject assocaiteProject1 = new TAssociateProject();
	 * assocaiteProject1.setEmployeeId(52330L);
	 * assocaiteProject1.setAssociateProjectId(1l);
	 * allocation1.setTAssociateProject(assocaiteProject1);
	 * 
	 * TAssociateAllocation allocation2 = new TAssociateAllocation();
	 * allocation2.setBillableStatusId(3l); allocation2.setFtePercent(50l);
	 * TAssociateProject assocaiteProject2 = new TAssociateProject();
	 * assocaiteProject2.setEmployeeId(52330L);
	 * assocaiteProject2.setAssociateProjectId(1l);
	 * allocation2.setTAssociateProject(assocaiteProject2);
	 * 
	 * allocationList.add(allocation); allocationList.add(allocation1);
	 * allocationList.add(allocation2);
	 * 
	 * List<TAssociateSkill> tAssociateSkillList = new ArrayList<>();
	 * TAssociateSkill associateSkill = new TAssociateSkill();
	 * associateSkill.setAssociateSkillId(1l);
	 * associateSkill.setAssociateId(51436l);
	 * associateSkill.setSkillCompetancyId(584l); associateSkill.setSkillId(1l);
	 * tAssociateSkillList.add(associateSkill);
	 * 
	 * PracticeProjectDto ppd = new PracticeProjectDto(); ppd.setPracticeId(1);
	 * ppd.setPracticeProjectId(1234); ppd.setPracticeProjectName("P1");
	 * ppd.setProjectId(12345);
	 * 
	 * PractiseDetailsDto pdd = new PractiseDetailsDto(); pdd.setPractiseId(1);
	 * pdd.setEmpId(51436); pdd.setPracticeAllocationStartDate(new Date());
	 * pdd.setPracticeAllocationEndDate(new Date());
	 * 
	 * List<LookupValueDto> lookupValueList = new ArrayList<>(); LookupValueDto
	 * lookupValueDto1 = new LookupValueDto(); lookupValueDto1.setLookUpId(1l);
	 * lookupValueDto1.setLookupType("BY_SEARCH");
	 * lookupValueDto1.setLookupValueCode("BY_SKILL"); LookupValueDto
	 * lookupValueDto2 = new LookupValueDto(); lookupValueDto2.setLookUpId(584l);
	 * lookupValueDto2.setLookupType("SKILL_COMPETANCY");
	 * lookupValueDto2.setLookupValueDescription("Primanry");
	 * //lookupValueList.add(lookupValueDto1); lookupValueList.add(lookupValueDto2);
	 * 
	 * List<LookupValueAndDescDto> lookuIdByTypeAndDescrList = new ArrayList<>();
	 * LookupValueAndDescDto lookupValueAndDescDto1 = new LookupValueAndDescDto();
	 * lookupValueAndDescDto1.setLookupValueId(1l);
	 * lookupValueAndDescDto1.setLookupValueDescr("Billable"); LookupValueAndDescDto
	 * lookupValueAndDescDto2 = new LookupValueAndDescDto();
	 * lookupValueAndDescDto2.setLookupValueId(2l);
	 * lookupValueAndDescDto2.setLookupValueDescr("Non Billable");
	 * LookupValueAndDescDto lookupValueAndDescDto3 = new LookupValueAndDescDto();
	 * lookupValueAndDescDto3.setLookupValueId(3l);
	 * lookupValueAndDescDto3.setLookupValueDescr("EBR");
	 * lookuIdByTypeAndDescrList.add(lookupValueAndDescDto1);
	 * lookuIdByTypeAndDescrList.add(lookupValueAndDescDto2);
	 * lookuIdByTypeAndDescrList.add(lookupValueAndDescDto3);
	 * 
	 * when(adminServiceClient.getLookupValueByLookupType(Mockito.anyString())).
	 * thenReturn(lookupValueList);
	 * 
	 * when(adminServiceClient.getLookupValue(Mockito.anyString(),
	 * Mockito.anyString())).thenReturn(valuedto1);
	 * when(adminServiceClient.getLookupValue(Mockito.anyString(),
	 * Mockito.anyString())).thenReturn(valuedto2);
	 * when(adminServiceClient.getLookupValue(Mockito.anyString(),
	 * Mockito.anyString())).thenReturn(valuedto3);
	 * when(adminServiceClient.getLookuIdByTypeAndDescrList(Mockito.anyString(),
	 * Mockito.anyList())).thenReturn(lookuIdByTypeAndDescrList); //
	 * when(adminServiceClient.getListOfSkills()).thenReturn(skillDto);
	 * when(tAssociateSkillRepository.findBySkillId(Mockito.anyLong(),Mockito.
	 * anyLong())).thenReturn(tAssociateSkillList);
	 * when(adminServiceClient.getAssociatesDetailsbyEmpIds(Mockito.anyList())).
	 * thenReturn(employeeDtoList); //
	 * when(adminServiceClient.getResourceDtlsListBySkill(Mockito.anyLong())).
	 * thenReturn(employeeDtoList); when(tAssociateAllocationRepository.
	 * getAssociateAllocationByWorkflowStatusAndStatusId(Mockito.anyLong(),
	 * Mockito.anyLong(), Mockito.anyList())).thenReturn(allocationList);
	 * when(adminServiceClient.getPracticeProject(Mockito.anyLong())).thenReturn(ppd
	 * );
	 * when(adminServiceClient.getResourcePracticeAllocByEmpId(Mockito.anyLong())).
	 * thenReturn(pdd); resourceSearchServiceImpl.getResourceDetails("BY_SKILL",
	 * 1l); // resourceSearchServiceImpl.getResourceDtlsListBySkill(1l); }
	 */
	@Test
	public void getPracticeListTest() throws ResourceManagementException {
		List<PracticeDto> practiceList = new ArrayList<>();
		when(adminServiceClient.getListOfPractice()).thenReturn(practiceList);
		resourceSearchServiceImpl.getPracticeList();
		verify(adminServiceClient, times(1)).getListOfPractice();

	}

	private AssociateSearchDto getAssociateDto() throws ParseException {
		AssociateSearchDto associateSearchDto = new AssociateSearchDto();
		associateSearchDto.setAllocationApproved(getEmployeeList());
		associateSearchDto.setAssociateProjectDetails(getEmployeeList());
		associateSearchDto.setAssociateTravelAllocationDetails(getEmployeeList());
		associateSearchDto.setDeallocationApproved(getEmployeeList());
		associateSearchDto.setReservedForAllocation(getEmployeeList());
		associateSearchDto.setReservedForDeallocation(getEmployeeList());
		return associateSearchDto;
	}

	private EmployeeDto getEmployee() throws ParseException {

		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(51509L);
		employeeDto.setEmployeeNumber(51509L);
		employeeDto.setActualAllocationDate(dateFormat.parse("2020-07-31"));
		employeeDto.setAllocationTypeId(1);
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setAvailibility(30L);
		employeeDto.setBand("B1");
		employeeDto.setBillingStatus("Test");
		employeeDto.setBillable(true);
		employeeDto.setBillingRateInUSD(1234.0);
		employeeDto.setBillingRatePerHour(234.0);
		employeeDto.setBillingStatus("Billable");
		employeeDto.setEbrReason("Billable");
		employeeDto.setEmployeeId(52330L);
		employeeDto.setEstimatedEndDate(dateFormat.parse("2020-07-31"));
		employeeDto.setEbrUtilization(20.0);
		employeeDto.setPrimaryProjectStatusId(true);
		employeeDto.setServiceLineName("Test");
		employeeDto.setPrimaryProjectStatusId(true);
		employeeDto.setBillingStatus("EBR");
		employeeDto.setEbrReason("EBR");
		employeeDto.setProjectUtilization(100);
		return employeeDto;

	}

	private List<AllocatedResourceProjection> getallocatedResourceProjection() {
		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(40001);
		allocatedResourceProjection.setBillableStatusId(1);
		allocatedResourceProjection.setFtePercent(30);
		allocatedResourceProjection.setsuperVisorId(52339l);
		allocatedResourceProjection.setsrfId(1l);
		allocatedResourceProjection.setebrReason(1);
		associateList.add(allocatedResourceProjection);

		return associateList;
	}

	private List<AllocatedResourceProjection> getallocatedResourceProjectionNull() {
		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(40001);
		allocatedResourceProjection.setBillableStatusId(null);
		allocatedResourceProjection.setFtePercent(30);
		allocatedResourceProjection.setsuperVisorId(52339l);
		allocatedResourceProjection.setsrfId(null);
		allocatedResourceProjection.setdefaultSkillId(1l);
		allocatedResourceProjection.setebrReason(null);
		associateList.add(allocatedResourceProjection);

		return associateList;
	}

	private List<ResourceRequirementDto> getResourceRequirementDtos() {
		List<ResourceRequirementDto> resourceReqList = new ArrayList<ResourceRequirementDto>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(2);
		resourceRequirementDto.setResourceRequirementLocation("Pune");
		resourceRequirementDto.setServiceLineName("AMS");
		resourceRequirementDto.setShore("DualShpre");
		resourceRequirementDto.setBillingRateInUSD(1234.0);
		resourceRequirementDto.setRequirementRole("SoftwareEngineer");
		resourceRequirementDto.setVersion("1");
		resourceReqList.add(resourceRequirementDto);
		return resourceReqList;
	}

	private List<EmployeeDto> getEmployeeList() throws ParseException {
		List<EmployeeDto> employeeList = new ArrayList<>();
		employeeList.add(getEmployee());
		return employeeList;

	}

	private LeaveDetailsDto getLeaveDeatils() {
		LeaveDetailsDto leaveDetailsDto = new LeaveDetailsDto();
		leaveDetailsDto.setEmployeeId(52330l);
		leaveDetailsDto.setLeaveId(1l);
		leaveDetailsDto.setStatus("Approved");
		return leaveDetailsDto;
	}

	private List<SrfProjection> getSrfProjections() {
		List<SrfProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		SrfProjection getSrfProjection1 = factory.createProjection(SrfProjection.class);
		getSrfProjection1.setSrfId(1);
		getSrfProjection1.setSrfNumber(2346l);
		getSrfProjection1.setCandidateId(52330l);

		/*
		 * SrfProjection getSrfProjection2 =
		 * factory.createProjection(SrfProjection.class);
		 * getSrfProjection2.setSrfId(1l); getSrfProjection2.setSrfNumber(2348l);
		 * getSrfProjection2.setCandidateId(52330l);
		 */

		srfProjectionList.add(getSrfProjection1);
		// srfProjectionList.add(getSrfProjection2);
		return srfProjectionList;
	}

	private List<SuperVisiorDetailsDto> getSupervisiorList() {
		List<SuperVisiorDetailsDto> superVisiorDetailsList = new ArrayList<SuperVisiorDetailsDto>();
		SuperVisiorDetailsDto superVisiorDetailsDto = new SuperVisiorDetailsDto();
		superVisiorDetailsDto.setEmpId(52339l);
		superVisiorDetailsDto.setEmpName("SandepBhai Yadav");
		superVisiorDetailsList.add(superVisiorDetailsDto);
		return superVisiorDetailsList;
	}

	private List<ProjectDto> getProjectList() {
		List<ProjectDto> projectList = new ArrayList<ProjectDto>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(40001);
		projectDto.setProjectName("test1");
		projectList.add(projectDto);
		return projectList;
	}

	private LookupValueDto getLookupValueDto() {
		LookupValueDto lookupValueDto = new LookupValueDto();
		lookupValueDto.setLookUpId(1l);
		lookupValueDto.setLookupType("Billable");
		lookupValueDto.setLookupType("Billable");
		return lookupValueDto;

	}

	@Test(expected = ResourceManagementException.class)
	public void getResourceProjectDtlsByAssociateIDTest() throws ResourceManagementException, ParseException {
		when(adminServiceClient.getEmployeeDetails(Mockito.anyLong())).thenReturn(getEmployee());
		when(adminServiceClient.getLeaveDetails(Mockito.anyLong())).thenReturn(getLeaveDeatils());
		when(tAssociateAllocationRepository.searchEmployeeNonBillableUtilization(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(20.0);
	//	when(tAssociateAllocationRepository.searchEmployeeBillableUtilization(Mockito.anyLong())).thenReturn(20.0);
		when(tAssociateAllocationRepository.searchEmployeeEBRUtilization(Mockito.anyLong())).thenReturn(20.0);
		when(tAssociateAllocationRepository.searchAllocatedToProject(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(),Mockito.anyLong(), Mockito.anyLong(), null)).thenReturn(getallocatedResourceProjection());
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(getResourceRequirementDtos());
		when(tSrfRepository.findBysrfId(Mockito.anyList())).thenReturn(getSrfProjections());
		when(adminServiceClient.getSuperVisiorList(Mockito.anyList())).thenReturn(getSupervisiorList());
		when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(getProjectList());
		when(allocatedHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
		when(adminServiceClient.getLookUpById(Mockito.anyInt())).thenReturn(getLookupValueDto());
		AssociateSearchDto associateSearchDto = resourceSearchServiceImpl.getResourceProjectDtlsByAssociateID("52330","allocated",54168L,457L);
		assertNull(associateSearchDto);   
	}

	@Test
	public void getResourceProjectDtlsByAssociateIDTestEmpName() throws ResourceManagementException, ParseException {
		PracticeProjectDto practiceProjectDto = new PracticeProjectDto();
		practiceProjectDto.setPracticeId(1);
		practiceProjectDto.setPracticeProjectId(100001);
		practiceProjectDto.setPracticeProjectName("AMS");
		practiceProjectDto.setProjectId(10001);
		
		List<Long> empNumberList = new ArrayList<Long>();
		empNumberList.add(52330l);
		
		List<SkillTaxonomyDto> skillTaxanomyList = new ArrayList<SkillTaxonomyDto>();
		SkillTaxonomyDto taxdto = new SkillTaxonomyDto();
		taxdto.setL1PracticeId(1l);
		taxdto.setL1PracticeName("biliubliu");
		skillTaxanomyList.add(taxdto);
		
		List<AvaibalityProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		AvaibalityProjection getSrfProjection1 = factory.createProjection(AvaibalityProjection.class);
		getSrfProjection1.setAllocatedFte(22l);
		getSrfProjection1.setEmployeeId(52330);
		srfProjectionList.add(getSrfProjection1);
		
		List<LookupValueDto> lookuTypes = new ArrayList<LookupValueDto>();
		LookupValueDto dto = new LookupValueDto();
		dto.setLookUpId(1l);
		dto.setLookupType("POOL");
		
		lookuTypes.add(dto);
		EmployeeSkillDto empdto = new EmployeeSkillDto();
		empdto.setEmployeeId(1l);
		empdto.setSkillFamilyList(skillTaxanomyList);
		 Map<Long, EmployeeSkillDto> skillMap = new HashMap<Long, EmployeeSkillDto>();
		 skillMap.put(52330l, empdto);
		
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(srfProjectionList);
        when(adminServiceClient.getEmployeeDetails(Mockito.anyLong())).thenReturn(getEmployee());
		when(adminServiceClient.getLeaveDetails(Mockito.anyLong())).thenReturn(null);
		when(adminServiceClient.getPracticeProject(Mockito.anyLong())).thenReturn(practiceProjectDto);
		when(tAssociateAllocationRepository.searchEmployeeNonBillableUtilization(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		when(resourceRequirementServiceImpl.getWorkingDaysBetweenTwoDates(Mockito.any(), Mockito.any())).thenReturn(2);
		//when(tAssociateAllocationRepository.searchEmployeeBillableUtilization(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.searchEmployeeEBRUtilization(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.searchAllocatedToProject(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(),Mockito.anyLong(), Mockito.anyLong(), null)).thenReturn(getallocatedResourceProjectionNull());
		when(tAssociateAllocationRepository.getEmpNumbers(Mockito.anyList())).thenReturn(empNumberList);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(getResourceRequirementDtos());
		when(tSrfRepository.findBysrfId(Mockito.anyList())).thenReturn(getSrfProjections());
		when(allocatedHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
        when(adminServiceClient.getSuperVisiorList(Mockito.anyList())).thenReturn(getSupervisiorList());
        when(adminServiceClient.getSkillFamilyByskillId(Mockito.anyList())).thenReturn(skillTaxanomyList);
        when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(getProjectList());
		when( adminServiceClient.getLookupValueByLookupType(Mockito.anyString())).thenReturn(lookuTypes);
        when(adminServiceClient.getLookUpById(Mockito.anyInt())).thenReturn(getLookupValueDto());
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(getEmployee());
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(getEmployee());
		when(resourceAllocationServiceImpl.getSkillFamilyForAssociate(Mockito.anyList())).thenReturn(skillMap);
		AssociateSearchDto associateSearchDto = resourceSearchServiceImpl
				.getResourceProjectDtlsByAssociateID("Akshay Tiwari","allocated",54168L,457L);
		assertNotNull(associateSearchDto);
	}     

	@Test
	public void getSupervisorListTest() throws ResourceManagementException {
		List<SupervisorDto> supervisorList = new ArrayList<>();
		List<EmployeeDto> employeeDtoList = new ArrayList<>();
		SupervisorDto supervisorDto = new SupervisorDto();
		supervisorDto.setSupervisorId(1L);
		supervisorDto.setSupervisorName("AJAY");
		supervisorList.add(supervisorDto);
		
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(51509L);
		employeeDto.setEmployeeNumber(51509L);
		employeeDto.setEmployeeName("Test");
		employeeDtoList.add(employeeDto);
		
		when(adminServiceClient.getAssociatesDetailsbyEmpIds(Mockito.anyList())).thenReturn(employeeDtoList);
		resourceSearchServiceImpl.getSupervisorList(40017L);
		verify(adminServiceClient, times(1)).getAssociatesDetailsbyEmpIds(Mockito.anyList());
	}

	@Test(expected = ResourceManagementException.class)
	public void updateProjectDtlsForSearchTest() throws ResourceManagementException, ParseException {
		ResourceSearchDto resourceSearchDto = new ResourceSearchDto();

		List<EmployeeDto> empList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(52331l);
		employeeDto.setEmployeeName("A");
		employeeDto.setProjectId(40001l);
		employeeDto.setRequirementId(1l);
		employeeDto.setPrimaryProjectStatusId(true);
		employeeDto.setSupervisorId(51509l);
		employeeDto.setCapHours(9.00);
		employeeDto.setSkillChampion(true);
		Date today = new Date();
		Date tomorrow = new Date(today.getTime() - (1000 * 60 * 60 * 24));
		employeeDto.setEffectiveStartDate(new Date());
		employeeDto.setComments("Test");

		empList.add(employeeDto);

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBand("F2");
		resourceRequirementDto.setProjectId(40001l);

		List<TAssociateProject> tAssociateProjectList = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		tAssociateProject.setAssociateProjectId(1l);
		tAssociateProject.setProjectId(40001l);
		tAssociateProject.setEmployeeId(52331l);
		tAssociateProject.setSupervisorId(51509l);
		tAssociateProjectList.add(tAssociateProject);

		List<TAssociateAllocation> tAssociateAllocationList = new ArrayList<>();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		tAssociateAllocation.setAssociateAllocationId(1l);
		tAssociateAllocation.setTAssociateProject(tAssociateProject);
		tAssociateAllocation.setRequirementId(1l);
		tAssociateAllocation.setSkillChampionFlag(true);
		tAssociateAllocation.setEffectiveStartDate(tomorrow);
		tAssociateAllocation.setCapHours(9.00);
		tAssociateAllocationList.add(tAssociateAllocation);

		resourceSearchDto.setEmployeeList(empList);

		when(bapServiceClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateProjectRepository.findByEmployeeIdAndProjectId(Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(tAssociateProjectList);
		when(tAssociateAllocationRepository.getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong())).thenReturn(tAssociateAllocationList);
		when(jvDetailsRepository.getWindowEndDate()).thenReturn(new Date());
		when(jvCheckHelperService.isJvCheckForSearch(tomorrow, tAssociateAllocation.getEffectiveStartDate(),
				employeeDto.getEffectiveStartDate())).thenReturn(true);

		resourceSearchServiceImpl.updateProjectDtlsForSearch(resourceSearchDto);
	}

	@Test(expected = ResourceManagementException.class)
	public void updateProjectDtlsForSearchWithFTETest() throws ResourceManagementException, ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		ResourceSearchDto resourceSearchDto = new ResourceSearchDto();

		List<EmployeeDto> empList = new ArrayList<>();

		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(52331l);
		employeeDto.setEmployeeName("A");
		employeeDto.setProjectId(40001l);
		employeeDto.setRequirementId(1l);
		employeeDto.setPrimaryProjectStatusId(true);
		employeeDto.setSupervisorId(51509l);
		employeeDto.setFte_percent(100);
		employeeDto.setCapHours(9.00);
		employeeDto.setSkillChampion(true);
		Date tempDate = new Date(1403685556000L);
		employeeDto.setEffectiveStartDate(tempDate);
		employeeDto.setComments("Test");

		empList.add(employeeDto);

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBand("F2");
		resourceRequirementDto.setProjectId(40001l);
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");

		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		projectBudgetDto.setId(1l);
		projectBudgetDto.setMonth("2020-01");
		projectBudgetDto.setAvailableBudget(10D);
		projectBudgetDto.setConsumedBudget(100D);
		projectBudgetDto.setProjectId("test");
		projectBudgetDto.setBudgetCurrency(10000D);
		projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-01-30"));
		projectBudget.add(projectBudgetDto);

		List<TAssociateProject> tAssociateProjectList = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		tAssociateProject.setAssociateProjectId(1l);
		tAssociateProject.setProjectId(40001l);
		tAssociateProject.setEmployeeId(52331l);
		tAssociateProject.setSupervisorId(51509l);
		tAssociateProjectList.add(tAssociateProject);

		List<TAssociateAllocation> tAssociateAllocationList = new ArrayList<>();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		tAssociateAllocation.setAssociateAllocationId(1l);
		tAssociateAllocation.setTAssociateProject(tAssociateProject);
		tAssociateAllocation.setRequirementId(1l);
		tAssociateAllocation.setSkillChampionFlag(true);
		Date tempDate1 = new Date(1403685556000L);
		tAssociateAllocation.setEffectiveStartDate(tempDate1);
		tAssociateAllocation.setFtePercent(100D);
		tAssociateAllocation.setCapHours(9.00);
		tAssociateAllocationList.add(tAssociateAllocation);

		resourceSearchDto.setEmployeeList(empList);

		when(bapServiceClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateProjectRepository.findByEmployeeIdAndProjectId(Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(tAssociateProjectList);
		when(tAssociateAllocationRepository.getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong())).thenReturn(tAssociateAllocationList);
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		when(resourceAllocationServiceImpl.performBudgetControlCheck(Mockito.any(), Mockito.anyList(),
				Mockito.anyMap())).thenReturn(true);

		resourceSearchServiceImpl.updateProjectDtlsForSearch(resourceSearchDto);
	}

	@Test
	public void getSearchListTest() throws ResourceManagementException {
		List<LookupValueDto> lookupValueDtoForSearch = new ArrayList<>();
		LookupValueDto lookupValueDto1 = new LookupValueDto();
		lookupValueDto1.setLookUpId(1l);
		lookupValueDto1.setLookupType("SEARCH_BY");
		lookupValueDto1.setLookupValueCode("BY_PRACTICE");

		LookupValueDto lookupValueDto2 = new LookupValueDto();
		lookupValueDto2.setLookUpId(2l);
		lookupValueDto2.setLookupType("SEARCH_BY");
		lookupValueDto2.setLookupValueCode("BY_SKILL");

		lookupValueDtoForSearch.add(lookupValueDto1);
		lookupValueDtoForSearch.add(lookupValueDto2);

		when(adminServiceClient.getLookupValueByLookupType(Mockito.anyString())).thenReturn(lookupValueDtoForSearch);
		resourceSearchServiceImpl.getSearchList();
		verify(adminServiceClient, times(1)).getLookupValueByLookupType(Mockito.anyString());
	}

	@Test
	public void getSearchListNoContentTest() throws ResourceManagementException {

		when(adminServiceClient.getLookupValueByLookupType(Mockito.anyString())).thenReturn(null);
		resourceSearchServiceImpl.getSearchList();
		verify(adminServiceClient, times(1)).getLookupValueByLookupType(Mockito.anyString());
	}

	@Test
	public void saveResourcesForExtensionSupervisorCheckFailedTest()
			throws ResourceManagementException, ParseException {
		ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
		resourceSearchDto.setProjectId(40777L);
		resourceSearchDto.setRoleId(1L);
		resourceSearchDto.setSupervisorId(57280L);
		resourceSearchDto.setUserId(50002L);
		List<EmployeeDto> employeeDtoList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(3L);
		employeeDto.setAssociateProjectId(66797L);
		employeeDto.setEmployeeId(50340L);
		employeeDto.setProjectId(40777L);
		employeeDto.setBand("A2");
		employeeDtoList.add(employeeDto);
		resourceSearchDto.setEmployeeList(employeeDtoList);
		EmployeeDto supervisorEmployeeDto = new EmployeeDto();
		supervisorEmployeeDto.setBand("E2");
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");

		List<TAssociateProject> tAssociateProjectList = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		tAssociateProject.setAssociateProjectId(6666L);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setAssociateProjectId(6666L);
		tAssociateProjectList.add(tAssociateProject);

		when(adminServiceClient.getEmployeeDetails(Mockito.anyLong())).thenReturn(supervisorEmployeeDto);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateProjectRepository.findByAssociateProjectId(Mockito.anyLong())).thenReturn(tAssociateProject);

		resourceSearchServiceImpl.saveResourcesForExtension(resourceSearchDto);
		verify(adminServiceClient, times(1)).getEmployeeDetails(Mockito.anyLong());
	}

	@Test
	public void saveResourcesForExtensionSupervisorCheckPassedTest()
			throws ResourceManagementException, ParseException {
		ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
		resourceSearchDto.setProjectId(40777L);
		resourceSearchDto.setRoleId(1L);
		resourceSearchDto.setSupervisorId(57280L);
		resourceSearchDto.setUserId(50002L);
		List<EmployeeDto> employeeDtoList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(3L);
		employeeDto.setAssociateProjectId(66797L);
		employeeDto.setEmployeeId(50340L);
		employeeDto.setProjectId(40777L);
		employeeDto.setBand("F2");
		employeeDtoList.add(employeeDto);
		resourceSearchDto.setEmployeeList(employeeDtoList);
		EmployeeDto supervisorEmployeeDto = new EmployeeDto();
		supervisorEmployeeDto.setBand("E2");
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");

		List<TAssociateProject> tAssociateProjectList = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		tAssociateProject.setAssociateProjectId(6666L);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setAssociateProjectId(6666L);
		tAssociateProjectList.add(tAssociateProject);

		List<TAssociateAllocation> associateAllocationList = new ArrayList<>();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		tAssociateAllocation.setActualAllocationEndDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setRequirementId(3L);
		tAssociateAllocation.setSupervisorId(54011L);
		tAssociateAllocation.setTAssociateProject(tAssociateProject);
		tAssociateAllocation.setCreatedBy(54011L);
		tAssociateAllocation.setCreatedDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setLastUpdatedBy(54011L);
		tAssociateAllocation.setLastUpdatedDate(new Date());
		tAssociateAllocation.setStatusId(1L);
		tAssociateAllocation.setEffectiveEndDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setEffectiveStartDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setActualAllocationStartDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setFtePercent(100D);
		tAssociateAllocation.setRequirementId(3L);
		tAssociateAllocation.setRemarks("TEST");
		tAssociateAllocation.setRoleId(1L);
		tAssociateAllocation.setWorkLocationId(1L);
		tAssociateAllocation.setBaseHours(9.0);
		tAssociateAllocation.setEstAllocationEndDate(dateFormat.parse("2021-01-01"));
		tAssociateAllocation.setAssociateAllocationId(1L);
		tAssociateAllocation.setTransactionHistoryId(1L);
		associateAllocationList.add(tAssociateAllocation);

		when(adminServiceClient.getEmployeeDetails(Mockito.anyLong())).thenReturn(supervisorEmployeeDto);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateProjectRepository.findByAssociateProjectId(Mockito.anyLong())).thenReturn(tAssociateProject);
		when(tAssociateAllocationRepository.getAssociateAllocationById(Mockito.anyList()))
				.thenReturn(associateAllocationList);

		resourceSearchServiceImpl.saveResourcesForExtension(resourceSearchDto);
		verify(adminServiceClient, times(1)).getEmployeeDetails(Mockito.anyLong());
	}

	@Test
	public void saveResourcesForExtensionBudgetCheckFailed() throws ResourceManagementException, ParseException {
		ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
		resourceSearchDto.setEstEndDate(dateFormat.parse("2020-04-01"));
		resourceSearchDto.setProjectId(40777L);
		resourceSearchDto.setRoleId(1L);
		resourceSearchDto.setUserId(50002L);
		List<EmployeeDto> employeeDtoList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(3L);
		employeeDto.setAssociateProjectId(66797L);
		employeeDto.setEmployeeId(50340L);
		employeeDto.setProjectId(40777L);
		employeeDto.setBand("F2");
		employeeDtoList.add(employeeDto);
		resourceSearchDto.setEmployeeList(employeeDtoList);

		EmployeeDto supervisorEmployeeDto = new EmployeeDto();
		supervisorEmployeeDto.setBand("E2");
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");

		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		projectBudgetDto.setId(1l);
		projectBudgetDto.setMonth("2020-01");
		projectBudgetDto.setAvailableBudget(10D);
		projectBudgetDto.setConsumedBudget(100D);
		projectBudgetDto.setProjectId("test");
		projectBudgetDto.setBudgetCurrency(10000D);
		projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-01-30"));
		projectBudget.add(projectBudgetDto);

		List<TAssociateProject> tAssociateProjectList = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		tAssociateProject.setAssociateProjectId(6666L);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		TAssociateAllocationDto tAssociateAllocationDto = new TAssociateAllocationDto();
		tAssociateAllocationDto.setEstAllocationEndDate(new Date());
		tAssociateProjectDto.setTAssociateAllocation(tAssociateAllocationDto);
		tAssociateProjectDto.setAssociateProjectId(6666L);
		tAssociateProjectList.add(tAssociateProject);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateProjectRepository.findByAssociateProjectId(Mockito.anyLong())).thenReturn(tAssociateProject);
		when(tAssociateProjectMapper.tAssociateProjectToTAssociateProjectDto(tAssociateProject))
				.thenReturn(tAssociateProjectDto);
		when(resourceAllocationServiceImpl.getBudgetAndCostCheck(Mockito.anyLong())).thenReturn(true);

		resourceSearchServiceImpl.saveResourcesForExtension(resourceSearchDto);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
	}

	@Test
	public void saveResourcesForExtensionBudgetCheckPassed() throws ResourceManagementException, ParseException {
		ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
		resourceSearchDto.setEstEndDate(dateFormat.parse("2020-04-01"));
		resourceSearchDto.setProjectId(40777L);
		resourceSearchDto.setRoleId(1L);
		resourceSearchDto.setUserId(50002L);
		List<EmployeeDto> employeeDtoList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(3L);
		employeeDto.setAssociateProjectId(66797L);
		employeeDto.setEmployeeId(50340L);
		employeeDto.setProjectId(40777L);
		employeeDto.setBand("F2");
		employeeDtoList.add(employeeDto);
		resourceSearchDto.setEmployeeList(employeeDtoList);

		EmployeeDto supervisorEmployeeDto = new EmployeeDto();
		supervisorEmployeeDto.setBand("E2");
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");

		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		projectBudgetDto.setId(1l);
		projectBudgetDto.setMonth("2020-04");
		projectBudgetDto.setAvailableBudget(100D);
		projectBudgetDto.setConsumedBudget(10D);
		projectBudgetDto.setProjectId("test");
		projectBudgetDto.setBudgetCurrency(10000D);
		projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-04-30"));
		projectBudget.add(projectBudgetDto);

		List<TAssociateProject> tAssociateProjectList = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		tAssociateProject.setAssociateProjectId(6666L);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setAssociateProjectId(6666L);
		tAssociateProjectList.add(tAssociateProject);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateProjectRepository.findByAssociateProjectId(Mockito.anyLong())).thenReturn(tAssociateProject);
		when(tAssociateProjectMapper.tAssociateProjectToTAssociateProjectDto(tAssociateProject))
				.thenReturn(tAssociateProjectDto);
		when(resourceAllocationServiceImpl.performBudgetControlCheck(Mockito.any(), Mockito.anyList(),
				Mockito.anyMap())).thenReturn(true);
		when(resourceAllocationServiceImpl.getBudgetAndCostCheck(Mockito.anyLong())).thenReturn(false);

		resourceSearchServiceImpl.saveResourcesForExtension(resourceSearchDto);
		//verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
	}

	@Test
	public void saveResourcesForExtensionTagAdmin() throws ResourceManagementException, ParseException {
		ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
		resourceSearchDto.setEstEndDate(dateFormat.parse("2020-04-01"));
		resourceSearchDto.setProjectId(40777L);
		resourceSearchDto.setRoleId(1L);
		resourceSearchDto.setUserId(50002L);
		List<EmployeeDto> employeeDtoList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(3L);
		employeeDto.setAssociateProjectId(66797L);
		employeeDto.setEmployeeId(50340L);
		employeeDto.setProjectId(40777L);
		employeeDto.setBand("F2");
		employeeDtoList.add(employeeDto);
		resourceSearchDto.setEmployeeList(employeeDtoList);

		EmployeeDto supervisorEmployeeDto = new EmployeeDto();
		supervisorEmployeeDto.setBand("E2");
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");

		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		projectBudgetDto.setId(1l);
		projectBudgetDto.setMonth("2020-04");
		projectBudgetDto.setAvailableBudget(100D);
		projectBudgetDto.setConsumedBudget(10D);
		projectBudgetDto.setProjectId("test");
		projectBudgetDto.setBudgetCurrency(10000D);
		projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-04-30"));
		projectBudget.add(projectBudgetDto);

		List<TAssociateProject> tAssociateProjectList = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		tAssociateProject.setAssociateProjectId(6666L);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setAssociateProjectId(6666L);
		TAssociateAllocationDto tAssociateAllocationDto = new TAssociateAllocationDto();
		tAssociateAllocationDto.setEstAllocationEndDate(new Date());
		tAssociateProjectDto.setTAssociateAllocation(tAssociateAllocationDto);
		tAssociateProjectList.add(tAssociateProject);
		List<Long> roleIds = List.of(1L);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateProjectRepository.findByAssociateProjectId(Mockito.anyLong())).thenReturn(tAssociateProject);
		when(tAssociateProjectMapper.tAssociateProjectToTAssociateProjectDto(tAssociateProject))
				.thenReturn(tAssociateProjectDto);
		when(resourceAllocationServiceImpl.performBudgetControlCheck(Mockito.any(), Mockito.anyList(),
				Mockito.anyMap())).thenReturn(true);
		when(adminServiceClient.getRoleIds(Mockito.anyList())).thenReturn(roleIds);
		when(resourceAllocationServiceImpl.getBudgetAndCostCheck(Mockito.anyLong())).thenReturn(true);

		resourceSearchServiceImpl.saveResourcesForExtension(resourceSearchDto);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
	}

	@Test
	public void saveResourcesForExtensionWFRole() throws ResourceManagementException, ParseException {
		ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
		resourceSearchDto.setEstEndDate(dateFormat.parse("2020-04-01"));
		resourceSearchDto.setProjectId(40777L);
		resourceSearchDto.setRoleId(1L);
		resourceSearchDto.setUserId(50002L);
		List<EmployeeDto> employeeDtoList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(3L);
		employeeDto.setAssociateProjectId(66797L);
		employeeDto.setEmployeeId(50340L);
		employeeDto.setProjectId(40777L);
		employeeDto.setBand("F2");
		employeeDtoList.add(employeeDto);
		resourceSearchDto.setEmployeeList(employeeDtoList);

		EmployeeDto supervisorEmployeeDto = new EmployeeDto();
		supervisorEmployeeDto.setBand("E2");
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");

		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		projectBudgetDto.setId(1l);
		projectBudgetDto.setMonth("2020-04");
		projectBudgetDto.setAvailableBudget(100D);
		projectBudgetDto.setConsumedBudget(10D);
		projectBudgetDto.setProjectId("test");
		projectBudgetDto.setBudgetCurrency(10000D);
		projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-04-30"));
		projectBudget.add(projectBudgetDto);

		List<TAssociateProject> tAssociateProjectList = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		tAssociateProject.setAssociateProjectId(6666L);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		TAssociateAllocationDto tAssociateAllocationDto = new TAssociateAllocationDto();
		tAssociateAllocationDto.setEstAllocationEndDate(new Date());
		tAssociateProjectDto.setTAssociateAllocation(tAssociateAllocationDto);
		tAssociateProjectDto.setAssociateProjectId(6666L);
		tAssociateProjectList.add(tAssociateProject);
		List<Long> roleIds = List.of(3L);

		List<TAssociateExtension> tAssociateExtensionList = new ArrayList<>();
		TAssociateExtension tAssociateExtension = new TAssociateExtension();
		tAssociateExtension.setActualAllocationEndDate(dateFormat.parse("2020-04-01"));
		tAssociateExtension.setRequirementId(3L);
		tAssociateExtension.setSupervisorId(54011L);
		tAssociateExtension.setTAssociateProject(tAssociateProject);
		tAssociateExtension.setCreatedBy(54011L);
		tAssociateExtension.setCreatedDate(dateFormat.parse("2020-04-01"));
		tAssociateExtension.setLastUpdatedBy(54011L);
		tAssociateExtension.setLastUpdatedDate(new Date());
		tAssociateExtension.setStatusId(1L);
		tAssociateExtension.setEffectiveEndDate(dateFormat.parse("2020-04-01"));
		tAssociateExtension.setEffectiveStartDate(dateFormat.parse("2020-04-01"));
		tAssociateExtension.setActualAllocationStartDate(dateFormat.parse("2020-04-01"));
		tAssociateExtension.setFtePercent(100L);
		tAssociateExtension.setRequirementId(3L);
		tAssociateExtension.setRemarks("TEST");
		tAssociateExtension.setRoleId(1L);
		tAssociateExtension.setWorkLocationId(1L);
		tAssociateExtension.setBaseHours(9);
		tAssociateExtension.setEstAllocationEndDate(dateFormat.parse("2021-01-01"));
		tAssociateExtension.setTransactionHistoryId(1L);
		tAssociateExtension.setAssociateExtensionId(1L);
		tAssociateExtensionList.add(tAssociateExtension);

		List<TAssociateAllocation> associateAllocationList = new ArrayList<>();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		tAssociateAllocation.setActualAllocationEndDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setRequirementId(3L);
		tAssociateAllocation.setSupervisorId(54011L);
		tAssociateAllocation.setTAssociateProject(tAssociateProject);
		tAssociateAllocation.setCreatedBy(54011L);
		tAssociateAllocation.setCreatedDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setLastUpdatedBy(54011L);
		tAssociateAllocation.setLastUpdatedDate(new Date());
		tAssociateAllocation.setStatusId(1L);
		tAssociateAllocation.setEffectiveEndDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setEffectiveStartDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setActualAllocationStartDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setFtePercent(100D);
		tAssociateAllocation.setRequirementId(3L);
		tAssociateAllocation.setRemarks("TEST");
		tAssociateAllocation.setRoleId(1L);
		tAssociateAllocation.setWorkLocationId(1L);
		tAssociateAllocation.setBaseHours(9.0);
		tAssociateAllocation.setEstAllocationEndDate(dateFormat.parse("2021-01-01"));
		tAssociateAllocation.setAssociateAllocationId(1L);
		tAssociateAllocation.setTransactionHistoryId(1L);
		associateAllocationList.add(tAssociateAllocation);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateProjectRepository.findByAssociateProjectId(Mockito.anyLong())).thenReturn(tAssociateProject);
		when(tAssociateProjectMapper.tAssociateProjectToTAssociateProjectDto(tAssociateProject))
				.thenReturn(tAssociateProjectDto);
		when(resourceAllocationServiceImpl.performBudgetControlCheck(Mockito.any(), Mockito.anyList(),
				Mockito.anyMap())).thenReturn(true);
		when(adminServiceClient.getRoleIds(Mockito.anyList())).thenReturn(roleIds);
		when(tAssociateExtensionRepository.saveAll(Mockito.anyList())).thenReturn(tAssociateExtensionList);
		when(tAssociateAllocationRepository.getAssociateAllocationIdByProjectId(Mockito.anyList(), Mockito.anyLong()))
				.thenReturn(associateAllocationList);
		when(resourceAllocationServiceImpl.getBudgetAndCostCheck(Mockito.anyLong())).thenReturn(true);

		resourceSearchServiceImpl.saveResourcesForExtension(resourceSearchDto);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
	}

	@Test
	public void saveResourcesForExtensionLockingPeriod() throws ResourceManagementException, ParseException {
		ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
		resourceSearchDto.setEstEndDate(dateFormat.parse("2020-04-01"));
		resourceSearchDto.setProjectId(40777L);
		resourceSearchDto.setRoleId(1L);
		resourceSearchDto.setUserId(50002L);
		List<EmployeeDto> employeeDtoList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(3L);
		employeeDto.setAssociateProjectId(66797L);
		employeeDto.setEmployeeId(50340L);
		employeeDto.setProjectId(40777L);
		employeeDto.setBand("F2");
		employeeDtoList.add(employeeDto);
		resourceSearchDto.setEmployeeList(employeeDtoList);

		EmployeeDto supervisorEmployeeDto = new EmployeeDto();
		supervisorEmployeeDto.setBand("E2");
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");

		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		projectBudgetDto.setId(1l);
		projectBudgetDto.setMonth("2020-04");
		projectBudgetDto.setAvailableBudget(100D);
		projectBudgetDto.setConsumedBudget(10D);
		projectBudgetDto.setProjectId("test");
		projectBudgetDto.setBudgetCurrency(10000D);
		projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-04-30"));
		projectBudget.add(projectBudgetDto);

		List<TAssociateProject> tAssociateProjectList = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		tAssociateProject.setAssociateProjectId(6666L);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		TAssociateAllocationDto tAssociateAllocationDto = new TAssociateAllocationDto();
		tAssociateAllocationDto.setEstAllocationEndDate(new Date());
		tAssociateProjectDto.setTAssociateAllocation(tAssociateAllocationDto);
		tAssociateProjectDto.setAssociateProjectId(6666L);
		tAssociateProjectList.add(tAssociateProject);
		List<Long> roleIds = List.of(3L);

		List<TAssociateExtension> tAssociateExtensionList = new ArrayList<>();
		TAssociateExtension tAssociateExtension = new TAssociateExtension();
		tAssociateExtension.setActualAllocationEndDate(dateFormat.parse("2020-04-01"));
		tAssociateExtension.setRequirementId(3L);
		tAssociateExtension.setSupervisorId(54011L);
		tAssociateExtension.setTAssociateProject(tAssociateProject);
		tAssociateExtension.setCreatedBy(54011L);
		tAssociateExtension.setCreatedDate(dateFormat.parse("2020-04-01"));
		tAssociateExtension.setLastUpdatedBy(54011L);
		tAssociateExtension.setLastUpdatedDate(new Date());
		tAssociateExtension.setStatusId(1L);
		tAssociateExtension.setEffectiveEndDate(dateFormat.parse("2020-04-01"));
		tAssociateExtension.setEffectiveStartDate(dateFormat.parse("2020-04-01"));
		tAssociateExtension.setActualAllocationStartDate(dateFormat.parse("2020-04-01"));
		tAssociateExtension.setFtePercent(100L);
		tAssociateExtension.setRequirementId(3L);
		tAssociateExtension.setRemarks("TEST");
		tAssociateExtension.setRoleId(1L);
		tAssociateExtension.setWorkLocationId(1L);
		tAssociateExtension.setBaseHours(9);
		tAssociateExtension.setEstAllocationEndDate(new Date(new Date().getTime() + (1000 * 60 * 60 * 24 * 7)));
		tAssociateExtension.setTransactionHistoryId(1L);
		tAssociateExtension.setAssociateExtensionId(1L);
		tAssociateExtensionList.add(tAssociateExtension);

		List<TAssociateAllocation> associateAllocationList = new ArrayList<>();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		tAssociateAllocation.setActualAllocationEndDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setRequirementId(3L);
		tAssociateAllocation.setSupervisorId(54011L);
		tAssociateAllocation.setTAssociateProject(tAssociateProject);
		tAssociateAllocation.setCreatedBy(54011L);
		tAssociateAllocation.setCreatedDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setLastUpdatedBy(54011L);
		tAssociateAllocation.setLastUpdatedDate(new Date());
		tAssociateAllocation.setStatusId(1L);
		tAssociateAllocation.setEffectiveEndDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setEffectiveStartDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setActualAllocationStartDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocation.setFtePercent(100D);
		tAssociateAllocation.setRequirementId(3L);
		tAssociateAllocation.setRemarks("TEST");
		tAssociateAllocation.setRoleId(1L);
		tAssociateAllocation.setWorkLocationId(1L);
		tAssociateAllocation.setBaseHours(9.0);
		tAssociateAllocation.setEstAllocationEndDate(new Date(new Date().getTime() + (1000 * 60 * 60 * 24 * 7)));
		tAssociateAllocation.setAssociateAllocationId(1L);
		associateAllocationList.add(tAssociateAllocation);
		
		List<RMApproversDto> rmDtoList = new ArrayList<>();
		RMApproversDto rmDto = new RMApproversDto();
		rmDto.setUserId(1234l);
		rmDto.setRoleId(1l);
		rmDtoList.add(rmDto);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateProjectRepository.findByAssociateProjectId(Mockito.anyLong())).thenReturn(tAssociateProject);
		when(tAssociateProjectMapper.tAssociateProjectToTAssociateProjectDto(tAssociateProject))
				.thenReturn(tAssociateProjectDto);
		when(resourceAllocationServiceImpl.performBudgetControlCheck(Mockito.any(), Mockito.anyList(),
				Mockito.anyMap())).thenReturn(true);
		when(adminServiceClient.getRoleIds(Mockito.anyList())).thenReturn(roleIds);
		when(tAssociateExtensionRepository.saveAll(Mockito.anyList())).thenReturn(tAssociateExtensionList);
		when(tAssociateAllocationRepository.getAssociateAllocationIdByProjectId(Mockito.anyList(), Mockito.anyLong()))
				.thenReturn(associateAllocationList);
		when(resourceAllocationServiceImpl.getBudgetAndCostCheck(Mockito.anyLong())).thenReturn(true);
		when(resourceExtensionUtils.getRMApproversList(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyString())).thenReturn(rmDtoList);

		resourceSearchServiceImpl.saveResourcesForExtension(resourceSearchDto);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
	}

	@Test
	public void approveRTApprovalForAllocReqTest() throws ResourceManagementException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_FTE_CHANGE_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);

		/*
		 * List<RTResourceDto> rtResourceDtoList = new ArrayList<>(); RTResourceDto
		 * rtResourceDto = new RTResourceDto(); rtResourceDto.setEmpId(111l);
		 * RTProjectDto rtprojectDto = new RTProjectDto();
		 * rtprojectDto.setAllocationDate(new Date());
		 * rtResourceDto.setTargetProjectDetails(rtprojectDto);
		 * rtResourceDtoList.add(rtResourceDto);
		 * rmApprovalInputDtoObj.setResourceList(rtResourceDtoList);
		 */
		// rtResourceDto.setTargetProjectDetails(rtprojectDto);
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMDA");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(1L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		when(tAssociateAllocationRepository.getRAllocationDetailsForFte(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(resourceWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		doNothing().when(sendMailHelperServiceObj).sendEmailForApprovalConfirmation(Mockito.any(), Mockito.anyString());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		resourceSearchServiceImpl.approveOrRejectRMApproval(RMApprovalInputDtlsList);
		verify(tAssociateAllocationRepository, times(1)).getRAllocationDetailsForFte(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong());
	}

	@Test
	public void approveRTApprovalForAllocReqRoleIdZeroTest() throws ResourceManagementException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_FTE_CHANGE_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		rmApprovalInputDtoObj.setCurrentProjectId(2l);
		rmApprovalInputDtoObj.setCurrentRequirementId(10l);
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);

		List<RTResourceDto> rtResourceDtoList = new ArrayList<>();
		RTResourceDto rtResourceDto = new RTResourceDto();
		rtResourceDto.setEmpId(111l);

		RTProjectDto rtTargetprojectDto = new RTProjectDto();
		rtTargetprojectDto.setAllocationDate(new Date());
		rtTargetprojectDto.setProjectUtilization(100l);
		rtTargetprojectDto.setRequirementId(10l);
		rtResourceDto.setTargetProjectDetails(rtTargetprojectDto);

		RTProjectDto rtCurrentProjectDto = new RTProjectDto();
		rtCurrentProjectDto.setAllocationDate(new Date());
		rtCurrentProjectDto.setProjectUtilization(100l);
		rtCurrentProjectDto.setRequirementId(12l);
		rtResourceDto.setCurrentProjectDetails(rtCurrentProjectDto);

		rtResourceDtoList.add(rtResourceDto);
		rmApprovalInputDtoObj.setResourceList(rtResourceDtoList);

		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		tAssociateAllocationObj.setTransactionHistoryId(2l);

		TAssociateProject associateProject = new TAssociateProject();
		associateProject.setAssociateProjectId(1l);
		associateProject.setEmployeeId(111l);
		associateProject.setLastUpdatedDate(new Date());
		tAssociateAllocationObj.setTAssociateProject(associateProject);
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMT");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(0L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(0L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		ModuleStatusDto statusDto = new ModuleStatusDto();
		statusDto.setModuleId(12l);
		statusDto.setAction("TRANSFER");
		statusDto.setParentModule("RESOURCE_MANAGEMENT");
		statusDto.setSubModule("RESOURCE_TRANSFER");

		when(tAssociateAllocationRepository.getRAllocationDetailsForFte(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(resourceWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		doNothing().when(sendMailHelperServiceObj).sendEmailForApprovalConfirmation(Mockito.any(), Mockito.anyString());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(statusDto.getModuleId());
		doNothing().when(tAssociateAllocationRepository).deactivateResourceAllocation(Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(), Mockito.anyLong());
		when(tAssociateAllocationRepository.getPreviousDataByTransactionHistoryId(Mockito.anyList()))
				.thenReturn(rAllocationDtlsListObj);
		doNothing().when(resourceManagementServiceImpl).releaseAllocatedBudgetForAlloc(Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong());
		when(tAssociateAllocationRepository.getCurrentProjectData(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(tAssociateAllocationObj);
		doNothing().when(sendMailHelperServiceObj).sendEmailForFinalApprovalConfirmation(Mockito.any(),
				Mockito.anyString(), Mockito.anyLong());
		resourceSearchServiceImpl.approveOrRejectRMApproval(RMApprovalInputDtlsList);
		verify(tAssociateAllocationRepository, times(1)).getRAllocationDetailsForFte(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong());

	}

	@Test
	public void approveRTApprovalForUnEqualProjectFteTest() throws ResourceManagementException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_FTE_CHANGE_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		rmApprovalInputDtoObj.setCurrentProjectId(2l);
		rmApprovalInputDtoObj.setCurrentRequirementId(10l);
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);

		List<RTResourceDto> rtResourceDtoList = new ArrayList<>();
		RTResourceDto rtResourceDto = new RTResourceDto();
		rtResourceDto.setEmpId(111l);

		RTProjectDto rtTargetprojectDto = new RTProjectDto();
		rtTargetprojectDto.setAllocationDate(new Date());
		rtTargetprojectDto.setProjectUtilization(70l);
		rtTargetprojectDto.setRequirementId(10l);
		rtResourceDto.setTargetProjectDetails(rtTargetprojectDto);

		RTProjectDto rtCurrentProjectDto = new RTProjectDto();
		rtCurrentProjectDto.setAllocationDate(new Date());
		rtCurrentProjectDto.setProjectUtilization(100l);
		rtCurrentProjectDto.setRequirementId(12l);
		rtResourceDto.setCurrentProjectDetails(rtCurrentProjectDto);

		rtResourceDtoList.add(rtResourceDto);
		rmApprovalInputDtoObj.setResourceList(rtResourceDtoList);

		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		tAssociateAllocationObj.setTransactionHistoryId(2l);
		TAssociateProject associateProject = new TAssociateProject();
		associateProject.setAssociateProjectId(1l);
		associateProject.setEmployeeId(111l);
		associateProject.setLastUpdatedDate(new Date());
		tAssociateAllocationObj.setTAssociateProject(associateProject);
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMT");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(0L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(0L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		ModuleStatusDto statusDto = new ModuleStatusDto();
		statusDto.setModuleId(12l);
		statusDto.setAction("TRANSFER");
		statusDto.setParentModule("RESOURCE_MANAGEMENT");
		statusDto.setSubModule("RESOURCE_TRANSFER");

		when(tAssociateAllocationRepository.getRAllocationDetailsForFte(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(resourceWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		doNothing().when(sendMailHelperServiceObj).sendEmailForApprovalConfirmation(Mockito.any(), Mockito.anyString());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(statusDto.getModuleId());
		doNothing().when(tAssociateAllocationRepository).deactivateResourceAllocation(Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(), Mockito.anyLong());
		when(tAssociateAllocationRepository.getPreviousDataByTransactionHistoryId(Mockito.anyList()))
				.thenReturn(rAllocationDtlsListObj);
		doNothing().when(resourceManagementServiceImpl).releaseAllocatedBudgetForAlloc(Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong());
		when(tAssociateAllocationRepository.getCurrentProjectData(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(tAssociateAllocationObj);
		doNothing().when(sendMailHelperServiceObj).sendEmailForFinalApprovalConfirmation(Mockito.any(),
				Mockito.anyString(), Mockito.anyLong());
		resourceSearchServiceImpl.approveOrRejectRMApproval(RMApprovalInputDtlsList);
		verify(tAssociateAllocationRepository, times(1)).getRAllocationDetailsForFte(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong());

	}

	@Test
	public void rejectRMApprovalForAllocReqTest() throws ResourceManagementException, ParseException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_FTE_CHANGE_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("REJECTED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);

		List<RTResourceDto> rtResourceDtoList = new ArrayList<>();
		RTResourceDto rtResourceDto = new RTResourceDto();
		rtResourceDto.setEmpId(111l);
		RTProjectDto rtprojectDto = new RTProjectDto();
		rtprojectDto.setAllocationDate(new Date());
		rtResourceDto.setTargetProjectDetails(rtprojectDto);
		rtResourceDtoList.add(rtResourceDto);
		rmApprovalInputDtoObj.setResourceList(rtResourceDtoList);
		rtResourceDto.setTargetProjectDetails(rtprojectDto);

		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		tAssociateAllocationObj.setFtePercent(100.00);
		tAssociateAllocationObj.setActualAllocationStartDate(new Date());
		tAssociateAllocationObj.setActualAllocationEndDate(new Date());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		tAssociateAllocationObj.setActualAllocationEndDate(dateFormat.parse(("2020-07-30")));
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMDA");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(1L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(getProjectBudgetDto());
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateAllocationRepository.getRAllocationDetailsForFte(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(resourceWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		doNothing().when(resourceAllocationServiceImpl).updateBudget(Mockito.any());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		resourceManagementServiceImpl.callSendEmailUtility(usrDtlsMap, 1);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		resourceSearchServiceImpl.approveOrRejectRMApproval(RMApprovalInputDtlsList);
		verify(tAssociateAllocationRepository, times(1)).getRAllocationDetailsForFte(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong());

	}

	@Test
	public void rejectRMApprovalForAllocReqRoleNullTest() throws ResourceManagementException, ParseException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_FTE_CHANGE_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("REJECTED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);

		List<RTResourceDto> rtResourceDtoList = new ArrayList<>();
		RTResourceDto rtResourceDto = new RTResourceDto();
		rtResourceDto.setEmpId(111l);
		RTProjectDto rtprojectDto = new RTProjectDto();
		rtprojectDto.setAllocationDate(new Date());
		rtResourceDto.setTargetProjectDetails(rtprojectDto);
		rtResourceDtoList.add(rtResourceDto);
		rmApprovalInputDtoObj.setResourceList(rtResourceDtoList);
		rtResourceDto.setTargetProjectDetails(rtprojectDto);

		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		tAssociateAllocationObj.setFtePercent(100.00);
		tAssociateAllocationObj.setActualAllocationStartDate(new Date());
		tAssociateAllocationObj.setActualAllocationEndDate(new Date());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		tAssociateAllocationObj.setActualAllocationEndDate(dateFormat.parse(("2020-07-30")));
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMDA");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(0L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(0L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		ModuleStatusDto statusDto = new ModuleStatusDto();
		statusDto.setModuleId(12l);
		statusDto.setAction("REJECTED");
		statusDto.setParentModule("RESOURCE_MANAGEMENT");
		statusDto.setSubModule("RESOURCE_ALLOCATION");

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(getProjectBudgetDto());
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateAllocationRepository.getRAllocationDetailsForFte(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(resourceWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		doNothing().when(resourceAllocationServiceImpl).updateBudget(Mockito.any());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		resourceManagementServiceImpl.callSendEmailUtility(usrDtlsMap, 1);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		doNothing().when(tAssociateAllocationRepository).updateStatusAndEffectiveEndDate(Mockito.anyLong(),
				Mockito.anyList(), Mockito.any(), Mockito.anyLong(), Mockito.any());
		doNothing().when(resourceManagementServiceImpl).releaseAllocatedBudgetForAlloc(Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong());
		doNothing().when(resourceManagementServiceImpl).updateProjectStatus(Mockito.anyLong());
		resourceSearchServiceImpl.approveOrRejectRMApproval(RMApprovalInputDtlsList);
		verify(tAssociateAllocationRepository, times(1)).getRAllocationDetailsForFte(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong());

	}

	private ResourceRequirementDto getResourceRequirementDto() {
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");
		return resourceRequirementDto;
	}

	private List<ProjectBudgetDto> getProjectBudgetDto() throws ParseException {
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(200000.00);
		projectBudgetDto1.setConsumedBudget(10.00);

		projectBudget.add(projectBudgetDto1);

		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto2.setBudgetCurrency(5.0);
		projectBudgetDto2.setMonth("2020-07");
		projectBudgetDto2.setAvailableBudget(300000.00);
		projectBudgetDto2.setConsumedBudget(10d);
		projectBudget.add(projectBudgetDto2);
		return projectBudget;
	}
	
	public HashBasedTable<String, String, Long> getAllNewModuleList() {
		 
		List<ModuleStatusDto> moduleList = new ArrayList<>();
		ModuleStatusDto moduleStatusDtoAllocation = new ModuleStatusDto();
		moduleStatusDtoAllocation.setModuleId(1l);
		moduleStatusDtoAllocation.setModuleStatusId(1l);
		moduleStatusDtoAllocation.setModuleCode("RM");
		moduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setAction("APPROVED");
		moduleList.add(moduleStatusDtoAllocation);
		
		ModuleStatusDto moduleStatusDtoAllocationSAVED = new ModuleStatusDto();
		moduleStatusDtoAllocationSAVED.setModuleId(1l);
		moduleStatusDtoAllocationSAVED.setModuleStatusId(1l);
		moduleStatusDtoAllocationSAVED.setModuleCode("RM");
		moduleStatusDtoAllocationSAVED.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSAVED.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSAVED.setAction("SAVED");
		moduleList.add(moduleStatusDtoAllocationSAVED);
		
		ModuleStatusDto moduleStatusDtoAllocationSUBMITTED = new ModuleStatusDto();
		moduleStatusDtoAllocationSUBMITTED.setModuleId(1l);
		moduleStatusDtoAllocationSUBMITTED.setModuleStatusId(1l);
		moduleStatusDtoAllocationSUBMITTED.setModuleCode("RM");
		moduleStatusDtoAllocationSUBMITTED.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSUBMITTED.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSUBMITTED.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoAllocationSUBMITTED);
	
		
		ModuleStatusDto newmoduleStatus2DtoAllocation = new ModuleStatusDto();
		newmoduleStatus2DtoAllocation.setModuleId(2l);
		newmoduleStatus2DtoAllocation.setModuleStatusId(2l);
		newmoduleStatus2DtoAllocation.setModuleCode("RM");
		newmoduleStatus2DtoAllocation.setSubModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setParentModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setAction("DEACTIVATE");
		moduleList.add(newmoduleStatus2DtoAllocation);
		ModuleStatusDto newmoduleStatusDtoAllocation = new ModuleStatusDto();

		newmoduleStatusDtoAllocation.setModuleId(2l);
		newmoduleStatusDtoAllocation.setModuleStatusId(1l);
		newmoduleStatusDtoAllocation.setModuleCode("RM");
		newmoduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setAction("ACTIVATE");
		moduleList.add(newmoduleStatusDtoAllocation);

		ModuleStatusDto moduleStatusDtoTransfer = new ModuleStatusDto();
		moduleStatusDtoTransfer.setModuleId(1l);
		moduleStatusDtoTransfer.setModuleStatusId(1l);
		moduleStatusDtoTransfer.setModuleCode("RM");
		moduleStatusDtoTransfer.setSubModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setAction("APPROVED");
		moduleList.add(moduleStatusDtoTransfer);

		ModuleStatusDto moduleStatusDtoDeallocationSved = new ModuleStatusDto();
		moduleStatusDtoDeallocationSved.setModuleId(1l);
		moduleStatusDtoDeallocationSved.setModuleStatusId(1l);
		
		moduleStatusDtoDeallocationSved.setModuleCode("RM");
		moduleStatusDtoDeallocationSved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSved.setAction("SAVED");
		moduleList.add(moduleStatusDtoDeallocationSved);
		
		
		
		
		ModuleStatusDto moduleStatusDtoDeallocationSubmitted = new ModuleStatusDto();
		moduleStatusDtoDeallocationSubmitted.setModuleId(1l);
		moduleStatusDtoDeallocationSubmitted.setModuleStatusId(1l);
		moduleStatusDtoDeallocationSubmitted.setModuleCode("RM");
		moduleStatusDtoDeallocationSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSubmitted.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoDeallocationSubmitted);
		ModuleStatusDto moduleStatusDtoDeallocationApproved = new ModuleStatusDto();
		moduleStatusDtoDeallocationApproved.setModuleId(1l);
		moduleStatusDtoDeallocationApproved.setModuleCode("RM");
		moduleStatusDtoDeallocationApproved.setModuleStatusId(1l);
		moduleStatusDtoDeallocationApproved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationApproved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationApproved.setAction("APPROVED");
		moduleList.add(moduleStatusDtoDeallocationApproved);

		ModuleStatusDto moduleStatusDtoTansferSved = new ModuleStatusDto();
		moduleStatusDtoTansferSved.setModuleId(1l);  
		moduleStatusDtoTansferSved.setModuleStatusId(1l);
		moduleStatusDtoTansferSved.setModuleCode("RM");
		moduleStatusDtoTansferSved.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTansferSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTansferSved.setAction("SAVED");
		moduleList.add(moduleStatusDtoTansferSved);
		ModuleStatusDto moduleStatusDtoTransferSubmitted = new ModuleStatusDto();
		moduleStatusDtoTransferSubmitted.setModuleId(1l);
		moduleStatusDtoTransferSubmitted.setModuleStatusId(1l);
		moduleStatusDtoTransferSubmitted.setModuleCode("RM");
		moduleStatusDtoTransferSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTransferSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransferSubmitted.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoTansferSved);
		ModuleStatusDto moduleStatusDtoExtension = new ModuleStatusDto();
		moduleStatusDtoExtension.setModuleId(1l);
		moduleStatusDtoExtension.setModuleStatusId(1l);    
		moduleStatusDtoExtension.setModuleCode("RM");
		moduleStatusDtoExtension.setSubModule("RESOURCE_EXTENSION");
		moduleStatusDtoExtension.setParentModule("RESOURCE_EXTENSION"); 
		moduleStatusDtoExtension.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoExtension);
		
		ModuleStatusDto extensionApproved = new ModuleStatusDto();
		extensionApproved.setModuleId(1l);
		extensionApproved.setModuleStatusId(1l);    
		extensionApproved.setModuleCode("RM");
		extensionApproved.setSubModule("RESOURCE_EXTENSION");
		extensionApproved.setParentModule("RESOURCE_EXTENSION"); 
		extensionApproved.setAction("APPROVED");
		moduleList.add(extensionApproved);
		
		
		ModuleStatusDto deallocationApproved = new ModuleStatusDto();
		deallocationApproved.setModuleId(1l);
		deallocationApproved.setModuleStatusId(1l);    
		deallocationApproved.setModuleCode("RM");
		deallocationApproved.setSubModule("RESOURCE_DEALLOCATION");
		deallocationApproved.setParentModule("RESOURCE_DEALLOCATION"); 
		deallocationApproved.setAction("APPROVED");
		moduleList.add(deallocationApproved);


		moduleList.add(moduleStatusDtoTransferSubmitted);
		
		HashBasedTable<String, String, Long> table = HashBasedTable.create();
		for (ModuleStatusDto temp : moduleList) {
			table.put(temp.getSubModule(), temp.getAction(), temp.getModuleStatusId());
		}
		return table;

	}   
	
	private List<AvaibalityProjection> getavilibalityProjections() {
		List<AvaibalityProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		AvaibalityProjection getSrfProjection1 = factory.createProjection(AvaibalityProjection.class);
		getSrfProjection1.setAllocatedFte(22l);
		getSrfProjection1.setEmployeeId(52330);
		srfProjectionList.add(getSrfProjection1);
		
		AvaibalityProjection getSrfProjection2 = factory.createProjection(AvaibalityProjection.class);
		getSrfProjection2.setAllocatedFte(22l);
		getSrfProjection2.setEmployeeId(52330);
		srfProjectionList.add(getSrfProjection2);

		return srfProjectionList;
		}
	
	@Test
	public void updateSupervisorDetailsTest() throws ResourceManagementException {
		SupervisorDto supervisorDto = new SupervisorDto();
		supervisorDto.setSupervisorId(123l);
		supervisorDto.setProjectId(343l);
		
		List<Long> empIds = new ArrayList<>();
		empIds.add(123l);
		empIds.add(3243l);
		supervisorDto.setEmployeeIds(empIds);
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString())).thenReturn(7l);
		doNothing().when(tAssociateProjectRepository).updateSupervisorDetails(Mockito.any(), Mockito.anyLong());
		doNothing().when(tAssociateAllocationRepository).updateSupervisorDetails(Mockito.any(), Mockito.anyLong(), Mockito.anyLong());
		resourceSearchServiceImpl.updateSupervisorDetails(supervisorDto);
		assertNotNull(resourceSearchServiceImpl);
	}
	
	@Test
	public void getResourceProjectDtlsByAssociatereservedForAlloc() throws ResourceManagementException, ParseException {
		PracticeProjectDto practiceProjectDto = new PracticeProjectDto();
		practiceProjectDto.setPracticeId(1);
		practiceProjectDto.setPracticeProjectId(100001);
		practiceProjectDto.setPracticeProjectName("AMS");
		practiceProjectDto.setProjectId(10001);
		
		List<Long> empNumberList = new ArrayList<Long>();
		empNumberList.add(52330l);
		
		List<SkillTaxonomyDto> skillTaxanomyList = new ArrayList<SkillTaxonomyDto>();
		SkillTaxonomyDto taxdto = new SkillTaxonomyDto();
		taxdto.setL1PracticeId(1l);
		taxdto.setL1PracticeName("biliubliu");
		skillTaxanomyList.add(taxdto);
		
		List<AvaibalityProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		AvaibalityProjection getSrfProjection1 = factory.createProjection(AvaibalityProjection.class);
		getSrfProjection1.setAllocatedFte(22l);
		getSrfProjection1.setEmployeeId(52330);
		srfProjectionList.add(getSrfProjection1);
		
		List<LookupValueDto> lookuTypes = new ArrayList<LookupValueDto>();
		LookupValueDto dto = new LookupValueDto();
		dto.setLookUpId(1l);
		dto.setLookupType("POOL");
		
		lookuTypes.add(dto);
		EmployeeSkillDto empdto = new EmployeeSkillDto();
		empdto.setEmployeeId(1l);
		empdto.setSkillFamilyList(skillTaxanomyList);
		 Map<Long, EmployeeSkillDto> skillMap = new HashMap<Long, EmployeeSkillDto>();
		 skillMap.put(52330l, empdto);
		
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(srfProjectionList);
        when(adminServiceClient.getEmployeeDetails(Mockito.anyLong())).thenReturn(getEmployee());
		when(adminServiceClient.getLeaveDetails(Mockito.anyLong())).thenReturn(null);
		when(adminServiceClient.getPracticeProject(Mockito.anyLong())).thenReturn(practiceProjectDto);
		when(tAssociateAllocationRepository.searchEmployeeNonBillableUtilization(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		when(resourceRequirementServiceImpl.getWorkingDaysBetweenTwoDates(Mockito.any(), Mockito.any())).thenReturn(2);
		//when(tAssociateAllocationRepository.searchEmployeeBillableUtilization(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.searchEmployeeEBRUtilization(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.searchAllocatedToProject(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(),Mockito.anyLong(), Mockito.anyLong(), null)).thenReturn(getallocatedResourceProjectionNull());
		when(tAssociateAllocationRepository.getEmpNumbers(Mockito.anyList())).thenReturn(empNumberList);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(getResourceRequirementDtos());
		when(tSrfRepository.findBysrfId(Mockito.anyList())).thenReturn(getSrfProjections());
		when(allocatedHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
        when(adminServiceClient.getSuperVisiorList(Mockito.anyList())).thenReturn(getSupervisiorList());
        when(adminServiceClient.getSkillFamilyByskillId(Mockito.anyList())).thenReturn(skillTaxanomyList);
        when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(getProjectList());
		when( adminServiceClient.getLookupValueByLookupType(Mockito.anyString())).thenReturn(lookuTypes);
        when(adminServiceClient.getLookUpById(Mockito.anyInt())).thenReturn(getLookupValueDto());
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(getEmployee());
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(getEmployee());
		when(resourceAllocationServiceImpl.getSkillFamilyForAssociate(Mockito.anyList())).thenReturn(skillMap);
		AssociateSearchDto associateSearchDto = resourceSearchServiceImpl
				.getResourceProjectDtlsByAssociateID("Akshay Tiwari","reservedforallocation",54168L,457L);
		assertNotNull(associateSearchDto);
	}     
	
	@Test
	public void getResourceProjectDtlsByAssociatAllocApproved() throws ResourceManagementException, ParseException {
		PracticeProjectDto practiceProjectDto = new PracticeProjectDto();
		practiceProjectDto.setPracticeId(1);
		practiceProjectDto.setPracticeProjectId(100001);
		practiceProjectDto.setPracticeProjectName("AMS");
		practiceProjectDto.setProjectId(10001);
		
		List<Long> empNumberList = new ArrayList<Long>();
		empNumberList.add(52330l);
		
		List<SkillTaxonomyDto> skillTaxanomyList = new ArrayList<SkillTaxonomyDto>();
		SkillTaxonomyDto taxdto = new SkillTaxonomyDto();
		taxdto.setL1PracticeId(1l);
		taxdto.setL1PracticeName("biliubliu");
		skillTaxanomyList.add(taxdto);
		
		List<AvaibalityProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		AvaibalityProjection getSrfProjection1 = factory.createProjection(AvaibalityProjection.class);
		getSrfProjection1.setAllocatedFte(22l);
		getSrfProjection1.setEmployeeId(52330);
		srfProjectionList.add(getSrfProjection1);
		
		List<LookupValueDto> lookuTypes = new ArrayList<LookupValueDto>();
		LookupValueDto dto = new LookupValueDto();
		dto.setLookUpId(1l);
		dto.setLookupType("POOL");
		
		lookuTypes.add(dto);
		EmployeeSkillDto empdto = new EmployeeSkillDto();
		empdto.setEmployeeId(1l);
		empdto.setSkillFamilyList(skillTaxanomyList);
		 Map<Long, EmployeeSkillDto> skillMap = new HashMap<Long, EmployeeSkillDto>();
		 skillMap.put(52330l, empdto);
		
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(srfProjectionList);
        when(adminServiceClient.getEmployeeDetails(Mockito.anyLong())).thenReturn(getEmployee());
		when(adminServiceClient.getLeaveDetails(Mockito.anyLong())).thenReturn(null);
		when(adminServiceClient.getPracticeProject(Mockito.anyLong())).thenReturn(practiceProjectDto);
		when(tAssociateAllocationRepository.searchEmployeeNonBillableUtilization(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		when(resourceRequirementServiceImpl.getWorkingDaysBetweenTwoDates(Mockito.any(), Mockito.any())).thenReturn(2);
		//when(tAssociateAllocationRepository.searchEmployeeBillableUtilization(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.searchEmployeeEBRUtilization(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.searchAllocatedToProject(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(),Mockito.anyLong(), Mockito.anyLong(), null)).thenReturn(getallocatedResourceProjectionNull());
		when(tAssociateAllocationRepository.getEmpNumbers(Mockito.anyList())).thenReturn(empNumberList);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(getResourceRequirementDtos());
		when(tSrfRepository.findBysrfId(Mockito.anyList())).thenReturn(getSrfProjections());
		when(allocatedHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
        when(adminServiceClient.getSuperVisiorList(Mockito.anyList())).thenReturn(getSupervisiorList());
        when(adminServiceClient.getSkillFamilyByskillId(Mockito.anyList())).thenReturn(skillTaxanomyList);
        when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(getProjectList());
		when( adminServiceClient.getLookupValueByLookupType(Mockito.anyString())).thenReturn(lookuTypes);
        when(adminServiceClient.getLookUpById(Mockito.anyInt())).thenReturn(getLookupValueDto());
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(getEmployee());
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(getEmployee());
		when(resourceAllocationServiceImpl.getSkillFamilyForAssociate(Mockito.anyList())).thenReturn(skillMap);
		AssociateSearchDto associateSearchDto = resourceSearchServiceImpl
				.getResourceProjectDtlsByAssociateID("Akshay Tiwari","allocationapproved",54168L,457L);
		assertNotNull(associateSearchDto);
	}     
	
	
	@Test
	public void getResourceProjectDtlsByAssociatereservedfordeallocation() throws ResourceManagementException, ParseException {
		PracticeProjectDto practiceProjectDto = new PracticeProjectDto();
		practiceProjectDto.setPracticeId(1);
		practiceProjectDto.setPracticeProjectId(100001);
		practiceProjectDto.setPracticeProjectName("AMS");
		practiceProjectDto.setProjectId(10001);
		
		List<Long> empNumberList = new ArrayList<Long>();
		empNumberList.add(52330l);
		
		List<SkillTaxonomyDto> skillTaxanomyList = new ArrayList<SkillTaxonomyDto>();
		SkillTaxonomyDto taxdto = new SkillTaxonomyDto();
		taxdto.setL1PracticeId(1l);
		taxdto.setL1PracticeName("biliubliu");
		skillTaxanomyList.add(taxdto);
		
		List<AvaibalityProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		AvaibalityProjection getSrfProjection1 = factory.createProjection(AvaibalityProjection.class);
		getSrfProjection1.setAllocatedFte(22l);
		getSrfProjection1.setEmployeeId(52330);
		srfProjectionList.add(getSrfProjection1);
		
		List<LookupValueDto> lookuTypes = new ArrayList<LookupValueDto>();
		LookupValueDto dto = new LookupValueDto();
		dto.setLookUpId(1l);
		dto.setLookupType("POOL");
		
		lookuTypes.add(dto);
		EmployeeSkillDto empdto = new EmployeeSkillDto();
		empdto.setEmployeeId(1l);
		empdto.setSkillFamilyList(skillTaxanomyList);
		 Map<Long, EmployeeSkillDto> skillMap = new HashMap<Long, EmployeeSkillDto>();
		 skillMap.put(52330l, empdto);
		
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(srfProjectionList);
        when(adminServiceClient.getEmployeeDetails(Mockito.anyLong())).thenReturn(getEmployee());
		when(adminServiceClient.getLeaveDetails(Mockito.anyLong())).thenReturn(null);
		when(adminServiceClient.getPracticeProject(Mockito.anyLong())).thenReturn(practiceProjectDto);
		when(tAssociateAllocationRepository.searchEmployeeNonBillableUtilization(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		when(resourceRequirementServiceImpl.getWorkingDaysBetweenTwoDates(Mockito.any(), Mockito.any())).thenReturn(2);
		//when(tAssociateAllocationRepository.searchEmployeeBillableUtilization(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.searchEmployeeEBRUtilization(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.searchAllocatedToProject(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(),Mockito.anyLong(), Mockito.anyLong(), null)).thenReturn(getallocatedResourceProjectionNull());
		when(tAssociateAllocationRepository.getEmpNumbers(Mockito.anyList())).thenReturn(empNumberList);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(getResourceRequirementDtos());
		when(tSrfRepository.findBysrfId(Mockito.anyList())).thenReturn(getSrfProjections());
		when(allocatedHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
        when(adminServiceClient.getSuperVisiorList(Mockito.anyList())).thenReturn(getSupervisiorList());
        when(adminServiceClient.getSkillFamilyByskillId(Mockito.anyList())).thenReturn(skillTaxanomyList);
        when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(getProjectList());
		when( adminServiceClient.getLookupValueByLookupType(Mockito.anyString())).thenReturn(lookuTypes);
        when(adminServiceClient.getLookUpById(Mockito.anyInt())).thenReturn(getLookupValueDto());
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(getEmployee());
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(getEmployee());
		when(resourceAllocationServiceImpl.getSkillFamilyForAssociate(Mockito.anyList())).thenReturn(skillMap);
		AssociateSearchDto associateSearchDto = resourceSearchServiceImpl
				.getResourceProjectDtlsByAssociateID("Akshay Tiwari","reservedfordeallocation",54168L,457L);
		assertNotNull(associateSearchDto);
	}     
	
	@Test
	public void getResourceProjectDtlsByAssociatedeallocationApproved() throws ResourceManagementException, ParseException {
		PracticeProjectDto practiceProjectDto = new PracticeProjectDto();
		practiceProjectDto.setPracticeId(1);
		practiceProjectDto.setPracticeProjectId(100001);
		practiceProjectDto.setPracticeProjectName("AMS");
		practiceProjectDto.setProjectId(10001);
		
		List<Long> empNumberList = new ArrayList<Long>();
		empNumberList.add(52330l);
		
		List<SkillTaxonomyDto> skillTaxanomyList = new ArrayList<SkillTaxonomyDto>();
		SkillTaxonomyDto taxdto = new SkillTaxonomyDto();
		taxdto.setL1PracticeId(1l);
		taxdto.setL1PracticeName("biliubliu");
		skillTaxanomyList.add(taxdto);
		
		List<AvaibalityProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		AvaibalityProjection getSrfProjection1 = factory.createProjection(AvaibalityProjection.class);
		getSrfProjection1.setAllocatedFte(22l);
		getSrfProjection1.setEmployeeId(52330);
		srfProjectionList.add(getSrfProjection1);
		
		List<LookupValueDto> lookuTypes = new ArrayList<LookupValueDto>();
		LookupValueDto dto = new LookupValueDto();
		dto.setLookUpId(1l);
		dto.setLookupType("POOL");
		
		lookuTypes.add(dto);
		EmployeeSkillDto empdto = new EmployeeSkillDto();
		empdto.setEmployeeId(1l);
		empdto.setSkillFamilyList(skillTaxanomyList);
		 Map<Long, EmployeeSkillDto> skillMap = new HashMap<Long, EmployeeSkillDto>();
		 skillMap.put(52330l, empdto);
		
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(srfProjectionList);
        when(adminServiceClient.getEmployeeDetails(Mockito.anyLong())).thenReturn(getEmployee());
		when(adminServiceClient.getLeaveDetails(Mockito.anyLong())).thenReturn(null);
		when(adminServiceClient.getPracticeProject(Mockito.anyLong())).thenReturn(practiceProjectDto);
		when(tAssociateAllocationRepository.searchEmployeeNonBillableUtilization(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		when(resourceRequirementServiceImpl.getWorkingDaysBetweenTwoDates(Mockito.any(), Mockito.any())).thenReturn(2);
		//when(tAssociateAllocationRepository.searchEmployeeBillableUtilization(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.searchEmployeeEBRUtilization(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.searchAllocatedToProject(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(),Mockito.anyLong(), Mockito.anyLong(), null)).thenReturn(getallocatedResourceProjectionNull());
		when(tAssociateAllocationRepository.getEmpNumbers(Mockito.anyList())).thenReturn(empNumberList);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(getResourceRequirementDtos());
		when(tSrfRepository.findBysrfId(Mockito.anyList())).thenReturn(getSrfProjections());
		when(allocatedHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
        when(adminServiceClient.getSuperVisiorList(Mockito.anyList())).thenReturn(getSupervisiorList());
        when(adminServiceClient.getSkillFamilyByskillId(Mockito.anyList())).thenReturn(skillTaxanomyList);
        when(bapServiceClient.getProjectDetailByIds(Mockito.anyList())).thenReturn(getProjectList());
		when( adminServiceClient.getLookupValueByLookupType(Mockito.anyString())).thenReturn(lookuTypes);
        when(adminServiceClient.getLookUpById(Mockito.anyInt())).thenReturn(getLookupValueDto());
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(getEmployee());
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(getEmployee());
		when(resourceAllocationServiceImpl.getSkillFamilyForAssociate(Mockito.anyList())).thenReturn(skillMap);
		AssociateSearchDto associateSearchDto = resourceSearchServiceImpl
				.getResourceProjectDtlsByAssociateID("Akshay Tiwari","deallocationapproved",54168L,457L);
		assertNotNull(associateSearchDto);
	}     

}
