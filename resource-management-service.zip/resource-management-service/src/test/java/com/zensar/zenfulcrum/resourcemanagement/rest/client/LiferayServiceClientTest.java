package com.zensar.zenfulcrum.resourcemanagement.rest.client;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.zensar.zenfulcrum.resourcemanagement.dto.MailTemplateDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.LiferayServiceClient;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class LiferayServiceClientTest {
	
	@Mock
	private RestTemplate restTemplate;
	@InjectMocks
	private LiferayServiceClient liferayServiceClient;	
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(liferayServiceClient, "liferayBaseUrl", "liferayBaseUrl");
	}
	
	@Test 
	public void getEmailTemplateTest() throws Exception {
		MailTemplateDto ipMailTemplateDto =  new MailTemplateDto();
		ResponseEntity<MailTemplateDto> responseEntityObj = new ResponseEntity<>(ipMailTemplateDto, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<MailTemplateDto>>any()))
		.thenReturn(responseEntityObj);
		MailTemplateDto opMailTemplateDto = liferayServiceClient.getEmailTemplate("RMA");
		assertNotNull(opMailTemplateDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<MailTemplateDto>>any());

	}

	@Test 
	public void getEmailTemplateTestNull() throws Exception {
		ResponseEntity<MailTemplateDto> responseEntityObj = new ResponseEntity<>(null, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<MailTemplateDto>>any()))
		.thenReturn(responseEntityObj);
		MailTemplateDto opMailTemplateDto = liferayServiceClient.getEmailTemplate("RMA");
		assertNull(opMailTemplateDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<MailTemplateDto>>any());
	}

	@Test 
	public void getEmailTemplateTestDiffStatusCode() throws Exception {
		ResponseEntity<MailTemplateDto> responseEntityObj = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<MailTemplateDto>>any()))
		.thenReturn(responseEntityObj);
		MailTemplateDto opMailTemplateDto = liferayServiceClient.getEmailTemplate("RMA");
		assertNull(opMailTemplateDto);
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<MailTemplateDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getEmailTemplateTestResourceException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<MailTemplateDto>>any()))
		.thenThrow(new ResourceAccessException("TestError"));
		liferayServiceClient.getEmailTemplate("RMA");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<MailTemplateDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getEmailTemplateTestHttpServerException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<MailTemplateDto>>any()))
		.thenThrow(HttpServerErrorException.class);
		liferayServiceClient.getEmailTemplate("RMA");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<MailTemplateDto>>any());
	}

	@Test(expected = ResourceManagementException.class)
	public void getEmailTemplateTestHttpClientException() throws Exception {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<MailTemplateDto>>any()))
		.thenThrow(HttpClientErrorException.class);
		liferayServiceClient.getEmailTemplate("RMA");
		verify(restTemplate, times(1)).exchange(Mockito.anyString(), Mockito.any(),
				Mockito.<HttpEntity<String>>any(), Mockito.<ParameterizedTypeReference<MailTemplateDto>>any());
	}
	
}
