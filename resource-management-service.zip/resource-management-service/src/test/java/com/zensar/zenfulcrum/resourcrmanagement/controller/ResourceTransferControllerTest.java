package com.zensar.zenfulcrum.resourcrmanagement.controller;

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.controller.ResourceTransferController;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTWithinSamePhaseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TransferResourceListDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceTransferService;

@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceTransferControllerTest {

	@InjectMocks
	private ResourceTransferController resourceTransferController;

	@Mock
	private ResourceTransferService resourceTransferService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
  

	@Test
	public void updateResTransferInSameProjectTest() throws ResourceManagementException, ParseException {
		RTWithinSamePhaseDto rtWithinSamePhaseDto = new RTWithinSamePhaseDto();

		rtWithinSamePhaseDto.setUserId(111l);
		//rtWithinSamePhaseDto.setEffectiveStartDate(new Date());
		rtWithinSamePhaseDto.setRoleId(1l);

		List<TransferResourceListDto> resourceList = new ArrayList<>();
		TransferResourceListDto resource1 = new TransferResourceListDto();
		resource1.setRequirementId(12l);
		resource1.setRoleId(100l);
		resource1.setWorkLocationId(12l);

		List<Long> employeeIdList = new ArrayList<>();
		employeeIdList.add(1111l);
		employeeIdList.add(2222l);
		resource1.setEmployeeIdList(employeeIdList);
		resourceList.add(resource1);

		rtWithinSamePhaseDto.setRequirementList(resourceList);

		doNothing().when(resourceTransferService).updateResTransferInSameProject(Mockito.any());
		// when(resourceTransferService.updateResTransferInSamePhase(Mockito.any())).thenReturn(rtWithinSamePhaseDto);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceTransferController
				.updateResTransferInSameProject(rtWithinSamePhaseDto);
		assertEquals(201, responseEntityObj.getStatusCodeValue());
		verify(resourceTransferService, times(1)).updateResTransferInSameProject(Mockito.any());
	}

	@Test
	public void updateResTransferInSameProjectNullTest() throws ResourceManagementException, ParseException {
		RTWithinSamePhaseDto rtWithinSamePhaseDto = new RTWithinSamePhaseDto();

		rtWithinSamePhaseDto.setUserId(111l);
		//rtWithinSamePhaseDto.setEffectiveStartDate(new Date());
		rtWithinSamePhaseDto.setRoleId(1l);

		List<TransferResourceListDto> resourceList =null;
		TransferResourceListDto resource1 = new TransferResourceListDto();
		resource1.setRequirementId(12l);
		resource1.setRoleId(100l);
		resource1.setWorkLocationId(12l);

		List<Long> employeeIdList = new ArrayList<>();
		employeeIdList.add(1111l);
		employeeIdList.add(2222l);
		resource1.setEmployeeIdList(employeeIdList);

		rtWithinSamePhaseDto.setRequirementList(resourceList);

		doNothing().when(resourceTransferService).updateResTransferInSameProject(Mockito.any());
		ResponseEntity<RMResponseDto> responseEntityObj = resourceTransferController
				.updateResTransferInSameProject(rtWithinSamePhaseDto);
		assertEquals(400, responseEntityObj.getStatusCodeValue());
		//verify(resourceTransferService, times(1)).updateResTransferInSamePhase(Mockito.any());
	}


	@Test
	public void saveRTWithinODCAndProjectTest() throws ResourceManagementException, ParseException {

		RMApprovalInputDto rtInputDto = new RMApprovalInputDto();
		rtInputDto.setCurrentProjectId(40002L);
		rtInputDto.setProjectId(40001L);
		rtInputDto.setUserId(52338L);

		doNothing().when(resourceTransferService).saveRTWithinODCAndProjectAndBU(Mockito.any());
		ResponseEntity<RMResponseDto> responseEntityObj = resourceTransferController
				.saveRTWithinODCAndProjectAndBU(rtInputDto);
		assertEquals(201, responseEntityObj.getStatusCodeValue());
		verify(resourceTransferService, times(1)).saveRTWithinODCAndProjectAndBU(Mockito.any());
	}

	@Test
	public void saveRTWithinODCAndProjectNullTest() throws ResourceManagementException, ParseException {
		RMApprovalInputDto rtInputDto = null;
		doNothing().when(resourceTransferService).saveRTWithinODCAndProjectAndBU(Mockito.any());
		ResponseEntity<RMResponseDto> responseEntityObj = resourceTransferController
				.saveRTWithinODCAndProjectAndBU(rtInputDto);
		assertEquals(400, responseEntityObj.getStatusCodeValue());
	}

	@Test
	public void rejectRTWithinODCAndProjectTest() throws ResourceManagementException {

		RMApprovalInputDto rtInputDto = new RMApprovalInputDto();
		rtInputDto.setCurrentProjectId(40002L);
		rtInputDto.setProjectId(40001L);
		rtInputDto.setUserId(52338L);

		doNothing().when(resourceTransferService).rejectRTWithinODCAndProjectAndBU(Mockito.any());
		ResponseEntity<RMResponseDto> responseEntityObj = resourceTransferController
				.rejectRTWithinODCAndProjectAndBU(List.of(rtInputDto));
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(resourceTransferService, times(1)).rejectRTWithinODCAndProjectAndBU(Mockito.any());
	}

	@Test
	public void rejectRTWithinODCAndProjectNullTest() throws ResourceManagementException {
		List<RMApprovalInputDto> rtInputDto = null;

		doNothing().when(resourceTransferService).rejectRTWithinODCAndProjectAndBU(Mockito.any());
		ResponseEntity<RMResponseDto> responseEntityObj = resourceTransferController
				.rejectRTWithinODCAndProjectAndBU(rtInputDto);
		assertEquals(400, responseEntityObj.getStatusCodeValue());
	}


	@Test
	public void getAllocatedResourceFTETest() throws ResourceManagementException {
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");
		resourceRequirementAndFteDto.setEmployeeList(employeeList);
		when(resourceTransferService.getAllocatedResourceFTE(Mockito.anyLong(), Mockito.anyString()))
				.thenReturn(resourceRequirementAndFteDto);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceTransferController.getAllocatedResource(123L,
				"transferBetweenPhases");
		assertNotNull(responseEntityObj);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(resourceTransferService, times(1)).getAllocatedResourceFTE(123L, "transferBetweenPhases");
	}

	@Test
	public void getAllocatedResourceFTENull() throws ResourceManagementException {

		when(resourceTransferService.getAllocatedResourceFTE(Mockito.anyLong(), Mockito.anyString())).thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceTransferController.getAllocatedResource(123L,
				"transferBetweenPhases");
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceTransferService, times(1)).getAllocatedResourceFTE(123L, "transferBetweenPhases");
	}
	
	
	@Test
	public void getProjectFromSameOdc() throws ResourceManagementException {
		List<ProjectDto> projectList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");
		projectList.add(projectDto);
		when(resourceTransferService.getProjectfromSameOdc(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(projectList);
		ResponseEntity<RMResponseDto> response = resourceTransferController.getProjectFromSameOdc(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		assertNotNull(response);
		verify(resourceTransferService, times(1)).getProjectfromSameOdc(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
	}
	
	@Test
	public void getProjectFromSameOdcNoContent() throws ResourceManagementException {
		when(resourceTransferService.getProjectfromSameOdc(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		ResponseEntity<RMResponseDto> response = resourceTransferController.getProjectFromSameOdc(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		assertEquals(204, response.getStatusCodeValue());
        verify(resourceTransferService, times(1)).getProjectfromSameOdc(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
	}
	
	@Test
	public void getResourceFromIntransitProject() throws ResourceManagementException {

		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");

		when(resourceTransferService.getResourceFromIntransitProject(Mockito.anyLong(), Mockito.anyString()))
				.thenReturn(employeeDto);
		ResponseEntity<RMResponseDto> response = resourceTransferController.getResourceFromIntransitProject(123l, "123");
		assertNotNull(response);
		verify(resourceTransferService, times(1)).getResourceFromIntransitProject(Mockito.anyLong(),Mockito.anyString());

	}
	
	@Test
	public void getResourceFromIntransitProjectNullTest() throws ResourceManagementException {

		when(resourceTransferService.getResourceFromIntransitProject(Mockito.anyLong(), Mockito.anyString()))
				.thenReturn(null);
		ResponseEntity<RMResponseDto> response = resourceTransferController.getResourceFromIntransitProject(123l, "123");
		assertEquals(204, response.getStatusCodeValue());
		verify(resourceTransferService, times(1)).getResourceFromIntransitProject(Mockito.anyLong(), Mockito.anyString());

	}
	
	
    @Test
	public void approveOrRejectRTApprovalTest() throws ResourceManagementException  {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		doNothing().when(resourceTransferService).approveOrRejectRTApproval(RMApprovalInputDtlsList);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceTransferController.approveOrRejectRTApproval(RMApprovalInputDtlsList);
		assertEquals(201, responseEntityObj.getStatusCodeValue());
		assertNotNull(responseEntityObj);
		verify(resourceTransferService, times(1)).approveOrRejectRTApproval(RMApprovalInputDtlsList);
	}
}
