package com.zensar.zenfulcrum.resourcrmanagement.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.controller.ResourceProjectDetailsController;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDtlsDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceProjectDetailsService;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceTransferService;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceProjectDetailsControllerTest {
	@InjectMocks
	private ResourceProjectDetailsController resourceProjectController;
	
	@Mock
	ResourceProjectDetailsService service;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void getProjectIdsByUserIdTest() throws ResourceManagementException {
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectName("test");
		List<ProjectDto> projectDtoLsit = new ArrayList<ProjectDto>();
		projectDtoLsit.add(projectDto);
		when(service.getProjectIdsByUserId(Mockito.anyLong())).thenReturn( projectDtoLsit);
		ResponseEntity<List<ProjectDto>> responseEntityObj = resourceProjectController. getProjectIdsByUserId(1L);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		 
	}
	@Test
	public void getProjectIdsByUserIdNullTest() throws ResourceManagementException {
 
		when(service.getProjectIdsByUserId(Mockito.anyLong())).thenReturn( null);
		ResponseEntity<List<ProjectDto>> responseEntityObj = resourceProjectController.getProjectIdsByUserId(1L);
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		 
	}
	@Test
	public void getProjectMonthlyBudgetsDetailsTest() throws ResourceManagementException {
		List<ProjectBudgetDto> projectBudgetList = new ArrayList<ProjectBudgetDto>();
		ProjectBudgetDto projectBudgetDto= new ProjectBudgetDto();
		projectBudgetDto.setId(1L);
		projectBudgetList.add(projectBudgetDto);
		when(service.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudgetList);
		ResponseEntity<List<ProjectBudgetDto>> responseEntityObj = resourceProjectController. getProjectMonthlyBudgetsDetails(1L);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		 
	}
	@Test()
	public void getProjectMonthlyBudgetsDetailsNullTest() throws ResourceManagementException {
		 
		when(service.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(null);
		ResponseEntity<List<ProjectBudgetDto>> responseEntityObj = resourceProjectController. getProjectMonthlyBudgetsDetails(1L);
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		 
	}
	
	@Test
	public void getAllocatedResourcesTest() throws ResourceManagementException {
		ProjectDtlsDto projectDto = new ProjectDtlsDto();
		projectDto.setProjectName("Test");
		when(service.getAllocatedResources(Mockito.anyLong())).thenReturn(projectDto);
		ResponseEntity<ProjectDtlsDto> responseEntityObj = resourceProjectController.getAllocatedResources(1L);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
	}
	
	@Test
	public void getAllocatedResourcesNullTest() throws ResourceManagementException {
 
		when(service.getAllocatedResources(Mockito.anyLong())).thenReturn(null);
		ResponseEntity<ProjectDtlsDto> responseEntityObj = resourceProjectController.getAllocatedResources(1L);
		assertEquals(204, responseEntityObj.getStatusCodeValue());
	}
	
	
	
}
