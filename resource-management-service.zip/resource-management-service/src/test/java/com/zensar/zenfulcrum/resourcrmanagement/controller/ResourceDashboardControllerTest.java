package com.zensar.zenfulcrum.resourcrmanagement.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.controller.ResourceDashboardController;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceApprovalDashboardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TraceabilityApprSummaryDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TraceabilityCurrentStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TraceabilityDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceDashboardService;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;

@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceDashboardControllerTest {
	@InjectMocks
	private ResourceDashboardController resourceDashboardController;
	
	@Mock
	private ResourceDashboardService resourceDashboardService;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void getResourcePendingCountTest() throws ResourceManagementException {
		
		ResourceApprovalDashboardDto dto = new ResourceApprovalDashboardDto();
		
		Map<String,Integer> resourcePendingCountMap = new HashMap<>();
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_ALLOCATION_APPROVAL,12); 
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_DEALLOCATION_APPROVAL,10);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_TRANSFER_APPROVAL,8);
		resourcePendingCountMap.put(ResourceManagementConstant.PENDING_EXTENSION_APPROVAL,6);
		
		dto.setResourcePendingCountMap(resourcePendingCountMap);
		
		when(resourceDashboardService.getResourcePendingCount(Mockito.anyLong(), Mockito.anyLong())).thenReturn(dto);
		ResponseEntity<RMResponseDto> response = resourceDashboardController.getResourcePendingCount(Mockito.anyLong(), Mockito.anyLong());
		assertNotNull(response);
		verify(resourceDashboardService, times(1)).getResourcePendingCount(Mockito.anyLong(), Mockito.anyLong());
	}
	
	@Test
	public void getResourcePendingCountNoContentTest() throws ResourceManagementException {
		when(resourceDashboardService.getResourcePendingCount(Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceDashboardController.getResourcePendingCount(Long.valueOf(123),
				Long.valueOf(123));
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceDashboardService, times(1)).getResourcePendingCount(123l, 123l);
	}
	
	@Test
	public void getPendingResourceDetailsTest() throws ResourceManagementException {		
		ResourceApprovalDashboardDto resourcesPendingForApprovalDtls = new ResourceApprovalDashboardDto();		
		when(resourceDashboardService.getPendingResourceDetails(Mockito.anyLong(), Mockito.anyLong())).thenReturn(resourcesPendingForApprovalDtls);
		ResponseEntity<RMResponseDto> responseObj = resourceDashboardController.getPendingResourceDetails(Mockito.anyLong(), Mockito.anyLong());
		assertNotNull(responseObj);
		verify(resourceDashboardService, times(1)).getPendingResourceDetails(Mockito.anyLong(), Mockito.anyLong());
	}
	
	@Test
	public void getPendingResourceDetailsNoContentTest() throws ResourceManagementException {
		when(resourceDashboardService.getPendingResourceDetails(Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceDashboardController.getPendingResourceDetails(Mockito.anyLong(), Mockito.anyLong());
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceDashboardService, times(1)).getPendingResourceDetails(Mockito.anyLong(), Mockito.anyLong());
	}

	
	
	
	@Test
	public void getResourceTraceabilityTest() throws ResourceManagementException {
		
		TraceabilityDto dto = new TraceabilityDto();
		
		List<TraceabilityCurrentStatusDto> currentList = new ArrayList<>();
		TraceabilityCurrentStatusDto current1 = new TraceabilityCurrentStatusDto();
		current1.setAction("PENDING");
		current1.setApproverEmpId(1l);
		current1.setApproverName("AB");
		current1.setRoleName("PM");
		current1.setEmployeeName("XY");
		currentList.add(current1);
		dto.setCurrentStatus(currentList);
		
		List<TraceabilityApprSummaryDto> summaryList = new ArrayList<>();
		TraceabilityApprSummaryDto summary1 = new TraceabilityApprSummaryDto();
		summary1.setAction("APPR");
		summary1.setActionDate(new Date());
		summary1.setApproverName("AB");
		summary1.setComments("XY");
		summary1.setRoleName("PGM");
		summaryList.add(summary1);
		dto.setApprovalSummary(summaryList);
		
		when(resourceDashboardService.getRMPendingTraceability(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyString())).thenReturn(dto);
		ResponseEntity<RMResponseDto> response = resourceDashboardController.getRMPendingTraceability(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyString());
		assertNotNull(response);
		verify(resourceDashboardService, times(1)).getRMPendingTraceability(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyString());
	}
	
	@Test
	public void getResourceTraceabilityNoContentTest() throws ResourceManagementException {
		when(resourceDashboardService.getRMPendingTraceability(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyString())).thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceDashboardController.getRMPendingTraceability(Long.valueOf(123),
				Long.valueOf(123),Long.valueOf(123),"RALLOCATION");
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceDashboardService, times(1)).getRMPendingTraceability(Long.valueOf(123),
				Long.valueOf(123),Long.valueOf(123),"RALLOCATION");
	}

}
