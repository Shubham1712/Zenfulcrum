package com.zensar.zenfulcrum.resourcrmanagement.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.zensar.zenfulcrum.resourcemanagement.controller.ResourceRequirementController;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceRequirementService;

@Ignore
public class ResourceRequirementControllerTest {
	
	
	@InjectMocks
	private ResourceRequirementController  resourceRequirementController;

	@Mock
	private ResourceRequirementService resourceRequirementService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	
	@Test
	public void getRRforAllocation() throws ResourceManagementException {
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");
		resourceRequirementAndFteDto.setEmployeeList(employeeList);
		when(resourceRequirementService.getRRforAllocation(Mockito.anyLong()))
				.thenReturn(resourceRequirementAndFteDto);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceRequirementController.getRRforAllocation(123l);
		assertNotNull(responseEntityObj);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(resourceRequirementService, times(1)).getRRforAllocation(123l);
	}
	  
	@Test
	public void getRRforAllocationNull() throws ResourceManagementException {

		when(resourceRequirementService.getRRforAllocation(Mockito.anyLong()))
				.thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceRequirementController.getRRforAllocation(123l);
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceRequirementService, times(1)).getRRforAllocation(123l);
	}
	
	
	@Test
	public void getRRforDeallocation() throws ResourceManagementException {
	
		List<EmployeeDto> employeeList =new ArrayList<>();
		EmployeeDto employeeDto =new EmployeeDto();
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("AKSHAY T");
		employeeList.add(employeeDto);
		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setAllocateResourceQty(2l);
		resourceRequirementDto.setBand("A");
		resourceRequirementDto.setBillingEffortsPerHrs(1234);
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setProjectId(40001);
		resourceRequirementDto.setBillingRateInUSD(123);
		resourceRequirementDto.setReqId(20001);
		resourceRequirementDto.setSkills("java");
		resourceRequirementDto.setTotalResourceQty(12);
		resourceRequirementDto.setBillable(1);
		resourceRequirementDto.setResourceRequirementLocation("pune");
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setEmployeeList(employeeList);
		resourcerequirementlist.add(resourceRequirementDto);
		
		when(resourceRequirementService.getRRforDeallocation(Mockito.anyLong()))
				.thenReturn(resourcerequirementlist);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceRequirementController.getRRforDeallocation(13l);
		assertNotNull(responseEntityObj);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(resourceRequirementService, times(1)).getRRforDeallocation(Mockito.anyLong());
	}
	  
	@Test
	public void getRRforDeallocationNull() throws ResourceManagementException {

		when(resourceRequirementService.getRRforAllocation(Mockito.anyLong()))
				.thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceRequirementController.getRRforDeallocation(123l);
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceRequirementService, times(1)).getRRforDeallocation(123l);
	}
	
	@Test
	public void getRRforTransfer() throws ResourceManagementException {
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");
		resourceRequirementAndFteDto.setEmployeeList(employeeList);
		when(resourceRequirementService.getRRforTransfer(Mockito.anyLong()))
				.thenReturn(resourceRequirementAndFteDto);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceRequirementController.getRRforTransfer(123l);
		assertNotNull(responseEntityObj);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(resourceRequirementService, times(1)).getRRforTransfer(123l);
	}
	  
	@Test
	public void getRRforTransferNull() throws ResourceManagementException {

		when(resourceRequirementService.getRRforAllocation(Mockito.anyLong()))
				.thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceRequirementController.getRRforTransfer(123l);
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceRequirementService, times(1)).getRRforTransfer(123l);
	}
	 
	 
	 @Test
	 public void getMarginsTest() throws ResourceManagementException {
			ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
			resourceRequirementAndFteDto.setActualMargin(0);
			when(resourceRequirementService.getMargins(Mockito.anyLong())).thenReturn(resourceRequirementAndFteDto);
			ResponseEntity<ResourceRequirementAndFteDto> responseEntityObj = resourceRequirementController.getMargins(123l);
			assertEquals(200, responseEntityObj.getStatusCodeValue());
			verify(resourceRequirementService, times(1)).getMargins(123l);
	 
	 }

	 @Test
	 public void getMarginsNullTest() throws ResourceManagementException {
		 
			when(resourceRequirementService.getMargins(Mockito.anyLong())).thenReturn(null);
			ResponseEntity<ResourceRequirementAndFteDto> responseEntityObj = resourceRequirementController.getMargins(123l);
			assertEquals(204, responseEntityObj.getStatusCodeValue());
			verify(resourceRequirementService, times(1)).getMargins(123l);
	 
	 }
}
