package com.zensar.zenfulcrum.resourcrmanagement.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.projection.ProjectionFactory;
import org.springframework.data.projection.SpelAwareProxyProjectionFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.controller.ResourceReportDetailsController;
import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateAllocationRequestDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateAllocationResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateHistoryReportDto;

import com.zensar.zenfulcrum.resourcemanagement.dto.BapReportDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;

import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;

import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectAndAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ReportServiceException;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.projection.TAssociateAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceReportService;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceReportDetailsControllerTest {

	@InjectMocks
	private ResourceReportDetailsController resourceReportDetailsController;

	@Mock
	private ResourceReportService resourceReportService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getAssociateHistoryTest() throws ResourceManagementException {
		List<AssociateHistoryReportDto> projectList = new ArrayList<AssociateHistoryReportDto>();
		AssociateHistoryReportDto associateHistoryReportDto = new AssociateHistoryReportDto();
		associateHistoryReportDto.setActualAllocationEndDate("Test");
		projectList.add(associateHistoryReportDto);
		when(resourceReportService.resourceAllocationHistory(Mockito.anyLong())).thenReturn(projectList);
		ResponseEntity<List<AssociateHistoryReportDto>> responseEntityObj = resourceReportDetailsController
				.getAssociateHistory(1L);
		assertEquals(200, responseEntityObj.getStatusCodeValue());

	}

	@Test
	public void getAssociateHistoryNullTest() throws ResourceManagementException {

		when(resourceReportService.resourceAllocationHistory(Mockito.anyLong())).thenReturn(null);
		ResponseEntity<List<AssociateHistoryReportDto>> responseEntityObj = resourceReportDetailsController
				.getAssociateHistory(1L);
		assertEquals(204, responseEntityObj.getStatusCodeValue());

	}

	@Test
	public void getActualAndEstAllocationDateTest() throws ResourceManagementException {
		TAssociateAllocationDto tAssociateAllocationDto = new TAssociateAllocationDto();
		tAssociateAllocationDto.setSrReference("Test");
		when(resourceReportService.getActualAndEstAllocationDate(Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(tAssociateAllocationDto);
		ResponseEntity<TAssociateAllocationDto> responseEntityObj = resourceReportDetailsController
				.getActualAndEstAllocationDate(1L, 2L);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
	}

	@Test
	public void getActualAndEstAllocationDateNullTest() throws ResourceManagementException {
		when(resourceReportService.getActualAndEstAllocationDate(Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(null);
		ResponseEntity<TAssociateAllocationDto> responseEntityObj = resourceReportDetailsController
				.getActualAndEstAllocationDate(1L, 2L);
		assertEquals(204, responseEntityObj.getStatusCodeValue());
	}

	@Test
	public void getAssociateDetailsByAssociateIdTest() throws ResourceManagementException {
		List<TAssociateProjectAndAllocationDto> dtoList = new ArrayList<>();
		TAssociateProjectAndAllocationDto tAssociateAllocationDto = new TAssociateProjectAndAllocationDto();
		tAssociateAllocationDto.setEmployeeId(1l);
		dtoList.add(tAssociateAllocationDto);

		when(resourceReportService.getAssociateDetailsByAssociateId(Mockito.anyLong())).thenReturn(dtoList);
		ResponseEntity<List<TAssociateProjectAndAllocationDto>> responseEntityObj = resourceReportDetailsController
				.getAssociateDetailsByAssociateId(Mockito.anyLong());
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(resourceReportService, times(1)).getAssociateDetailsByAssociateId(Mockito.anyLong());
	}

	@Test
	public void getAssociateDetailsByAssociateIdNullTest() throws ResourceManagementException {
		when(resourceReportService.getAssociateDetailsByAssociateId(Mockito.anyLong())).thenReturn(null);
		ResponseEntity<List<TAssociateProjectAndAllocationDto>> responseEntityObj = resourceReportDetailsController
				.getAssociateDetailsByAssociateId(Mockito.anyLong());
		assertEquals(204, responseEntityObj.getStatusCodeValue());
	}

	@Test
	public void getAssociateDeallocationDetailsTest() throws ResourceManagementException {
		List<TAssociateDeAllocationDto> dtoList = new ArrayList<>();
		TAssociateDeAllocationDto allocationDto = new TAssociateDeAllocationDto();
		allocationDto.setEmployeeId(1l);
		allocationDto.setProjectId(123l);
		dtoList.add(allocationDto);

		when(resourceReportService.getAssociateDeallocationDetails()).thenReturn(dtoList);
		ResponseEntity<List<TAssociateDeAllocationDto>> responseEntityObj = resourceReportDetailsController
				.getAssociateDeallocationDetails();
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(resourceReportService, times(1)).getAssociateDeallocationDetails();
	}

	@Test
	public void getAssociateDeallocationDetailsNullTest() throws ResourceManagementException {
		when(resourceReportService.getAssociateDeallocationDetails()).thenReturn(null);
		ResponseEntity<List<TAssociateDeAllocationDto>> responseEntityObj = resourceReportDetailsController
				.getAssociateDeallocationDetails();
		assertEquals(204, responseEntityObj.getStatusCodeValue());
	}

	@Test
	public void getAssociateAllocationIdByProjectIdTest() throws ReportServiceException {
		List<TAssociateAllocationProjection> associateAllocationList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		TAssociateAllocationProjection projectProjection = factory
				.createProjection(TAssociateAllocationProjection.class);
		projectProjection.setbillableStatusId(893l);
		projectProjection.setftePercent(100);
		associateAllocationList.add(projectProjection);
		AssociateAllocationRequestDto associateAllocationRequest = new AssociateAllocationRequestDto();
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
		associateAllocationRequest.setProjectIds(projectIds);
		when(resourceReportService.getAssociateAllocationIdByProjectId(Mockito.any()))
				.thenReturn(associateAllocationList);
		ResponseEntity<AssociateAllocationResponseDto> responseEntityObj = resourceReportDetailsController
				.getAssociateAllocationIdByProjectId(associateAllocationRequest);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(resourceReportService, times(1)).getAssociateAllocationIdByProjectId(Mockito.any());
	}

	@Test
	public void getAssociateAllocationIdByProjectIdnullTest() throws ReportServiceException {
		when(resourceReportService.getAssociateAllocationIdByProjectId(Mockito.anyList())).thenReturn(null);
		AssociateAllocationRequestDto associateAllocationRequest = new AssociateAllocationRequestDto();
		List<Long> projectIds = new ArrayList<Long>();
		projectIds.add(1l);
		associateAllocationRequest.setProjectIds(projectIds);
		ResponseEntity<AssociateAllocationResponseDto> responseEntityObj = resourceReportDetailsController
				.getAssociateAllocationIdByProjectId(associateAllocationRequest);
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceReportService, times(1)).getAssociateAllocationIdByProjectId(Mockito.any());
	}

	@Test
	public void getRequirementIdsTest() throws ResourceManagementException {

		BapReportDto bapReportDto = new BapReportDto();

		when(resourceReportService.getRequirementIds(Mockito.anyLong())).thenReturn(bapReportDto);
		ResponseEntity<BapReportDto> responseEntityObj = resourceReportDetailsController.getRequirementIds(1L);
		assertEquals(200, responseEntityObj.getStatusCodeValue());

	}

	@Test
	public void getRequirementIdsNullTest() throws ResourceManagementException {

		when(resourceReportService.getRequirementIds(Mockito.anyLong())).thenReturn(null);
		ResponseEntity<BapReportDto> responseEntityObj = resourceReportDetailsController.getRequirementIds(1L);
		assertEquals(204, responseEntityObj.getStatusCodeValue());

	}

	@Test
	public void getAllocationWorkflowDetailsTest() throws ResourceManagementException {
		List<TAssociateProjectAndAllocationDto> dtoList = new ArrayList<>();
		TAssociateProjectAndAllocationDto allocationDto = new TAssociateProjectAndAllocationDto();
		allocationDto.setEmployeeId(1l);
		allocationDto.setProjectId(123l);
		dtoList.add(allocationDto);

		when(resourceReportService.getAllocationWorkflowDetails()).thenReturn(dtoList);
		ResponseEntity<List<TAssociateProjectAndAllocationDto>> responseEntityObj = resourceReportDetailsController
				.getAllocationWorkflowDetails();
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(resourceReportService, times(1)).getAllocationWorkflowDetails();
	}

	@Test
	public void getAllocationWorkflowDetailsNullTest() throws ResourceManagementException {
		when(resourceReportService.getAllocationWorkflowDetails()).thenReturn(null);
		ResponseEntity<List<TAssociateProjectAndAllocationDto>> responseEntityObj = resourceReportDetailsController
				.getAllocationWorkflowDetails();
		assertEquals(204, responseEntityObj.getStatusCodeValue());
	}
}
