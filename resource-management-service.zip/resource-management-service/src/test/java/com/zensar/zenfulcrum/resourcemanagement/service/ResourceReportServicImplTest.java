package com.zensar.zenfulcrum.resourcemanagement.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.projection.ProjectionFactory;
import org.springframework.data.projection.SpelAwareProxyProjectionFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateHistoryReportDto;

import com.zensar.zenfulcrum.resourcemanagement.dto.BapReportDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;

import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;

import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectAndAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.mapper.AssociateHistoryMapper;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateAllocationMapper;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateDeAllocation;
import com.zensar.zenfulcrum.resourcemanagement.projection.AssociateHistoryProjecation;
import com.zensar.zenfulcrum.resourcemanagement.projection.TAssociateProjectAndAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceReportServicImplTest {

	@InjectMocks
	ResourceReportServicImpl resourceReportServicImpl;

	@Mock
	private AssociateHistoryMapper associateHistoryMapper;

	@Mock
	private TAssociateProjectRepository tAssociateProjectRepository;

	@Mock
	private ResourceManagementServiceImpl resourceManagementServiceImpl;

	@Mock
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Mock
	private TAssociateAllocationMapper tAssociateAllocationMapper;

	@Mock
	TAssociateDeAllocationRepository tAssociateDeAllocationRepository;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void resourceAllocationHistoryTest() {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AssociateHistoryProjecation projection = factory.createProjection(AssociateHistoryProjecation.class);
		List<AssociateHistoryProjecation> projectionList = new ArrayList<AssociateHistoryProjecation>();
		projection.setAllocationStatus("Test");
		projectionList.add(projection);
		when(tAssociateProjectRepository.getAssociateHistory(Mockito.anyLong())).thenReturn(projectionList);
		List<AssociateHistoryReportDto> dto = resourceReportServicImpl.resourceAllocationHistory(1234L);
		assertNotNull(dto);
	}

	@Test
	public void getActualAndEstAllocationDateTest() throws ResourceManagementException {
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		tAssociateAllocation.setCreatedBy(1L);

		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString())).thenReturn(1L);
		when(tAssociateAllocationRepository.getActualAndEstAllocationDate(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(tAssociateAllocation);
		TAssociateAllocationDto dto = resourceReportServicImpl.getActualAndEstAllocationDate(1L, 1L);
		assertNull(dto);

	}

	@Test
	public void getRequirementIdsTest() throws ResourceManagementException {
		List<Long> list = new ArrayList<Long>();
		list.add(1L);
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString())).thenReturn(1L);
		when(tAssociateAllocationRepository.getRequirementIds(Mockito.anyLong(), Mockito.anyLong())).thenReturn(list);
		BapReportDto dto = resourceReportServicImpl.getRequirementIds(1L);
		assertNotNull(dto);
	}

	@Test
	public void getAssociateDetailsByAssociateIdTest() throws ResourceManagementException {
		List<TAssociateProjectAndAllocationProjection> projectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		TAssociateProjectAndAllocationProjection projection = factory
				.createProjection(TAssociateProjectAndAllocationProjection.class);
		projection.setprojectId(123l);
		projection.setemployeeId(1l);
		projectionList.add(projection);

		when(tAssociateProjectRepository.findByEmployeeId(Mockito.anyLong())).thenReturn(projectionList);
		List<TAssociateProjectAndAllocationDto> finalData = resourceReportServicImpl
				.getAssociateDetailsByAssociateId(1L);
		assertNotNull(finalData);
		verify(tAssociateProjectRepository, times(1)).findByEmployeeId(Mockito.anyLong());

	}

	@Test
	public void getAssociateDeallocationDetailsTest() throws ResourceManagementException {
		List<TAssociateDeAllocation> associateDeAllocations = new ArrayList<>();
		TAssociateDeAllocation deAllocation = new TAssociateDeAllocation();
		deAllocation.setAssociateAllocationId(1l);
		deAllocation.setFtePercent(100.00);
		associateDeAllocations.add(deAllocation);

		List<TAssociateProjectAndAllocationProjection> projectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		TAssociateProjectAndAllocationProjection projection = factory
				.createProjection(TAssociateProjectAndAllocationProjection.class);
		projection.setprojectId(123l);
		projection.setemployeeId(1l);
		projectionList.add(projection);

		when(tAssociateDeAllocationRepository.getDeallocationDetails()).thenReturn(associateDeAllocations);
		List<TAssociateDeAllocationDto> finalData = resourceReportServicImpl.getAssociateDeallocationDetails();
		assertNotNull(finalData);
		verify(tAssociateDeAllocationRepository, times(1)).getDeallocationDetails();

	}

	@Test
	public void getAllocationWorkflowDetailsTest() throws ResourceManagementException {
		List<TAssociateProjectAndAllocationDto> associateAllocations = new ArrayList<>();
		TAssociateProjectAndAllocationDto allocation = new TAssociateProjectAndAllocationDto();
		allocation.setProjectId(1234l);
		allocation.setFtePercent(100.00);
		associateAllocations.add(allocation);

		List<TAssociateProjectAndAllocationProjection> projectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		TAssociateProjectAndAllocationProjection projection = factory
				.createProjection(TAssociateProjectAndAllocationProjection.class);
		projection.setprojectId(123l);
		projection.setemployeeId(1l);
		projectionList.add(projection);

		when(tAssociateAllocationRepository.getAllocationWorkflowDetails()).thenReturn(projectionList);
		List<TAssociateProjectAndAllocationDto> finalData = resourceReportServicImpl.getAllocationWorkflowDetails();
		assertNotNull(finalData);
		verify(tAssociateAllocationRepository, times(1)).getAllocationWorkflowDetails();

	}

}
