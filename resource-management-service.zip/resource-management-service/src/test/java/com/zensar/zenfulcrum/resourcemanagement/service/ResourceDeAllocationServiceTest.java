package com.zensar.zenfulcrum.resourcemanagement.service;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.projection.ProjectionFactory;
import org.springframework.data.projection.SpelAwareProxyProjectionFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.HttpClientErrorException;

import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeallocationInputDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.JVCheckHelperService;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateDeAllocationMapper;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateDeAllocation;
import com.zensar.zenfulcrum.resourcemanagement.projection.AssociateDeAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.JVDetailsRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceDeAllocationServiceTest {

	@InjectMocks
	ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl;

	@Mock
	private BAPServiceClient bapSrvcClient;

	@Mock
	TAssociateDeAllocationRepository resourceDeallocationRepositary;

	@Mock
	AdminServiceClient adminServiceClient;

	@Mock
	private TAssociateAllocationRepository allocationRepository;

	@Mock
	TAssociateDeAllocationMapper asssociateDeallocationMapper;

	@Mock
	private HttpSession httpSession;
	
	@Mock
	private ResourceManagementServiceImpl rsrcMgmntSrvcImpl;

	@Mock
	TAssociateDeAllocationRepository tAssociateDeallocationRepository;

	@Mock
	JVDetailsRepository jvDetailsRepository;

	@Mock
	JVCheckHelperService jvCheckHelperService;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void saveResourceDeallocationsTest() throws ResourceManagementException, ParseException {
		TAssociateDeAllocationDto tAssociateDeallocationDto = new TAssociateDeAllocationDto();
		TAssociateDeAllocation associateDeallocation = new TAssociateDeAllocation();
		Calendar calender = new GregorianCalendar();
		List<TAssociateDeAllocation> associateDeallocationList = new ArrayList<>();

		associateDeallocation.setAssociateAllocationId(2L);
		associateDeallocation.setAssociateDeAllocationId(1L);
		associateDeallocation.setCreatedDate(calender.getTime());
		associateDeallocation.setDeallocationDate(calender.getTime());
		associateDeallocation.setDeallocationNotificationDate(calender.getTime());
		associateDeallocation.setDeallocationReasonId(2L);
		associateDeallocation.setEffectiveEndDate(calender.getTime());
		associateDeallocation.setEffectiveStartDate(calender.getTime());
		associateDeallocation.setEmployeeId(123L);
		associateDeallocation.setLastUpdatedBy(124L);
		associateDeallocation.setLastUpdatedDate(calender.getTime());
		associateDeallocation.setProjectId(444L);
		associateDeallocation.setRemarks("apply for deallocation");
		associateDeallocation.setRequirementId(2L);
		associateDeallocation.setWorkflowReasonId(2L);

		associateDeallocation.setStatusId(4L);
		associateDeallocation.setCreatedBy(1111L);

		tAssociateDeallocationDto.setAssociateAllocationId(2L);
		tAssociateDeallocationDto.setAssociateDeallocationId(1L);
		tAssociateDeallocationDto.setCreatedDate(calender.getTime());
		tAssociateDeallocationDto.setDeallocationDate(calender.getTime());
		tAssociateDeallocationDto.setDeallocationNotificationDate(calender.getTime());
		tAssociateDeallocationDto.setDeallocationReasonId(2L);
		tAssociateDeallocationDto.setEffectiveEndDate(calender.getTime());
		tAssociateDeallocationDto.setEffectiveStartDate(calender.getTime());
		tAssociateDeallocationDto.setEmployeeId(123L);
		tAssociateDeallocationDto.setLastUpdatedBy(124L);
		tAssociateDeallocationDto.setLastUpdatedDate(calender.getTime());
		tAssociateDeallocationDto.setProjectId(444L);
		tAssociateDeallocationDto.setRemarks("apply for deallocation");
		tAssociateDeallocationDto.setRequirementId(2L);
		tAssociateDeallocationDto.setWorkflowReasonId(2L);

		tAssociateDeallocationDto.setStatusId(4L);
		tAssociateDeallocationDto.setCreatedBy(1111L);

		List<TAssociateDeAllocationDto> associateDeallocationDto = new ArrayList<>();
		associateDeallocationDto.add(tAssociateDeallocationDto);

		associateDeallocationList.add(associateDeallocation);

		ModuleStatusDto deallocationStatusDto = new ModuleStatusDto();
		deallocationStatusDto.setModuleStatusId(4L);
		
		Date today = new Date();
		Date yesterdayDate = new Date(today.getTime() - (1000 * 60 * 60 * 24));
		
		TAssociateDeallocationInputDto tassociateDeallocationInputDto=new TAssociateDeallocationInputDto();
		tassociateDeallocationInputDto.setRoleName("PGM");
		tassociateDeallocationInputDto.setTassociateDeAllocationList(associateDeallocationDto);
		
		when(jvCheckHelperService.isJvCheck(yesterdayDate)).thenReturn(true);
		when(jvDetailsRepository.getWindowEndDate()).thenReturn(new Date());
		when(asssociateDeallocationMapper.associateDeallocationDtoToAssociateDeallocations(associateDeallocationDto))
				.thenReturn(associateDeallocationList);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(deallocationStatusDto);
		resourceDeallocationServiceImpl.saveALLResourceDeallocation(tassociateDeallocationInputDto);
		verify(adminServiceClient, times(3)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(jvDetailsRepository,times(1)).getWindowEndDate();
	}
	
	@Test
	public void saveResourceDeallocationsJvNullTest() throws ResourceManagementException, ParseException {
		TAssociateDeAllocationDto tAssociateDeallocationDto = new TAssociateDeAllocationDto();
		TAssociateDeAllocation associateDeallocation = new TAssociateDeAllocation();
		Calendar calender = new GregorianCalendar();
		List<TAssociateDeAllocation> associateDeallocationList = new ArrayList<>();

		associateDeallocation.setAssociateAllocationId(2L);
		associateDeallocation.setAssociateDeAllocationId(1L);
		associateDeallocation.setCreatedDate(calender.getTime());
		associateDeallocation.setDeallocationDate(calender.getTime());
		associateDeallocation.setDeallocationNotificationDate(calender.getTime());
		associateDeallocation.setDeallocationReasonId(2L);
		associateDeallocation.setEffectiveEndDate(calender.getTime());
		associateDeallocation.setEffectiveStartDate(calender.getTime());
		associateDeallocation.setEmployeeId(123L);
		associateDeallocation.setLastUpdatedBy(124L);
		associateDeallocation.setLastUpdatedDate(calender.getTime());
		associateDeallocation.setProjectId(444L);
		associateDeallocation.setRemarks("apply for deallocation");
		associateDeallocation.setRequirementId(2L);
		associateDeallocation.setWorkflowReasonId(2L);

		associateDeallocation.setStatusId(4L);
		associateDeallocation.setCreatedBy(1111L);

		tAssociateDeallocationDto.setAssociateAllocationId(2L);
		tAssociateDeallocationDto.setAssociateDeallocationId(1L);
		tAssociateDeallocationDto.setCreatedDate(calender.getTime());
		tAssociateDeallocationDto.setDeallocationDate(calender.getTime());
		tAssociateDeallocationDto.setDeallocationNotificationDate(calender.getTime());
		tAssociateDeallocationDto.setDeallocationReasonId(2L);
		tAssociateDeallocationDto.setEffectiveEndDate(calender.getTime());
		tAssociateDeallocationDto.setEffectiveStartDate(calender.getTime());
		tAssociateDeallocationDto.setEmployeeId(123L);
		tAssociateDeallocationDto.setLastUpdatedBy(124L);
		tAssociateDeallocationDto.setLastUpdatedDate(calender.getTime());
		tAssociateDeallocationDto.setProjectId(444L);
		tAssociateDeallocationDto.setRemarks("apply for deallocation");
		tAssociateDeallocationDto.setRequirementId(2L);
		tAssociateDeallocationDto.setWorkflowReasonId(2L);

		tAssociateDeallocationDto.setStatusId(4L);
		tAssociateDeallocationDto.setCreatedBy(1111L);

		List<TAssociateDeAllocationDto> associateDeallocationDto = new ArrayList<>();
		associateDeallocationDto.add(tAssociateDeallocationDto);

		associateDeallocationList.add(associateDeallocation);

		ModuleStatusDto deallocationStatusDto = new ModuleStatusDto();
		deallocationStatusDto.setModuleStatusId(4L);
		
		TAssociateDeallocationInputDto tassociateDeallocationInputDto=new TAssociateDeallocationInputDto();
		tassociateDeallocationInputDto.setRoleName("PGM");
		tassociateDeallocationInputDto.setTassociateDeAllocationList(associateDeallocationDto);
		Date today = new Date();
		Date yesterdayDate = new Date(today.getTime() - (1000 * 60 * 60 * 24));
		
		when(jvCheckHelperService.isJvCheck(yesterdayDate)).thenReturn(null);
		when(jvDetailsRepository.getWindowEndDate()).thenReturn(new Date());
		when(asssociateDeallocationMapper.associateDeallocationDtoToAssociateDeallocations(associateDeallocationDto))
				.thenReturn(associateDeallocationList);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(deallocationStatusDto);
		resourceDeallocationServiceImpl.saveALLResourceDeallocation(tassociateDeallocationInputDto);
		verify(adminServiceClient, times(3)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(jvDetailsRepository,times(1)).getWindowEndDate();
	}

	@Test
	public void saveDeallocationByAdmin() throws ResourceManagementException, ParseException {
		TAssociateDeAllocationDto tAssociateDeallocationDto = new TAssociateDeAllocationDto();
		TAssociateDeAllocation associateDeallocation = new TAssociateDeAllocation();
		Calendar calender = new GregorianCalendar();
		List<TAssociateDeAllocation> associateDeallocationList = new ArrayList<>();

		associateDeallocation.setAssociateAllocationId(2L);
		associateDeallocation.setAssociateDeAllocationId(1L);
		associateDeallocation.setCreatedDate(calender.getTime());
		associateDeallocation.setDeallocationDate(calender.getTime());
		associateDeallocation.setDeallocationNotificationDate(calender.getTime());
		associateDeallocation.setDeallocationReasonId(2L);
		associateDeallocation.setEffectiveEndDate(calender.getTime());
		associateDeallocation.setEffectiveStartDate(calender.getTime());
		associateDeallocation.setEmployeeId(123L);
		associateDeallocation.setLastUpdatedBy(124L);
		associateDeallocation.setLastUpdatedDate(calender.getTime());
		associateDeallocation.setProjectId(444L);
		associateDeallocation.setRemarks("apply for deallocation");
		associateDeallocation.setRequirementId(2L);
		associateDeallocation.setWorkflowReasonId(2L);

		associateDeallocation.setStatusId(4L);
		associateDeallocation.setCreatedBy(1111L);

		tAssociateDeallocationDto.setAssociateAllocationId(2L);
		tAssociateDeallocationDto.setAssociateDeallocationId(1L);
		tAssociateDeallocationDto.setCreatedDate(calender.getTime());
		tAssociateDeallocationDto.setDeallocationDate(calender.getTime());
		tAssociateDeallocationDto.setDeallocationNotificationDate(calender.getTime());
		tAssociateDeallocationDto.setDeallocationReasonId(2L);
		tAssociateDeallocationDto.setEffectiveEndDate(calender.getTime());
		tAssociateDeallocationDto.setEffectiveStartDate(calender.getTime());
		tAssociateDeallocationDto.setEmployeeId(123L);
		tAssociateDeallocationDto.setLastUpdatedBy(124L);
		tAssociateDeallocationDto.setLastUpdatedDate(calender.getTime());
		tAssociateDeallocationDto.setProjectId(444L);
		tAssociateDeallocationDto.setRemarks("apply for deallocation");
		tAssociateDeallocationDto.setRequirementId(2L);
		tAssociateDeallocationDto.setWorkflowReasonId(2L);

		tAssociateDeallocationDto.setStatusId(4L);
		tAssociateDeallocationDto.setCreatedBy(1111L);

		List<TAssociateDeAllocationDto> associateDeallocationDto = new ArrayList<>();
		associateDeallocationDto.add(tAssociateDeallocationDto);

		associateDeallocationList.add(associateDeallocation);

		TAssociateDeallocationInputDto tassociateDeallocationInputDto=new TAssociateDeallocationInputDto();
		tassociateDeallocationInputDto.setRoleName("ADMIN");
		tassociateDeallocationInputDto.setTassociateDeAllocationList(associateDeallocationDto);
		
		ModuleStatusDto deallocationStatusDto = new ModuleStatusDto();
		deallocationStatusDto.setModuleStatusId(4L);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1L);
		ModuleStatusDto ModuleDto = new ModuleStatusDto();
		ModuleDto.setModuleCode("RMDA");
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<AssociateDeAllocationProjection> rDeAllocationDtlsListObj = new ArrayList<>();
		AssociateDeAllocationProjection tAssociateDeAllocationObj = factory
				.createProjection(AssociateDeAllocationProjection.class);
		tAssociateDeAllocationObj.setAssociateAllocationId(1L);
		tAssociateDeAllocationObj.setAssociateDeAllocationId(1L);
		tAssociateDeAllocationObj.setFtePercent(100.00);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		tAssociateDeAllocationObj.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		tAssociateDeAllocationObj.setActualAllocationEndDate(dateFormat.parse("2020-06-30"));
		tAssociateDeAllocationObj.setEstAllocationEndDate(dateFormat.parse("2020-06-30"));
		tAssociateDeAllocationObj.setDeallocationDate(dateFormat.parse("2020-06-25"));
		rDeAllocationDtlsListObj.add(tAssociateDeAllocationObj);

		when(asssociateDeallocationMapper.associateDeallocationDtoToAssociateDeallocations(associateDeallocationDto))
				.thenReturn(associateDeallocationList);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(deallocationStatusDto);
		when(rsrcMgmntSrvcImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
		when(tAssociateDeallocationRepository.getRDeAllocationRequiredDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(rDeAllocationDtlsListObj);
		resourceDeallocationServiceImpl.saveALLResourceDeallocation(tassociateDeallocationInputDto);
		verify(adminServiceClient, times(3)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(adminServiceClient, times(3)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());

	}
	
	@Test
	public void saveDeallocationByTag() throws ResourceManagementException, ParseException {
		TAssociateDeAllocationDto tAssociateDeallocationDto = new TAssociateDeAllocationDto();
		TAssociateDeAllocation associateDeallocation = new TAssociateDeAllocation();
		Calendar calender = new GregorianCalendar();
		List<TAssociateDeAllocation> associateDeallocationList = new ArrayList<>();

		associateDeallocation.setAssociateAllocationId(2L);
		associateDeallocation.setAssociateDeAllocationId(1L);
		associateDeallocation.setCreatedDate(calender.getTime());
		associateDeallocation.setDeallocationDate(calender.getTime());
		associateDeallocation.setDeallocationNotificationDate(calender.getTime());
		associateDeallocation.setDeallocationReasonId(2L);
		associateDeallocation.setEffectiveEndDate(calender.getTime());
		associateDeallocation.setEffectiveStartDate(calender.getTime());
		associateDeallocation.setEmployeeId(123L);
		associateDeallocation.setLastUpdatedBy(124L);
		associateDeallocation.setLastUpdatedDate(calender.getTime());
		associateDeallocation.setProjectId(444L);
		associateDeallocation.setRemarks("apply for deallocation");
		associateDeallocation.setRequirementId(2L);
		associateDeallocation.setWorkflowReasonId(2L);

		associateDeallocation.setStatusId(4L);
		associateDeallocation.setCreatedBy(1111L);

		tAssociateDeallocationDto.setAssociateAllocationId(2L);
		tAssociateDeallocationDto.setAssociateDeallocationId(1L);
		tAssociateDeallocationDto.setCreatedDate(calender.getTime());
		tAssociateDeallocationDto.setDeallocationDate(calender.getTime());
		tAssociateDeallocationDto.setDeallocationNotificationDate(calender.getTime());
		tAssociateDeallocationDto.setDeallocationReasonId(2L);
		tAssociateDeallocationDto.setEffectiveEndDate(calender.getTime());
		tAssociateDeallocationDto.setEffectiveStartDate(calender.getTime());
		tAssociateDeallocationDto.setEmployeeId(123L);
		tAssociateDeallocationDto.setLastUpdatedBy(124L);
		tAssociateDeallocationDto.setLastUpdatedDate(calender.getTime());
		tAssociateDeallocationDto.setProjectId(444L);
		tAssociateDeallocationDto.setRemarks("apply for deallocation");
		tAssociateDeallocationDto.setRequirementId(2L);
		tAssociateDeallocationDto.setWorkflowReasonId(2L);

		tAssociateDeallocationDto.setStatusId(4L);
		tAssociateDeallocationDto.setCreatedBy(1111L);

		List<TAssociateDeAllocationDto> associateDeallocationDto = new ArrayList<>();
		associateDeallocationDto.add(tAssociateDeallocationDto);

		associateDeallocationList.add(associateDeallocation);

		TAssociateDeallocationInputDto tassociateDeallocationInputDto=new TAssociateDeallocationInputDto();
		tassociateDeallocationInputDto.setRoleName("TAG");
		tassociateDeallocationInputDto.setTassociateDeAllocationList(associateDeallocationDto);
		
		ModuleStatusDto deallocationStatusDto = new ModuleStatusDto();
		deallocationStatusDto.setModuleStatusId(4L);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1L);
		ModuleStatusDto ModuleDto = new ModuleStatusDto();
		ModuleDto.setModuleCode("RMDA");
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<AssociateDeAllocationProjection> rDeAllocationDtlsListObj = new ArrayList<>();
		AssociateDeAllocationProjection tAssociateDeAllocationObj = factory
				.createProjection(AssociateDeAllocationProjection.class);
		tAssociateDeAllocationObj.setAssociateAllocationId(1L);
		tAssociateDeAllocationObj.setAssociateDeAllocationId(1L);
		tAssociateDeAllocationObj.setFtePercent(100.00);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		tAssociateDeAllocationObj.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		tAssociateDeAllocationObj.setActualAllocationEndDate(dateFormat.parse("2020-06-30"));
		tAssociateDeAllocationObj.setEstAllocationEndDate(dateFormat.parse("2020-06-30"));
		tAssociateDeAllocationObj.setDeallocationDate(dateFormat.parse("2020-06-25"));
		rDeAllocationDtlsListObj.add(tAssociateDeAllocationObj);

		when(asssociateDeallocationMapper.associateDeallocationDtoToAssociateDeallocations(associateDeallocationDto))
				.thenReturn(associateDeallocationList);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(deallocationStatusDto);
		when(rsrcMgmntSrvcImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
		when(tAssociateDeallocationRepository.getRDeAllocationRequiredDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(rDeAllocationDtlsListObj);
		resourceDeallocationServiceImpl.saveALLResourceDeallocation(tassociateDeallocationInputDto);
		verify(adminServiceClient, times(3)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(adminServiceClient, times(3)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());

	}
}
