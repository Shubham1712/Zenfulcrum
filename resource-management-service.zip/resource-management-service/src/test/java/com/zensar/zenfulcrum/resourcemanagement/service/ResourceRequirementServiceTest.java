package com.zensar.zenfulcrum.resourcemanagement.service;

import static org.junit.Assert.assertNotNull;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.projection.ProjectionFactory;
import org.springframework.data.projection.SpelAwareProxyProjectionFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.HashBasedTable;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBuDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.AllocatedResourceHelperClass;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateProjectMapper;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.GetResourceReqProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.ReservedAssociateProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceDeAllocationServiceImpl;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceRequirementServiceImpl;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceRequirementServiceTest {

	@InjectMocks
	private ResourceRequirementServiceImpl resourceRequirementServiceImpl;
	/*
	 * @Mock private BAPServiceClient bapServiceClient;
	 */

	
	  @Mock 
	  private TAssociateAllocationRepository tAssociateAllocationRepository;
	 
	@Mock
	private BudgetControlServiceClient budgetControlServiceClient;

	@Mock
	TAssociateProjectMapper asssociateProjectMapper;

	@Mock
	TAssociateAllocationRepository allocationRepository;

	@Mock  
	AdminServiceClient adminServiceClient;

	@Mock
	TAssociateDeAllocationRepository resourceDeallocationRepositary;

	@Mock
	BAPServiceClient bapServiceClient;
	
	@Mock
	AllocatedResourceHelperClass  allocatedResourceHelperClass;
	
	@Mock
	ResourceAllocationServiceImpl resourceAllocationServiceImpl;
  
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	private List<ProjectBudgetDto> getProjectBudgetDto() throws ParseException {
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(200000.00);
		projectBudgetDto1.setConsumedBudget(10.00);  
  
		projectBudget.add(projectBudgetDto1);

		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto2.setBudgetCurrency(5.0);
		projectBudgetDto2.setMonth("2020-07");
		projectBudgetDto2.setAvailableBudget(300000.00);
  
		projectBudget.add(projectBudgetDto2);
		return projectBudget;
	}

	
	@Test
	public void getResourceRequirementListTest() throws ResourceManagementException, ParseException {
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		resourceRequirementAndFteDto.setTotalBapFte(30.00);
		resourceRequirementAndFteDto.setProjectBillingType("Billable");
		resourceRequirementAndFteDto.setPoOrderValue(223456.0);
		resourceRequirementAndFteDto.setActualMargin(22.23);
		resourceRequirementAndFteDto.setProjectedMargin(33.44);
		DecimalFormat df = new DecimalFormat("#.##");
		//double a = Double.parseDouble(df.format(actualMargin));
		//double p = Double.parseDouble(df.format(projectedmargin));
		
		List<ResourceRequirementDto> resourceReqList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(4);
		resourceRequirementDto.setResourceRequirementLocation("Pune");
		resourceReqList.add(resourceRequirementDto);
		resourceRequirementAndFteDto.setTotalBudget(12345);
		resourceRequirementDto.setRequirmentEffortsHours(222.00);
		resourceRequirementDto.setRequirmentCostRate(22.00);
		resourceRequirementAndFteDto.setResourceRequirementDto(resourceReqList);
		List<Long> reqIds = new ArrayList<>();
		reqIds.add(1l);
		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(4);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection);

		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory1 = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory1
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(4);
		allocatedResourceProjection.setEmployeeId(1L);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setEstEndDate(dateFormat.parse("2020-04-01"));
		allocatedResourceProjection.setActualStartDate(dateFormat.parse("2020-06-01"));
		allocatedResourceProjection.setBillableStatusId(ResourceManagementConstant.EBR);
		allocatedResourceProjection.setemployeeCostRate(22.0);
		associateList.add(allocatedResourceProjection);
	       when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
        when(allocatedResourceHelperClass.getRoundedOffValue(Mockito.anyDouble())).thenReturn(22.22);
		when(bapServiceClient.getSkillFamilyByReqId(Mockito.anyList())).thenReturn(skillFamilyList());
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(resourceReqList);
		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(allocationRepository.getAssociatesByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(associateList);
		when(bapServiceClient.getProjectFte(Mockito.anyLong())).thenReturn(resourceRequirementAndFteDto);
		when(tAssociateAllocationRepository.getAllocatedResourceList(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(),
				Mockito.anyLong())).thenReturn(associateList);
		ResourceRequirementAndFteDto newresourceRequirementAndFteDto = resourceRequirementServiceImpl
				.getRRforAllocation(1234l);  
		assertNotNull(newresourceRequirementAndFteDto);
		verify(bapServiceClient, times(1)).getResourceRequiremetList(Mockito.anyLong());
		verify(bapServiceClient, times(1)).getProjectFte(Mockito.anyLong());
	}

	@Test
	public void getResourceRequirementListDiffReqTest() throws ResourceManagementException {
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		resourceRequirementAndFteDto.setTotalBapFte(30.00);
		resourceRequirementAndFteDto.setProjectBillingType("Billable");
		resourceRequirementAndFteDto.setPoOrderValue(223456.0);
		List<ResourceRequirementDto> resourceReqList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(2);
		resourceRequirementDto.setResourceRequirementLocation("Pune");
		resourceRequirementDto.setRequirmentEffortsHours(22.0);
		resourceRequirementDto.setRequirmentCostRate(22.0);
		resourceReqList.add(resourceRequirementDto);
		resourceRequirementAndFteDto.setTotalBudget(12345);
		resourceRequirementAndFteDto.setResourceRequirementDto(resourceReqList);
		List<Long> reqIds = new ArrayList<>();
		reqIds.add(1l);
		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(1);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection);
		when(bapServiceClient.getSkillFamilyByReqId(Mockito.anyList())).thenReturn(skillFamilyList());
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(resourceReqList);
		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
	       when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());

		when(bapServiceClient.getProjectFte(Mockito.anyLong())).thenReturn(resourceRequirementAndFteDto);
		ResourceRequirementAndFteDto newresourceRequirementAndFteDto = resourceRequirementServiceImpl
				.getRRforAllocation(1234l);
		assertNotNull(newresourceRequirementAndFteDto);
		verify(bapServiceClient, times(1)).getResourceRequiremetList(Mockito.anyLong());
		verify(bapServiceClient, times(1)).getProjectFte(Mockito.anyLong());
	}

	@Test  
	public void getResourceRequirementListFTETest() throws ResourceManagementException {
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		resourceRequirementAndFteDto.setTotalBapFte(30.00);
		resourceRequirementAndFteDto.setProjectBillingType("Billable");
		resourceRequirementAndFteDto.setPoOrderValue(223456.0);
		List<ResourceRequirementDto> resourceReqList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(2);
		resourceRequirementDto.setResourceRequirementLocation("Pune");
		resourceRequirementDto.setRequirmentEffortsHours(22.0);
		resourceRequirementDto.setRequirmentCostRate(22.0);
		resourceReqList.add(resourceRequirementDto);
		resourceRequirementAndFteDto.setTotalBudget(12345);
		resourceRequirementAndFteDto.setResourceRequirementDto(resourceReqList);
		
		
		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory1 = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory1
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(4);
		allocatedResourceProjection.setEmployeeId(1L);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(ResourceManagementConstant.EBR);
		associateList.add(allocatedResourceProjection);
		
		List<Long> reqIds = new ArrayList<>();
		reqIds.add(1l);
		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(1);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection);
	       when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());

		when(bapServiceClient.getSkillFamilyByReqId(Mockito.anyList())).thenReturn(skillFamilyList());
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(resourceReqList);
		when(tAssociateAllocationRepository.getAssociatesByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(associateList);
		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(bapServiceClient.getProjectFte(Mockito.anyLong())).thenReturn(resourceRequirementAndFteDto);
		when(tAssociateAllocationRepository.getTotalAllocatedBillbleFteForProject(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyList(), Mockito.anyLong()))
				.thenReturn(12.00);
		when(tAssociateAllocationRepository.getTotalAllocatedEBRFteForProject(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(2.00);
		ResourceRequirementAndFteDto newresourceRequirementAndFteDto = resourceRequirementServiceImpl
				.getRRforAllocation(1234l);
		// when(allocatedResourceHelperClass.getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList())).thenReturn(associateList);
		when(allocatedResourceHelperClass.getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean())).thenReturn(associateList);

		assertNotNull(newresourceRequirementAndFteDto);
		verify(bapServiceClient, times(1)).getResourceRequiremetList(Mockito.anyLong());
		verify(bapServiceClient, times(1)).getProjectFte(Mockito.anyLong());
	}

	@Test
	public void getResourceRequirementEmptyListFTETest() throws ResourceManagementException {
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		resourceRequirementAndFteDto.setTotalBapFte(30.00);
		resourceRequirementAndFteDto.setProjectBillingType("Billable");
		resourceRequirementAndFteDto.setPoOrderValue(223456.0);
		List<ResourceRequirementDto> resourceReqList = new ArrayList<>();
		resourceRequirementAndFteDto.setResourceRequirementDto(resourceReqList);
		List<Long> reqIds = new ArrayList<>();
		reqIds.add(1l);
		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(1);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection);
		when(bapServiceClient.getSkillFamilyByReqId(Mockito.anyList())).thenReturn(skillFamilyList());
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(resourceReqList);
		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(bapServiceClient.getProjectFte(Mockito.anyLong())).thenReturn(resourceRequirementAndFteDto);
		when(tAssociateAllocationRepository.getTotalAllocatedBillbleFteForProject(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyList(), Mockito.anyLong()))
				.thenReturn(12.00);
		when(tAssociateAllocationRepository.getTotalAllocatedEBRFteForProject(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(null);
	       when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());

		ResourceRequirementAndFteDto newresourceRequirementAndFteDto = resourceRequirementServiceImpl
				.getRRforAllocation(1234l);
		assertNotNull(newresourceRequirementAndFteDto);
		verify(bapServiceClient, times(1)).getResourceRequiremetList(Mockito.anyLong());
		verify(bapServiceClient, times(1)).getProjectFte(Mockito.anyLong());
	}

	@Test
	public void getResourceRequirementBillableFteNullTest() throws ResourceManagementException, ParseException {
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		resourceRequirementAndFteDto.setTotalBapFte(30.00);
		resourceRequirementAndFteDto.setProjectBillingType("Billable");
		resourceRequirementAndFteDto.setPoOrderValue(223456.0);
		List<ResourceRequirementDto> resourceReqList = new ArrayList<>();
		resourceRequirementAndFteDto.setResourceRequirementDto(resourceReqList);
		List<Long> reqIds = new ArrayList<>();
		reqIds.add(1l);
		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(1);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection);
		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDto();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(0.00);
		projectBudgetDto1.setConsumedBudget(-.00);
		projectBudgetDto.add(projectBudgetDto1);

		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto2.setBudgetCurrency(5.0);
		projectBudgetDto2.setMonth("2020-07");
		projectBudgetDto2.setAvailableBudget(0.00);
		projectBudgetDto2.setConsumedBudget(0.00);
		projectBudgetDto.add(projectBudgetDto2);

		ProjectBudgetDto projectBudgetDto3 = new ProjectBudgetDto();
		projectBudgetDto3.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto3.setBudgetCurrency(5.0);
		projectBudgetDto3.setMonth("2020-08");
		projectBudgetDto3.setAvailableBudget(0.00);
		projectBudgetDto3.setConsumedBudget(0.00);
		projectBudgetDto.add(projectBudgetDto3);
		when(bapServiceClient.getSkillFamilyByReqId(Mockito.anyList())).thenReturn(skillFamilyList());
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(resourceReqList);
		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(bapServiceClient.getProjectFte(Mockito.anyLong())).thenReturn(resourceRequirementAndFteDto);
		when(tAssociateAllocationRepository.getTotalAllocatedBillbleFteForProject(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyList(), Mockito.anyLong()))
				.thenReturn(null);
		when(tAssociateAllocationRepository.getTotalAllocatedEBRFteForProject(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(13.00);
	       when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());

		ResourceRequirementAndFteDto newresourceRequirementAndFteDto = resourceRequirementServiceImpl
				.getRRforAllocation(1234l);
       
		assertNotNull(newresourceRequirementAndFteDto);
		verify(bapServiceClient, times(1)).getResourceRequiremetList(Mockito.anyLong());
		verify(bapServiceClient, times(1)).getProjectFte(Mockito.anyLong());
	}  

	@Test
	public void getResourceRequirementFteNullTest() throws ResourceManagementException, ParseException {
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		resourceRequirementAndFteDto.setTotalBapFte(30.00);

		List<ResourceRequirementDto> resourceReqList = new ArrayList<>();
		resourceRequirementAndFteDto.setResourceRequirementDto(resourceReqList);
		List<Long> reqIds = new ArrayList<>();
		reqIds.add(1l);
		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(1);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection);
		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDto();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(0.00);
		projectBudgetDto1.setConsumedBudget(-.00);
		projectBudgetDto.add(projectBudgetDto1);

		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto2.setBudgetCurrency(5.0);
		projectBudgetDto2.setMonth("2020-07");
		projectBudgetDto2.setAvailableBudget(30.00);
		projectBudgetDto2.setConsumedBudget(0.00);
		projectBudgetDto.add(projectBudgetDto2);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);

		when(bapServiceClient.getProjectFte(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.getTotalAllocatedBillbleFteForProject(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyList(), Mockito.anyLong()))
				.thenReturn(null);

				when(tAssociateAllocationRepository.getTotalAllocatedEBRFteForProject(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(null);
		ResourceRequirementAndFteDto newresourceRequirementAndFteDto = resourceRequirementServiceImpl
				.getRRforAllocation(1234l);
		assertNull(newresourceRequirementAndFteDto);

	}

	@Test
	public void getResourceRequirementListNullTest() throws ResourceManagementException {
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		resourceRequirementAndFteDto.setTotalBapFte(30.00);
		List<ResourceRequirementDto> resourceReqList = new ArrayList<>();
		resourceRequirementAndFteDto.setResourceRequirementDto(resourceReqList);
		List<Long> reqIds = new ArrayList<>();
		reqIds.add(1l);
		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(1);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(null);
		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(bapServiceClient.getProjectFte(Mockito.anyLong())).thenReturn(resourceRequirementAndFteDto);
		when(tAssociateAllocationRepository.getTotalAllocatedBillbleFteForProject(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyList(), Mockito.anyLong()))
				.thenReturn(null);
		when(tAssociateAllocationRepository.getTotalAllocatedEBRFteForProject(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(null);

		ResourceRequirementAndFteDto newresourceRequirementAndFteDto = resourceRequirementServiceImpl
				.getRRforAllocation(1234l);
		assertNotNull(newresourceRequirementAndFteDto);

	}

	@Test public void getResourceRequirementListDeallocationsTest() throws
	  ResourceManagementException {
	  
	  List<EmployeeDto> employeeList = new ArrayList<>(); EmployeeDto employeeDto =
	  new EmployeeDto(); employeeDto.setEmployeeId(1L);
	  employeeDto.setEmployeeName("AKSHAY T"); employeeList.add(employeeDto);
	  
	  List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
	  ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
	  resourceRequirementDto.setAllocateResourceQty(2l);
	  resourceRequirementDto.setReqId(2);
	  resourceRequirementDto.setResourceRequirementLocation("pune"); //
	  resourceRequirementDto.setBillingStatus("billable");
	  resourceRequirementDto.setEmployeeList(employeeList);
	  resourcerequirementlist.add(resourceRequirementDto);
	  
	  List<AllocatedResourceProjection> associateList = new ArrayList<>();
	  ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
	  AllocatedResourceProjection allocatedResourceProjection = factory
	  .createProjection(AllocatedResourceProjection.class);
	  allocatedResourceProjection.setAssociateAllocationId(2l);
	  allocatedResourceProjection.setRequirementId(2);
	  allocatedResourceProjection.setEmployeeId(1L);
	  allocatedResourceProjection.setFtePercent(20l);
	  allocatedResourceProjection.setProjectId(13l);
	  allocatedResourceProjection.setBillableStatusId(ResourceManagementConstant.
	  EBR); associateList.add(allocatedResourceProjection);
	  
	  List<ReservedAssociateProjection> reservedForAssociateProjections = new
	  ArrayList<ReservedAssociateProjection>(); ReservedAssociateProjection
	  newreservedAssociateProjection = factory
	  .createProjection(ReservedAssociateProjection.class);
	  newreservedAssociateProjection.setrequirementId(2l);
	  newreservedAssociateProjection.setreservedAssociateCount(4);
	  reservedForAssociateProjections.add(newreservedAssociateProjection);
	  
	  List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
	  GetResourceReqProjection getResourceReqProjection =
	  factory.createProjection(GetResourceReqProjection.class);
	  getResourceReqProjection.setRequirementId(2);
	  getResourceReqProjection.setAllocatedFte(1l);
	  reqProjectionList.add(getResourceReqProjection);
	  
	  List<Long> reqIdList = new ArrayList<>(); reqIdList.add(123L);
	  
	  ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl2 = new
	  ResourceDeAllocationServiceImpl(); ResourceDeAllocationServiceImpl
	  resourceDeallocationServiceImpl1 = Mockito
	  .spy(resourceDeallocationServiceImpl2);
	  
	  
	  when(bapServiceClient.getProjectDetail(Mockito.anyLong())).thenReturn(
	  getProjectDto());
	  when(allocationRepository.getAssociatesByRequirementId(Mockito.anyList(),
	  Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())) .thenReturn(associateList);
	  when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(
	  Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong())) .thenReturn(reqProjectionList);
	  when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.
	  anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())) .thenReturn(reqProjectionList);
	  when(allocationRepository.getReservedAssociateForAllocation(Mockito.anyList(),Mockito.anyLong(),Mockito.anyList()
	  )) .thenReturn(reservedForAssociateProjections);
	  when(resourceDeallocationRepositary.getReservedAssociateForDeallocation(
	  Mockito.anyList(), Mockito.anyList())) .thenReturn(reservedForAssociateProjections);
	  when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).
	  thenReturn(resourcerequirementlist);
	  when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn
	  (employeeList);
	  when(tAssociateAllocationRepository.getAllocatedResourceList(Mockito.anyLong(
	  ), Mockito.anyList(), Mockito.anyLong(), Mockito.anyList(),
	  Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(),
	  Mockito.anyLong())).thenReturn(associateList);
	  when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(
	  employeeList);
	  when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).
	  thenReturn(getModuleList());
      when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
      when(adminServiceClient.getBuForProject(Mockito.anyLong())).thenReturn(getpdbudget());
	//	when(allocatedResourceHelperClass.getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList())).thenReturn(associateList);
		when(allocatedResourceHelperClass.getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean())).thenReturn(associateList);
		when(adminServiceClient.getEmployeeDetailsByEmpId(Mockito.anyLong())).thenReturn(employeeDto);
	  List<ResourceRequirementDto> resourceRequirementList =
	  resourceRequirementServiceImpl .getRRforDeallocation(13l);
	  System.out.println(resourceRequirementList);
	  assertNotNull(resourceRequirementList);
	  
	  verify(allocationRepository,
	  times(1)).getAllocatedResourceByRequirementId(Mockito.anyList(),
	  Mockito.anyLong(),Mockito.anyLong()); verify(bapServiceClient,
	  times(1)).getResourceRequiremetList(13l);
	  
	  }

	@Test
	public void getResourceRequirementDeallocationsListDiffBillingStatusTest() throws ResourceManagementException {

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("AKSHAY T");
		employeeDto.setRequirementId(2);
		employeeList.add(employeeDto);

		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setAllocateResourceQty(2l);
		resourceRequirementDto.setReqId(2);
		resourceRequirementDto.setResourceRequirementLocation("pune"); //
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setEmployeeList(employeeList);
		resourcerequirementlist.add(resourceRequirementDto);

		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(ResourceManagementConstant.BILLABLE);
		associateList.add(allocatedResourceProjection);

		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(2);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection);

		List<Long> reqIdList = new ArrayList<>();
		reqIdList.add(123L);

		ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl2 = new ResourceDeAllocationServiceImpl();
		ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl1 = Mockito
				.spy(resourceDeallocationServiceImpl2);

		
		when(bapServiceClient.getProjectDetail(Mockito.anyLong())).thenReturn(getProjectDto());

		when(allocationRepository.getAssociatesByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(associateList);
		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(resourcerequirementlist); //
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
	       when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
	       when(adminServiceClient.getBuForProject(Mockito.anyLong())).thenReturn(getpdbudget());

		List<ResourceRequirementDto> resourceRequirementList = resourceRequirementServiceImpl.getRRforDeallocation(13l);

		System.out.println(resourceRequirementList);
		assertNotNull(resourceRequirementList);

		verify(allocationRepository, times(1)).getAllocatedResourceByRequirementId(Mockito.anyList(),
				Mockito.anyLong(),Mockito.anyLong());
		verify(bapServiceClient, times(1)).getResourceRequiremetList(Mockito.anyLong());

	}

	@Test
	public void getResourceRequirementDeallocationsNonBillableStatusTest() throws ResourceManagementException {

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("AKSHAY T");
		employeeList.add(employeeDto);

		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setAllocateResourceQty(2l);
		resourceRequirementDto.setReqId(2);
		resourceRequirementDto.setResourceRequirementLocation("pune"); //
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setEmployeeList(employeeList);
		resourcerequirementlist.add(resourceRequirementDto);

		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(5);
		associateList.add(allocatedResourceProjection);

		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(2);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection);

		ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl2 = new ResourceDeAllocationServiceImpl();
		ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl1 = Mockito
				.spy(resourceDeallocationServiceImpl2);

	    when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
        when(bapServiceClient.getProjectDetail(Mockito.anyLong())).thenReturn(getProjectDto());
		when(allocationRepository.getAssociatesByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(associateList);
		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(resourcerequirementlist); //
		//when(allocatedResourceHelperClass.getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList())).thenReturn(associateList);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
	      when(adminServiceClient.getBuForProject(Mockito.anyLong())).thenReturn(getpdbudget());
	      List<ResourceRequirementDto> resourceRequirementList = resourceRequirementServiceImpl.getRRforDeallocation(13l);
		assertNotNull(resourceRequirementList);

		verify(allocationRepository, times(1)).getAllocatedResourceByRequirementId(Mockito.anyList(),
				Mockito.anyLong(),Mockito.anyLong());
		verify(bapServiceClient, times(1)).getResourceRequiremetList(13l);

	}

	public ProjectDto getProjectDto() {
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(123l);
		projectDto.setProjectName("test");
		List<Long> reqIdList = new ArrayList<>();
		reqIdList.add(123L);
		return projectDto;
	}

	@Test
	public void getResourceRequiremenDeallocationsEmptyListTest() throws ResourceManagementException {

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("AKSHAY T");
		employeeList.add(employeeDto);

		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();

		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(ResourceManagementConstant.EBR);
		associateList.add(allocatedResourceProjection);

		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(2);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection);

		List<Long> reqIdList = new ArrayList<>();
		reqIdList.add(123L);

		ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl2 = new ResourceDeAllocationServiceImpl();
		ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl1 = Mockito
				.spy(resourceDeallocationServiceImpl2);

		when(bapServiceClient.getProjectDetail(Mockito.anyLong())).thenReturn(getProjectDto());

		when(allocationRepository.getAssociatesByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(associateList);
		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(resourcerequirementlist); //
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
	//	when(allocatedResourceHelperClass.getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList())).thenReturn(associateList);
		when(allocatedResourceHelperClass.getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean())).thenReturn(associateList);
	       when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
	       when(adminServiceClient.getBuForProject(Mockito.anyLong())).thenReturn(getpdbudget());

		List<ResourceRequirementDto> resourceRequirementList = resourceRequirementServiceImpl.getRRforDeallocation(13l);

		System.out.println(resourceRequirementList);
		assertNotNull(resourceRequirementList);

		verify(allocationRepository, times(1)).getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong());
		verify(bapServiceClient, times(1)).getResourceRequiremetList(Mockito.anyLong());

	}

	@Test
	public void getResourceRequirementListDeallocationsProjectionTest() throws ResourceManagementException {

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("AKSHAY T");
		employeeList.add(employeeDto);

		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(2);
		resourceRequirementDto.setAllocateResourceQty(2l);
		resourceRequirementDto.setResourceRequirementLocation("pune");
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setEmployeeList(employeeList);
		resourcerequirementlist.add(resourceRequirementDto);

		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(2);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection);

		List<Long> reqIdList = new ArrayList<>();
		reqIdList.add(123L);

		ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl2 = new ResourceDeAllocationServiceImpl();
		ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl1 = Mockito
				.spy(resourceDeallocationServiceImpl2);

		
		when(bapServiceClient.getProjectDetail(Mockito.anyLong())).thenReturn(getProjectDto());

		when(allocationRepository.getAssociatesByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(associateList);
		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(resourcerequirementlist); //
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(tAssociateAllocationRepository.getAllocatedResourceList(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(),
				Mockito.anyLong())).thenReturn(associateList);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
	//	when(allocatedResourceHelperClass.getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList())).thenReturn(associateList);
		when(allocatedResourceHelperClass.getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean())).thenReturn(associateList);
	       when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
	       when(adminServiceClient.getBuForProject(Mockito.anyLong())).thenReturn(getpdbudget());
	       when(adminServiceClient.getBuForProject(Mockito.anyLong())).thenReturn(getpdbudget());
	       when(adminServiceClient.getBuForProject(Mockito.anyLong())).thenReturn(getpdbudget());

		List<ResourceRequirementDto> resourceRequirementList = resourceRequirementServiceImpl.getRRforDeallocation(13l);

		System.out.println(resourceRequirementList);
		assertNotNull(resourceRequirementList);

		verify(allocationRepository, times(1)).getAllocatedResourceByRequirementId(Mockito.anyList(),
				Mockito.anyLong(),Mockito.anyLong());
		verify(bapServiceClient, times(1)).getResourceRequiremetList(Mockito.anyLong());

	}

	@Test
	public void getResourceRequirementListDeallocationsDiffReqIdTest() throws ResourceManagementException {

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("AKSHAY T");
		employeeList.add(employeeDto);

		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setAllocateResourceQty(2l);
		resourceRequirementDto.setReqId(1);
		resourceRequirementDto.setResourceRequirementLocation("pune");
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setEmployeeList(employeeList);
		resourcerequirementlist.add(resourceRequirementDto);

		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(ResourceManagementConstant.NON_BILLABLE);
		associateList.add(allocatedResourceProjection);

		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(2);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection);

		List<Long> reqIdList = new ArrayList<>();
		reqIdList.add(123L);

		ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl2 = new ResourceDeAllocationServiceImpl();
		ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl1 = Mockito
				.spy(resourceDeallocationServiceImpl2);

		when(bapServiceClient.getProjectDetail(Mockito.anyLong())).thenReturn(getProjectDto());
		when(allocationRepository.getAssociatesByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(associateList);
		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(resourcerequirementlist);
		when(tAssociateAllocationRepository.getAllocatedResourceList(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(),
				Mockito.anyLong())).thenReturn(associateList);
	       when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());

		//
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
	//	when(allocatedResourceHelperClass.getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList())).thenReturn(associateList);
		when(allocatedResourceHelperClass.getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean())).thenReturn(associateList);
	      when(adminServiceClient.getBuForProject(Mockito.anyLong())).thenReturn(getpdbudget());

		List<ResourceRequirementDto> resourceRequirementList = resourceRequirementServiceImpl.getRRforDeallocation(13l);

		System.out.println(resourceRequirementList);
		assertNotNull(resourceRequirementList);

		verify(allocationRepository, times(1)).getAllocatedResourceByRequirementId(Mockito.anyList(),
				Mockito.anyLong(),Mockito.anyLong());
		verify(bapServiceClient, times(1)).getResourceRequiremetList(Mockito.anyLong());

	}

  
	@Test
	public void getResourceRequirementListTransfersTest() throws ResourceManagementException {

		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		resourceRequirementAndFteDto.setTotalBapFte(30.00);
		resourceRequirementAndFteDto.setBudgetAndCostCheck(true);

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(1l);
		employeeDto.setRequirementId(2);
		employeeDto.setEmployeeName("AKSHAY T");
		employeeList.add(employeeDto);

		List<ResourceRequirementDto> resourcerequirementlist = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setAllocateResourceQty(2l);
		resourceRequirementDto.setReqId(2);
		resourceRequirementDto.setResourceRequirementLocation("pune"); //
		resourceRequirementDto.setBillingStatus("billable");
		resourceRequirementDto.setEmployeeList(employeeList);
		resourcerequirementlist.add(resourceRequirementDto);

		resourceRequirementAndFteDto.setResourceRequirementDto(resourcerequirementlist);

		List<AllocatedResourceProjection> newassociateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(1l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(ResourceManagementConstant.EBR);
		allocatedResourceProjection.setdefaultSkillId(1l);
		AllocatedResourceProjection newallocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		newallocatedResourceProjection.setAssociateAllocationId(2l);
		newallocatedResourceProjection.setRequirementId(2);
		newallocatedResourceProjection.setEmployeeId(1l);
		newallocatedResourceProjection.setFtePercent(20l);
		newallocatedResourceProjection.setProjectId(13l);
		newallocatedResourceProjection.setBillableStatusId(ResourceManagementConstant.EBR);
  
		newassociateList.add(allocatedResourceProjection);
		newassociateList.add(newallocatedResourceProjection);

		List<ReservedAssociateProjection> reservedForAssociateProjections = new ArrayList<ReservedAssociateProjection>();
		ReservedAssociateProjection newreservedAssociateProjection = factory
				.createProjection(ReservedAssociateProjection.class);
		newreservedAssociateProjection.setrequirementId(2l);
		newreservedAssociateProjection.setreservedAssociateCount(4);
		reservedForAssociateProjections.add(newreservedAssociateProjection);

		List<ReservedAssociateProjection> reservedForAllocationProjections = new ArrayList<ReservedAssociateProjection>();
		ReservedAssociateProjection newreservedAllocationProjection = factory
				.createProjection(ReservedAssociateProjection.class);
		newreservedAllocationProjection.setrequirementId(2l);
		newreservedAllocationProjection.setreservedAssociateCount(4);
		reservedForAllocationProjections.add(newreservedAssociateProjection);

		List<GetResourceReqProjection> reqProjectionList = new ArrayList<>();
		GetResourceReqProjection getResourceReqProjection = factory.createProjection(GetResourceReqProjection.class);
		getResourceReqProjection.setRequirementId(2);
		getResourceReqProjection.setAllocatedFte(1l);
		reqProjectionList.add(getResourceReqProjection); 
		
		List<SkillTaxonomyDto> skillTaxanomyList = new ArrayList<SkillTaxonomyDto>();
		SkillTaxonomyDto skillTaxonomyDto = new SkillTaxonomyDto();
		skillTaxonomyDto.setL4SkillId(1l);
		skillTaxonomyDto.setEmployeeId(5233l); 
		skillTaxonomyDto.setL1PracticeId(1l);
		skillTaxonomyDto.setNicheSkillFlag(true);
		skillTaxonomyDto.setL4skillName("TEST");
		skillTaxanomyList.add(skillTaxonomyDto); 

		List<Long> reqIdList = new ArrayList<>();
		reqIdList.add(123L);

		ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl2 = new ResourceDeAllocationServiceImpl();
		ResourceDeAllocationServiceImpl resourceDeallocationServiceImpl1 = Mockito
				.spy(resourceDeallocationServiceImpl2);
		/*
		 * Mockito.doReturn(reqProjectionList).when(resourceDeallocationServiceImpl1)
		 * .getAllocatedResourceForRequirement(Mockito.anyList(), Mockito.anyLong());
		 */

		when(bapServiceClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(resourcerequirementlist);
		when(bapServiceClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourcerequirementlist);

		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);

		when(bapServiceClient.getSkillFamilyByReqId(Mockito.anyList())).thenReturn(skillFamilyList());

		when(bapServiceClient.getProjectDetail(Mockito.anyLong())).thenReturn(getProjectDto());

		/*
		 * when(allocationRepository.getAssociatesByRequirementId(Mockito.anyList(),
		 * Mockito.anyLong())) .thenReturn(associateList);
		 */
		when(resourceAllocationServiceImpl.getBudgetAndCostCheck(Mockito.anyLong())).thenReturn(true);
	       when(adminServiceClient.getSkillFamilyByskillId(Mockito.anyList())).thenReturn(skillTaxanomyList);

		when(allocationRepository.getAllocatedResourceList(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(), Mockito.anyLong()))
						.thenReturn(newassociateList);
	       when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());

		when(tAssociateAllocationRepository.getAllocatedResourceByRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(tAssociateAllocationRepository.getBillableFTEForRequirementId(Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(reqProjectionList);
		when(allocationRepository.getReservedAssociateForAllocation(Mockito.anyList(),Mockito.anyLong(),Mockito.anyList()))
				.thenReturn(reservedForAllocationProjections);
		when(resourceDeallocationRepositary.getReservedAssociateForDeallocation(Mockito.anyList(), Mockito.anyList()))
				.thenReturn(reservedForAssociateProjections); //
		when(bapServiceClient.getProjectFte(Mockito.anyLong())).thenReturn(resourceRequirementAndFteDto);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
	     when(adminServiceClient.getBuForProject(Mockito.anyLong())).thenReturn(getpdbudget());

		ResourceRequirementAndFteDto resourceRequirementList = resourceRequirementServiceImpl.getRRforTransfer(13l);
		System.out.println(resourceRequirementList);
		assertNotNull(resourceRequirementList);

		verify(allocationRepository, times(1)).getAllocatedResourceByRequirementId(Mockito.anyList(),
				Mockito.anyLong(),Mockito.anyLong());
		verify(bapServiceClient, times(1)).getProjectFte(Mockito.anyLong());

	}

	@Test
	public void setAllocatedResourceQtyTest() {

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setAllocateResourceQty(2l);
		resourceRequirementDto.setReqId(2);
		resourceRequirementDto.setResourceRequirementLocation("pune");
		Map<Long, Double> allocatedReourceMap = new HashMap<Long, Double>();
		allocatedReourceMap.put(2l, 3.0);

		resourceRequirementServiceImpl.setAllocatedResourceQty(allocatedReourceMap, resourceRequirementDto);
	}

	public List<ModuleStatusDto> getModuleList() {
		/*
		 * System.out.println(projectId);
		 * System.out.println(wfStatusIdForAllocationOrTransferApproved);
		 * System.out.println(statusIdForAllocationActive); // null
		 * System.out.println(requirementIds);
		 * System.out.println(statusIdForDeAllocationDeActive); // null
		 * System.out.println(wfStatusIdForSavedOrSubmittedForDeallocation);
		 * System.out.println(wfStatusIdForSavedOrSubmittedForTransfer);
		 * System.out.println(wfIdForSubmittedForExtension); // null
		 */
		List<ModuleStatusDto> moduleList = new ArrayList<>();
		ModuleStatusDto moduleStatusDtoAllocation = new ModuleStatusDto();
		moduleStatusDtoAllocation.setModuleId(1l);
		moduleStatusDtoAllocation.setModuleCode("RM");
		moduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setAction("APPROVED");
		moduleList.add(moduleStatusDtoAllocation);
		ModuleStatusDto newmoduleStatus2DtoAllocation = new ModuleStatusDto();
		newmoduleStatus2DtoAllocation.setModuleId(2l);
		newmoduleStatus2DtoAllocation.setModuleCode("RM");
		newmoduleStatus2DtoAllocation.setSubModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setParentModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setAction("DEACTIVE");
		moduleList.add(newmoduleStatus2DtoAllocation);
		ModuleStatusDto newmoduleStatusDtoAllocation = new ModuleStatusDto();

		newmoduleStatusDtoAllocation.setModuleId(2l);
		newmoduleStatusDtoAllocation.setModuleCode("RM");
		newmoduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setAction("ACTIVE");
		moduleList.add(newmoduleStatusDtoAllocation);
		

		ModuleStatusDto moduleSaved = new ModuleStatusDto();
		moduleSaved.setModuleId(2l);
		moduleSaved.setModuleCode("RM");
		moduleSaved.setSubModule("RESOURCE_ALLOCATION");
		moduleSaved.setParentModule("RESOURCE_ALLOCATION");
		moduleSaved.setAction("SAVED");


		ModuleStatusDto moduleStatusDtoTransfer = new ModuleStatusDto();
		moduleStatusDtoTransfer.setModuleId(1l);
		moduleStatusDtoTransfer.setModuleCode("RM");
		moduleStatusDtoTransfer.setSubModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setAction("APPROVED");
		moduleList.add(moduleStatusDtoTransfer);

		ModuleStatusDto moduleStatusDtoDeallocationSved = new ModuleStatusDto();
		moduleStatusDtoDeallocationSved.setModuleId(1l);
		moduleStatusDtoDeallocationSved.setModuleCode("RM");
		moduleStatusDtoDeallocationSved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSved.setAction(ResourceManagementConstant.DEALLOCATION_ACTION_SAVED);
		moduleList.add(moduleStatusDtoDeallocationSved);
		ModuleStatusDto moduleStatusDtoDeallocationSubmitted = new ModuleStatusDto();
		moduleStatusDtoDeallocationSubmitted.setModuleId(1l);
		moduleStatusDtoDeallocationSubmitted.setModuleCode("RM");
		moduleStatusDtoDeallocationSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSubmitted.setAction(ResourceManagementConstant.SUBMITTED);
		moduleList.add(moduleStatusDtoDeallocationSubmitted);
		ModuleStatusDto moduleStatusDtoDeallocationApproved = new ModuleStatusDto();
		moduleStatusDtoDeallocationApproved.setModuleId(1l);
		moduleStatusDtoDeallocationApproved.setModuleCode("RM");
		moduleStatusDtoDeallocationApproved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationApproved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationApproved.setAction(ResourceManagementConstant.APPROVED_ACTION);
		moduleList.add(moduleStatusDtoDeallocationApproved);

		ModuleStatusDto moduleStatusDtoTansferSved = new ModuleStatusDto();
		moduleStatusDtoTansferSved.setModuleId(1l);
		moduleStatusDtoTansferSved.setModuleCode("RM");
		moduleStatusDtoTansferSved.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTansferSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTansferSved.setAction(ResourceManagementConstant.TRANSFER_ACTION_SAVED);
		moduleList.add(moduleStatusDtoTansferSved);
		ModuleStatusDto moduleStatusDtoTransferSubmitted = new ModuleStatusDto();
		moduleStatusDtoTransferSubmitted.setModuleId(1l);
		moduleStatusDtoTransferSubmitted.setModuleCode("RM");
		moduleStatusDtoTransferSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTransferSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransferSubmitted.setAction(ResourceManagementConstant.SUBMITTED);
		moduleList.add(moduleStatusDtoTansferSved);
		ModuleStatusDto moduleStatusDtoExtension = new ModuleStatusDto();
		moduleStatusDtoExtension.setModuleId(1l);
		moduleStatusDtoExtension.setModuleCode("RM");
		moduleStatusDtoExtension.setSubModule("RESOURCE_EXTENSION");
		moduleStatusDtoExtension.setParentModule("RESOURCE_EXTENSION");
		moduleStatusDtoExtension.setAction("SUBMITTED FOR EXTENSION");
		moduleList.add(moduleStatusDtoExtension);

		moduleList.add(moduleStatusDtoTransferSubmitted);

		return moduleList;
	}

	List<SkillTaxonomyDto> skillFamilyList() {

		List<SkillTaxonomyDto> listofSkillFamily = new ArrayList<SkillTaxonomyDto>();
		SkillTaxonomyDto skillFamilyDto = new SkillTaxonomyDto();
		skillFamilyDto.setRequirmentId(1);
		skillFamilyDto.setL1PracticeId(1l);
		listofSkillFamily.add(skillFamilyDto);
		SkillTaxonomyDto skillFamilyDto1 = new SkillTaxonomyDto();
		skillFamilyDto1.setRequirmentId(2);
		skillFamilyDto1.setL1PracticeId(2l);
		listofSkillFamily.add(skillFamilyDto1);
		return listofSkillFamily;

	}
	
	public HashBasedTable<String, String, Long> getAllNewModuleList() {
		 
		List<ModuleStatusDto> moduleList = new ArrayList<>();
		ModuleStatusDto moduleStatusDtoAllocation = new ModuleStatusDto();
		moduleStatusDtoAllocation.setModuleId(1l);
		moduleStatusDtoAllocation.setModuleStatusId(1l);
		moduleStatusDtoAllocation.setModuleCode("RM");
		moduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setAction("APPROVED");
		moduleList.add(moduleStatusDtoAllocation);
		
		ModuleStatusDto moduleStatusDtoAllocationSAVED = new ModuleStatusDto();
		moduleStatusDtoAllocationSAVED.setModuleId(1l);
		moduleStatusDtoAllocationSAVED.setModuleStatusId(1l);
		moduleStatusDtoAllocationSAVED.setModuleCode("RM");
		moduleStatusDtoAllocationSAVED.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSAVED.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSAVED.setAction("SAVED");
		moduleList.add(moduleStatusDtoAllocationSAVED);
		
		ModuleStatusDto moduleStatusDtoAllocationSUBMITTED = new ModuleStatusDto();
		moduleStatusDtoAllocationSUBMITTED.setModuleId(1l);
		moduleStatusDtoAllocationSUBMITTED.setModuleStatusId(1l);
		moduleStatusDtoAllocationSUBMITTED.setModuleCode("RM");
		moduleStatusDtoAllocationSUBMITTED.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSUBMITTED.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSUBMITTED.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoAllocationSUBMITTED);
	
		
		ModuleStatusDto newmoduleStatus2DtoAllocation = new ModuleStatusDto();
		newmoduleStatus2DtoAllocation.setModuleId(2l);
		newmoduleStatus2DtoAllocation.setModuleStatusId(2l);
		newmoduleStatus2DtoAllocation.setModuleCode("RM");
		newmoduleStatus2DtoAllocation.setSubModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setParentModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setAction("DEACTIVATE");
		moduleList.add(newmoduleStatus2DtoAllocation);
		ModuleStatusDto newmoduleStatusDtoAllocation = new ModuleStatusDto();

		newmoduleStatusDtoAllocation.setModuleId(2l);
		newmoduleStatusDtoAllocation.setModuleStatusId(1l);
		newmoduleStatusDtoAllocation.setModuleCode("RM");
		newmoduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setAction("ACTIVATE");
		moduleList.add(newmoduleStatusDtoAllocation);

		ModuleStatusDto moduleStatusDtoTransfer = new ModuleStatusDto();
		moduleStatusDtoTransfer.setModuleId(1l);
		moduleStatusDtoTransfer.setModuleStatusId(1l);
		moduleStatusDtoTransfer.setModuleCode("RM");
		moduleStatusDtoTransfer.setSubModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setAction("APPROVED");
		moduleList.add(moduleStatusDtoTransfer);

		ModuleStatusDto moduleStatusDtoDeallocationSved = new ModuleStatusDto();
		moduleStatusDtoDeallocationSved.setModuleId(1l);
		moduleStatusDtoDeallocationSved.setModuleStatusId(1l);
		
		moduleStatusDtoDeallocationSved.setModuleCode("RM");
		moduleStatusDtoDeallocationSved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSved.setAction("SAVED");
		moduleList.add(moduleStatusDtoDeallocationSved);
		
		
		
		
		ModuleStatusDto moduleStatusDtoDeallocationSubmitted = new ModuleStatusDto();
		moduleStatusDtoDeallocationSubmitted.setModuleId(1l);
		moduleStatusDtoDeallocationSubmitted.setModuleStatusId(1l);
		moduleStatusDtoDeallocationSubmitted.setModuleCode("RM");
		moduleStatusDtoDeallocationSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSubmitted.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoDeallocationSubmitted);
		ModuleStatusDto moduleStatusDtoDeallocationApproved = new ModuleStatusDto();
		moduleStatusDtoDeallocationApproved.setModuleId(1l);
		moduleStatusDtoDeallocationApproved.setModuleCode("RM");
		moduleStatusDtoDeallocationApproved.setModuleStatusId(1l);
		moduleStatusDtoDeallocationApproved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationApproved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationApproved.setAction("APPROVED");
		moduleList.add(moduleStatusDtoDeallocationApproved);

		ModuleStatusDto moduleStatusDtoTansferSved = new ModuleStatusDto();
		moduleStatusDtoTansferSved.setModuleId(1l);  
		moduleStatusDtoTansferSved.setModuleStatusId(1l);
		moduleStatusDtoTansferSved.setModuleCode("RM");
		moduleStatusDtoTansferSved.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTansferSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTansferSved.setAction("SAVED");
		moduleList.add(moduleStatusDtoTansferSved);
		ModuleStatusDto moduleStatusDtoTransferSubmitted = new ModuleStatusDto();
		moduleStatusDtoTransferSubmitted.setModuleId(1l);
		moduleStatusDtoTransferSubmitted.setModuleStatusId(1l);
		moduleStatusDtoTransferSubmitted.setModuleCode("RM");
		moduleStatusDtoTransferSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTransferSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransferSubmitted.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoTansferSved);
		ModuleStatusDto moduleStatusDtoExtension = new ModuleStatusDto();
		moduleStatusDtoExtension.setModuleId(1l);
		moduleStatusDtoExtension.setModuleStatusId(1l);    
		moduleStatusDtoExtension.setModuleCode("RM");
		moduleStatusDtoExtension.setSubModule("RESOURCE_EXTENSION");
		moduleStatusDtoExtension.setParentModule("RESOURCE_EXTENSION"); 
		moduleStatusDtoExtension.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoExtension);
		
		ModuleStatusDto extensionApproved = new ModuleStatusDto();
		extensionApproved.setModuleId(1l);
		extensionApproved.setModuleStatusId(1l);    
		extensionApproved.setModuleCode("RM");
		extensionApproved.setSubModule("RESOURCE_EXTENSION");
		extensionApproved.setParentModule("RESOURCE_EXTENSION"); 
		extensionApproved.setAction("APPROVED");
		moduleList.add(extensionApproved);
		
		
		ModuleStatusDto deallocationApproved = new ModuleStatusDto();
		deallocationApproved.setModuleId(1l);
		deallocationApproved.setModuleStatusId(1l);    
		deallocationApproved.setModuleCode("RM");
		deallocationApproved.setSubModule("RESOURCE_DEALLOCATION");
		deallocationApproved.setParentModule("RESOURCE_DEALLOCATION"); 
		deallocationApproved.setAction("APPROVED");
		moduleList.add(deallocationApproved);

		moduleList.add(moduleStatusDtoTransferSubmitted);
		
		HashBasedTable<String, String, Long> table = HashBasedTable.create();
		for (ModuleStatusDto temp : moduleList) {
			table.put(temp.getSubModule(), temp.getAction(), temp.getModuleStatusId());
		}
		return table;

	}   

	public ProjectBuDto getpdbudget() {
		ProjectBuDto projectBuDto = new ProjectBuDto();
		projectBuDto.setBuId(1l);
		projectBuDto.setBuName("test");
		projectBuDto.setProjectId(1l);
		return projectBuDto;
	}
	
 
}
