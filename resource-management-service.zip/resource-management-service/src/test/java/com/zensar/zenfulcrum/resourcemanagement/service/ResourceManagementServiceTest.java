package com.zensar.zenfulcrum.resourcemanagement.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.projection.ProjectionFactory;
import org.springframework.data.projection.SpelAwareProxyProjectionFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CostCardInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.CountryDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.FYIapproverDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueAndDescDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.MailTemplateDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PrimaryUsersDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBuDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApproversDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TransferApproverResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.UserDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.WrkflwStepDefinitionDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.SendMailHelperService;
import com.zensar.zenfulcrum.resourcemanagement.model.ResourceWorkflow;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocationBudget;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateDeAllocation;
import com.zensar.zenfulcrum.resourcemanagement.projection.AssociateDeAllocationProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AssociateExtensionProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.EstimatedEndDateProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.AssociateAllocationBudgetRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.AssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceRequirementRepositary;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceWorkflowRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateExtensionRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TSrfRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.LiferayServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.WrkflwEngineServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.SendMailUtil;
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceManagementServiceTest {
 
	@InjectMocks
	private ResourceManagementServiceImpl rsrcMgmntSrvcImpl;
	@Mock
	private BAPServiceClient bapSrvcClient;
	@Mock
	private WrkflwEngineServiceClient wrkflwEngineSrvcClient;
	@Mock
	private AdminServiceClient adminSrvcClient;

	@Mock
	private ResourceRequirementRepositary resourceRequirementRepositary;

	@Mock
	private TSrfRepository tSrfRepository;

	@Mock
	private SendMailUtil sendMailUtil;

	@Mock
	private SendMailHelperService sendMailHelperServiceObj;

	@Mock
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Mock
	TAssociateDeAllocationRepository tAssociateDeallocationRepository;

	@Mock
	private ResourceWorkflowRepository rsrcWorkflowRepository;

	@Mock
	private BudgetControlServiceClient budgetControlServiceClient;

	@Mock
	private ResourceAllocationServiceImpl rsrcAllocationSrvcImpl;

	@Mock
	BudgetControlServiceClient budgetCntrlServiceClient;

	@Mock
	AssociateProjectRepository associateProjectRepository;

	@Mock
	LiferayServiceClient liferayServiceClient;
	
	@Mock
	private ResourceAllocationServiceImpl resourceAllocationServiceImplObj;
	
	@Mock
	AssociateAllocationBudgetRepository associateAllocationBudgetRepository;

	
	@Mock
	private TAssociateExtensionRepository tAssociateExtensionRepository;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);

	}


	@Test
	public void getProjectListTest() throws ResourceManagementException {
		List<ProjectDto> projectList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");
		projectList.add(projectDto);
		when(bapSrvcClient.getProjectList(Mockito.anyLong(), Mockito.anyLong())).thenReturn(projectList);
		List<ProjectDto> response = rsrcMgmntSrvcImpl.getProjectList(Mockito.anyLong(), Mockito.anyLong());
		assertNotNull(response);
		verify(bapSrvcClient, times(1)).getProjectList(Mockito.anyLong(), Mockito.anyLong());
	}

	@Test
	public void getRMApproversListTest() throws ResourceManagementException {
		RMApproversDto rmApproversDtoObjOne = new RMApproversDto();
		RMApproversDto rmApproversDtoObjTwo = new RMApproversDto();
		RMApproversDto rmApproversDtoObjThree = new RMApproversDto();
		rmApproversDtoObjOne.setRoleId(1);
		rmApproversDtoObjTwo.setRoleId(2);
		rmApproversDtoObjThree.setRoleId(2);
		rmApproversDtoObjOne.setRoleName("PM");
		rmApproversDtoObjTwo.setRoleName("PGM");
		rmApproversDtoObjThree.setRoleName("PGM");
		rmApproversDtoObjOne.setUserId(1);
		rmApproversDtoObjTwo.setUserId(2);
		rmApproversDtoObjThree.setUserId(3);
		rmApproversDtoObjOne.setUserName("user-1");
		rmApproversDtoObjTwo.setUserName("user-2");
		rmApproversDtoObjThree.setUserName("user-3");
		List<RMApproversDto> ipRMApproversListDtoObj = new ArrayList<>();
		ipRMApproversListDtoObj.add(rmApproversDtoObjOne);
		ipRMApproversListDtoObj.add(rmApproversDtoObjTwo);
		ipRMApproversListDtoObj.add(rmApproversDtoObjThree);
		List<Long> userIdListObj = new ArrayList<>();
		userIdListObj.add(1L);
		userIdListObj.add(2L);
		userIdListObj.add(3L);
		WrkflwStepDefinitionDto wrkflwDfntnDtoObjOne = new WrkflwStepDefinitionDto();
		WrkflwStepDefinitionDto wrkflwDfntnDtoObjTwo = new WrkflwStepDefinitionDto();
		WrkflwStepDefinitionDto wrkflwDfntnDtoObjThree = new WrkflwStepDefinitionDto();
        wrkflwDfntnDtoObjOne.setRoleId(2);
		wrkflwDfntnDtoObjTwo.setRoleId(1);
		wrkflwDfntnDtoObjThree.setRoleId(305);
		wrkflwDfntnDtoObjOne.setNextRoleId(3);
		wrkflwDfntnDtoObjTwo.setNextRoleId(2);
		wrkflwDfntnDtoObjOne.setStepId(1);
		wrkflwDfntnDtoObjTwo.setStepId(2);
		wrkflwDfntnDtoObjThree.setStepId(233);
		List<WrkflwStepDefinitionDto> wrkflwDfntnDtoListObj = new ArrayList<>();
		wrkflwDfntnDtoListObj.add(wrkflwDfntnDtoObjOne);
		wrkflwDfntnDtoListObj.add(wrkflwDfntnDtoObjTwo);
		wrkflwDfntnDtoListObj.add(wrkflwDfntnDtoObjThree);
		
		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList =new ArrayList<>();
		LookupValueAndDescDto dto = new LookupValueAndDescDto();
		dto.setLookupValueId(1l);
		dto.setLookupValueDescr("PROJECT MANAGER");
		LookupValueAndDescDto dto1 = new LookupValueAndDescDto();
		dto1.setLookupValueId(2l);
		dto1.setLookupValueDescr("PROGRAM MANAGER");
		LookupValueAndDescDto dto3 = new LookupValueAndDescDto();
		dto3.setLookupValueId(305l);
		dto3.setLookupValueDescr("TAG TEAM");
		lookuIdByTypeAndDescrList.add(dto3);
		lookuIdByTypeAndDescrList.add(dto);
		lookuIdByTypeAndDescrList.add(dto1);
				
		when(wrkflwEngineSrvcClient.getWrkflwStepDetails(Mockito.anyString())).thenReturn(wrkflwDfntnDtoListObj);
		when(adminSrvcClient.getLookuIdByTypeAndDescrList(Mockito.anyString(),Mockito.anyList())).thenReturn(lookuIdByTypeAndDescrList);
		when(bapSrvcClient.getPrimaryOwnersList(Mockito.anyLong())).thenReturn(userIdListObj);
		List<Long> roleIdListObj = new ArrayList<>();
		roleIdListObj.add(1L);
		ModuleStatusDto moduleDtlsDto = new ModuleStatusDto();
		moduleDtlsDto.setModuleCode("RMA");
		when(adminSrvcClient.getRMApproversList(roleIdListObj, userIdListObj)).thenReturn(ipRMApproversListDtoObj);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDtlsDto);
		List<RMApproversDto> opRMApproversListDtoObj = rsrcMgmntSrvcImpl.getRMApproversList(1, 2, 2, "RALLOCATION",false);
        // assertNull(opRMApproversListDtoObj);
		// verify(adminSrvcClient, times(1)).getRMApproversList(roleIdStrListObj,
		// userIdStrListObj);
	}
	
	@Test
	public void getRMApproversList1Test() throws ResourceManagementException {
		RMApproversDto rmApproversDtoObjOne = new RMApproversDto();
		RMApproversDto rmApproversDtoObjTwo = new RMApproversDto();
		RMApproversDto rmApproversDtoObjThree = new RMApproversDto();
		rmApproversDtoObjOne.setRoleId(1);
		rmApproversDtoObjTwo.setRoleId(2);
		rmApproversDtoObjThree.setRoleId(2);
		rmApproversDtoObjOne.setRoleName("PM");
		rmApproversDtoObjTwo.setRoleName("PGM");
		rmApproversDtoObjThree.setRoleName("PGM");
		rmApproversDtoObjOne.setUserId(1);
		rmApproversDtoObjTwo.setUserId(2);
		rmApproversDtoObjThree.setUserId(3);
		rmApproversDtoObjOne.setUserName("user-1");
		rmApproversDtoObjTwo.setUserName("user-2");
		rmApproversDtoObjThree.setUserName("user-3");
		List<RMApproversDto> ipRMApproversListDtoObj = new ArrayList<>();
		ipRMApproversListDtoObj.add(rmApproversDtoObjOne);
		ipRMApproversListDtoObj.add(rmApproversDtoObjTwo);
		ipRMApproversListDtoObj.add(rmApproversDtoObjThree);
		List<Long> userIdListObj = new ArrayList<>();
		userIdListObj.add(1L);
		userIdListObj.add(2L);
		userIdListObj.add(3L);
		WrkflwStepDefinitionDto wrkflwDfntnDtoObjOne = new WrkflwStepDefinitionDto();
		WrkflwStepDefinitionDto wrkflwDfntnDtoObjTwo = new WrkflwStepDefinitionDto();
		WrkflwStepDefinitionDto wrkflwDfntnDtoObjThree = new WrkflwStepDefinitionDto();
        wrkflwDfntnDtoObjOne.setRoleId(2);
		wrkflwDfntnDtoObjTwo.setRoleId(1);
		wrkflwDfntnDtoObjThree.setRoleId(305);
		wrkflwDfntnDtoObjOne.setNextRoleId(3);
		wrkflwDfntnDtoObjTwo.setNextRoleId(2);
		wrkflwDfntnDtoObjOne.setStepId(1);
		wrkflwDfntnDtoObjTwo.setStepId(2);
		wrkflwDfntnDtoObjThree.setStepId(233);
		List<WrkflwStepDefinitionDto> wrkflwDfntnDtoListObj = new ArrayList<>();
		wrkflwDfntnDtoListObj.add(wrkflwDfntnDtoObjOne);
		wrkflwDfntnDtoListObj.add(wrkflwDfntnDtoObjTwo);
		wrkflwDfntnDtoListObj.add(wrkflwDfntnDtoObjThree);
		
		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList =new ArrayList<>();
		LookupValueAndDescDto dto = new LookupValueAndDescDto();
		dto.setLookupValueId(2l);
		dto.setLookupValueDescr("PROJECT MANAGER");
		LookupValueAndDescDto dto1 = new LookupValueAndDescDto();
		dto1.setLookupValueId(1l);
		dto1.setLookupValueDescr("PROGRAM MANAGER");
		lookuIdByTypeAndDescrList.add(dto);
		lookuIdByTypeAndDescrList.add(dto1);
				
		when(wrkflwEngineSrvcClient.getWrkflwStepDetails(Mockito.anyString())).thenReturn(wrkflwDfntnDtoListObj);
		when(adminSrvcClient.getLookuIdByTypeAndDescrList(Mockito.anyString(),Mockito.anyList())).thenReturn(lookuIdByTypeAndDescrList);
		when(bapSrvcClient.getPrimaryOwnersList(Mockito.anyLong())).thenReturn(userIdListObj);
		List<Long> roleIdListObj = new ArrayList<>();
		roleIdListObj.add(1L);
		ModuleStatusDto moduleDtlsDto = new ModuleStatusDto();
		moduleDtlsDto.setModuleCode("RMA");
		when(adminSrvcClient.getRMApproversList(roleIdListObj, userIdListObj)).thenReturn(ipRMApproversListDtoObj);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDtlsDto);
		List<RMApproversDto> opRMApproversListDtoObj = rsrcMgmntSrvcImpl.getRMApproversList(1, 2, 2, "RALLOCATION", false);
        // assertNull(opRMApproversListDtoObj);
		// verify(adminSrvcClient, times(1)).getRMApproversList(roleIdStrListObj,
		// userIdStrListObj);
	}

	@Test   
	public void submitRMApprovalTest() throws ResourceManagementException {
		List<Long> reqList = new ArrayList<>();
		reqList.add(1l);
		RMApprovalInputDto rmApprovalInputDtoAllocObj = new RMApprovalInputDto();
		rmApprovalInputDtoAllocObj.setProjectId(1);
		rmApprovalInputDtoAllocObj.setRequirementId(1);
		rmApprovalInputDtoAllocObj.setRequestType(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		rmApprovalInputDtoAllocObj.setRoleId(1);
		rmApprovalInputDtoAllocObj.setUserId(1);  
		rmApprovalInputDtoAllocObj.setRequirmentList(reqList);
		ResourceRequirementDto resourceRequirementDtls = new ResourceRequirementDto();
		List<Long> employeeIdList = new ArrayList<>();
		employeeIdList.add(123L);
		resourceRequirementDtls.setEmployeeIdList(employeeIdList);
		resourceRequirementDtls.setReqId(1);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		resourceRequirementList.add(resourceRequirementDtls);
		rmApprovalInputDtoAllocObj.setResourceRequirementList(resourceRequirementList);
		;
		RMApprovalInputDto rmApprovalInputDtoDeAllocObj = new RMApprovalInputDto();
		rmApprovalInputDtoDeAllocObj.setProjectId(1);
		rmApprovalInputDtoDeAllocObj.setRequirementId(1);
		rmApprovalInputDtoDeAllocObj.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		rmApprovalInputDtoDeAllocObj.setResourceRequirementList(resourceRequirementList);
		rmApprovalInputDtoDeAllocObj.setRoleId(1);
		rmApprovalInputDtoDeAllocObj.setUserId(1);
		RMApproversDto RMSelectedApproversDtoObjOne = new RMApproversDto();
		RMApproversDto RMSelectedApproversDtoObjTwo = new RMApproversDto();
		RMSelectedApproversDtoObjOne.setRoleId(2);
		RMSelectedApproversDtoObjTwo.setRoleId(3);
		RMSelectedApproversDtoObjOne.setRoleName("PGM");
		RMSelectedApproversDtoObjTwo.setRoleName("TAG");
		RMSelectedApproversDtoObjOne.setUserId(2);
		RMSelectedApproversDtoObjTwo.setUserId(3);
		RMSelectedApproversDtoObjOne.setUserName("USER-2");
		RMSelectedApproversDtoObjTwo.setUserName("USER-3");
		List<RMApproversDto> rmApproversDtoList = new ArrayList<>();
		rmApproversDtoList.add(RMSelectedApproversDtoObjOne);
		rmApproversDtoList.add(RMSelectedApproversDtoObjTwo);
		rmApprovalInputDtoAllocObj.setRmApproversList(rmApproversDtoList);
		rmApprovalInputDtoDeAllocObj.setRmApproversList(rmApproversDtoList);
		WrkflwStepDefinitionDto wrkflwDfntnDtoObjOne = new WrkflwStepDefinitionDto();
		WrkflwStepDefinitionDto wrkflwDfntnDtoObjTwo = new WrkflwStepDefinitionDto();
		WrkflwStepDefinitionDto wrkflwDfntnDtoObjThree = new WrkflwStepDefinitionDto();
		wrkflwDfntnDtoObjOne.setRoleId(1);
		wrkflwDfntnDtoObjTwo.setRoleId(2);
		wrkflwDfntnDtoObjThree.setRoleId(3);
		wrkflwDfntnDtoObjOne.setNextRoleId(2);
		wrkflwDfntnDtoObjTwo.setNextRoleId(3);
		wrkflwDfntnDtoObjThree.setNextRoleId(0);
		wrkflwDfntnDtoObjOne.setStepId(1);
		wrkflwDfntnDtoObjTwo.setStepId(2);
		wrkflwDfntnDtoObjThree.setStepId(3);
		List<WrkflwStepDefinitionDto> wrkflwDfntnDtoListObj = new ArrayList<>();
		wrkflwDfntnDtoListObj.add(wrkflwDfntnDtoObjOne);
		wrkflwDfntnDtoListObj.add(wrkflwDfntnDtoObjTwo);
		wrkflwDfntnDtoListObj.add(wrkflwDfntnDtoObjThree);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		List<TAssociateDeAllocation> rDeAllocationDtlsListObj = new ArrayList<>();
		TAssociateDeAllocation tAssociateDeAllocationObj = new TAssociateDeAllocation();
		tAssociateDeAllocationObj.setAssociateDeAllocationId(1L);
		rDeAllocationDtlsListObj.add(tAssociateDeAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);
		
		List<LookupValueAndDescDto> lookuIdByTypeAndDescrList =new ArrayList<>();
		LookupValueAndDescDto dto = new LookupValueAndDescDto();
		dto.setLookupValueId(1l);
		dto.setLookupValueDescr("PROJECT MANAGER");
		LookupValueAndDescDto dto1 = new LookupValueAndDescDto();
		dto1.setLookupValueId(1l);
		dto1.setLookupValueDescr("PROGRAM MANAGER");
		LookupValueAndDescDto dto2 = new LookupValueAndDescDto();
		dto2.setLookupValueId(2l);
		dto2.setLookupValueDescr("TAG TEAM");
		lookuIdByTypeAndDescrList.add(dto);
		lookuIdByTypeAndDescrList.add(dto1);
		lookuIdByTypeAndDescrList.add(dto2);
		
		List<ModuleStatusDto> newmoduleList = new ArrayList<>();
		ModuleStatusDto statusDto = new ModuleStatusDto();
		statusDto.setModuleId(1797l);
		statusDto.setModuleStatusId(1797l); 
		statusDto.setParentModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		statusDto.setSubModule(ResourceManagementConstant.DEACTIVATE);	
		newmoduleList.add(statusDto);
		
		ProjectBuDto projectBuDto = new ProjectBuDto();
		projectBuDto.setBuName("Cisco");
		
		when(adminSrvcClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminSrvcClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		
		when(wrkflwEngineSrvcClient.getWrkflwStepDetails("RMA")).thenReturn(wrkflwDfntnDtoListObj);
		when(tAssociateAllocationRepository.getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);
		when(tAssociateAllocationRepository.getRAllocationDetailsList(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyList(),Mockito.anyList())).thenReturn(rAllocationDtlsListObj);
	
		when(tAssociateDeallocationRepository.getRDeAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(rDeAllocationDtlsListObj);
		when(adminSrvcClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminSrvcClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(newmoduleList);
		ModuleStatusDto moduleDtlsDto = new ModuleStatusDto();
		moduleDtlsDto.setModuleCode("RMA");
		moduleDtlsDto.setModuleStatusId(1L);
		moduleDtlsDto.setModuleId(1L);
		MailTemplateDto mailTemplateDtls = new MailTemplateDto();
		mailTemplateDtls.setMessageBodyContent("");
		mailTemplateDtls.setMessageBodyFooter("");
		mailTemplateDtls.setMessageBodyHeader("");
		mailTemplateDtls.setSubject("");
		mailTemplateDtls.setMessageBodyTable("");
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		when(adminSrvcClient.getLookuIdByTypeAndDescrList(Mockito.anyString(),Mockito.anyList())).thenReturn(lookuIdByTypeAndDescrList);
		when(adminSrvcClient.getBuForProject(Mockito.any())).thenReturn(projectBuDto);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDtlsDto);
		when(adminSrvcClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getnewRMModuleList());
		rsrcMgmntSrvcImpl.submitRMApproval(List.of(rmApprovalInputDtoAllocObj));
		rsrcMgmntSrvcImpl.submitRMApproval(List.of(rmApprovalInputDtoDeAllocObj));
		verify(wrkflwEngineSrvcClient, times(2)).getWrkflwStepDetails(Mockito.anyString());
	}

	@Test
	public void approveRMApprovalForAllocReqTest() throws ResourceManagementException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMDA");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(1L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		rsrcWrkflwObj.setStatusId(0l);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);

		when(adminSrvcClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminSrvcClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		
		when(tAssociateAllocationRepository.getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);
		when(adminSrvcClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(rsrcWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
	//	rsrcMgmntSrvcImpl.approveOrRejectRMApproval(RMApprovalInputDtlsList);
		//verify(tAssociateAllocationRepository, times(1)).getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
		//		Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong());
	}

	@Test
	public void rejectRMApprovalForAllocReqTest() throws ResourceManagementException, ParseException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("REJECTED");
		rmApprovalInputDtoObj.setRoleName("PROJECT MANAGER");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		tAssociateAllocationObj.setFtePercent(100.00);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		tAssociateAllocationObj.setActualAllocationStartDate(dateFormat.parse(("2020-06-01")));		
		tAssociateAllocationObj.setActualAllocationEndDate(dateFormat.parse(("2020-07-30")));
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMDA");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(1L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		rsrcWrkflwObj.setStatusId(0l);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);

		when(adminSrvcClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminSrvcClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(getProjectBudgetDto());
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateAllocationRepository.getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);
		when(adminSrvcClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(rsrcWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		doNothing().when(rsrcAllocationSrvcImpl).updateBudget(Mockito.any());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		rsrcMgmntSrvcImpl.callSendEmailUtility(usrDtlsMap, 1);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		rsrcMgmntSrvcImpl.approveOrRejectRMApproval(RMApprovalInputDtlsList);
		verify(tAssociateAllocationRepository, times(1)).getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong());
	}

	private ResourceRequirementDto getResourceRequirementDto() {
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore(ResourceManagementConstant.ONSHORE);
		resourceRequirementDto.setZenAccurateCurrency(10d);
		return resourceRequirementDto;
	}

	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	private List<ProjectBudgetDto> getProjectBudgetDto() throws ParseException {
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(200000.00);
		projectBudgetDto1.setConsumedBudget(10.00);
		projectBudgetDto1.setBudgetCurrency(10d);

		projectBudget.add(projectBudgetDto1);

		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto2.setBudgetCurrency(5.0);
		projectBudgetDto2.setMonth("2020-07");
		projectBudgetDto2.setAvailableBudget(300000.00);
		projectBudgetDto2.setConsumedBudget(10d);
		projectBudgetDto2.setBudgetCurrency(10d);
		projectBudget.add(projectBudgetDto2);
		
		return projectBudget;
	}

	@Test
	public void approveRMApprovalForDeAllocReqTest() throws ResourceManagementException, ParseException {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		rmApprovalInputDtoObj.setBudgetAndCostCheck(true);
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<AssociateDeAllocationProjection> rDeAllocationDtlsListObj = new ArrayList<>();
		AssociateDeAllocationProjection tAssociateDeAllocationObj = factory
				.createProjection(AssociateDeAllocationProjection.class);
		tAssociateDeAllocationObj.setAssociateAllocationId(1L);
		tAssociateDeAllocationObj.setAssociateDeAllocationId(1L);
		tAssociateDeAllocationObj.setFtePercent(100.00);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		tAssociateDeAllocationObj.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		tAssociateDeAllocationObj.setActualAllocationEndDate(dateFormat.parse("2020-06-30"));
		tAssociateDeAllocationObj.setEstAllocationEndDate(dateFormat.parse("2020-06-30"));
		tAssociateDeAllocationObj.setDeallocationDate(dateFormat.parse("2020-06-25"));
		tAssociateDeAllocationObj.setemployeeCostRate(22.00);

		rDeAllocationDtlsListObj.add(tAssociateDeAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		ModuleStatusDto ModuleDto = new ModuleStatusDto();
		ModuleDto.setModuleCode("RMDA");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(0L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(0L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);

		
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(getProjectBudgetDto());
		when(resourceAllocationServiceImplObj.getBudgetAndCostCheck(Mockito.anyLong())).thenReturn(true);
		when(associateAllocationBudgetRepository.findByAssociateAllocationIdAndBudgetAllocationMonth(Mockito.anyLong(), Mockito.anyString()))
		.thenReturn(getBudget());
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateDeallocationRepository.getRDeAllocationRequiredDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(rDeAllocationDtlsListObj);
		when(adminSrvcClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(ModuleDto);
		when(rsrcWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		when(adminSrvcClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminSrvcClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		rsrcMgmntSrvcImpl.callSendEmailUtility(usrDtlsMap, 1);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		rsrcMgmntSrvcImpl.approveOrRejectRMApproval(RMApprovalInputDtlsList);
		verify(adminSrvcClient, times(5)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString()); 
	}
	
	
	
	@Test
	public void approveRMApprovalForBudgetReleaseTest() throws ResourceManagementException, ParseException {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		rmApprovalInputDtoObj.setBudgetAndCostCheck(true);

		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<AssociateDeAllocationProjection> rDeAllocationDtlsListObj = new ArrayList<>();
		AssociateDeAllocationProjection tAssociateDeAllocationObj = factory
				.createProjection(AssociateDeAllocationProjection.class);
		tAssociateDeAllocationObj.setAssociateAllocationId(1L);
		tAssociateDeAllocationObj.setAssociateDeAllocationId(1L);
		tAssociateDeAllocationObj.setFtePercent(100.00);
		tAssociateDeAllocationObj.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		tAssociateDeAllocationObj.setActualAllocationEndDate(dateFormat.parse("2020-09-30"));
		tAssociateDeAllocationObj.setEstAllocationEndDate(dateFormat.parse("2020-09-30"));
		tAssociateDeAllocationObj.setDeallocationDate(dateFormat.parse("2020-06-25"));
		rDeAllocationDtlsListObj.add(tAssociateDeAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		ModuleStatusDto ModuleDto = new ModuleStatusDto();
		ModuleDto.setModuleCode("RMDA");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(0L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(0L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		
		List<ProjectBudgetDto> projectBudget = getProjectBudgetDto();
		
		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-08");
		projectBudgetDto1.setAvailableBudget(300000.00);
		projectBudgetDto1.setConsumedBudget(10d);
		projectBudgetDto1.setBudgetCurrency(10d);
		projectBudget.add(projectBudgetDto1);
		
		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto2.setBudgetCurrency(5.0);
		projectBudgetDto2.setMonth("2020-09");
		projectBudgetDto2.setAvailableBudget(300000.00);
		projectBudgetDto2.setConsumedBudget(10d);
		projectBudgetDto2.setBudgetCurrency(10d);
		projectBudget.add(projectBudgetDto2);
		
		ProjectBudgetDto projectBudgetDto3 = new ProjectBudgetDto();
		projectBudgetDto3.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto3.setBudgetCurrency(5.0);
		projectBudgetDto3.setMonth("2020-04");
		projectBudgetDto3.setAvailableBudget(300000.00);
		projectBudgetDto3.setConsumedBudget(10d);
		projectBudgetDto3.setBudgetCurrency(10d);
		projectBudget.add(projectBudgetDto3);
		
		ProjectBudgetDto projectBudgetDto4 = new ProjectBudgetDto();
		projectBudgetDto4.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto4.setBudgetCurrency(5.0);
		projectBudgetDto4.setMonth("2020-05");
		projectBudgetDto4.setAvailableBudget(300000.00);
		projectBudgetDto4.setConsumedBudget(10d);
		projectBudgetDto4.setBudgetCurrency(10d);
		projectBudget.add(projectBudgetDto4);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);

		when(adminSrvcClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminSrvcClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudget);
		List<TAssociateAllocationBudget> allocationBudget = new ArrayList<>();
		TAssociateAllocationBudget budget1 = new TAssociateAllocationBudget();
		budget1.setBudgetAllocatedMonth("2020-06");
		budget1.setBudgetAllocationMonth("2020-06");
		budget1.setMonthlyAvailableBudget(200000d);
		budget1.setMonthlyBudget(2000d);
		budget1.setMonthlyUsedBudget(2000d);
		allocationBudget.add(budget1);
		when(associateAllocationBudgetRepository.findByAssociateAllocationIdAndBudgetAllocationMonth(Mockito.anyLong(), Mockito.anyString()))
		.thenReturn(allocationBudget);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateDeallocationRepository.getRDeAllocationRequiredDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(rDeAllocationDtlsListObj);
		when(adminSrvcClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(ModuleDto);
		when(rsrcWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		rsrcMgmntSrvcImpl.callSendEmailUtility(usrDtlsMap, 1);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		rsrcMgmntSrvcImpl.approveOrRejectRMApproval(RMApprovalInputDtlsList);
		verify(adminSrvcClient, times(5)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
	}
	
	@Test
	public void approveRMApprovalForCumulativeBudgetReleaseTest1() throws ResourceManagementException, ParseException {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		rmApprovalInputDtoObj.setBudgetAndCostCheck(true);

		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<AssociateDeAllocationProjection> rDeAllocationDtlsListObj = new ArrayList<>();
		AssociateDeAllocationProjection tAssociateDeAllocationObj = factory
				.createProjection(AssociateDeAllocationProjection.class);
		tAssociateDeAllocationObj.setAssociateAllocationId(1L);
		tAssociateDeAllocationObj.setAssociateDeAllocationId(1L);
		tAssociateDeAllocationObj.setFtePercent(100.00);
		tAssociateDeAllocationObj.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		tAssociateDeAllocationObj.setActualAllocationEndDate(dateFormat.parse("2020-06-30"));
		tAssociateDeAllocationObj.setEstAllocationEndDate(dateFormat.parse("2020-06-30"));
		tAssociateDeAllocationObj.setDeallocationDate(dateFormat.parse("2020-06-25"));
		rDeAllocationDtlsListObj.add(tAssociateDeAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		ModuleStatusDto ModuleDto = new ModuleStatusDto();
		ModuleDto.setModuleCode("RMDA");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(0L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(0L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		
		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(200.00);
		projectBudgetDto1.setConsumedBudget(10.00);
		projectBudgetDto1.setBudgetCurrency(10d);
		
		projectBudget.add(projectBudgetDto1);
		
		ProjectBudgetDto projectBudgetDto3 = new ProjectBudgetDto();
		projectBudgetDto3.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto3.setBudgetCurrency(5.0);
		projectBudgetDto3.setMonth("2020-04");
		projectBudgetDto3.setAvailableBudget(100.00);
		projectBudgetDto3.setConsumedBudget(10d);
		projectBudgetDto3.setBudgetCurrency(10d);
		projectBudget.add(projectBudgetDto3);
		
		ProjectBudgetDto projectBudgetDto4 = new ProjectBudgetDto();
		projectBudgetDto4.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto4.setBudgetCurrency(5.0);
		projectBudgetDto4.setMonth("2020-05");
		projectBudgetDto4.setAvailableBudget(300000.00);
		projectBudgetDto4.setConsumedBudget(10d);
		projectBudgetDto4.setBudgetCurrency(10d);
		projectBudget.add(projectBudgetDto4);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);

		when(adminSrvcClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminSrvcClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudget);
		
		List<TAssociateAllocationBudget> allocationBudget = new ArrayList<>();
		TAssociateAllocationBudget budget1 = new TAssociateAllocationBudget();
		budget1.setBudgetAllocatedMonth("2020-06");
		budget1.setBudgetAllocationMonth("2020-06");
		budget1.setMonthlyAvailableBudget(200d);
		budget1.setMonthlyBudget(2000d);
		budget1.setMonthlyUsedBudget(200d);
		allocationBudget.add(budget1);
		
		TAssociateAllocationBudget budget2 = new TAssociateAllocationBudget();
		budget2.setBudgetAllocatedMonth("2020-04");
		budget2.setBudgetAllocationMonth("2020-06");
		budget2.setMonthlyAvailableBudget(100d);
		budget2.setMonthlyBudget(2000d);
		budget2.setMonthlyUsedBudget(100d);
		allocationBudget.add(budget2);
		
		TAssociateAllocationBudget budget3 = new TAssociateAllocationBudget();
		budget3.setBudgetAllocatedMonth("2020-05");
		budget3.setBudgetAllocationMonth("2020-06");
		budget3.setMonthlyAvailableBudget(300000d);
		budget3.setMonthlyBudget(2000d);
		budget3.setMonthlyUsedBudget(1700d);
		allocationBudget.add(budget3);
		
		when(associateAllocationBudgetRepository.findByAssociateAllocationIdAndBudgetAllocationMonth(Mockito.anyLong(), Mockito.anyString()))
		.thenReturn(allocationBudget);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateDeallocationRepository.getRDeAllocationRequiredDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(rDeAllocationDtlsListObj);
		when(adminSrvcClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(ModuleDto);
		when(rsrcWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		rsrcMgmntSrvcImpl.callSendEmailUtility(usrDtlsMap, 1);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		rsrcMgmntSrvcImpl.approveOrRejectRMApproval(RMApprovalInputDtlsList);
		verify(adminSrvcClient, times(5)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
	}

	private List<TAssociateAllocationBudget> getBudget() {
		List<TAssociateAllocationBudget> allocationBudget = new ArrayList<>();
		TAssociateAllocationBudget budget1 = new TAssociateAllocationBudget();
		budget1.setBudgetAllocatedMonth("2020-06");
		budget1.setBudgetAllocationMonth("2020-06");
		budget1.setMonthlyAvailableBudget(200000d);
		budget1.setMonthlyBudget(2000d);
		budget1.setMonthlyUsedBudget(2000d);
		allocationBudget.add(budget1);
		
		TAssociateAllocationBudget budget2 = new TAssociateAllocationBudget();
		budget2.setBudgetAllocatedMonth("2020-07");
		budget2.setBudgetAllocationMonth("2020-07");
		budget2.setMonthlyAvailableBudget(300000d);
		budget2.setMonthlyBudget(200d);
		budget2.setMonthlyUsedBudget(200d);
		allocationBudget.add(budget2);
		
		TAssociateAllocationBudget budget3 = new TAssociateAllocationBudget();
		budget3.setBudgetAllocatedMonth("2020-08");
		budget3.setBudgetAllocationMonth("2020-08");
		budget3.setMonthlyAvailableBudget(300000d);
		budget3.setMonthlyBudget(200d);
		budget3.setMonthlyUsedBudget(200d);
		allocationBudget.add(budget3);
		
		TAssociateAllocationBudget budget4 = new TAssociateAllocationBudget();
		budget4.setBudgetAllocatedMonth("2020-09");
		budget4.setBudgetAllocationMonth("2020-09");
		budget4.setMonthlyAvailableBudget(300000d);
		budget4.setMonthlyBudget(200d);
		budget4.setMonthlyUsedBudget(200d);
		allocationBudget.add(budget4);
		
		return allocationBudget;
	}

	@Test
	public void rejectRMApprovalForDeAllocReqTest() throws ResourceManagementException, ParseException {
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("REJECTED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		rmApprovalInputDtoObj.setRoleName("PROGRAM MANAGER");
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<AssociateDeAllocationProjection> rDeAllocationDtlsListObj = new ArrayList<>();
		AssociateDeAllocationProjection tAssociateDeAllocationObj = factory
				.createProjection(AssociateDeAllocationProjection.class);
		tAssociateDeAllocationObj.setAssociateDeAllocationId(1L);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		tAssociateDeAllocationObj.setActualAllocationStartDate(dateFormat.parse(("2020-06-01")));
		tAssociateDeAllocationObj.setActualAllocationEndDate(dateFormat.parse(("2020-07-30")));
		rDeAllocationDtlsListObj.add(tAssociateDeAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMDA");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(1L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);

		when(adminSrvcClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminSrvcClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(getProjectBudgetDto());
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateDeallocationRepository.getRDeAllocationRequiredDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(rDeAllocationDtlsListObj);
		when(adminSrvcClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(rsrcWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		doNothing().when(rsrcAllocationSrvcImpl).updateBudget(Mockito.any());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		rsrcMgmntSrvcImpl.callSendEmailUtility(usrDtlsMap, 1);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		rsrcMgmntSrvcImpl.approveOrRejectRMApproval(RMApprovalInputDtlsList);
		verify(adminSrvcClient, times(3)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
	}

	@Test
	public void rejectRMSavedResourcesAllocationTest() throws ResourceManagementException {

		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(4001);
		rmApprovalInputDtoObj.setRequirementId(7);
		rmApprovalInputDtoObj.setRequestType("RALLOCATION");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(11L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);

		ModuleStatusDto allocationStatusDto = new ModuleStatusDto();
		allocationStatusDto.setAction(ResourceManagementConstant.REJECTED);
		allocationStatusDto.setModuleId(3L);
		allocationStatusDto.setModuleStatusId(1L);
		allocationStatusDto.setParentModule(ResourceManagementConstant.RESOURCE_MANAGEMENT);
		allocationStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_ALLOCATION);

		List<TAssociateAllocation> tAllocationDtlsListObj = new ArrayList<>();

		when(adminSrvcClient.getModuleStatus("RESOURCE_MANAGEMENT", "RESOURCE_ALLOCATION", "REJECTED"))
				.thenReturn(allocationStatusDto);
		doNothing().when(tAssociateAllocationRepository).rejectRMSavedResources(Mockito.anyInt(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong());

		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		ResourceRequirementDto rsrcRqrmntDtoObj = new ResourceRequirementDto();

		when(budgetCntrlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(new ArrayList<>());
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(rsrcRqrmntDtoObj);

		rsrcMgmntSrvcImpl.releaseAllocatedBudgetForAlloc(tAllocationDtlsListObj, 4001L, 7L);
		doNothing().when(associateProjectRepository).setStatusIdForProject(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.any());
		when(tAssociateAllocationRepository.getActiveStatusCount(Mockito.anyLong(), Mockito.anyLong())).thenReturn(1);
		rsrcMgmntSrvcImpl.rejectRMSavedResources(List.of(rmApprovalInputDtoObj));
		verify(adminSrvcClient, times(1)).getModuleStatus("RESOURCE_MANAGEMENT", "RESOURCE_ALLOCATION", "REJECTED");
	}

	@Test
	public void rejectRMSavedResourcesDeallocationTest() throws ResourceManagementException {

		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(4001);
		rmApprovalInputDtoObj.setRequirementId(7);
		rmApprovalInputDtoObj.setRequestType("RDEALLOCATION");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(11L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		ResourceRequirementDto resourceRequirementDtls = new ResourceRequirementDto();
		List<Long> employeeIdList = new ArrayList<>();
		employeeIdList.add(123L);
		resourceRequirementDtls.setEmployeeIdList(employeeIdList);
		resourceRequirementDtls.setReqId(1);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		resourceRequirementList.add(resourceRequirementDtls);
		rmApprovalInputDtoObj.setResourceRequirementList(resourceRequirementList);
		;

		ModuleStatusDto deallocationStatusDto = new ModuleStatusDto();
		deallocationStatusDto.setAction(ResourceManagementConstant.REJECTED);
		deallocationStatusDto.setModuleId(4L);
		deallocationStatusDto.setModuleStatusId(4L);
		deallocationStatusDto.setParentModule(ResourceManagementConstant.RESOURCE_MANAGEMENT);
		deallocationStatusDto.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);

		when(adminSrvcClient.getModuleStatus("RESOURCE_MANAGEMENT", "RESOURCE_DEALLOCATION", "REJECTED"))
				.thenReturn(deallocationStatusDto);
		doNothing().when(tAssociateDeallocationRepository).rejectRMSavedResources(Mockito.anyInt(), Mockito.anyList(),
				Mockito.anyLong());
		rsrcMgmntSrvcImpl.rejectRMSavedResources(List.of(rmApprovalInputDtoObj));
		verify(adminSrvcClient, times(1)).getModuleStatus("RESOURCE_MANAGEMENT", "RESOURCE_DEALLOCATION", "REJECTED");
	}

	@Test
	public void getWrkflwTypeIdByRequestTypeTest() throws ResourceManagementException {
		List<String> requestTypes = new ArrayList<>();
		requestTypes.add(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		requestTypes.add(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		requestTypes.add(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		requestTypes.add(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE);
		ModuleStatusDto moduleDetailsDto = new ModuleStatusDto();
		moduleDetailsDto.setModuleId(1L);
		moduleDetailsDto.setModuleStatusId(1L);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDetailsDto);
		for (String requesType : requestTypes) {
			long wrkflwId = rsrcMgmntSrvcImpl.getWrkflwTypeIdByRequestType(requesType);
			assertNotNull(wrkflwId);
		}
	}

	@Test
	public void setWrkflwCodeByRequestTypeTest() throws ResourceManagementException {
		List<String> requestTypes = new ArrayList<>();
		requestTypes.add(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		requestTypes.add(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		requestTypes.add(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		requestTypes.add(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE);
		ModuleStatusDto moduleDetailsDto = new ModuleStatusDto();
		moduleDetailsDto.setModuleId(1L);
		moduleDetailsDto.setModuleStatusId(1L);
		moduleDetailsDto.setModuleCode("RMA");
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDetailsDto);
		for (String requesType : requestTypes) {
			String wrkflwCode=null;
			if(requesType.equalsIgnoreCase(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE))
				wrkflwCode = rsrcMgmntSrvcImpl.setWrkflwCode(requesType, "RMTPGM");
			else
				wrkflwCode = rsrcMgmntSrvcImpl.setWrkflwCode(requesType, null);
			assertNotNull(wrkflwCode);
		}
	}

	@Test
	public void getRMTransferApproversListTest() throws ResourceManagementException {
		RMApproversDto rmApproversDtoObjOne = new RMApproversDto();
		RMApproversDto rmApproversDtoObjTwo = new RMApproversDto();
		RMApproversDto rmApproversDtoObjThree = new RMApproversDto();
		rmApproversDtoObjOne.setRoleId(1);
		rmApproversDtoObjTwo.setRoleId(2);
		rmApproversDtoObjThree.setRoleId(2);
		rmApproversDtoObjOne.setRoleName("PM");
		rmApproversDtoObjTwo.setRoleName("PGM");
		rmApproversDtoObjThree.setRoleName("PGM");
		rmApproversDtoObjOne.setUserId(1);
		rmApproversDtoObjTwo.setUserId(2);
		rmApproversDtoObjThree.setUserId(3);
		rmApproversDtoObjOne.setUserName("user-1");
		rmApproversDtoObjTwo.setUserName("user-2");
		rmApproversDtoObjThree.setUserName("user-3");
		List<RMApproversDto> ipRMApproversListDtoObj = new ArrayList<>();
		ipRMApproversListDtoObj.add(rmApproversDtoObjOne);
		ipRMApproversListDtoObj.add(rmApproversDtoObjTwo);
		ipRMApproversListDtoObj.add(rmApproversDtoObjThree);
		List<Long> userIdListObj = new ArrayList<>();
		userIdListObj.add(1L);
		userIdListObj.add(2L);
		userIdListObj.add(3L);
		
		WrkflwStepDefinitionDto wrkflwDfntnDtoObjOne = new WrkflwStepDefinitionDto();
		WrkflwStepDefinitionDto wrkflwDfntnDtoObjTwo = new WrkflwStepDefinitionDto();
		WrkflwStepDefinitionDto wrkflwDfntnDtoObjThree = new WrkflwStepDefinitionDto();
        wrkflwDfntnDtoObjOne.setRoleId(2);
		wrkflwDfntnDtoObjTwo.setRoleId(1);
		wrkflwDfntnDtoObjThree.setRoleId(305);
		wrkflwDfntnDtoObjOne.setNextRoleId(3);
		wrkflwDfntnDtoObjTwo.setNextRoleId(2);
		wrkflwDfntnDtoObjOne.setStepId(1);
		wrkflwDfntnDtoObjTwo.setStepId(2);
		wrkflwDfntnDtoObjThree.setStepId(233);
		List<WrkflwStepDefinitionDto> wrkflwDfntnDtoListObj = new ArrayList<>();
		wrkflwDfntnDtoListObj.add(wrkflwDfntnDtoObjOne);
		wrkflwDfntnDtoListObj.add(wrkflwDfntnDtoObjTwo);
		wrkflwDfntnDtoListObj.add(wrkflwDfntnDtoObjThree);
		
		
		when(wrkflwEngineSrvcClient.getWrkflwStepDetails(Mockito.anyString())).thenReturn(wrkflwDfntnDtoListObj);
		when(bapSrvcClient.getPrimaryOwnersList(Mockito.anyLong())).thenReturn(userIdListObj);
		List<Long> roleIdListObj = new ArrayList<>();
		roleIdListObj.add(1L);
		ModuleStatusDto moduleDtlsDto = new ModuleStatusDto();
		moduleDtlsDto.setModuleCode("RMA");
		UserDto userDto = new UserDto();
		userDto.setUserId(52336);
		userDto.setUserName("user-5");
		List<UserDto> userObj = new ArrayList<>();
		userObj.add(userDto);

		PrimaryUsersDto primaryUsersDto = new PrimaryUsersDto();
		primaryUsersDto.setProjectCode("MSS");
		primaryUsersDto.setProjectId(49000);
		primaryUsersDto.setUserId(123l);
		primaryUsersDto.setUserName("xyz");
		primaryUsersDto.setRoleId(2l);
		primaryUsersDto.setRoleName("PGM");
		primaryUsersDto.setCustomerCode("CISCO");

		List<Long> projectIdList = new ArrayList<>();
		projectIdList.add(40002l);
		projectIdList.add(40001l);

		List<PrimaryUsersDto> user = new ArrayList<>();
		user.add(primaryUsersDto);

		FYIapproverDto fYIapproverDto = new FYIapproverDto();
		fYIapproverDto.setSourceFYIapproversList(user);
		fYIapproverDto.setTargetFYIapproversList(user);

		List<FYIapproverDto> fYIapproveList = new ArrayList<>();
		fYIapproveList.add(fYIapproverDto);

		TransferApproverResponseDto transferApproverResponseDto = new TransferApproverResponseDto();

		transferApproverResponseDto.setFyiApproverDto(fYIapproverDto);
		transferApproverResponseDto.setRmSourceApproversListObj(ipRMApproversListDtoObj);

		List<Long> roleIds = new ArrayList<>();
		roleIds.add(2l);
		
		List<WrkflwStepDefinitionDto> configuredEmailRoles = new ArrayList<>();
		WrkflwStepDefinitionDto wrkflwStepDefinitionDto = new WrkflwStepDefinitionDto();
		wrkflwStepDefinitionDto.setRoleId(1);
		wrkflwStepDefinitionDto.setStepId(123l);
		configuredEmailRoles.add(wrkflwStepDefinitionDto);

		when(wrkflwEngineSrvcClient.getWrkflwStepEmailDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyLong())).thenReturn(configuredEmailRoles);
		when(adminSrvcClient.getRMApproversList(Mockito.anyList(), Mockito.anyList()))
				.thenReturn(ipRMApproversListDtoObj);
		when(tAssociateAllocationRepository.getLookupValueForTag()).thenReturn(1L);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDtlsDto);
		when(adminSrvcClient.getEmailRMApproversList(Mockito.anyLong(), Mockito.anyLong())).thenReturn(userObj);
		when(adminSrvcClient.getRoleIds(Mockito.anyList())).thenReturn(roleIds);
		when(bapSrvcClient.getListPrimaryOwnersList(Mockito.anyList(), Mockito.anyList())).thenReturn(user);
		transferApproverResponseDto = rsrcMgmntSrvcImpl.getRMTransferApproversList(40001l, 40002l, 52336l, 1l,
				"RALLOCATION");

		assertNotNull(transferApproverResponseDto);

	}

	@Test
	public void findStatusIdByRequestTypeTest() throws ResourceManagementException {
		List<String> requestTypes = new ArrayList<>();
		requestTypes.add(ResourceManagementConstant.RM_ALLOCATION_REQUEST_CODE);
		requestTypes.add(ResourceManagementConstant.RM_DEALLOCATION_REQUEST_CODE);
		requestTypes.add(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		requestTypes.add(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE);
		ModuleStatusDto moduleDetailsDto = new ModuleStatusDto();
		moduleDetailsDto.setModuleId(1L);
		moduleDetailsDto.setModuleStatusId(1L);
		moduleDetailsDto.setModuleCode("RMA");
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDetailsDto);
		for (String requesType : requestTypes) {
			long statusId = rsrcMgmntSrvcImpl.findSubmitStatusIdByRequestType(requesType);
			assertNotNull(statusId);
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	
	@Test
	public void approveRMApprovalForAllocReqTestExtension() throws ResourceManagementException, ParseException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(1L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		rsrcWrkflwObj.setStatusId(0l);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
		
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);
		
		when(tAssociateExtensionRepository.getExtensionResourceList(Mockito.anyList(),Mockito.anyLong() ,Mockito.anyLong(), Mockito.anyLong())).thenReturn(getassociateExtensionProjection());
		when(adminSrvcClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleStatusDto);
		when(rsrcWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		
		when(adminSrvcClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminSrvcClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);
		
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		//rsrcMgmntSrvcImpl.approveOrRejectRMApproval(RMApprovalInputDtlsList);
		rsrcMgmntSrvcImpl.approveOrRejectRMApprovalForExtension(RMApprovalInputDtlsList);
		verify(tAssociateExtensionRepository, times(1)).getExtensionResourceList(Mockito.anyList(), Mockito.anyLong(),  Mockito.anyLong(),  Mockito.anyLong());
	}
	
	
	@Test
	public void approveRMApprovalForAllocReqTestFinalApprovalEXTENSION() throws ResourceManagementException, ParseException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(0l);
		rsrcWrkflwObj.setResourceWrkflwId(0l);
		rsrcWrkflwObj.setNextUserId(0L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		
		List<EstimatedEndDateProjection> estimatedEndDateProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		EstimatedEndDateProjection estimatedEndDateProjection = factory.createProjection(EstimatedEndDateProjection.class);
		estimatedEndDateProjection.setassociateAllocationId(1L);
		estimatedEndDateProjection.setapprovedEndDate(dateFormat.parse("2020-07-31"));
		estimatedEndDateProjectionList.add(estimatedEndDateProjection);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);
		
		when(tAssociateExtensionRepository.getApprovedEndDateofResource(Mockito.anyList(), Mockito.anyLong(),  Mockito.anyLong())).thenReturn(estimatedEndDateProjectionList);
		when(tAssociateExtensionRepository.getExtensionResourceList(Mockito.anyList(),Mockito.anyLong() ,Mockito.anyLong(), Mockito.anyLong())).thenReturn(getassociateExtensionProjection());

		when(adminSrvcClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleStatusDto);
		when(rsrcWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		when(adminSrvcClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminSrvcClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		rsrcMgmntSrvcImpl.approveOrRejectRMApprovalForExtension(RMApprovalInputDtlsList);
		verify(tAssociateExtensionRepository, times(1)).getExtensionResourceList(Mockito.anyList(), Mockito.anyLong(),  Mockito.anyLong(),  Mockito.anyLong());

	}
	
	@Test
	public void rejectRMApprovalForAllocReqTestEXTENSION() throws ResourceManagementException, ParseException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("REJECTED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		tAssociateAllocationObj.setFtePercent(100.00);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		tAssociateAllocationObj.setActualAllocationStartDate(dateFormat.parse(("2020-06-01")));		
		tAssociateAllocationObj.setActualAllocationEndDate(dateFormat.parse(("2020-07-30")));
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(1L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		rsrcWrkflwObj.setStatusId(0l);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);

		when(adminSrvcClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminSrvcClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		
		/*
		 * when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.
		 * anyLong())) .thenReturn(getProjectBudgetDto());
		 */
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateExtensionRepository.getExtensionResourceList(Mockito.anyList(),Mockito.anyLong() ,Mockito.anyLong(), Mockito.anyLong())).thenReturn(getassociateExtensionProjection());

		when(adminSrvcClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleStatusDto);
		when(rsrcWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		doNothing().when(rsrcAllocationSrvcImpl).updateBudget(Mockito.any());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		//resourceExtensionServiceImpl.callSendEmailUtility(usrDtlsMap, 1);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		rsrcMgmntSrvcImpl.approveOrRejectRMApprovalForExtension(RMApprovalInputDtlsList);
		verify(tAssociateExtensionRepository, times(1)).getExtensionResourceList(Mockito.anyList(), Mockito.anyLong(),  Mockito.anyLong(),  Mockito.anyLong());
		/*
		 * verify(tAssociateAllocationRepository,
		 * times(1)).getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
		 * Mockito.anyList(), Mockito.anyLong());
		 */
	}
	

	
	@Test
	public void rejectRMApprovalForAllocReqTestFinalRejectionEXTENSION() throws ResourceManagementException, ParseException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("REJECTED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		tAssociateAllocationObj.setFtePercent(100.00);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		tAssociateAllocationObj.setActualAllocationStartDate(dateFormat.parse(("2020-06-01")));		
		tAssociateAllocationObj.setActualAllocationEndDate(dateFormat.parse(("2020-07-30")));
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(0L);
		rsrcWrkflwObj.setCurrentUserId(0L);
		rsrcWrkflwObj.setNextRoleId(0L);
		rsrcWrkflwObj.setResourceWrkflwId(4L);
		rsrcWrkflwObj.setNextUserId(0L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(24L);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);

		when(adminSrvcClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminSrvcClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		/*
		 * when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.
		 * anyLong())) .thenReturn(getProjectBudgetDto());
		 */
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateExtensionRepository.getExtensionResourceList(Mockito.anyList(),Mockito.anyLong() ,Mockito.anyLong(), Mockito.anyLong())).thenReturn(getassociateExtensionProjection());

		when(adminSrvcClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleStatusDto);
		when(rsrcWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(null);
		when(rsrcWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(null);
		doNothing().when(rsrcAllocationSrvcImpl).updateBudget(Mockito.any());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		//resourceExtensionServiceImpl.callSendEmailUtility(usrDtlsMap, 1);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		rsrcMgmntSrvcImpl.approveOrRejectRMApprovalForExtension(RMApprovalInputDtlsList);
		verify(tAssociateExtensionRepository, times(1)).getExtensionResourceList(Mockito.anyList(), Mockito.anyLong(),  Mockito.anyLong(),  Mockito.anyLong());
	
		/*
		 * verify(tAssociateAllocationRepository,
		 * times(1)).getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
		 * Mockito.anyList(), Mockito.anyLong());
		 */
	}
	
	private  List<AssociateExtensionProjection> getassociateExtensionProjection() throws ParseException
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		List<AssociateExtensionProjection> associateList = new ArrayList<>();
        ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
        AssociateExtensionProjection allocatedExtensionProjection = factory
				.createProjection(AssociateExtensionProjection.class);
        allocatedExtensionProjection.setallocationId(1l);
        allocatedExtensionProjection.setextensionId(1l);
        allocatedExtensionProjection.setrequirmentId(2l);
        allocatedExtensionProjection.setextendedDate(dateFormat.parse(("2020-06-01")));
		
		associateList.add(allocatedExtensionProjection);

		return associateList;
	}
	
	@Test(expected = ResourceManagementException.class)
	public void approveRMApprovalForAllocReqTestFinalApprovalEXTENSIONNull() throws ResourceManagementException, ParseException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_ALLOCATION_EXTENSION_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		moduleStatusDto.setModuleStatusId(1L);
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(0l);
		rsrcWrkflwObj.setResourceWrkflwId(0l); 
		rsrcWrkflwObj.setNextUserId(0L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		
		List<EstimatedEndDateProjection> estimatedEndDateProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		EstimatedEndDateProjection estimatedEndDateProjection = factory.createProjection(EstimatedEndDateProjection.class);
		estimatedEndDateProjection.setassociateAllocationId(1L);
		estimatedEndDateProjection.setapprovedEndDate(dateFormat.parse("2020-07-31"));
		estimatedEndDateProjectionList.add(estimatedEndDateProjection);
		when(tAssociateExtensionRepository.getApprovedEndDateofResource(Mockito.anyList(), Mockito.anyLong(),  Mockito.anyLong())).thenReturn(estimatedEndDateProjectionList);
		when(tAssociateExtensionRepository.getExtensionResourceList(Mockito.anyList(),Mockito.anyLong() ,Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
  
		when(adminSrvcClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminSrvcClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleStatusDto);
		when(rsrcWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(rsrcWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		rsrcMgmntSrvcImpl.approveOrRejectRMApprovalForExtension(RMApprovalInputDtlsList);
		assertEquals(500, 500,"Internal Server Error");
        verify(tAssociateExtensionRepository, times(1)).getExtensionResourceList(Mockito.anyList(), Mockito.anyLong(),  Mockito.anyLong(),  Mockito.anyLong());

	}
	
	
	
	@Test
	public void getCostCardTest() throws ResourceManagementException
	{
		CostCardDto costCardDto = new CostCardDto();
		costCardDto.setCurrencyId(1L);
		costCardDto.setCurrencyId(2L);
		costCardDto.setEightHrsCostRate(new BigDecimal(2L));
		CostCardInputDto costCardInputDto = new CostCardInputDto();
		costCardInputDto.setBandId(1l);
		costCardInputDto.setLocationType("Onshore");
		when(adminSrvcClient.getCostCard(Mockito.any())).thenReturn(costCardDto);
		CostCardDto costcarddto = rsrcMgmntSrvcImpl.getCostCard(costCardInputDto);
        assertNotNull(costcarddto);

	}
	
	public List<ModuleStatusDto> getnewRMModuleList() {
		 
		List<ModuleStatusDto> moduleList = new ArrayList<>();
		 ModuleStatusDto moduleStatusDtoAllocation = new ModuleStatusDto();
	        moduleStatusDtoAllocation.setModuleId(1l);
	        moduleStatusDtoAllocation.setModuleStatusId(1l);
	        moduleStatusDtoAllocation.setModuleCode("RM");
	        moduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
	        moduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
	        moduleStatusDtoAllocation.setAction("APPROVED");
	        moduleList.add(moduleStatusDtoAllocation);
	        ModuleStatusDto newmoduleStatus2DtoAllocation = new ModuleStatusDto();
	        newmoduleStatus2DtoAllocation.setModuleId(2l);
	        newmoduleStatus2DtoAllocation.setModuleStatusId(2l);
	        newmoduleStatus2DtoAllocation.setModuleCode("RM");
	        newmoduleStatus2DtoAllocation.setSubModule("RESOURCE_DEALLOCATION");
	        newmoduleStatus2DtoAllocation.setParentModule("RESOURCE_DEALLOCATION");
	        newmoduleStatus2DtoAllocation.setAction("DEACTIVATE");
	        moduleList.add(newmoduleStatus2DtoAllocation);
	        ModuleStatusDto newmoduleStatusDtoAllocation = new ModuleStatusDto();

	 

	        newmoduleStatusDtoAllocation.setModuleId(2l);
	        newmoduleStatusDtoAllocation.setModuleStatusId(1l);
	        newmoduleStatusDtoAllocation.setModuleCode("RM");
	        newmoduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
	        newmoduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
	        newmoduleStatusDtoAllocation.setAction("ACTIVATE");
	        moduleList.add(newmoduleStatusDtoAllocation);

	 

	        ModuleStatusDto moduleStatusDtoTransfer = new ModuleStatusDto();
	        moduleStatusDtoTransfer.setModuleId(1l);
	        moduleStatusDtoTransfer.setModuleStatusId(1l);
	        moduleStatusDtoTransfer.setModuleCode("RM");
	        moduleStatusDtoTransfer.setSubModule("RESOURCE_TRANSFER");
	        moduleStatusDtoTransfer.setParentModule("RESOURCE_TRANSFER");
	        moduleStatusDtoTransfer.setAction("APPROVED");
	        moduleList.add(moduleStatusDtoTransfer);

	 

	        ModuleStatusDto moduleStatusDtoDeallocationSved = new ModuleStatusDto();
	        moduleStatusDtoDeallocationSved.setModuleId(1l);
	        moduleStatusDtoDeallocationSved.setModuleStatusId(1l);
	        
	        moduleStatusDtoDeallocationSved.setModuleCode("RM");
	        moduleStatusDtoDeallocationSved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
	        moduleStatusDtoDeallocationSved.setParentModule("RESOURCE_TRANSFER");
	        moduleStatusDtoDeallocationSved.setAction("SAVED");
	        moduleList.add(moduleStatusDtoDeallocationSved);
	        ModuleStatusDto moduleStatusDtoDeallocationSubmitted = new ModuleStatusDto();
	        moduleStatusDtoDeallocationSubmitted.setModuleId(1l);
	        moduleStatusDtoDeallocationSubmitted.setModuleStatusId(1l);
	        moduleStatusDtoDeallocationSubmitted.setModuleCode("RM");
	        moduleStatusDtoDeallocationSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
	        moduleStatusDtoDeallocationSubmitted.setParentModule("RESOURCE_TRANSFER");
	        moduleStatusDtoDeallocationSubmitted.setAction("SUBMITTED");
	        moduleList.add(moduleStatusDtoDeallocationSubmitted);
	        ModuleStatusDto moduleStatusDtoDeallocationApproved = new ModuleStatusDto();
	        moduleStatusDtoDeallocationApproved.setModuleId(1l);
	        moduleStatusDtoDeallocationApproved.setModuleCode("RM");
	        moduleStatusDtoDeallocationApproved.setModuleStatusId(1l);
	        moduleStatusDtoDeallocationApproved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
	        moduleStatusDtoDeallocationApproved.setParentModule("RESOURCE_TRANSFER");
	        moduleStatusDtoDeallocationApproved.setAction("APPROVED");
	        moduleList.add(moduleStatusDtoDeallocationApproved);

	 

	        ModuleStatusDto moduleStatusDtoTansferSved = new ModuleStatusDto();
	        moduleStatusDtoTansferSved.setModuleId(1l);  
	        moduleStatusDtoTansferSved.setModuleStatusId(1l);
	        moduleStatusDtoTansferSved.setModuleCode("RM");
	        moduleStatusDtoTansferSved.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
	        moduleStatusDtoTansferSved.setParentModule("RESOURCE_TRANSFER");
	        moduleStatusDtoTansferSved.setAction("SAVED");
	        moduleList.add(moduleStatusDtoTansferSved);
	        ModuleStatusDto moduleStatusDtoTransferSubmitted = new ModuleStatusDto();
	        moduleStatusDtoTransferSubmitted.setModuleId(1l);
	        moduleStatusDtoTransferSubmitted.setModuleStatusId(1l);
	        moduleStatusDtoTransferSubmitted.setModuleCode("RM");
	        moduleStatusDtoTransferSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
	        moduleStatusDtoTransferSubmitted.setParentModule("RESOURCE_TRANSFER");
	        moduleStatusDtoTransferSubmitted.setAction("SUBMITTED");
	        moduleList.add(moduleStatusDtoTansferSved);
	        ModuleStatusDto moduleStatusDtoExtension = new ModuleStatusDto();
	        moduleStatusDtoExtension.setModuleId(1l);
	        moduleStatusDtoExtension.setModuleStatusId(1l);    
	        moduleStatusDtoExtension.setModuleCode("RM");
	        moduleStatusDtoExtension.setSubModule("RESOURCE_EXTENSION");
	        moduleStatusDtoExtension.setParentModule("RESOURCE_EXTENSION"); 
	        moduleStatusDtoExtension.setAction("SUBMITTED");
	        moduleList.add(moduleStatusDtoExtension);
	        return moduleList;
	}
	
	
	@Test
	public void getAllEmployeeDetailsTest() throws ResourceManagementException {
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employee = new EmployeeDto();
		employee.setEmployeeName("ABC");
		employee.setEmployeeId(1L);
		employeeList.add(employee);
		when(adminSrvcClient.getAllEmployeeDetails(Mockito.anyString())).thenReturn(employeeList);
		List<EmployeeDto> employees = rsrcMgmntSrvcImpl.getAllEmployeeDetails(Mockito.anyString());
		assertNotNull(employees);
	}

	@Test
	public void getAllEmployeeDetailsMissingTest() throws ResourceManagementException {
		when(adminSrvcClient.getAllEmployeeDetails(Mockito.anyString())).thenReturn(null);
		List<EmployeeDto> employees = rsrcMgmntSrvcImpl.getAllEmployeeDetails(Mockito.anyString());
		assertNull(employees);
	}

}
