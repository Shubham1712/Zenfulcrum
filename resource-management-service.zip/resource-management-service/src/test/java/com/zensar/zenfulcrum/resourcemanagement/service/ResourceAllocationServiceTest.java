package com.zensar.zenfulcrum.resourcemanagement.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.projection.ProjectionFactory;
import org.springframework.data.projection.SpelAwareProxyProjectionFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.HashBasedTable;
import com.zensar.zenfulcrum.resourcemanagement.dto.AllocationTypeStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PrimaryUsersDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ServiceLineDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.AllocatedResourceHelperClass;
import com.zensar.zenfulcrum.resourcemanagement.helper.JVCheckHelperService;
import com.zensar.zenfulcrum.resourcemanagement.helper.SendMailHelperService;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateAllocationMapper;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateProjectMapper;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocationBudget;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateProject;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateSkill;
import com.zensar.zenfulcrum.resourcemanagement.model.TSrf;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.AvaibalityProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.GetResourceReqProjection;
import com.zensar.zenfulcrum.resourcemanagement.projection.SrfProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.JVDetailsRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateSkillRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TSrfRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementUtil;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceAllocationServiceTest {
  
	@InjectMocks
	private ResourceAllocationServiceImpl resourceAllocationServiceImpl;
	@Mock
	private BAPServiceClient bapSrvcClient;

	@Mock
	private BudgetControlServiceClient budgetControlServiceClient;
 
	@Mock
	TAssociateAllocationRepository allocationRepository;

	@Mock
	TAssociateProjectMapper asssociateProjectMapper;

	@Mock
	private AdminServiceClient adminServiceClient;

	@Mock
	private TSrfRepository tSrfRepository;

	@Mock
	private TAssociateAllocationRepository tAssociateAllocationRepository;

	@Mock
	private TAssociateProjectRepository associateProjectRepository;

	@Mock
	private GetResourceReqProjection getResourceReqProjection;

	@Mock
	private SendMailHelperService sendMailHelperService;

	@Mock
	private TAssociateAllocationMapper tAssociateAllocationMapper;

	@Mock
	private TAssociateSkillRepository skillRepository;

	@Mock
	JVDetailsRepository jvDetailsRepository;

	@Mock
	JVCheckHelperService jvCheckHelperService;
	
	@Mock
	AllocatedResourceHelperClass allocatedResourceHelper;

	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getEarmarkedAssociatesTest() throws ResourceManagementException {
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(1l);
		employeeDto.setEmployeeName("Test");
		List<EmployeeDto> employeesObj = new ArrayList<>();
		employeesObj.add(employeeDto);

		List<Long> tSrfsList = new ArrayList<>();
		tSrfsList.add(123l);
		tSrfsList.add(124l);
		
		List<Long> empList = new ArrayList<>();
		empList.add(123l);
  
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		when(allocatedResourceHelper.getallModuleData()).thenReturn(getModuleList());
		when(tAssociateAllocationRepository.getResourceInAllocWfForProject(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong())).thenReturn(empList);
	
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		
		when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
		when(tSrfRepository.getCandidateIds(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(tSrfsList);
		when(adminServiceClient.getAssociatesDetails(Mockito.any())).thenReturn(employeesObj);
		when(tSrfRepository.getModuleIdForSrf(Mockito.anyString(), Mockito.anyString())).thenReturn(9L);
		when(tAssociateAllocationRepository.getProjectCode(Mockito.anyLong())).thenReturn("123435");

		List<EmployeeDto> employees = resourceAllocationServiceImpl.getEarmarkedAssociates(123l, 1l);
		assertNotNull(employees);

		verify(adminServiceClient, times(1)).getAssociatesDetails(Mockito.any());
		verify(tSrfRepository, times(1)).getCandidateIds(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean(),Mockito.anyLong(),Mockito.anyLong());
	}

	@Test
	public void getEarmarkedAssociatesTestNull() throws ResourceManagementException {
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		
		
		List<Long> empList = new ArrayList<>();
		empList.add(123l);
  

		when(allocatedResourceHelper.getallModuleData()).thenReturn(getModuleList());
		when(tAssociateAllocationRepository.getResourceInAllocWfForProject(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong())).thenReturn(null);
	

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
		when(tSrfRepository.getCandidateIds(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(null);
		when(tSrfRepository.getModuleIdForSrf(Mockito.anyString(), Mockito.anyString())).thenReturn(9L);
		when(tAssociateAllocationRepository.getProjectCode(Mockito.anyLong())).thenReturn("123435");
		List<EmployeeDto> employees = resourceAllocationServiceImpl.getEarmarkedAssociates(123l, 1l);
		assertNull(employees);
		verify(tSrfRepository, times(1)).getCandidateIds(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean(),Mockito.anyLong(),Mockito.anyLong());
	}

	@Test
	public void getEarmarkedAssociatesTestEmpty() throws ResourceManagementException {
		List<Long> tSrfsList = new ArrayList<>();
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		
		List<Long> empList = new ArrayList<>();
		empList.add(123l);
  

		when(allocatedResourceHelper.getallModuleData()).thenReturn(getModuleList());
		when(tAssociateAllocationRepository.getResourceInAllocWfForProject(Mockito.anyLong(), Mockito.anyList(), Mockito.anyLong())).thenReturn(empList);
	
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
        when(tSrfRepository.getCandidateIds(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(tSrfsList);
		when(tSrfRepository.getModuleIdForSrf(Mockito.anyString(), Mockito.anyString())).thenReturn(9L);
		when(tAssociateAllocationRepository.getProjectCode(Mockito.anyLong())).thenReturn("123435");

		List<EmployeeDto> employees = resourceAllocationServiceImpl.getEarmarkedAssociates(123l, 1l);
		assertNull(employees);
		verify(tSrfRepository, times(1)).getCandidateIds(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean(),Mockito.anyLong(),Mockito.anyLong());
	}

	@Test
	public void saveResourceAllocationsTest() throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setStdCost(22.0);

		allocationDto.setSupervisorId(52336l);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setSupervisorId(52336l);
		tAssociateProjectDto.setRoleName("PGM");
		tAssociateProjectDto.setBudgetAndCostCheck(true);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		moduleStatusDto.setModuleStatusId(1l);


		List<ProjectBudgetDto> projectBudget = getProjectBudgetDto();
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);
		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);

		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		Date today = new Date();
		Date yesterdayDate = new Date(today.getTime() - (1000 * 60 * 60 * 24));

		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(associateProjectRepository.save(Mockito.any())).thenReturn(null);
		when(jvDetailsRepository.getWindowEndDate()).thenReturn(new Date());
		when(jvCheckHelperService.isJvCheck(yesterdayDate)).thenReturn(true);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(5)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(adminServiceClient, times(1)).getAllocationTypeStatus(Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());
	}

	@Test
	public void saveResourceAllocationsTestForNonBillableProject() throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setStdCost(22.0);

		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setSupervisorId(52336l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("PGM");
		tAssociateProjectDto.setBudgetAndCostCheck(true);
		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		moduleStatusDto.setModuleStatusId(1l);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		List<ProjectBudgetDto> projectBudget = getProjectBudgetDto();
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);
		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);
		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);
		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");

		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);

		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());
	}

	@Test
	public void saveResourceAllocationsTestForCumulativeBudgetCheck()
			throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setStdCost(22.0);

		allocationDto.setRequirementId(1l);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setSupervisorId(52336l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("PGM");
		tAssociateProjectDto.setBudgetAndCostCheck(true);
		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDtoForCumulativeBudget();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setMonth("2020-04");
		projectBudgetDto1.setAvailableBudget(200000.00);
		projectBudgetDto1.setConsumedBudget(300.00);
		projectBudgetDto1.setBudgetCurrency(5d);
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.add(projectBudgetDto1);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementDto.setRequirementStartDate(dateFormat.parse("2020-04-01"));
		resourceRequirementDto.setRequirementEndDate(dateFormat.parse("2021-04-01"));
        resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);
		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);

		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(associateProjectRepository.save(Mockito.any())).thenReturn(null);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(5)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());
	}

	@Test
	public void saveResourceAllocationsTestForZeroCumulativeBudgetCheck()
			throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setRequirementId(1l);
		allocationDto.setStdCost(22.0);

		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("PGM");
		tAssociateProjectDto.setBudgetAndCostCheck(true);
		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		moduleStatusDto.setModuleStatusId(1l);


		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDtoForCumulativeBudget();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setMonth("2020-04");
		projectBudgetDto1.setAvailableBudget(0d);
		projectBudgetDto1.setBudgetCurrency(5d);
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.add(projectBudgetDto1);

		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		resourceRequirementDto.setRequirementStartDate(dateFormat.parse("2020-04-01"));
		resourceRequirementDto.setRequirementEndDate(dateFormat.parse("2021-04-01"));
        when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);

		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");

		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);

		when(associateProjectRepository.save(Mockito.any())).thenReturn(null);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(5)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());
	}

	@Test
	public void saveResourceAllocationsTestForCumulativeBudgetCheckWithoutConsumedBudget()
			throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setRequirementId(1l);
		allocationDto.setStdCost(22.0);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setBudgetAndCostCheck(true);
		tAssociateProjectDto.setRoleName("PGM");
		

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDtoForCumulativeBudget();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setMonth("2020-04");
		projectBudgetDto1.setAvailableBudget(20d);
		projectBudgetDto1.setBudgetCurrency(5d);
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.add(projectBudgetDto1);

		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);

		Date today = new Date();
		Date yesterdayDate = new Date(today.getTime() - (1000 * 60 * 60 * 24));

		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementDto.setRequirementStartDate(dateFormat.parse("2020-04-01"));
		resourceRequirementDto.setRequirementEndDate(dateFormat.parse("2021-04-01"));
         resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);
		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");

		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");
		when(associateProjectRepository.save(Mockito.any())).thenReturn(null);
		when(jvCheckHelperService.isJvCheck(yesterdayDate)).thenReturn(true);
		when(jvDetailsRepository.getWindowEndDate()).thenReturn(new Date());
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		 verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(5)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());
	}

	private List<ProjectBudgetDto> getProjectBudgetDtoForCumulativeBudget() throws ParseException {
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(200.00);
		projectBudgetDto1.setConsumedBudget(10.00);
		projectBudgetDto1.setBudgetCurrency(5d);
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setProjectEndDate(dateFormat.parse("2021-04-01"));
		projectBudget.add(projectBudgetDto1);

		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setMonth("2020-07");
		projectBudgetDto2.setAvailableBudget(300.00);
		projectBudgetDto2.setBudgetCurrency(5d);
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setProjectEndDate(dateFormat.parse("2021-04-01"));

		projectBudget.add(projectBudgetDto2);

		ProjectBudgetDto projectBudgetDto3 = new ProjectBudgetDto();
		projectBudgetDto3.setMonth("2020-05");
		projectBudgetDto3.setAvailableBudget(200000.00);
		projectBudgetDto3.setBudgetCurrency(5d);
		projectBudgetDto3.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setProjectEndDate(dateFormat.parse("2021-04-01"));

		projectBudget.add(projectBudgetDto3);
		return projectBudget;
	}

	@Test
	public void saveResourceAllocationsTestOffShore() throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setRequirementId(1l);

		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setStdCost(22.0);

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("PGM");
		tAssociateProjectDto.setBudgetAndCostCheck(true);
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDto();
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);
		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);

		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");

		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(associateProjectRepository.save(Mockito.any())).thenReturn(null);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(5)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());

	}

	/*
	 * @Test(expected = ResourceManagementException.class) public void
	 * saveResourceAllocationsTestNoAvailableBudget() throws
	 * ResourceManagementException, ParseException { TAssociateAllocationDto
	 * allocationDto = new TAssociateAllocationDto();
	 * allocationDto.setRequirementId(1l);
	 * 
	 * allocationDto.setFtePercent(100.00);
	 * allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
	 * allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
	 * allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
	 * allocationDto.setRequirementId(1l); allocationDto.setAllocationTypeId(2l);
	 * allocationDto.setAssociateProjectId(40001l);
	 * allocationDto.setAssociateAllocationId(1l); allocationDto.setRoleId(2l);
	 * allocationDto.setWorkLocationId(2l);
	 * 
	 * List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
	 * TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
	 * tAssociateProjectDto.setProjectId(Long.valueOf(123));
	 * tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
	 * tAssociateProjectDto.setTAssociateAllocation(allocationDto);
	 * tAssociateProjectDto.setRoleName("PGM");
	 * 
	 * allocationDtoList.add(tAssociateProjectDto);
	 * 
	 * ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
	 * moduleStatusDto.setModuleStatusId(1l);
	 * 
	 * List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDto();
	 * AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
	 * allocationTypeStatus.setAllocationTypeId(1l);
	 * allocationTypeStatus.setAllocationTypeValue("xyz");
	 * 
	 * when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).
	 * thenReturn(allocationTypeStatus);
	 * when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.
	 * anyLong())) .thenReturn(projectBudgetDto);
	 * resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l,
	 * allocationDtoList); verify(budgetControlServiceClient,
	 * times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong()); }
	 */

	@Test
	public void saveResourceAllocationsTestNullAvailablebudgetForMonth()
			throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setRequirementId(1l);
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setStdCost(22.0);

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(1l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("PGM");
		tAssociateProjectDto.setBudgetAndCostCheck(true);
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		moduleStatusDto.setModuleStatusId(1l);


		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDto();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-05");
		projectBudgetDto1.setAvailableBudget(2000.00);
		projectBudgetDto.add(projectBudgetDto1);

		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);

		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(5)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
	}

	@Test(expected = ResourceManagementException.class)
	public void saveResourceAllocationsTestLessAvailablebudgetForMonth()
			throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setRequirementId(1l);
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setStdCost(22.0);

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(1l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("PGM");

		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDto();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(10.00);
		projectBudgetDto.add(projectBudgetDto1);

		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto2.setBudgetCurrency(5.0);
		projectBudgetDto2.setMonth("2020-07");
		projectBudgetDto2.setAvailableBudget(30.00);
		projectBudgetDto.add(projectBudgetDto2);
		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);

		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementDto.setRequirementStartDate(dateFormat.parse("2020-04-01"));
		resourceRequirementDto.setRequirementEndDate(dateFormat.parse("2021-04-01"));
        resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(1)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
	}

	@Test(expected = ResourceManagementException.class)
	public void saveResourceAllocationsTestZeroAvailablebudgetForMonth()
			throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setRequirementId(1l);
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setStdCost(22.0);

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(1l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("PGM");

		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDto();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(0.00);
		projectBudgetDto.add(projectBudgetDto1);

		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto2.setBudgetCurrency(5.0);
		projectBudgetDto2.setMonth("2020-07");
		projectBudgetDto2.setAvailableBudget(30.00);
		projectBudgetDto.add(projectBudgetDto2);

		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
	
		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementDto.setRequirementStartDate(dateFormat.parse("2020-04-01"));
		resourceRequirementDto.setRequirementEndDate(dateFormat.parse("2021-04-01"));
        resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(1)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
	}

	private ResourceRequirementDto getResourceRequirementDto() {
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("ONSHORE");
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("ONSHORE");
		return resourceRequirementDto;
	}
	
	private List<ResourceRequirementDto> getResourceRequirementDtoList() {
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		return resourceRequirementList;
	}

	private List<ProjectBudgetDto> getProjectBudgetDto() throws ParseException {
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(200000.00);
		projectBudgetDto1.setConsumedBudget(10.00);

		projectBudget.add(projectBudgetDto1);

		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto2.setBudgetCurrency(5.0);
		projectBudgetDto2.setMonth("2020-07");
		projectBudgetDto2.setAvailableBudget(300000.00);

		projectBudget.add(projectBudgetDto2);
		return projectBudget;
	}

	/*
	 * @Test(expected = ResourceManagementException.class) public void
	 * saveResourceAllocationsTestFalse() throws ResourceManagementException,
	 * ParseException { TAssociateAllocationDto allocationDto = new
	 * TAssociateAllocationDto(); allocationDto.setRequirementId(1l);
	 * 
	 * allocationDto.setFtePercent(100.00);
	 * allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
	 * allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
	 * allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
	 * allocationDto.setRequirementId(1l); allocationDto.setAllocationTypeId(2l);
	 * allocationDto.setAssociateProjectId(40001l);
	 * allocationDto.setAssociateAllocationId(1l); allocationDto.setRoleId(2l);
	 * allocationDto.setWorkLocationId(2l);
	 * 
	 * List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
	 * TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
	 * tAssociateProjectDto.setProjectId(Long.valueOf(123));
	 * tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
	 * tAssociateProjectDto.setTAssociateAllocation(allocationDto);
	 * tAssociateProjectDto.setRoleName("PGM");
	 * 
	 * allocationDtoList.add(tAssociateProjectDto);
	 * 
	 * when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.
	 * anyLong())).thenReturn(null);
	 * resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l,
	 * allocationDtoList); verify(budgetControlServiceClient,
	 * times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong()); }
	 */

	/*
	 * @Test(expected = ResourceManagementException.class) public void
	 * saveResourceAllocationsTestNoRequirement() throws
	 * ResourceManagementException, ParseException { TAssociateAllocationDto
	 * allocationDto = new TAssociateAllocationDto();
	 * allocationDto.setRequirementId(1l);
	 * 
	 * allocationDto.setFtePercent(100.00);
	 * allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
	 * allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
	 * allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
	 * allocationDto.setRequirementId(1l); allocationDto.setAllocationTypeId(2l);
	 * allocationDto.setAssociateProjectId(40001l);
	 * allocationDto.setAssociateAllocationId(1l); allocationDto.setRoleId(2l);
	 * allocationDto.setWorkLocationId(2l);
	 * 
	 * List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
	 * TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
	 * tAssociateProjectDto.setProjectId(Long.valueOf(123));
	 * tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
	 * tAssociateProjectDto.setTAssociateAllocation(allocationDto);
	 * tAssociateProjectDto.setRoleName("PGM");
	 * 
	 * allocationDtoList.add(tAssociateProjectDto);
	 * when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.
	 * anyLong())) .thenReturn(getProjectBudgetDto());
	 * when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(
	 * null); resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l,
	 * allocationDtoList); verify(budgetControlServiceClient,
	 * times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
	 * verify(bapSrvcClient,
	 * times(1)).getRequirementDetailByReqId(Mockito.anyLong());
	 * 
	 * }
	 */

	@Test
	public void saveResourceAllocationsTestAddAnotherReqForSameProject()
			throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);

		allocationDto.setRequirementId(1l);

		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("PGM");
		tAssociateProjectDto.setBudgetAndCostCheck(true);
		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDto();
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
			.thenReturn(projectBudgetDto);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(associateProjectRepository.save(Mockito.any())).thenReturn(null);
		TAssociateProject tAssociateProjectExisting = new TAssociateProject();
		tAssociateProjectExisting.setAssociateProjectId(1l);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(tAssociateProjectExisting);
		TAssociateProjectDto tap = new TAssociateProjectDto();
		tap.setAssociateProjectId(1l);
		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);
		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		allocationDto.setStdCost(22.0);

		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(asssociateProjectMapper.tAssociateProjectToTAssociateProjectDto((TAssociateProject) Mockito.any()))
				.thenReturn(tap);

		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
	    verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(5)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		verify(asssociateProjectMapper, times(1))
				.tAssociateProjectToTAssociateProjectDto((TAssociateProject) Mockito.any());
	}

	@Test(expected = ResourceManagementException.class)
	public void saveResourceAllocationsTestNoAllocationRecord() throws ResourceManagementException, ParseException {
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setRoleName("PGM");

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(getProjectBudgetDto());
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(getResourceRequirementDtoList());
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(1)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
	}

	@Test
	public void getAssociateDetailTest() throws ResourceManagementException {

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(1);
		resourceRequirementDto.setBand("E2");
		resourceRequirementDto.setRequirementRole("Developer");

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto dto = new EmployeeDto();
		dto.setEmployeeId(52330l);
		dto.setEmployeeNumber(52330l);
		dto.setEmployeeName("Akshay T");
		dto.setEmployeePracticeId(2);
		dto.setPracticeName("AMS");
		dto.setBand("E1");
		dto.setRole("SOFTWARE ENGINEER");
		dto.setEmployeeRoleId(0);
		dto.setMatchFactor(1);
		dto.setAvailibility(20l);
		dto.setServiceLineId(2);
		dto.setServiceLineName("CORPORATE");
		dto.setResourceRequirementLocationId(3);
		dto.setResourceRequirementLocation("Hyderabad");
		dto.setRequirementRoleId(3);
		dto.setRequirementRole("Developer");
		dto.setBillable(false);
		employeeList.add(dto);
		List<SrfProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		SrfProjection getSrfProjection1 = factory.createProjection(SrfProjection.class);
		getSrfProjection1.setSrfId(3l);
		getSrfProjection1.setSrfNumber(2346l);
		getSrfProjection1.setCandidateId(52330l);

		SrfProjection getSrfProjection2 = factory.createProjection(SrfProjection.class);
		getSrfProjection2.setSrfId(5l);
		getSrfProjection2.setSrfNumber(2348l);
		getSrfProjection2.setCandidateId(52330l);

		srfProjectionList.add(getSrfProjection1);
		srfProjectionList.add(getSrfProjection2);

		List<AvaibalityProjection> avaibalityProjectionList = new ArrayList<>();
		AvaibalityProjection avaibalityProjection1 = factory.createProjection(AvaibalityProjection.class);
		avaibalityProjection1.setEmployeeId(52330l);
		avaibalityProjection1.setAllocatedFte(80l);
		avaibalityProjectionList.add(avaibalityProjection1);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		List<TAssociateSkill> associateSkill = new ArrayList<TAssociateSkill>();
		TAssociateSkill tAssociateSkill = new TAssociateSkill();
		tAssociateSkill.setAssociateSkillId(1l);
		tAssociateSkill.setAssociateId(52330l);
		tAssociateSkill.setSkillId(1l);
		associateSkill.add(tAssociateSkill);

		List<Long> listOfIds = new ArrayList<Long>();
		listOfIds.add(1l);

		List<Long> employeeIds = new ArrayList<Long>();
		employeeIds.add(52330l);
 
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
		.thenReturn(moduleStatusDto);
        when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);

        when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("NO");
 
		when(skillRepository.findByAssociateIdIn(Mockito.anyList())).thenReturn(associateSkill);
		when(skillRepository.getPrimarySkillForAssociate(Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(associateSkill);
		when(skillRepository.getSkillListForEmployee(Mockito.anyLong())).thenReturn(listOfIds);
		when(skillRepository.getSkillListForEmployee(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(listOfIds);

		when(tAssociateAllocationRepository.getPrimaryProjectCheck(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(employeeIds);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tSrfRepository.getsrfdetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean())).thenReturn(srfProjectionList);
		
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(avaibalityProjectionList);
		List<EmployeeDto> employeeDto = resourceAllocationServiceImpl.getAssociatesDetails(123l, 234l, employeeList);
		assertNotNull(employeeDto);

	}

	@Test
	public void getAssociateDetailTestBand1() throws ResourceManagementException {

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(1);
		resourceRequirementDto.setBand("E1");
		resourceRequirementDto.setRequirementRole("Developer");

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto dto = new EmployeeDto();
		dto.setEmployeeId(52330l);
		dto.setEmployeeNumber(123l);
		dto.setEmployeeName("Akshay T");
		dto.setEmployeePracticeId(2);
		dto.setPracticeName("AMS");
		dto.setBand("E2");
		dto.setRole("SOFTWARE ENGINEER");
		dto.setEmployeeRoleId(0);
		dto.setMatchFactor(1);
		dto.setAvailibility(20l);
		dto.setServiceLineId(2);
		dto.setServiceLineName("CORPORATE");
		dto.setResourceRequirementLocationId(3);
		dto.setResourceRequirementLocation("Hyderabad");
		dto.setRequirementRoleId(3);
		dto.setRequirementRole("Developer");
		dto.setBillable(false);
		employeeList.add(dto);
		List<SrfProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		SrfProjection getSrfProjection1 = factory.createProjection(SrfProjection.class);
		getSrfProjection1.setSrfId(3l);
		getSrfProjection1.setSrfNumber(2346l);
		getSrfProjection1.setCandidateId(52330l);

		SrfProjection getSrfProjection2 = factory.createProjection(SrfProjection.class);
		getSrfProjection2.setSrfId(5l);
		getSrfProjection2.setSrfNumber(2348l);
		getSrfProjection2.setCandidateId(52330l);

		srfProjectionList.add(getSrfProjection1);
		srfProjectionList.add(getSrfProjection2);

		List<AvaibalityProjection> avaibalityProjectionList = new ArrayList<>();
		AvaibalityProjection avaibalityProjection1 = factory.createProjection(AvaibalityProjection.class);
		avaibalityProjection1.setEmployeeId(52330l);
		avaibalityProjection1.setAllocatedFte(80l);
		avaibalityProjectionList.add(avaibalityProjection1);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
		.thenReturn(moduleStatusDto);
when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("NO");


		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tSrfRepository.getsrfdetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean())).thenReturn(srfProjectionList);
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(avaibalityProjectionList);
		List<EmployeeDto> employeeDto = resourceAllocationServiceImpl.getAssociatesDetails(123l, 234l, employeeList);
		assertNotNull(employeeDto);

	}

	@Test
	public void getAssociateDetailTestBand2() throws ResourceManagementException {

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(1);
		resourceRequirementDto.setBand("E1");
		resourceRequirementDto.setRequirementRole("Developer");

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto dto = new EmployeeDto();
		dto.setEmployeeId(52330l);
		dto.setEmployeeNumber(123l);
		dto.setEmployeeName("Akshay T");
		dto.setEmployeePracticeId(2);
		dto.setPracticeName("AMS");
		dto.setBand("E1");
		dto.setRole("SOFTWARE ENGINEER");
		dto.setEmployeeRoleId(0);
		dto.setMatchFactor(1);
		dto.setAvailibility(20l);
		dto.setServiceLineId(2);
		dto.setServiceLineName("CORPORATE");
		dto.setResourceRequirementLocationId(3);
		dto.setResourceRequirementLocation("Hyderabad");
		dto.setRequirementRoleId(3);
		dto.setRequirementRole("Developer");
		dto.setBillable(false);
		employeeList.add(dto);
		List<SrfProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		SrfProjection getSrfProjection1 = factory.createProjection(SrfProjection.class);
		getSrfProjection1.setSrfId(3l);
		getSrfProjection1.setSrfNumber(2346l);
		getSrfProjection1.setCandidateId(52330l);

		SrfProjection getSrfProjection2 = factory.createProjection(SrfProjection.class);
		getSrfProjection2.setSrfId(5l);
		getSrfProjection2.setSrfNumber(2348l);
		getSrfProjection2.setCandidateId(52330l);

		srfProjectionList.add(getSrfProjection1);
		srfProjectionList.add(getSrfProjection2);

		List<AvaibalityProjection> avaibalityProjectionList = new ArrayList<>();
		AvaibalityProjection avaibalityProjection1 = factory.createProjection(AvaibalityProjection.class);
		avaibalityProjection1.setEmployeeId(52330l);
		avaibalityProjection1.setAllocatedFte(80l);
		avaibalityProjectionList.add(avaibalityProjection1);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
		.thenReturn(moduleStatusDto);
when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);

when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
.thenReturn(moduleStatusDto);
when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tSrfRepository.getsrfdetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean())).thenReturn(srfProjectionList);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(avaibalityProjectionList);
		List<EmployeeDto> employeeDto = resourceAllocationServiceImpl.getAssociatesDetails(123l, 234l, employeeList);
		assertNotNull(employeeDto);

	}

	@Test
	public void getAssociateDetailHighRequirementBandTest() throws ResourceManagementException {

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(1);
		resourceRequirementDto.setBand("C1");
		resourceRequirementDto.setRequirementRole("Developer");

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto dto = new EmployeeDto();
		dto.setEmployeeId(52330l);
		dto.setEmployeeNumber(123l);
		dto.setEmployeeName("Akshay T");
		dto.setEmployeePracticeId(2);
		dto.setPracticeName("AMS");
		dto.setBand("E1");
		dto.setRole("SOFTWARE ENGINEER");
		dto.setEmployeeRoleId(0);
		dto.setMatchFactor(1);
		dto.setAvailibility(20l);
		dto.setServiceLineId(2);
		dto.setServiceLineName("CORPORATE");
		dto.setResourceRequirementLocationId(3);
		dto.setResourceRequirementLocation("Hyderabad");
		dto.setRequirementRoleId(3);
		dto.setRequirementRole("Developer");
		dto.setBillable(false);
		employeeList.add(dto);
		List<SrfProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		SrfProjection getSrfProjection1 = factory.createProjection(SrfProjection.class);
		getSrfProjection1.setSrfId(3L);
		getSrfProjection1.setSrfNumber(2346L);
		getSrfProjection1.setCandidateId(52330l);

		SrfProjection getSrfProjection2 = factory.createProjection(SrfProjection.class);
		getSrfProjection2.setSrfId(5L);
		getSrfProjection2.setSrfNumber(2348L);
		getSrfProjection2.setCandidateId(52330L);

		srfProjectionList.add(getSrfProjection1);
		srfProjectionList.add(getSrfProjection2);

		List<AvaibalityProjection> avaibalityProjectionList = new ArrayList<>();
		AvaibalityProjection avaibalityProjection1 = factory.createProjection(AvaibalityProjection.class);
		avaibalityProjection1.setEmployeeId(52330l);
		avaibalityProjection1.setAllocatedFte(80l);
		avaibalityProjectionList.add(avaibalityProjection1);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
		.thenReturn(moduleStatusDto);
when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
.thenReturn(moduleStatusDto);
when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);

      when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tSrfRepository.getsrfdetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean())).thenReturn(srfProjectionList);
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(avaibalityProjectionList);
		List<EmployeeDto> employeeDto = resourceAllocationServiceImpl.getAssociatesDetails(123l, 234l, employeeList);
		assertNotNull(employeeDto);

	}

	@Test
	public void getAssociateDetailLowRequirementBandTest() throws ResourceManagementException {

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(1);
		resourceRequirementDto.setBand("E");
		resourceRequirementDto.setRequirementRole("Developer");

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto dto = new EmployeeDto();
		dto.setEmployeeId(52330l);
		dto.setEmployeeName("Akshay T");
		dto.setEmployeePracticeId(2);
		dto.setPracticeName("AMS");
		dto.setBand("C");
		dto.setRole("SOFTWARE ENGINEER");
		dto.setEmployeeRoleId(0);
		dto.setMatchFactor(1);
		dto.setAvailibility(20l);
		dto.setServiceLineId(2);
		dto.setServiceLineName("CORPORATE");
		dto.setResourceRequirementLocationId(3);
		dto.setResourceRequirementLocation("Hyderabad");
		dto.setRequirementRoleId(3);
		dto.setRequirementRole("Developer");
		dto.setBillable(false);
		employeeList.add(dto);
		List<SrfProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		SrfProjection getSrfProjection1 = factory.createProjection(SrfProjection.class);
		getSrfProjection1.setSrfId(3l);
		getSrfProjection1.setSrfNumber(2346l);
		getSrfProjection1.setCandidateId(52330l);

		SrfProjection getSrfProjection2 = factory.createProjection(SrfProjection.class);
		getSrfProjection2.setSrfId(5l);
		getSrfProjection2.setSrfNumber(2348l);
		getSrfProjection2.setCandidateId(52330l);

		srfProjectionList.add(getSrfProjection1);
		srfProjectionList.add(getSrfProjection2);

		List<AvaibalityProjection> avaibalityProjectionList = new ArrayList<>();
		AvaibalityProjection avaibalityProjection1 = factory.createProjection(AvaibalityProjection.class);
		avaibalityProjection1.setEmployeeId(52330l);
		avaibalityProjection1.setAllocatedFte(80l);
		avaibalityProjectionList.add(avaibalityProjection1);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
		.thenReturn(moduleStatusDto);
when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(tSrfRepository.getsrfdetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean())).thenReturn(srfProjectionList);
	      when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tSrfRepository.findByCandidateIdIn(Mockito.anyList(), Mockito.anyLong())).thenReturn(srfProjectionList);
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(avaibalityProjectionList);
		List<EmployeeDto> employeeDto = resourceAllocationServiceImpl.getAssociatesDetails(123l, 234l, employeeList);
		assertNotNull(employeeDto);

	}

	@Test
	public void getAssociateDetailNotEqualAvailabilityEmpIdAndNotEqualSrfCandidateIdTest()
			throws ResourceManagementException {

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(1);
		resourceRequirementDto.setBand("E");
		resourceRequirementDto.setRequirementRole("Developer");

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto dto = new EmployeeDto();
		dto.setEmployeeId(52330l);
		dto.setEmployeeName("Akshay T");
		dto.setEmployeePracticeId(2);
		dto.setPracticeName("AMS");
		dto.setBand("C");
		dto.setRole("SOFTWARE ENGINEER");
		dto.setEmployeeRoleId(0);
		dto.setMatchFactor(1);
		dto.setAvailibility(20l);
		dto.setServiceLineId(2);
		dto.setServiceLineName("CORPORATE");
		dto.setResourceRequirementLocationId(3);
		dto.setResourceRequirementLocation("Hyderabad");
		dto.setRequirementRoleId(3);
		dto.setRequirementRole("Developer");
		dto.setBillable(false);
		employeeList.add(dto);
		List<SrfProjection> srfProjectionList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();

		SrfProjection getSrfProjection1 = factory.createProjection(SrfProjection.class);
		getSrfProjection1.setSrfId(3l);
		getSrfProjection1.setSrfNumber(2346l);
		getSrfProjection1.setCandidateId(52330l);

		SrfProjection getSrfProjection2 = factory.createProjection(SrfProjection.class);
		getSrfProjection2.setSrfId(5l);
		getSrfProjection2.setSrfNumber(2348l);
		getSrfProjection2.setCandidateId(52331l);

		srfProjectionList.add(getSrfProjection1);
		srfProjectionList.add(getSrfProjection2);

		List<AvaibalityProjection> avaibalityProjectionList = new ArrayList<>();
		/*
		 * AvaibalityProjection avaibalityProjection1 =
		 * factory.createProjection(AvaibalityProjection.class);
		 * avaibalityProjection1.setEmployeeId(52331l);
		 * avaibalityProjection1.setAllocatedFte(80l);
		 * avaibalityProjectionList.add(avaibalityProjection1);
		 * 
		 *
		 */
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
		.thenReturn(moduleStatusDto);
        when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
        when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");
        when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
        when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tSrfRepository.findByCandidateIdIn(Mockito.anyList(), Mockito.anyLong())).thenReturn(srfProjectionList);
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(avaibalityProjectionList);
		List<EmployeeDto> employeeDto = resourceAllocationServiceImpl.getAssociatesDetails(123l, 234l, employeeList);
		assertNotNull(employeeDto);
	}

	@Test
	public void getAssociateDetailNullEmployeeListTest() throws ResourceManagementException {

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setReqId(1);
		resourceRequirementDto.setBand("E2");
		resourceRequirementDto.setRequirementRole("Developer");
		List<EmployeeDto> employeeList = null;
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
	      when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		List<EmployeeDto> employeeDto = resourceAllocationServiceImpl.getAssociatesDetails(123l, 234l, employeeList);
		assertNull(employeeDto);
	}

	@Test
	public void getAssociateTravelDetailTest() throws ResourceManagementException {

		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");
		employeeDto.setMatchFactor(1);
		employeeDto.setBand("F2");
		employeeDto.setAllocationTypeId(1l);

		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");

		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(1);
		allocatedResourceProjection.setServiceLineId(1l);

		ProjectionFactory factory1 = new SpelAwareProxyProjectionFactory();
		AvaibalityProjection employeeAvaibility = factory1.createProjection(AvaibalityProjection.class);
		employeeAvaibility.setAllocatedFte(20);

		ResourceRequirementDto rRDto = new ResourceRequirementDto();
		rRDto.setReqId(2);
		rRDto.setBillable(2.0);
		rRDto.setBillingEffortsPerHrs(1234.0);
		rRDto.setRequirementRole("PM");
		rRDto.setResourceRequirementLocation("Pune");
		rRDto.setBand("B2");
		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		ResourceManagementUtil.isNumeric("xyz");
		when(adminServiceClient.getEmployeeDetails(Mockito.anyLong())).thenReturn(employeeDto);
		when(tAssociateAllocationRepository.getAllocatedResourceAvail(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(employeeAvaibility);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		
		List<LookupValueDto> lookuTypes = new ArrayList<>();
		LookupValueDto lookupValDto = new LookupValueDto();
		lookupValDto.setLookUpId(2l);
		lookupValDto.setLookupType("POOL");
		lookuTypes.add(lookupValDto);
		
		List<ServiceLineDto> serviceLineList = new ArrayList<>();
		ServiceLineDto serviceLineDto = new ServiceLineDto();
		serviceLineDto.setServiceLine("CORPORATE");
		serviceLineDto.setServiceLineId(1);
		serviceLineList.add(serviceLineDto);
		when(tAssociateAllocationRepository.getAllocatedResourceToTravel(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(allocatedResourceProjection);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(rRDto);
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(employeeDto);
		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getLookupValueByLookupType(Mockito.anyString())).thenReturn(lookuTypes);
		when(adminServiceClient.getServiceLineList(Mockito.anyList())).thenReturn(serviceLineList);
		when(tAssociateAllocationRepository.checkIfexist(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(1l);
		EmployeeDto empDto = resourceAllocationServiceImpl.getAssociatesForTravelByIdOrName("xyz", 123l, 23l);
		assertNotNull(empDto);
		verify(tAssociateAllocationRepository, times(1)).getAllocatedResourceToTravel(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());

	}

	@Test
	public void getAssociateTravelDetailNumericTest() throws ResourceManagementException {

		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");
		employeeDto.setMatchFactor(1);
		employeeDto.setBand("F2");
		employeeDto.setAllocationTypeId(1l);

		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");

		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(1);

		ProjectionFactory factory1 = new SpelAwareProxyProjectionFactory();
		AvaibalityProjection employeeAvaibility = factory1.createProjection(AvaibalityProjection.class);
		employeeAvaibility.setAllocatedFte(20);

		ResourceRequirementDto rRDto = new ResourceRequirementDto();
		rRDto.setReqId(2);
		rRDto.setBillable(2.0);
		rRDto.setBillingEffortsPerHrs(1234.0);
		rRDto.setRequirementRole("PM");
		rRDto.setResourceRequirementLocation("Pune");
		rRDto.setBand("B2");
		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		when(adminServiceClient.getEmployeeDetails(Mockito.anyLong())).thenReturn(employeeDto);
		when(tAssociateAllocationRepository.getAllocatedResourceAvail(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong())).thenReturn(employeeAvaibility);
		when(tAssociateAllocationRepository.getAllocatedResourceToTravel(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(allocatedResourceProjection);
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(employeeDto);
		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);

		EmployeeDto empDto = resourceAllocationServiceImpl.getAssociatesForTravelByIdOrName("123", 123l, 4l);
		assertNotNull(empDto);

	}

	@Test
	public void saveResourceTravelAllocationsTest() throws ResourceManagementException {

		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(new Date());
		allocationDto.setActualAllocationEndDate(new Date());
		allocationDto.setRequirementId(1l);
		allocationDto.setEmployeeId(52336l);

		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setRoleId(2l);
		tAssociateProjectDto.setRoleName("PGM");
		tAssociateProjectDto.setTargetProjectId(40002);
		tAssociateProjectDto.setTargetRequirementId(2l);
		tAssociateProjectDto.setUserName("SAMAY R");
		tAssociateProjectDto.setUserId(52336l);
		tAssociateProjectDto.setProjectId(40001l);
		tAssociateProjectDto.setEmployeeId(52336l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("PGM");

		List<TAssociateProjectDto> projectAllocationDtoList = new ArrayList<>();
		projectAllocationDtoList.add(tAssociateProjectDto);

		projectAllocationDtoList.add(tAssociateProjectDto);
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		tAssociateAllocation.setActualAllocationEndDate(new Date());
		tAssociateAllocation.setActualAllocationStartDate(new Date());
		tAssociateAllocation.setAllocationTypeId(1l);
		tAssociateAllocation.setAssociateAllocationId(48111l);
		tAssociateAllocation.setBaseHours(9.0);
		tAssociateAllocation.setBillableStatusId(123l);
		tAssociateAllocation.setBillableStatusReasonId(2l);
		tAssociateAllocation.setCapHours(9.0);
		tAssociateAllocation.setCreatedBy(52336l);
		tAssociateAllocation.setCreatedDate(new Date());
		tAssociateAllocation.setEffectiveEndDate(new Date());
		tAssociateAllocation.setEffectiveStartDate(new Date());
		tAssociateAllocation.setEstAllocationEndDate(new Date());
		tAssociateAllocation.setFtePercent(0.00);
		tAssociateAllocation.setLastUpdatedBy(52331l);
		tAssociateAllocation.setLastUpdatedDate(new Date());
		tAssociateAllocation.setRemarks("xyz");
		tAssociateAllocation.setRequirementId(1l);
		tAssociateAllocation.setRoleId(2l);
		tAssociateAllocation.setSkillChampionFlag(true);
		tAssociateAllocation.setStatusId(2l);
		tAssociateAllocation.setSupervisorId(52336l);
		tAssociateAllocation.setWorkflowStatusId(1l);
		tAssociateAllocation.setWorkLocationId(12l);

		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		tAssociateProject.setAssociateProjectId(40002l);
		tAssociateProject.setCreatedBy(52337l);
		tAssociateProject.setEmployeeId(52331l);
		tAssociateProject.setIsPrimaryProject(0l);
		tAssociateProject.setLastUpdatedBy(52331l);
		tAssociateProject.setProjectId(40002l);
		tAssociateProject.setSrfId(123l);
		tAssociateProject.setStatusId(1l);
		tAssociateProject.setEffectiveStartDate(new Date());
		tAssociateProject.setEffectiveEndDate(new Date());
		tAssociateProject.setSupervisorId(52336l);
		tAssociateProject.setCreatedDate(new Date());
		tAssociateProject.setLastUpdatedDate(new Date());
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);

		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);

		ResourceRequirementDto requirementDetailList = new ResourceRequirementDto();

		requirementDetailList.setBand("F2");
		requirementDetailList.setNoOfWorkingDays(30);
		requirementDetailList.setSkills("java");

		ModuleStatusDto moduleStatus = new ModuleStatusDto();
		moduleStatus.setModuleStatusId(1l);

		AllocationTypeStatusDto allocationTypeStatu = new AllocationTypeStatusDto();
		allocationTypeStatu.setAllocationTypeId(1l);

		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);

		List<Long> alreadyAllocatedResource = new ArrayList<>();
		alreadyAllocatedResource.add(52336l);

		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(associateProjectRepository.save(Mockito.any())).thenReturn(null);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(requirementDetailList);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatus);
		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatu);

		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);

		resourceAllocationServiceImpl.saveResourceTravelAllocations(projectAllocationDtoList);
		verify(sendMailHelperService, times(1)).sendEmailForTravelSubmissionConfirmation(projectAllocationDtoList);
	}

	@Test
	public void saveResourceAllocationByAdminTest() throws ResourceManagementException, ParseException {
		
		List<TAssociateAllocationBudgetDto> newbudgetList = new ArrayList<TAssociateAllocationBudgetDto>();
		TAssociateAllocationBudgetDto budgetDto = new TAssociateAllocationBudgetDto();
		budgetDto.setAssociateAllocationBudgetId(1l);
		newbudgetList.add(budgetDto);
		
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setSupervisorId(52336l);
		allocationDto.setStdCost(22.0);
		allocationDto.setTAssociateAllocationBudget(newbudgetList);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setSupervisorId(52336l);
		tAssociateProjectDto.setRoleName("ADMIN");
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setBudgetAndCostCheck(true);
		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudget = getProjectBudgetDto();
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);
		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);

		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");

		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(associateProjectRepository.save(Mockito.any())).thenReturn(null);
		resourceAllocationServiceImpl.saveResourceAllocationByAdminOrTag(123l, 1l, allocationDtoList,true);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(2)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(6)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(adminServiceClient, times(1)).getAllocationTypeStatus(Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());
	}
 
	@Test  
	public void saveResourceAllocationByAdminNullTest() throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setStdCost(22.0);

		allocationDto.setSupervisorId(52336l);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setSupervisorId(52336l);
		tAssociateProjectDto.setRoleName("ADMIN");

		tAssociateProjectDto.setTAssociateAllocation(allocationDto);

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudget = getProjectBudgetDto();
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("NO");

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);

		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");

		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(null);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(associateProjectRepository.save(Mockito.any())).thenReturn(null);
		resourceAllocationServiceImpl.saveResourceAllocationByAdminOrTag(123l, 1l, allocationDtoList,false);
	//	verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
	//	verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(5)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
	//	verify(adminServiceClient, times(1)).getAllocationTypeStatus(Mockito.anyString());
	//	verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
	//			Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());
	}

	@Test
	public void saveResourceAllocationsAdminTestForNonBillableProject()
			throws ResourceManagementException, ParseException {
		
		List<TAssociateAllocationBudgetDto> newbudgetList = new ArrayList<TAssociateAllocationBudgetDto>();
		TAssociateAllocationBudgetDto budgetDto = new TAssociateAllocationBudgetDto();
		budgetDto.setAssociateAllocationBudgetId(1l);
		newbudgetList.add(budgetDto);
		
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setStdCost(22.0);
		allocationDto.setTAssociateAllocationBudget(newbudgetList);

		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setSupervisorId(52336l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("ADMIN");
		tAssociateProjectDto.setBudgetAndCostCheck(true);
		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
		List<ProjectBudgetDto> projectBudget = getProjectBudgetDto();
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);
		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);
		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(2)).getResourceRequiremetList(Mockito.anyList());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());
	}

	@Test
	public void saveResourceAllocationsAdminTestForCumulativeBudgetCheck()
			throws ResourceManagementException, ParseException {
		
		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDtoForCumulativeBudget();
		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setMonth("2020-04");
		projectBudgetDto1.setAvailableBudget(200000.00);
		projectBudgetDto1.setConsumedBudget(300.00);
		projectBudgetDto1.setBudgetCurrency(5d);
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.add(projectBudgetDto1);

		List<TAssociateAllocationBudgetDto> newbudgetList = new ArrayList<TAssociateAllocationBudgetDto>();
		TAssociateAllocationBudgetDto budgetDto = new TAssociateAllocationBudgetDto();
		budgetDto.setAssociateAllocationBudgetId(1l);
		newbudgetList.add(budgetDto);
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setStdCost(22.0);
		allocationDto.setTAssociateAllocationBudget(newbudgetList);

		allocationDto.setRequirementId(1l);
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setSupervisorId(52336l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("ADMIN");
		tAssociateProjectDto.setBudgetAndCostCheck(true);
		
		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();

		allocationDtoList.add(tAssociateProjectDto);



		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);
	


		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementDto.setRequirementStartDate(dateFormat.parse("2020-04-01"));
		resourceRequirementDto.setRequirementEndDate(dateFormat.parse("2021-04-01"));
      	resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);
		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);

		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(associateProjectRepository.save(Mockito.any())).thenReturn(null);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");
  
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(2)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(6)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());
	}

	@Test
	public void saveResourceAllocationsAdminTestForZeroCumulativeBudgetCheck()
			throws ResourceManagementException, ParseException {
		
		List<TAssociateAllocationBudgetDto> newbudgetList = new ArrayList<TAssociateAllocationBudgetDto>();
		TAssociateAllocationBudgetDto budgetDto = new TAssociateAllocationBudgetDto();
		budgetDto.setAssociateAllocationBudgetId(1l);
		newbudgetList.add(budgetDto);
		
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setRequirementId(1l);
		allocationDto.setStdCost(22.0);
		allocationDto.setTAssociateAllocationBudget(newbudgetList);
		
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("ADMIN");
		tAssociateProjectDto.setBudgetAndCostCheck(false);
		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDtoForCumulativeBudget();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setMonth("2020-04");
		projectBudgetDto1.setAvailableBudget(0d);
		projectBudgetDto1.setBudgetCurrency(5d);
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.add(projectBudgetDto1);

		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		resourceRequirementDto.setRequirementStartDate(dateFormat.parse("2020-04-01"));
		resourceRequirementDto.setRequirementEndDate(dateFormat.parse("2021-04-01"));
        when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);

		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(associateProjectRepository.save(Mockito.any())).thenReturn(null);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(2)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(6)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());
	}

	@Test
	public void saveResourceAllocationsAdminTestForCumulativeBudgetCheckWithoutConsumedBudget()
			throws ResourceManagementException, ParseException {
		
		List<TAssociateAllocationBudgetDto> newbudgetList = new ArrayList<TAssociateAllocationBudgetDto>();
		TAssociateAllocationBudgetDto budgetDto = new TAssociateAllocationBudgetDto();
		budgetDto.setAssociateAllocationBudgetId(1l);
		newbudgetList.add(budgetDto);
		
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setRequirementId(1l);
		allocationDto.setStdCost(22.0);
		allocationDto.setTAssociateAllocationBudget(newbudgetList);
	

		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(123l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("ADMIN");
		tAssociateProjectDto.setBudgetAndCostCheck(true);

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDtoForCumulativeBudget();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setMonth("2020-04");
		projectBudgetDto1.setAvailableBudget(20d);
		projectBudgetDto1.setBudgetCurrency(5d);
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.add(projectBudgetDto1);

		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementDto.setRequirementStartDate(dateFormat.parse("2020-04-01"));
		resourceRequirementDto.setRequirementEndDate(dateFormat.parse("2021-04-01"));
        resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		List<TAssociateProject> tAssociateProjects = new ArrayList<>();
		TAssociateProject tAssociateProject = new TAssociateProject();
		TAssociateAllocation tAssociateAllocation = new TAssociateAllocation();
		List<TAssociateAllocationBudget> budgetList = new ArrayList<>();
		TAssociateAllocationBudget tAssociateAllocationBudget = new TAssociateAllocationBudget();
		budgetList.add(tAssociateAllocationBudget);
		tAssociateAllocation.setTAssociateAllocationBudget(budgetList);
		tAssociateProject.setTAssociateAllocation(tAssociateAllocation);
		tAssociateProjects.add(tAssociateProject);
		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(asssociateProjectMapper.tAssociateProjectDtoToTAssociateProject(Mockito.anyList()))
				.thenReturn(tAssociateProjects);
		when(associateProjectRepository.save(Mockito.any())).thenReturn(null);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(2)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(6)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
		verify(asssociateProjectMapper, times(1)).tAssociateProjectDtoToTAssociateProject(Mockito.anyList());
	}

	/*
	 * @Test(expected = ResourceManagementException.class) public void
	 * saveResourceAllocationsAdminTestNoAvailableBudget() throws
	 * ResourceManagementException, ParseException { TAssociateAllocationDto
	 * allocationDto = new TAssociateAllocationDto();
	 * allocationDto.setRequirementId(1l);
	 * 
	 * allocationDto.setFtePercent(100.00);
	 * allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
	 * allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
	 * allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
	 * allocationDto.setRequirementId(1l); allocationDto.setAllocationTypeId(2l);
	 * allocationDto.setAssociateProjectId(40001l);
	 * allocationDto.setAssociateAllocationId(1l); allocationDto.setRoleId(2l);
	 * allocationDto.setWorkLocationId(2l);
	 * 
	 * List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
	 * TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
	 * tAssociateProjectDto.setProjectId(Long.valueOf(123));
	 * tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
	 * tAssociateProjectDto.setTAssociateAllocation(allocationDto);
	 * tAssociateProjectDto.setRoleName("ADMIN");
	 * 
	 * allocationDtoList.add(tAssociateProjectDto);
	 * 
	 * ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
	 * moduleStatusDto.setModuleStatusId(1l);
	 * 
	 * List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDto();
	 * AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
	 * allocationTypeStatus.setAllocationTypeId(1l);
	 * allocationTypeStatus.setAllocationTypeValue("xyz");
	 * 
	 * when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).
	 * thenReturn(allocationTypeStatus);
	 * when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.
	 * anyLong())) .thenReturn(projectBudgetDto);
	 * when(adminServiceClient.getModuleStatus(Mockito.anyString(),
	 * Mockito.anyString(), Mockito.anyString())) .thenReturn(moduleStatusDto);
	 * resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l,
	 * allocationDtoList); verify(budgetControlServiceClient,
	 * times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong()); }
	 */

	@Test
	public void saveResourceAllocationsAdminTestNullAvailablebudgetForMonth()
			throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setRequirementId(1l);
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setStdCost(22.0);

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(1l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("ADMIN");

		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDto();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-05");
		projectBudgetDto1.setAvailableBudget(2000.00);
		projectBudgetDto.add(projectBudgetDto1);

		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);

		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(2)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(6)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
	}

	@Test(expected = ResourceManagementException.class)
	public void saveResourceAllocationsAdminTestLessAvailablebudgetForMonth()
			throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setRequirementId(1l);
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setStdCost(22.0);

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(1l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("ADMIN");

		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDto();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(10.00);
		projectBudgetDto.add(projectBudgetDto1);

		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto2.setBudgetCurrency(5.0);
		projectBudgetDto2.setMonth("2020-07");
		projectBudgetDto2.setAvailableBudget(30.00);
		projectBudgetDto.add(projectBudgetDto2);
		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l); 
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);

		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);

		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementDto.setRequirementStartDate(dateFormat.parse("2020-04-01"));
		resourceRequirementDto.setRequirementEndDate(dateFormat.parse("2021-04-01"));
      	resourceRequirementList.add(resourceRequirementDto);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);

		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(1)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
	}

	@Test(expected = ResourceManagementException.class)
	public void saveResourceAllocationsAdminTestZeroAvailablebudgetForMonth()
			throws ResourceManagementException, ParseException {
		TAssociateAllocationDto allocationDto = new TAssociateAllocationDto();
		allocationDto.setRequirementId(1l);
		allocationDto.setFtePercent(100.00);
		allocationDto.setActualAllocationStartDate(dateFormat.parse("2020-06-01"));
		allocationDto.setActualAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setEstAllocationEndDate(dateFormat.parse("2020-07-31"));
		allocationDto.setRequirementId(1l);
		allocationDto.setAllocationTypeId(2l);
		allocationDto.setAssociateProjectId(40001l);
		allocationDto.setAssociateAllocationId(1l);
		allocationDto.setRoleId(2l);
		allocationDto.setWorkLocationId(2l);
		allocationDto.setStdCost(22.0);

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		tAssociateProjectDto.setProjectId(Long.valueOf(123));
		tAssociateProjectDto.setEmployeeId(Long.valueOf(123));
		tAssociateProjectDto.setSrfId(1l);
		tAssociateProjectDto.setTAssociateAllocation(allocationDto);
		tAssociateProjectDto.setRoleName("ADMIN");

		allocationDtoList.add(tAssociateProjectDto);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		List<ProjectBudgetDto> projectBudgetDto = getProjectBudgetDto();

		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(0.00);
		projectBudgetDto.add(projectBudgetDto1);

		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto2.setBudgetCurrency(5.0);
		projectBudgetDto2.setMonth("2020-07");
		projectBudgetDto2.setAvailableBudget(30.00);
		projectBudgetDto.add(projectBudgetDto2);

		PrimaryUsersDto userDto = new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList = new ArrayList<>();
		userList.add(userDto);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("YES");

		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudgetDto);
		
		AllocationTypeStatusDto allocationTypeStatus = new AllocationTypeStatusDto();
		allocationTypeStatus.setAllocationTypeId(1l);
		allocationTypeStatus.setAllocationTypeValue("xyz");
		List<ResourceRequirementDto> resourceRequirementList = new ArrayList<>();
		ResourceRequirementDto resourceRequirementDto = getResourceRequirementDto();
		resourceRequirementDto.setZenAccurateCurrency(5.0);
		resourceRequirementList.add(resourceRequirementDto);
		resourceRequirementDto.setRequirementStartDate(dateFormat.parse("2020-04-01"));
		resourceRequirementDto.setRequirementEndDate(dateFormat.parse("2021-04-01"));
        when(bapSrvcClient.getResourceRequiremetList(Mockito.anyList())).thenReturn(resourceRequirementList);
   
		when(adminServiceClient.getAllocationTypeStatus(Mockito.anyString())).thenReturn(allocationTypeStatus);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);

		when(associateProjectRepository.findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		resourceAllocationServiceImpl.saveResourceAllocations(123l, 1l, allocationDtoList);
		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyList());
		verify(adminServiceClient, times(1)).getModuleStatus(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString());
		verify(associateProjectRepository, times(1)).findByEmployeeIdAndSrfIdAndProjectIdAndStatusId(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
	}

	@Test
	public void getpoolToIntransitAllocationDtls() throws ResourceManagementException {
		EmployeeDto dto = new EmployeeDto();
		dto.setEmployeeId(52330l);
		dto.setEmployeeName("Akshay T");
		dto.setEmployeePracticeId(2);
		dto.setPracticeName("AMS");
		dto.setBand("E1");
		dto.setRole("SOFTWARE ENGINEER");
		dto.setEmployeeRoleId(0);
		dto.setMatchFactor(1);
		dto.setAvailibility(20l);
		dto.setServiceLineId(2);
		dto.setServiceLineName("CORPORATE");
		dto.setResourceRequirementLocationId(3);
		dto.setResourceRequirementLocation("Hyderabad");
		dto.setRequirementRoleId(3);
		dto.setRequirementRole("Developer");
		dto.setBillable(false);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		List<TSrf> tSrfList = new ArrayList<TSrf>();
		TSrf srf = new TSrf();
		srf.setCandidateId(52330l);
		srf.setProjectId("40001");
		tSrfList.add(srf);

		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<AvaibalityProjection> avaibalityProjectionList = new ArrayList<>();
		AvaibalityProjection avaibalityProjection1 = factory.createProjection(AvaibalityProjection.class);
		avaibalityProjection1.setEmployeeId(52330l);
		avaibalityProjection1.setAllocatedFte(80l);
		avaibalityProjectionList.add(avaibalityProjection1);

		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(44444l);
		boolean b = true;
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
		.thenReturn(moduleStatusDto);
when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);


		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(dto);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(tSrfRepository.getIntransitEarmarkedResource(Mockito.anyLong(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean())).thenReturn(tSrfList);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(avaibalityProjectionList);
		when(bapSrvcClient.getIntransitProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("true");
		List<EmployeeDto> empList = resourceAllocationServiceImpl.getpoolToIntransitAllocationDtls("52330", 44444l, 6l);
		assertNotNull(empList);

	}

	@Test
	public void getpoolToIntransitAllocationDtlsNull() throws ResourceManagementException {
		EmployeeDto dto = new EmployeeDto();
		dto.setEmployeeId(52330l);
		dto.setEmployeeName("Akshay T");
		dto.setEmployeePracticeId(2);
		dto.setPracticeName("AMS");
		dto.setBand("E1");
		dto.setRole("SOFTWARE ENGINEER");
		dto.setEmployeeRoleId(0);
		dto.setMatchFactor(1);
		dto.setAvailibility(20l);
		dto.setServiceLineId(2);
		dto.setServiceLineName("CORPORATE");
		dto.setResourceRequirementLocationId(3);
		dto.setResourceRequirementLocation("Hyderabad");
		dto.setRequirementRoleId(3);
		dto.setRequirementRole("Developer");
		dto.setBillable(false);

		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleStatusId(1l);

		List<TSrf> tSrfList = new ArrayList<TSrf>();
		TSrf srf = new TSrf();
		srf.setCandidateId(52330l);
		srf.setProjectId("40001");
		tSrfList.add(srf);

		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		List<AvaibalityProjection> avaibalityProjectionList = new ArrayList<>();
		AvaibalityProjection avaibalityProjection1 = factory.createProjection(AvaibalityProjection.class);
		avaibalityProjectionList.add(avaibalityProjection1);

		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(44444l);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
		.thenReturn(moduleStatusDto);
when(tAssociateAllocationRepository.getLookupValueIdByTypeAndDescr(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);


		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(dto);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(tSrfRepository.getIntransitEarmarkedResource(Mockito.anyLong(), Mockito.anyString(), Mockito.anyLong(),
				Mockito.anyBoolean())).thenReturn(tSrfList);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateAllocationRepository.getAllocatedResourceAvaibality(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(null);
		when(bapSrvcClient.getIntransitProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminServiceClient.getProjectBudgetStatus(Mockito.anyLong())).thenReturn("true");

		List<EmployeeDto> empList = resourceAllocationServiceImpl.getpoolToIntransitAllocationDtls("52330", 44444l, 6l);
		assertNotNull(empList);

	}
	
	public HashBasedTable<String, String, Long> getModuleList() {
		 
		List<ModuleStatusDto> moduleList = new ArrayList<>();
		ModuleStatusDto moduleStatusDtoAllocation = new ModuleStatusDto();
		moduleStatusDtoAllocation.setModuleId(1l);
		moduleStatusDtoAllocation.setModuleStatusId(1l);
		moduleStatusDtoAllocation.setModuleCode("RM");
		moduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setAction("APPROVED");
		moduleList.add(moduleStatusDtoAllocation);
		
		ModuleStatusDto moduleStatusDtoAllocationSaved = new ModuleStatusDto();
		moduleStatusDtoAllocationSaved.setModuleId(1l);
		moduleStatusDtoAllocationSaved.setModuleStatusId(1l);
		moduleStatusDtoAllocationSaved.setModuleCode("RM");
		moduleStatusDtoAllocationSaved.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSaved.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSaved.setAction("SAVED");
		moduleList.add(moduleStatusDtoAllocationSaved);
		
		
		ModuleStatusDto moduleStatusDtoAllocationSubmitted = new ModuleStatusDto();
		moduleStatusDtoAllocationSubmitted.setModuleId(1l);
		moduleStatusDtoAllocationSubmitted.setModuleStatusId(1l);
		moduleStatusDtoAllocationSubmitted.setModuleCode("RM");
		moduleStatusDtoAllocationSubmitted.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSubmitted.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSubmitted.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoAllocationSubmitted);
		
		
		ModuleStatusDto newmoduleStatus2DtoAllocation = new ModuleStatusDto();
		newmoduleStatus2DtoAllocation.setModuleId(2l);
		newmoduleStatus2DtoAllocation.setModuleStatusId(2l);
		newmoduleStatus2DtoAllocation.setModuleCode("RM");
		newmoduleStatus2DtoAllocation.setSubModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setParentModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setAction("DEACTIVE");
		moduleList.add(newmoduleStatus2DtoAllocation);
		ModuleStatusDto newmoduleStatusDtoAllocation = new ModuleStatusDto();

		newmoduleStatusDtoAllocation.setModuleId(2l);
		newmoduleStatusDtoAllocation.setModuleStatusId(1l);
		newmoduleStatusDtoAllocation.setModuleCode("RM");
		newmoduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setAction("ACTIVATE");
		moduleList.add(newmoduleStatusDtoAllocation);

		ModuleStatusDto moduleStatusDtoTransfer = new ModuleStatusDto();
		moduleStatusDtoTransfer.setModuleId(1l);
		moduleStatusDtoTransfer.setModuleStatusId(1l);
		moduleStatusDtoTransfer.setModuleCode("RM");
		moduleStatusDtoTransfer.setSubModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setAction("APPROVED");
		moduleList.add(moduleStatusDtoTransfer);

		ModuleStatusDto moduleStatusDtoDeallocationSved = new ModuleStatusDto();
		moduleStatusDtoDeallocationSved.setModuleId(1l);
		moduleStatusDtoDeallocationSved.setModuleStatusId(1l);
		
		moduleStatusDtoDeallocationSved.setModuleCode("RM");
		moduleStatusDtoDeallocationSved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSved.setAction(ResourceManagementConstant.SAVED);
		moduleList.add(moduleStatusDtoDeallocationSved);
		ModuleStatusDto moduleStatusDtoDeallocationSubmitted = new ModuleStatusDto();
		moduleStatusDtoDeallocationSubmitted.setModuleId(1l);
		moduleStatusDtoDeallocationSubmitted.setModuleStatusId(1l);
		moduleStatusDtoDeallocationSubmitted.setModuleCode("RM");
		moduleStatusDtoDeallocationSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSubmitted.setAction(ResourceManagementConstant.SUBMITTED);
		moduleList.add(moduleStatusDtoDeallocationSubmitted);
		ModuleStatusDto moduleStatusDtoDeallocationApproved = new ModuleStatusDto();
		moduleStatusDtoDeallocationApproved.setModuleId(1l);
		moduleStatusDtoDeallocationApproved.setModuleCode("RM");
		moduleStatusDtoDeallocationApproved.setModuleStatusId(1l);
		moduleStatusDtoDeallocationApproved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationApproved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationApproved.setAction(ResourceManagementConstant.APPROVED);
		moduleList.add(moduleStatusDtoDeallocationApproved);

		ModuleStatusDto moduleStatusDtoTansferSved = new ModuleStatusDto();
		moduleStatusDtoTansferSved.setModuleId(1l);  
		moduleStatusDtoTansferSved.setModuleStatusId(1l);
		moduleStatusDtoTansferSved.setModuleCode("RM");
		moduleStatusDtoTansferSved.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTansferSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTansferSved.setAction(ResourceManagementConstant.SAVED);
		moduleList.add(moduleStatusDtoTansferSved);
		ModuleStatusDto moduleStatusDtoTransferSubmitted = new ModuleStatusDto();
		moduleStatusDtoTransferSubmitted.setModuleId(1l);
		moduleStatusDtoTransferSubmitted.setModuleStatusId(1l);
		moduleStatusDtoTransferSubmitted.setModuleCode("RM");
		moduleStatusDtoTransferSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTransferSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransferSubmitted.setAction(ResourceManagementConstant.SUBMITTED);
		moduleList.add(moduleStatusDtoTansferSved);
		ModuleStatusDto moduleStatusDtoExtension = new ModuleStatusDto();
		moduleStatusDtoExtension.setModuleId(1l);
		moduleStatusDtoExtension.setModuleStatusId(1l);    
		moduleStatusDtoExtension.setModuleCode("RM");
		moduleStatusDtoExtension.setSubModule("RESOURCE_EXTENSION");
		moduleStatusDtoExtension.setParentModule("RESOURCE_EXTENSION"); 
		moduleStatusDtoExtension.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoExtension);

		moduleList.add(moduleStatusDtoTransferSubmitted);

		
		HashBasedTable<String, String, Long> table = HashBasedTable.create();
		for (ModuleStatusDto temp : moduleList) {
			table.put(temp.getSubModule(), temp.getAction(), temp.getModuleStatusId());
		}
		return table;
	}
	  

}