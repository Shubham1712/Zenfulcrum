package com.zensar.zenfulcrum.resourcrmanagement.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.controller.PDResourceManagmentController;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.PDResourceManagmentService;

@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class PDResourceManagmentControllerTest {

	@InjectMocks
	private PDResourceManagmentController pdResourceManagmentController;

	@Mock
	PDResourceManagmentService pdResourceManagmentService;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void getAssociateListByProjectId() throws ResourceManagementException {
		List<TAssociateAllocationDto> tAssociateAllocationList = new ArrayList<>();
		when(pdResourceManagmentService.getAssociateListByProjectId(Mockito.anyLong())).thenReturn(tAssociateAllocationList);
		pdResourceManagmentController.getAssociateListByProjectId(1L);
		verify(pdResourceManagmentService,times(1)).getAssociateListByProjectId(Mockito.anyLong());
	}
}
