package com.zensar.zenfulcrum.resourcemanagement.rest.client;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class AuthServiceClientTest {
	
	@Mock
	private RestTemplate restTemplate;

	@InjectMocks
	private AuthServiceClient authServiceClient;


	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(authServiceClient, "authServiceBaseUrl", "authServiceBaseUrl");
		ReflectionTestUtils.setField(authServiceClient, "validateAccessTokenRestURL", "validateAccessTokenRestURL");		
	}
	
	@Test 
	public void validateAccessTokenTest() throws Exception {
		Mockito.when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(),
				Mockito.any())) .thenReturn(new ResponseEntity(true, HttpStatus.OK)); 
		authServiceClient.validateAccessToken("sdbsbdsbjj","YS57280","wer234");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
								Mockito.any(), Mockito.any()); }
	
	@Test 
	public void validateAccessTokenNotOk() throws Exception {
		Mockito.when(restTemplate.postForEntity(Mockito.anyString(), Mockito.any(),
				Mockito.any())) .thenReturn(new ResponseEntity(false, HttpStatus.EXPECTATION_FAILED)); 
		authServiceClient.validateAccessToken("sdbsbdsbjj","YS57280","wer234");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
								Mockito.any(), Mockito.any()); }

	@Test(expected = ResourceManagementException.class)
	public void validateAccessTokenResourceAccessException() throws Exception {
		doThrow(new ResourceAccessException("Error")).when(restTemplate).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
		authServiceClient.validateAccessToken("sdbsbdsbjj","YS57280","wer234");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
	}

	@Test(expected = ResourceManagementException.class)
	public void validateAccessTokenTestHttpServerError() throws Exception {
		doThrow(HttpServerErrorException.class).when(restTemplate).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
		authServiceClient.validateAccessToken("sdbsbdsbjj","YS57280","wer234");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
	}

	@Test(expected = ResourceManagementException.class)
	public void validateAccessTokenTestHttpClientError() throws Exception {
		doThrow(HttpClientErrorException.class).when(restTemplate).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
		authServiceClient.validateAccessToken("sdbsbdsbjj","YS57280","wer234");
		verify(restTemplate, times(1)).postForEntity(Mockito.anyString(),
				Mockito.any(), Mockito.any());
	}
	

}
