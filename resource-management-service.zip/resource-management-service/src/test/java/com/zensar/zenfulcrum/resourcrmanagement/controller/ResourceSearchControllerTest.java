package com.zensar.zenfulcrum.resourcrmanagement.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.zensar.zenfulcrum.resourcemanagement.controller.ResourceSearchController;
import com.zensar.zenfulcrum.resourcemanagement.dto.AssociateSearchDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PracticeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceSearchDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RoleDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SupervisorDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceSearchService;

@Ignore
public class ResourceSearchControllerTest {

	@InjectMocks
	private ResourceSearchController  resourceSearchController;

	@Mock
	private ResourceSearchService resourceSearchService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	@Test
    public void getAssociateListByProjectIdTest() throws ResourceManagementException {
    	
		ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(51509L);
		employeeList.add(employeeDto);
		resourceSearchDto.setEmployeeList(employeeList);
    	when(resourceSearchService.getAssociateListByProjectId(Mockito.anyLong(), null, null)).thenReturn(resourceSearchDto);
        ResponseEntity<RMResponseDto> response = resourceSearchController.getAssociateListByProjectId(40001L,54168L,457L);
        assertNotNull(response);
        verify(resourceSearchService, times(1)).getAssociateListByProjectId(Mockito.anyLong(), null, null);
    }
      
    @Test
    public void getAssociateListByProjectIdNoContentTest() throws ResourceManagementException {
    	when(resourceSearchService.getAssociateListByProjectId(Mockito.anyLong(), null, null)).thenReturn(null);
  		ResponseEntity<RMResponseDto> responseEntityObj = resourceSearchController.getAssociateListByProjectId(40001L,54168L,457L);
  		assertEquals(204, responseEntityObj.getStatusCodeValue());
        verify(resourceSearchService, times(1)).getAssociateListByProjectId(Mockito.anyLong(), null, null);
    }
    @Test
    public void getResourceDtlsListByPracticeNameTest() throws ResourceManagementException {
    	
    	ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(51509L);
		employeeList.add(employeeDto);
		resourceSearchDto.setEmployeeList(employeeList);
    	when(resourceSearchService.getResourceDtlsListByPractice(Mockito.anyLong())).thenReturn(resourceSearchDto);
        ResponseEntity<RMResponseDto> response = resourceSearchController.getResourceDtlsListByPractice(1L);
        assertNotNull(response);
        verify(resourceSearchService, times(1)).getResourceDtlsListByPractice(Mockito.anyLong());
    }
    
    @Test
    public void getResourceDtlsListByPracticeNoContentTest() throws ResourceManagementException {
    	when(resourceSearchService.getResourceDtlsListByPractice(Mockito.anyLong())).thenReturn(null);
  		ResponseEntity<RMResponseDto> responseEntityObj = resourceSearchController.getResourceDtlsListByPractice(1L);
  		assertEquals(204, responseEntityObj.getStatusCodeValue());
        verify(resourceSearchService, times(1)).getResourceDtlsListByPractice(Mockito.anyLong());
    }
    
    @Test
    public void getListOfSkillsTest() throws ResourceManagementException {
    	List<SkillDto> skillDto = new ArrayList<>();
    	SkillDto dto1 = new SkillDto();
    	dto1.setSkillId(1l);
    	dto1.setSkillName("Java");
    	SkillDto dto2 = new SkillDto();
    	dto2.setSkillId(2l);
    	dto2.setSkillName("Net");
    	skillDto.add(dto1);
    	skillDto.add(dto2);
    	when(resourceSearchService.getListOfSkills()).thenReturn(skillDto);
    	ResponseEntity<RMResponseDto> response = resourceSearchController.getListOfSkills();
        assertNotNull(response);
        verify(resourceSearchService, times(1)).getListOfSkills();
    }
    
    
    @Test
    public void getListOfSkillsNoContentTest() throws ResourceManagementException {
    	when(resourceSearchService.getListOfSkills()).thenReturn(null);
  		ResponseEntity<RMResponseDto> responseEntityObj = resourceSearchController.getListOfSkills();
  		assertEquals(204, responseEntityObj.getStatusCodeValue());
        verify(resourceSearchService, times(1)).getListOfSkills();
    }
    
    @Test
    public void getRoleListTest() throws ResourceManagementException {
        List<RoleDto> roleDto = new ArrayList<>();
        RoleDto roleDto1 = new RoleDto();
        roleDto1.setRoleId(1l);
        roleDto1.setRoleName("xyz");
        RoleDto roleDto2 = new RoleDto();
        roleDto2.setRoleId(2l);
        roleDto2.setRoleName("Net");
        roleDto.add(roleDto1);
        roleDto.add(roleDto2);
        when(resourceSearchService.getRoleList()).thenReturn(roleDto);
        ResponseEntity<RMResponseDto> response = resourceSearchController.getRoleList();
        assertNotNull(response);
        verify(resourceSearchService, times(1)).getRoleList();
    }
   
   
    @Test
    public void getRoleListNoContentTest() throws ResourceManagementException {
        when(resourceSearchService.getRoleList()).thenReturn(null);
          ResponseEntity<RMResponseDto> responseEntityObj = resourceSearchController.getRoleList();
          assertEquals(204, responseEntityObj.getStatusCodeValue());
        verify(resourceSearchService, times(1)).getRoleList();
    }
    
  
    @Test
    public void getResourceDtlsListBySkillTest() throws ResourceManagementException {
    	
    	ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
    	List<EmployeeDto> employeeDtoList = new ArrayList<>();
    	EmployeeDto employeeDto = new EmployeeDto();
    	employeeDto.setEmployeeId(52330L);
    	employeeDtoList.add(employeeDto);
    	
    	resourceSearchDto.setEmployeeList(employeeDtoList);
    	when(resourceSearchService.getResourceDtlsListBySkill(Mockito.anyLong())).thenReturn(resourceSearchDto);
        ResponseEntity<RMResponseDto> response = resourceSearchController.getResourceDtlsListBySkill(1l);
        assertNotNull(response);
        verify(resourceSearchService, times(1)).getResourceDtlsListBySkill(Mockito.anyLong());
    }
    
    @Test
    public void getResourceDtlsListBySkillNoContentTest() throws ResourceManagementException {
    	when(resourceSearchService.getResourceDtlsListBySkill(Mockito.anyLong())).thenReturn(null);
  		ResponseEntity<RMResponseDto> responseEntityObj = resourceSearchController.getResourceDtlsListBySkill(1l);
  		assertEquals(204, responseEntityObj.getStatusCodeValue());
        verify(resourceSearchService, times(1)).getResourceDtlsListBySkill(Mockito.anyLong());
    }
    
    @Test
    public void getPracticeListTest() throws ResourceManagementException {
    	List<PracticeDto> practiceList = new ArrayList<>();
    	PracticeDto practice = new PracticeDto();
    	practice.setPracticeId(1L);
    	practiceList.add(practice);
        when(resourceSearchService.getPracticeList()).thenReturn(practiceList);
        ResponseEntity<RMResponseDto> response = resourceSearchController.getPracticeList();
        assertNotNull(response);
        verify(resourceSearchService, times(1)).getPracticeList();
    }
   
   
    @Test
    public void getPracticeListNoContentTest() throws ResourceManagementException {
        when(resourceSearchService.getPracticeList()).thenReturn(null);
          ResponseEntity<RMResponseDto> responseEntityObj = resourceSearchController.getPracticeList();
          assertEquals(204, responseEntityObj.getStatusCodeValue());
        verify(resourceSearchService, times(1)).getPracticeList();
    }
    
    
	
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	
	
	private AssociateSearchDto getAssociateDto() throws ParseException
	{
		AssociateSearchDto associateSearchDto = new AssociateSearchDto();
		associateSearchDto.setAllocationApproved(getEmployeeList());
		associateSearchDto.setAssociateProjectDetails(getEmployeeList());
		associateSearchDto.setAssociateTravelAllocationDetails(getEmployeeList());
		associateSearchDto.setDeallocationApproved(getEmployeeList());
		associateSearchDto.setReservedForAllocation(getEmployeeList());
		associateSearchDto.setReservedForDeallocation(getEmployeeList());
		return associateSearchDto;
   }
	
	
	private EmployeeDto getEmployee() throws ParseException
	{
		
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(51509L);
		employeeDto.setActualAllocationDate(dateFormat.parse("2020-07-31"));
		employeeDto.setAllocationTypeId(1);
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setAvailibility(30L);
		employeeDto.setBand("B1");
		employeeDto.setBillingStatus("Test");
		employeeDto.setBillable(true);
		employeeDto.setBillingRateInUSD(1234.0);
		employeeDto.setBillingRatePerHour(234.0);
		employeeDto.setBillingStatus("Billable");
		employeeDto.setEbrReason("Billable");
		employeeDto.setEmployeeId(52330L);
        employeeDto.setEstimatedEndDate(dateFormat.parse("2020-07-31"));
        employeeDto.setEbrUtilization(20.0);
        employeeDto.setPrimaryProjectStatusId(true);
		employeeDto.setServiceLineName("Test");
		employeeDto.setPrimaryProjectStatusId(true);
		employeeDto.setBillingStatus("EBR");
		employeeDto.setEbrReason("EBR");
		employeeDto.setProjectUtilization(100);
		return  employeeDto;
		
	}
	
	
	private List<EmployeeDto> getEmployeeList() throws ParseException
	{
		List<EmployeeDto> employeeList = new ArrayList<>();
		employeeList.add(getEmployee());
		return  employeeList;
		
	}
    
      
    
    
    @Test
    public void getResourceProjectDtlsByAssociateID() throws ResourceManagementException, ParseException
    {
    	when(resourceSearchService.getResourceProjectDtlsByAssociateID(Mockito.anyString(),Mockito.anyString(), null, null)).thenReturn(getAssociateDto());
        ResponseEntity<RMResponseDto> response = resourceSearchController.getResourceProjectDtlsByAssociateID("52330","allocated",54168L,457L);
        assertNotNull(response);
        verify(resourceSearchService, times(1)).getResourceProjectDtlsByAssociateID(Mockito.anyString(),Mockito.anyString(), null, null);
    }
 
    @Test
    public void getResourceProjectDtlsByAssociateIDNoContent() throws ResourceManagementException, ParseException
    {
    	when(resourceSearchService.getResourceProjectDtlsByAssociateID(Mockito.anyString(),Mockito.anyString(), null, null)).thenReturn(null);
        ResponseEntity<RMResponseDto> response = resourceSearchController.getResourceProjectDtlsByAssociateID("52330","allocated",54168L,457L);
  		assertEquals(204, response.getStatusCodeValue());
        verify(resourceSearchService, times(1)).getResourceProjectDtlsByAssociateID(Mockito.anyString(),Mockito.anyString(), null, null);
    }
    
    @Test
    public void getSupervisorListTest() throws ResourceManagementException {
    	List<SupervisorDto> supervisorDtoList = new ArrayList<>();
    	SupervisorDto supervisor = new SupervisorDto();
    	supervisor.setSupervisorId(1L);
    	supervisor.setSupervisorName("AJAY");
    	supervisorDtoList.add(supervisor);
    	
        when(resourceSearchService.getSupervisorList(Mockito.anyLong())).thenReturn(supervisorDtoList);
        ResponseEntity<RMResponseDto> response = resourceSearchController.getSupervisorList(Mockito.anyLong());
        assertNotNull(response);
        verify(resourceSearchService, times(1)).getSupervisorList(Mockito.anyLong());
    }
   
   
    @Test
    public void getSupervisorListNoContentTest() throws ResourceManagementException {
        when(resourceSearchService.getSupervisorList(Mockito.anyLong())).thenReturn(null);
          ResponseEntity<RMResponseDto> responseEntityObj = resourceSearchController.getSupervisorList(Mockito.anyLong());
          assertEquals(204, responseEntityObj.getStatusCodeValue());
        verify(resourceSearchService, times(1)).getSupervisorList(Mockito.anyLong());
    }
    
    @Test
    public void updateProjectDtlsForSearchTest() throws ResourceManagementException, ParseException {
    	ResourceSearchDto dto = new ResourceSearchDto();
    	
    	List<EmployeeDto> empList = new ArrayList<>();
    	
    	EmployeeDto employeeDto = new EmployeeDto();
    	employeeDto.setEmployeeId(52331l);
    	employeeDto.setEmployeeName("A");
    	employeeDto.setProjectId(40001l);
    	employeeDto.setRequirementId(1l);
    	employeeDto.setPrimaryProjectStatusId(true);
    	employeeDto.setSupervisorId(51509l);
    	employeeDto.setCapHours(9.00);
    	employeeDto.setSkillChampion(true);
    	employeeDto.setEffectiveStartDate(new Date());
    	employeeDto.setComments("Test");
    	
    	empList.add(employeeDto);
    	
    	dto.setEmployeeList(empList);
    	
    	doNothing().when(resourceSearchService).updateProjectDtlsForSearch(Mockito.any());
        ResponseEntity<RMResponseDto> response = resourceSearchController.updateProjectDtlsForSearch(dto);
        assertNotNull(response);
        verify(resourceSearchService, times(1)).updateProjectDtlsForSearch(dto);	
    }
    
    @Test
    public void getResourceDetailsTest() throws ResourceManagementException {
    	ResourceSearchDto resourceSearchDto = new ResourceSearchDto();
    	List<EmployeeDto> employeeDtoList = new ArrayList<>();
    	EmployeeDto employeeDto = new EmployeeDto();
    	employeeDto.setEmployeeId(52330L);
    	employeeDtoList.add(employeeDto);
    	
    	resourceSearchDto.setEmployeeList(employeeDtoList);
    	when(resourceSearchService.getResourceDetails(Mockito.anyString(),Mockito.anyLong(), null, null)).thenReturn(resourceSearchDto);
        ResponseEntity<RMResponseDto> response = resourceSearchController.getResourceDetails("A",1l,54168L,457L);
        assertNotNull(response);
        verify(resourceSearchService, times(1)).getResourceDetails(Mockito.anyString(),Mockito.anyLong(), null, null);
    }
    
    @Test
    public void getResourceDetailsNoContentTest() throws ResourceManagementException {
    
    	when(resourceSearchService.getResourceDetails(Mockito.anyString(),Mockito.anyLong(), null, null)).thenReturn(null);
  		ResponseEntity<RMResponseDto> responseEntityObj = resourceSearchController.getResourceDetails("A",1l,54168L,457L);
  		assertEquals(204, responseEntityObj.getStatusCodeValue());
        verify(resourceSearchService, times(1)).getResourceDetails(Mockito.anyString(),Mockito.anyLong(), null, null);
    }
    
    @Test
    public void getSearchListTest() throws ResourceManagementException {
    	List<LookupValueDto> lookupValueDtoForSearch = new ArrayList<>();
    	LookupValueDto lookupValueDto1 = new LookupValueDto();
    	lookupValueDto1.setLookUpId(1l);
    	lookupValueDto1.setLookupType("SEARCH_BY");
    	lookupValueDto1.setLookupValueCode("BY_PRACTICE");
    	
    	LookupValueDto lookupValueDto2 = new LookupValueDto();
    	lookupValueDto2.setLookUpId(2l);
    	lookupValueDto2.setLookupType("SEARCH_BY");
    	lookupValueDto2.setLookupValueCode("BY_SKILL");
    	
    	lookupValueDtoForSearch.add(lookupValueDto1);
    	lookupValueDtoForSearch.add(lookupValueDto2);
    	
    	when(resourceSearchService.getSearchList()).thenReturn(lookupValueDtoForSearch);
        ResponseEntity<RMResponseDto> response = resourceSearchController.getSearchList();
        assertNotNull(response);
        verify(resourceSearchService, times(1)).getSearchList();    	
    }
    
    @Test
    public void getSearchListNoContentTest() throws ResourceManagementException {
    
    	when(resourceSearchService.getSearchList()).thenReturn(null);
  		ResponseEntity<RMResponseDto> responseEntityObj = resourceSearchController.getSearchList();
  		assertEquals(204, responseEntityObj.getStatusCodeValue());
        verify(resourceSearchService, times(1)).getSearchList();
    }
    
    @Test
	public void saveResourcesForExtensionTest() throws ResourceManagementException {

    	ResourceSearchDto resourceSearchDto = new ResourceSearchDto();

		doNothing().when(resourceSearchService).saveResourcesForExtension(Mockito.any());
		ResponseEntity<RMResponseDto> responseEntityObj = resourceSearchController
				.saveResourcesForExtension(resourceSearchDto);
		assertEquals(201, responseEntityObj.getStatusCodeValue());
		verify(resourceSearchService, times(1)).saveResourcesForExtension(Mockito.any());
	}

    @Test
    public void updateSupervisorDetailsTest() throws ResourceManagementException {
    	SupervisorDto supervisorDto = new SupervisorDto();
    	doNothing().when(resourceSearchService).updateSupervisorDetails(Mockito.any());
    	ResponseEntity<RMResponseDto> responseEntityObj = resourceSearchController
				.updateSupervisorDetails(supervisorDto);
		assertEquals(201, responseEntityObj.getStatusCodeValue());
		verify(resourceSearchService, times(1)).updateSupervisorDetails(Mockito.any());
    }
}

