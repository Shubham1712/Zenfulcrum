package com.zensar.zenfulcrum.resourcemanagement.service;
  
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.projection.ProjectionFactory;
import org.springframework.data.projection.SpelAwareProxyProjectionFactory;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.HashBasedTable;
import com.zensar.zenfulcrum.resourcemanagement.dto.CountryDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeSkillDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.LookupValueDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ModuleStatusDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.PrimaryUsersDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectBudgetDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMApprovalInputDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTResourceDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RTWithinSamePhaseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementAndFteDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.ResourceRequirementDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateDeAllocationDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TransferResourceListDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.helper.AllocatedResourceHelperClass;
import com.zensar.zenfulcrum.resourcemanagement.helper.JVCheckHelperService;
import com.zensar.zenfulcrum.resourcemanagement.helper.SendMailHelperService;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateAllocationMapper;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateDeAllocationMapper;
import com.zensar.zenfulcrum.resourcemanagement.mapper.TAssociateProjectMapper;
import com.zensar.zenfulcrum.resourcemanagement.model.ResourceWorkflow;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateDeAllocation;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateProject;
import com.zensar.zenfulcrum.resourcemanagement.model.TAssociateSkill;
import com.zensar.zenfulcrum.resourcemanagement.projection.AllocatedResourceProjection;
import com.zensar.zenfulcrum.resourcemanagement.repository.JVDetailsRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.ResourceWorkflowRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateDeAllocationRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateProjectRepository;
import com.zensar.zenfulcrum.resourcemanagement.repository.TAssociateSkillRepository;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.AdminServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BAPServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.rest.client.BudgetControlServiceClient;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
import com.zensar.zenfulcrum.resourcemanagement.util.SendMailUtil;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceTransferServiceTest {
  
	@InjectMocks
	private ResourceTransferServiceImpl resourceTransferServiceImpl;

	@Mock
	private TAssociateAllocationMapper asssociateAllocationMapper;
	@Mock
	private ResourceAllocationServiceImpl resourceAllocationServiceImpl;
	@Mock
	private BAPServiceClient bapSrvcClient;
	@Mock
	private ResourceManagementServiceImpl resourceManagementServiceImpl;
	@Mock
	private TAssociateAllocationRepository tAssociateAllocationRepository;
	@Mock
	private TAssociateProjectRepository tAssociateProjectRepository;
	@Mock
	private TAssociateDeAllocationRepository tAssociateDeallocationRepository;
	@Mock
	private AdminServiceClient adminServiceClient;
	@Mock
	private TAssociateProjectMapper tAssociateProjectMapper;
	@Mock
	private BudgetControlServiceClient budgetControlServiceClient;
	@Mock
	private ResourceWorkflowRepository resourceWorkflowRepository;
	@Mock
	private SendMailUtil sendMailUtil;
	@Mock
	private SendMailHelperService sendMailHelperServiceObj;
	@Mock
	private TAssociateDeAllocationMapper asssociateDeallocationMapper;
	
	@Mock
	private TAssociateSkillRepository skillRepository;
	
	@Mock
	JVDetailsRepository jvDetailsRepository;

	@Mock
	JVCheckHelperService jvCheckHelperService;
	
	@Mock
	AllocatedResourceHelperClass  allocatedResourceHelperClass;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void updateResTransferInSameProjectNBillableTest() throws ResourceManagementException, ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		RTWithinSamePhaseDto rtWithinSamePhaseDto = new RTWithinSamePhaseDto();
		rtWithinSamePhaseDto.setUserId(111l);
		//rtWithinSamePhaseDto.setEffectiveStartDate(new Date());
		rtWithinSamePhaseDto.setRoleId(1l);
		rtWithinSamePhaseDto.setProjectId(40001l);
		rtWithinSamePhaseDto.setRoleName("ADMIN");

		List<TransferResourceListDto> resourceList = new ArrayList<>();
		TransferResourceListDto resource1 = new TransferResourceListDto();
		resource1.setRequirementId(12l);
		resource1.setRoleId(10l);
		resource1.setWorkLocationId(12l);
		List<Long> employeeIdList = new ArrayList<>();
		employeeIdList.add(1111l);
		resource1.setEmployeeIdList(employeeIdList);

		resourceList.add(resource1);  

		rtWithinSamePhaseDto.setRequirementList(resourceList); //
		// -----------------------------------------------------------------------------
		List<TAssociateAllocation> allocationList = new ArrayList<>();
		TAssociateAllocation allocation1 = new TAssociateAllocation();
		allocation1.setAssociateAllocationId(1l);
		allocation1.setRoleId(10l);
		allocation1.setRequirementId(12l);
		allocation1.setWorkLocationId(12l);
		allocation1.setSupervisorId(123l);
		allocation1.setTransactionHistoryId(123l);

		TAssociateAllocationDto allocationDto1 = new TAssociateAllocationDto();
		allocationDto1.setAssociateAllocationId(1l);
		allocationDto1.setRoleId(10l);
		allocationDto1.setRequirementId(12l);
		allocationDto1.setWorkLocationId(12l);
		allocationDto1.setFtePercent(100.00);
		allocationDto1.setActualAllocationStartDate(new Date());
		allocationDto1.setActualAllocationEndDate(new Date());
		allocationDto1.setSupervisorId(123l);
		
		List<TAssociateProject> projectList = new ArrayList<>();
		TAssociateProject project1 = new TAssociateProject();
		project1.setAssociateProjectId(10l);
		project1.setEmployeeId(1111l);
		project1.setProjectId(40001l);
		project1.setSrfId(10l);
		allocation1.setTAssociateProject(project1);
		project1.setTAssociateAllocation(allocation1);

		allocationList.add(allocation1);
		projectList.add(project1);

		List<TAssociateProjectDto> projectDtoList = new ArrayList<>();
		TAssociateProjectDto projectDto1 = new TAssociateProjectDto();
		projectDto1.setAssociateProjectId(10l);
		projectDto1.setEmployeeId(1111l);
		projectDto1.setProjectId(40001l);
		projectDto1.setSrfId(10l);
		projectDto1.setTAssociateAllocation(allocationDto1);
		projectDtoList.add(projectDto1);

		ModuleStatusDto statusActive = new ModuleStatusDto();
		statusActive.setModuleId(1l);
		statusActive.setAction("ACTIVE");
		ModuleStatusDto statusDeactive = new ModuleStatusDto();
		statusDeactive.setModuleId(2l);
		statusDeactive.setAction("DEACTIVE");

		Long statusActiveId = 1l;
		Long statusDeactiveId = 2l;

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");
		
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		projectBudgetDto.setId(1l);
		projectBudgetDto.setMonth("2020-01");
		projectBudgetDto.setAvailableBudget(10D);
		projectBudgetDto.setConsumedBudget(100D);
		projectBudgetDto.setProjectId("test");
		projectBudgetDto.setBudgetCurrency(10000D);
		projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-01-30"));
		projectBudget.add(projectBudgetDto);
		
		ModuleStatusDto moduleStatusDto=new ModuleStatusDto();
		moduleStatusDto.setModuleId(1l);
		
		TAssociateDeAllocationDto tAssociateDeallocationDto =new TAssociateDeAllocationDto();
		tAssociateDeallocationDto.setAssociateAllocationId(1l);
		tAssociateDeallocationDto.setProjectId(40001l);
		tAssociateDeallocationDto.setEmployeeId(52331l);
		tAssociateDeallocationDto.setCreatedBy(52336l);
		tAssociateDeallocationDto.setWorkflowStatusId(5l);
		tAssociateDeallocationDto.setRequirementId(10l);
		tAssociateDeallocationDto.setFtePercent(40);
		tAssociateDeallocationDto.setDeallocationReasonId(1l);
		tAssociateDeallocationDto.setWorkflowReasonId(1L);
		tAssociateDeallocationDto.setStatusId(5l);
		tAssociateDeallocationDto.setLastUpdatedBy(52336l);
		tAssociateDeallocationDto.setCreatedDate(dateFormat.parse("2020-04-01"));
		tAssociateDeallocationDto.setLastUpdatedDate(dateFormat.parse("2020-04-01"));
		tAssociateDeallocationDto.setEffectiveEndDate(dateFormat.parse("2020-04-01"));
		
		List<TAssociateDeAllocationDto> tAssociateDeallocationList = new ArrayList<>();
		tAssociateDeallocationList.add(tAssociateDeallocationDto);
		
		TAssociateDeAllocation associateDeallocation = new TAssociateDeAllocation();
		associateDeallocation.setAssociateAllocationId(1l);
		associateDeallocation.setProjectId(40001l);
		associateDeallocation.setEmployeeId(52331l);
		associateDeallocation.setCreatedBy(52336l);
		associateDeallocation.setWorkflowStatusId(5l);
		associateDeallocation.setRequirementId(10l);
		tAssociateDeallocationDto.setFtePercent(40);
		tAssociateDeallocationDto.setDeallocationReasonId(1l);
		tAssociateDeallocationDto.setWorkflowReasonId(1L);
		tAssociateDeallocationDto.setStatusId(5l);
		tAssociateDeallocationDto.setLastUpdatedBy(52336l);
		tAssociateDeallocationDto.setCreatedDate(dateFormat.parse("2020-04-01"));
		tAssociateDeallocationDto.setLastUpdatedDate(dateFormat.parse("2020-04-01"));
		tAssociateDeallocationDto.setEffectiveEndDate(dateFormat.parse("2020-04-01"));

		List<TAssociateDeAllocation> associateDeallocationList = new ArrayList<>();
		associateDeallocationList.add(associateDeallocation);
		PrimaryUsersDto userDto =new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList=new ArrayList<>();
		userList.add(userDto);
		
		LookupValueDto lookupValue = new LookupValueDto();
		lookupValue.setLookUpId(1l);
		lookupValue.setLookupType(ResourceManagementConstant.NonBillibale);
		lookupValue.setLookupValueCode(ResourceManagementConstant.NonBillibale);
		
		Long projectBillableIdbyProjectId =1l;
				
		when(adminServiceClient.getLookupValue(Mockito.anyString(),Mockito.anyString())).thenReturn(lookupValue);
		when(adminServiceClient.getLookuIdByTypeAndDescr(Mockito.anyString(),Mockito.anyString())).thenReturn(lookupValue.lookUpId);
		when(adminServiceClient.getProjectBillableIdbyProjectId(Mockito.anyLong())).thenReturn(projectBillableIdbyProjectId);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(asssociateDeallocationMapper.associateDeallocationDtoToAssociateDeallocations(tAssociateDeallocationList)).thenReturn(associateDeallocationList);
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudget);
		when(tAssociateAllocationRepository.getAllocationByassociateProjId(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(allocation1);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateProjectRepository.getAssociateProjectByEmployeeIdAndStatusId(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(projectList);
		when(tAssociateProjectMapper.tAssociateProjectToTAssociateProjectDto(Mockito.anyList()))
				.thenReturn(projectDtoList);
		when(resourceAllocationServiceImpl.performBudgetControlCheck(Mockito.any(), Mockito.anyList(), Mockito.anyMap())).thenReturn(true);

		doNothing().when(resourceAllocationServiceImpl).updateBudget(Mockito.anyMap());
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(statusActiveId);
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(statusDeactiveId);
		when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
		when(tAssociateAllocationRepository.saveAll(Mockito.any())).thenReturn(allocationList);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(moduleStatusDto);

		resourceTransferServiceImpl.updateResTransferInSameProject(rtWithinSamePhaseDto);


		//verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		//verify(bapSrvcClient, times(1)).getRequirementDetailByReqId(Mockito.anyLong());
		//verify(tAssociateProjectRepository, times(2)).getAssociateProjectByEmployeeIdAndStatusId(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong());
		//verify(resourceAllocationServiceImpl, times(1)).performBudgetControlCheck(Mockito.any(), Mockito.anyList(),
		//		Mockito.anyMap());
		verify(tAssociateAllocationRepository, times(1)).saveAll(Mockito.any());
	}
	
	
	@Test
	public void updateResTransferInSameProjectPMPGMTest() throws ResourceManagementException, ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		RTWithinSamePhaseDto rtWithinSamePhaseDto = new RTWithinSamePhaseDto();
		rtWithinSamePhaseDto.setUserId(111l);
		//rtWithinSamePhaseDto.setEffectiveStartDate(new Date());
		rtWithinSamePhaseDto.setRoleId(1l);
		rtWithinSamePhaseDto.setProjectId(40001l);
		rtWithinSamePhaseDto.setRoleName("PM");

		List<TransferResourceListDto> resourceList = new ArrayList<>();
		TransferResourceListDto resource1 = new TransferResourceListDto();
		resource1.setRequirementId(12l);
		resource1.setRoleId(10l);
		resource1.setWorkLocationId(12l);
		List<Long> employeeIdList = new ArrayList<>();
		employeeIdList.add(1111l);
		resource1.setEmployeeIdList(employeeIdList);

		resourceList.add(resource1);

		rtWithinSamePhaseDto.setRequirementList(resourceList); //
		// -----------------------------------------------------------------------------
		List<TAssociateAllocation> allocationList = new ArrayList<>();
		TAssociateAllocation allocation1 = new TAssociateAllocation();
		allocation1.setAssociateAllocationId(1l);
		allocation1.setRoleId(10l);
		allocation1.setRequirementId(12l);
		allocation1.setWorkLocationId(12l);
		allocation1.setSupervisorId(123l);

		TAssociateAllocationDto allocationDto1 = new TAssociateAllocationDto();
		allocationDto1.setAssociateAllocationId(1l);
		allocationDto1.setRoleId(10l);
		allocationDto1.setRequirementId(12l);
		allocationDto1.setWorkLocationId(12l);
		allocationDto1.setFtePercent(100.00);
		allocationDto1.setActualAllocationStartDate(new Date());
		allocationDto1.setActualAllocationEndDate(new Date());
		allocationDto1.setSupervisorId(123l);
		
		List<TAssociateProject> projectList = new ArrayList<>();
		TAssociateProject project1 = new TAssociateProject();
		project1.setAssociateProjectId(10l);
		project1.setEmployeeId(1111l);
		project1.setProjectId(40001l);
		project1.setSrfId(10l);
		allocation1.setTAssociateProject(project1);
		project1.setTAssociateAllocation(allocation1);

		allocationList.add(allocation1);
		projectList.add(project1);

		List<TAssociateProjectDto> projectDtoList = new ArrayList<>();
		TAssociateProjectDto projectDto1 = new TAssociateProjectDto();
		projectDto1.setAssociateProjectId(10l);
		projectDto1.setEmployeeId(1111l);
		projectDto1.setProjectId(40001l);
		projectDto1.setSrfId(10l);
		projectDto1.setTAssociateAllocation(allocationDto1);
		projectDtoList.add(projectDto1);

		ModuleStatusDto statusActive = new ModuleStatusDto();
		statusActive.setModuleId(1l);
		statusActive.setAction("ACTIVE");
		ModuleStatusDto statusDeactive = new ModuleStatusDto();
		statusDeactive.setModuleId(2l);
		statusDeactive.setAction("DEACTIVE");

		Long statusActiveId = 1l;
		Long statusDeactiveId = 2l;

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");
		
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		projectBudgetDto.setId(1l);
		projectBudgetDto.setMonth("2020-01");
		projectBudgetDto.setAvailableBudget(10D);
		projectBudgetDto.setConsumedBudget(100D);
		projectBudgetDto.setProjectId("test");
		projectBudgetDto.setBudgetCurrency(10000D);
		projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-01-30"));
		projectBudget.add(projectBudgetDto);
		
		ModuleStatusDto moduleStatusDto=new ModuleStatusDto();
		moduleStatusDto.setModuleId(1l);
		
		TAssociateDeAllocationDto tAssociateDeallocationDto =new TAssociateDeAllocationDto();
		tAssociateDeallocationDto.setAssociateAllocationId(1l);
		tAssociateDeallocationDto.setProjectId(40001l);
		tAssociateDeallocationDto.setEmployeeId(52331l);
		tAssociateDeallocationDto.setCreatedBy(52336l);
		tAssociateDeallocationDto.setWorkflowStatusId(5l);
		tAssociateDeallocationDto.setRequirementId(10l);
		tAssociateDeallocationDto.setFtePercent(40);
		tAssociateDeallocationDto.setDeallocationReasonId(1l);
		tAssociateDeallocationDto.setWorkflowReasonId(1L);
		tAssociateDeallocationDto.setStatusId(5l);
		tAssociateDeallocationDto.setLastUpdatedBy(52336l);
		tAssociateDeallocationDto.setCreatedDate(dateFormat.parse("2020-04-01"));
		tAssociateDeallocationDto.setLastUpdatedDate(dateFormat.parse("2020-04-01"));
		tAssociateDeallocationDto.setEffectiveEndDate(dateFormat.parse("2020-04-01"));
		
		List<TAssociateDeAllocationDto> tAssociateDeallocationList = new ArrayList<>();
		tAssociateDeallocationList.add(tAssociateDeallocationDto);
		
		TAssociateDeAllocation associateDeallocation = new TAssociateDeAllocation();
		associateDeallocation.setAssociateAllocationId(1l);
		associateDeallocation.setProjectId(40001l);
		associateDeallocation.setEmployeeId(52331l);
		associateDeallocation.setCreatedBy(52336l);
		associateDeallocation.setWorkflowStatusId(5l);
		associateDeallocation.setRequirementId(10l);
		tAssociateDeallocationDto.setFtePercent(40);
		tAssociateDeallocationDto.setDeallocationReasonId(1l);
		tAssociateDeallocationDto.setWorkflowReasonId(1L);
		tAssociateDeallocationDto.setStatusId(5l);
		tAssociateDeallocationDto.setLastUpdatedBy(52336l);
		tAssociateDeallocationDto.setCreatedDate(dateFormat.parse("2020-04-01"));
		tAssociateDeallocationDto.setLastUpdatedDate(dateFormat.parse("2020-04-01"));
		tAssociateDeallocationDto.setEffectiveEndDate(dateFormat.parse("2020-04-01"));

		List<TAssociateDeAllocation> associateDeallocationList = new ArrayList<>();
		associateDeallocationList.add(associateDeallocation);
		PrimaryUsersDto userDto =new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l); 
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList=new ArrayList<>();
		userList.add(userDto);
		
		LookupValueDto lookupValue = new LookupValueDto();
		lookupValue.setLookUpId(1l);
		lookupValue.setLookupType(ResourceManagementConstant.NonBillibale);
		lookupValue.setLookupValueCode(ResourceManagementConstant.NonBillibale);
		
		Long projectBillableIdbyProjectId =2l;
		
		when(adminServiceClient.getLookupValue(Mockito.anyString(),Mockito.anyString())).thenReturn(lookupValue);
		when(adminServiceClient.getProjectBillableIdbyProjectId(Mockito.anyLong())).thenReturn(projectBillableIdbyProjectId);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(asssociateDeallocationMapper.associateDeallocationDtoToAssociateDeallocations(tAssociateDeallocationList)).thenReturn(associateDeallocationList);
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudget);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateProjectRepository.getAssociateProjectByEmployeeIdAndStatusId(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(projectList);
		when(tAssociateProjectMapper.tAssociateProjectToTAssociateProjectDto(Mockito.anyList()))
				.thenReturn(projectDtoList);
		when(resourceAllocationServiceImpl.performBudgetControlCheck(Mockito.any(), Mockito.anyList(), Mockito.anyMap())).thenReturn(true);
		when(tAssociateAllocationRepository.getAllocationByassociateProjId(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(allocation1);

		doNothing().when(resourceAllocationServiceImpl).updateBudget(Mockito.anyMap());
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(statusActiveId);
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(statusDeactiveId);
		when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
		when(tAssociateAllocationRepository.saveAll(Mockito.any())).thenReturn(null);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(moduleStatusDto);

		resourceTransferServiceImpl.updateResTransferInSameProject(rtWithinSamePhaseDto);


		//verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		//verify(bapSrvcClient, times(1)).getRequirementDetailByReqId(Mockito.anyLong());
		//verify(tAssociateProjectRepository, times(2)).getAssociateProjectByEmployeeIdAndStatusId(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong());
		//verify(resourceAllocationServiceImpl, times(1)).performBudgetControlCheck(Mockito.any(), Mockito.anyList(),
		//		Mockito.anyMap());
		verify(tAssociateAllocationRepository, times(1)).saveAll(Mockito.any());
	}
	
	
	
	
	@Test
	public void updateResTransferInSameProjectNoBudgetTest() throws ResourceManagementException, ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		RTWithinSamePhaseDto rtWithinSamePhaseDto = new RTWithinSamePhaseDto();
		rtWithinSamePhaseDto.setUserId(111l);
		//rtWithinSamePhaseDto.setEffectiveStartDate(new Date());
		rtWithinSamePhaseDto.setRoleId(1l);
		rtWithinSamePhaseDto.setProjectId(40001l);
		rtWithinSamePhaseDto.setRoleName("PM");

		List<TransferResourceListDto> resourceList = new ArrayList<>();
		TransferResourceListDto resource1 = new TransferResourceListDto();
		resource1.setRequirementId(12l);
		resource1.setRoleId(10l);
		resource1.setWorkLocationId(12l);
		List<Long> employeeIdList = new ArrayList<>();
		employeeIdList.add(1111l);
		resource1.setEmployeeIdList(employeeIdList);

		resourceList.add(resource1);

		rtWithinSamePhaseDto.setRequirementList(resourceList); //
		// -----------------------------------------------------------------------------
		List<TAssociateAllocation> allocationList = new ArrayList<>();
		TAssociateAllocation allocation1 = new TAssociateAllocation();
		allocation1.setAssociateAllocationId(1l);
		allocation1.setRoleId(10l);
		allocation1.setRequirementId(12l);
		allocation1.setWorkLocationId(12l);

		TAssociateAllocationDto allocationDto1 = new TAssociateAllocationDto();
		allocationDto1.setAssociateAllocationId(1l);
		allocationDto1.setRoleId(10l);
		allocationDto1.setRequirementId(12l);
		allocationDto1.setWorkLocationId(12l);
		allocationDto1.setFtePercent(100.00);
		allocationDto1.setActualAllocationStartDate(new Date());
		allocationDto1.setActualAllocationEndDate(new Date());

		List<TAssociateProject> projectList = new ArrayList<>();
		TAssociateProject project1 = new TAssociateProject();
		project1.setAssociateProjectId(10l);
		project1.setEmployeeId(1111l);
		project1.setProjectId(40001l);
		project1.setSrfId(10l);
		allocation1.setTAssociateProject(project1);
		project1.setTAssociateAllocation(allocation1);

		allocationList.add(allocation1);
		projectList.add(project1);

		List<TAssociateProjectDto> projectDtoList = new ArrayList<>();
		TAssociateProjectDto projectDto1 = new TAssociateProjectDto();
		projectDto1.setAssociateProjectId(10l);
		projectDto1.setEmployeeId(1111l);
		projectDto1.setProjectId(40001l);
		projectDto1.setSrfId(10l);
		projectDto1.setTAssociateAllocation(allocationDto1);
		projectDtoList.add(projectDto1);

		ModuleStatusDto statusActive = new ModuleStatusDto();
		statusActive.setModuleId(1l);
		statusActive.setAction("ACTIVE");
		ModuleStatusDto statusDeactive = new ModuleStatusDto();
		statusDeactive.setModuleId(2l);
		statusDeactive.setAction("DEACTIVE");

		Long statusActiveId = 1l;
		Long statusDeactiveId = 2l;

		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");
		
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		projectBudgetDto.setId(1l);
		projectBudgetDto.setMonth("2020-01");
		projectBudgetDto.setAvailableBudget(10D);
		projectBudgetDto.setConsumedBudget(100D);
		projectBudgetDto.setProjectId("test");
		projectBudgetDto.setBudgetCurrency(10000D);
		projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-01-30"));
		projectBudget.add(projectBudgetDto);
		PrimaryUsersDto userDto =new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList=new ArrayList<>();
		userList.add(userDto);
		
		LookupValueDto lookupValue = new LookupValueDto();
		lookupValue.setLookUpId(1l);
		lookupValue.setLookupType(ResourceManagementConstant.NonBillibale);
		lookupValue.setLookupValueCode(ResourceManagementConstant.NonBillibale);
		
		Long projectBillableIdbyProjectId =2l;
		
		when(adminServiceClient.getLookupValue(Mockito.anyString(),Mockito.anyString())).thenReturn(lookupValue);
		when(adminServiceClient.getProjectBillableIdbyProjectId(Mockito.anyLong())).thenReturn(projectBillableIdbyProjectId);
        when(resourceAllocationServiceImpl.getBudgetAndCostCheck(Mockito.anyLong())).thenReturn(true);

		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);

		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(projectBudget);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(tAssociateProjectRepository.getAssociateProjectByEmployeeIdAndStatusId(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(projectList);
		when(tAssociateProjectMapper.tAssociateProjectToTAssociateProjectDto(Mockito.anyList()))
				.thenReturn(projectDtoList);
		when(resourceAllocationServiceImpl.performBudgetControlCheck(Mockito.any(), Mockito.anyList(), Mockito.anyMap())).thenReturn(false);
		doNothing().when(resourceAllocationServiceImpl).updateBudget(Mockito.anyMap());
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(statusActiveId);
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(statusDeactiveId);
		when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
		when(tAssociateAllocationRepository.saveAll(Mockito.any())).thenReturn(null);
		resourceTransferServiceImpl.updateResTransferInSameProject(rtWithinSamePhaseDto);

		verify(budgetControlServiceClient, times(1)).getProjectMonthlyBudgetsDetails(Mockito.anyLong());
		verify(bapSrvcClient, times(1)).getRequirementDetailByReqId(Mockito.anyLong());
		verify(tAssociateProjectRepository, times(1)).getAssociateProjectByEmployeeIdAndStatusId(Mockito.anyList(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong());
		verify(resourceAllocationServiceImpl, times(1)).performBudgetControlCheck(Mockito.any(), Mockito.anyList(),
				Mockito.anyMap());
	}

		
	/*
	 * @Test public void saveRTWithinODCAndProjectAndBUAdminAndBudgetTest() throws
	 * ResourceManagementException, ParseException { SimpleDateFormat dateFormat =
	 * new SimpleDateFormat("yyyy-MM-dd");
	 * 
	 * RMApprovalInputDto rtInputDto = new RMApprovalInputDto();
	 * rtInputDto.setUserId(55112L); rtInputDto.setRoleId(1L);
	 * rtInputDto.setFyiCurrentProgramManagerId(50336L);
	 * rtInputDto.setFyiTargetProgramManagerId(50337L);
	 * rtInputDto.setCurrentProjectId(41000L); rtInputDto.setProjectId(40001L);
	 * rtInputDto.setRequirementId(10L); rtInputDto.setCurrentRequirementId(10L);
	 * rtInputDto.setRoleName("ADMIN"); List<RTResourceDto> resourceDetailList = new
	 * ArrayList<>(); RTResourceDto resource = new RTResourceDto();
	 * resource.setEmpId(56778L); RTProjectDto currentProjectDetails = new
	 * RTProjectDto(); currentProjectDetails.setProjectUtilization(70L);
	 * currentProjectDetails.setAllocationDate(dateFormat.parse("2020-04-01"));
	 * currentProjectDetails.setEstimatedReleaseDate(dateFormat.parse("2020-04-30"))
	 * ; currentProjectDetails.setRequirementId(10L); RTProjectDto
	 * targetProjectDetails = new RTProjectDto();
	 * targetProjectDetails.setProjectUtilization(10L);
	 * targetProjectDetails.setAllocationDate(dateFormat.parse("2020-04-10"));
	 * targetProjectDetails.setEstimatedReleaseDate(dateFormat.parse("2020-05-10"));
	 * resource.setCurrentProjectDetails(currentProjectDetails);
	 * resource.setTargetProjectDetails(targetProjectDetails);
	 * resourceDetailList.add(resource);
	 * rtInputDto.setResourceList(resourceDetailList);
	 * 
	 * TAssociateProject tAssociateProject1=new TAssociateProject();
	 * tAssociateProject1.setEmployeeId(52331l); List<TAssociateAllocation>
	 * tAssociateAlloactionList=new ArrayList<>(); TAssociateAllocation
	 * tAssociateAlloaction = new TAssociateAllocation();
	 * tAssociateAlloaction.setRequirementId(10L);
	 * tAssociateAlloaction.setStatusId(1L);
	 * tAssociateAlloaction.setTransactionHistoryId(7L);
	 * tAssociateAlloaction.setFtePercent(25l);
	 * tAssociateAlloaction.setTAssociateProject(tAssociateProject1);
	 * TAssociateProject tAssociateProject=new TAssociateProject();
	 * tAssociateProject.setProjectId(41000L);
	 * tAssociateProject.setEmployeeId(52331l);
	 * tAssociateProject.setTAssociateAllocation(tAssociateAlloaction);
	 * tAssociateAlloactionList.add(tAssociateAlloaction);
	 * 
	 * TAssociateAllocation tAssociateAlloaction1 = new TAssociateAllocation();
	 * tAssociateAlloaction1.setRequirementId(10L);
	 * tAssociateAlloaction1.setStatusId(1L);
	 * tAssociateAlloaction1.setTransactionHistoryId(7L);
	 * tAssociateAlloaction1.setFtePercent(25l);
	 * tAssociateAlloaction1.setTAssociateProject(tAssociateProject1);
	 * tAssociateProject1.setProjectId(41000L);
	 * tAssociateProject1.setEmployeeId(52331l);
	 * tAssociateProject1.setTAssociateAllocation(tAssociateAlloaction1);
	 * tAssociateAlloactionList.add(tAssociateAlloaction1);
	 * 
	 * List<TAssociateProjectDto> tAssociateProjectListDto = new ArrayList<>();
	 * TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
	 * TAssociateAllocationDto tAssociateAllocationDto = new
	 * TAssociateAllocationDto(); tAssociateProjectDto.setProjectId(123L);
	 * tAssociateProjectDto.setEmployeeId(52336L);
	 * tAssociateProjectDto.setStatusId(1L);
	 * tAssociateAllocationDto.setActualAllocationStartDate(dateFormat.parse(
	 * "2020-04-01"));
	 * tAssociateAllocationDto.setEstAllocationEndDate(dateFormat.parse("2020-04-10"
	 * )); tAssociateAllocationDto.setBillableStatusId(1l);
	 * tAssociateAllocationDto.setFtePercent(100);
	 * tAssociateAllocationDto.setStatusId(3L);
	 * tAssociateAllocationDto.setRequirementId(6L);
	 * tAssociateAllocationDto.setRoleId(1L);
	 * tAssociateAllocationDto.setWorkLocationId(4L);
	 * tAssociateAllocationDto.setBaseHours(8);
	 * tAssociateProjectDto.setTAssociateAllocation(tAssociateAllocationDto);
	 * tAssociateProjectListDto.add(tAssociateProjectDto);
	 * 
	 * ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
	 * resourceRequirementDto.setBillingEffortsPerHrs(10);
	 * resourceRequirementDto.setShore("onsite");
	 * 
	 * List<ProjectBudgetDto> projectBudget = new ArrayList<>(); ProjectBudgetDto
	 * projectBudgetDto = new ProjectBudgetDto(); projectBudgetDto.setId(1l);
	 * projectBudgetDto.setMonth("2020-01");
	 * projectBudgetDto.setAvailableBudget(10D);
	 * projectBudgetDto.setConsumedBudget(100D);
	 * projectBudgetDto.setProjectId("test");
	 * projectBudgetDto.setBudgetCurrency(10000D);
	 * projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
	 * projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-01-30"));
	 * projectBudget.add(projectBudgetDto); ModuleStatusDto moduleStatusDto=new
	 * ModuleStatusDto(); moduleStatusDto.setModuleId(1l);
	 * 
	 * 
	 * 
	 * TAssociateDeAllocationDto tAssociateDeallocationDto =new
	 * TAssociateDeAllocationDto();
	 * tAssociateDeallocationDto.setAssociateAllocationId(1l);
	 * tAssociateDeallocationDto.setProjectId(40001l);
	 * tAssociateDeallocationDto.setEmployeeId(tAssociateProject.getEmployeeId());
	 * tAssociateDeallocationDto.setCreatedBy(52336l);
	 * tAssociateDeallocationDto.setWorkflowStatusId(5l);
	 * tAssociateDeallocationDto.setRequirementId(10l);
	 * tAssociateDeallocationDto.setFtePercent(40);
	 * tAssociateDeallocationDto.setDeallocationReasonId(1l);
	 * tAssociateDeallocationDto.setWorkflowReasonId(1L);
	 * tAssociateDeallocationDto.setStatusId(5l);
	 * tAssociateDeallocationDto.setLastUpdatedBy(52336l);
	 * tAssociateDeallocationDto.setCreatedDate(dateFormat.parse("2020-04-01"));
	 * tAssociateDeallocationDto.setLastUpdatedDate(dateFormat.parse("2020-04-01"));
	 * tAssociateDeallocationDto.setEffectiveEndDate(dateFormat.parse("2020-04-01"))
	 * ;
	 * 
	 * List<TAssociateDeAllocationDto> tAssociateDeallocationList = new
	 * ArrayList<>(); tAssociateDeallocationList.add(tAssociateDeallocationDto);
	 * 
	 * TAssociateDeAllocation associateDeallocation = new TAssociateDeAllocation();
	 * associateDeallocation.setAssociateAllocationId(1l);
	 * associateDeallocation.setProjectId(40001l);
	 * associateDeallocation.setEmployeeId(tAssociateProject.getEmployeeId());
	 * associateDeallocation.setCreatedBy(52336l);
	 * associateDeallocation.setWorkflowStatusId(5l);
	 * associateDeallocation.setRequirementId(10l); List<TAssociateDeAllocation>
	 * associateDeallocationList = new ArrayList<>();
	 * associateDeallocationList.add(associateDeallocation); PrimaryUsersDto userDto
	 * =new PrimaryUsersDto(); userDto.setCustomerCode("CISCO");
	 * userDto.setProjectCode("AMS"); userDto.setProjectId(50001l);
	 * userDto.setRoleId(1l); userDto.setRoleName("PM"); userDto.setUserId(52336l);
	 * userDto.setUserName("xyz"); List<PrimaryUsersDto> userList=new ArrayList<>();
	 * userList.add(userDto); LookupValueDto lookupValue=new LookupValueDto();
	 * lookupValue.setLookUpId(1l);
	 * 
	 * 
	 * when(tAssociateAllocationRepository.getCurrentProjectDetail(Mockito.anyLong()
	 * ,Mockito.anyLong(),Mockito.anyLong())).thenReturn(tAssociateAlloactionList);
	 * when(tAssociateAllocationRepository.getCurrentProjectData(Mockito.anyLong(),
	 * Mockito.anyLong(),Mockito.anyLong())).thenReturn(tAssociateAlloaction);
	 * when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(),
	 * Mockito.anyList())).thenReturn(userList); when(asssociateDeallocationMapper.
	 * associateDeallocationDtoToAssociateDeallocations(tAssociateDeallocationList))
	 * .thenReturn(associateDeallocationList);
	 * when(tAssociateAllocationRepository.getCurrentProjectAllocationId(Mockito.
	 * anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.
	 * anyList())).thenReturn(tAssociateAlloaction);
	 * when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.
	 * anyLong())).thenReturn(projectBudget);
	 * when(resourceAllocationServiceImpl.performBudgetControlCheck(Mockito.any(),
	 * Mockito.any(),Mockito.anyMap())).thenReturn(true);
	 * when(tAssociateProjectRepository.save(Mockito.any())).thenReturn(
	 * tAssociateProject1);
	 * when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn
	 * (resourceRequirementDto);
	 * when(adminServiceClient.getModuleStatus(Mockito.anyString(),
	 * Mockito.anyString(), Mockito.anyString())).thenReturn(moduleStatusDto);
	 * when(adminServiceClient.getLookupValue(Mockito.anyString(),
	 * Mockito.anyString())).thenReturn(lookupValue);
	 * when(tAssociateProjectRepository.getByEmpIdAndProjId(Mockito.anyLong(),
	 * Mockito.anyLong())).thenReturn(tAssociateProject);
	 * when(adminServiceClient.getProjectBillableIdbyProjectId(Mockito.anyLong())).
	 * thenReturn(2l);
	 * when(allocatedResourceHelperClass.getallModuleData()).thenReturn(
	 * getAllNewModuleList());
	 * when(adminServiceClient.getLookUpById(Mockito.anyLong())).thenReturn(
	 * lookupValue);
	 * resourceTransferServiceImpl.saveRTWithinODCAndProjectAndBU(rtInputDto);
	 * //verify(adminServiceClient, times(1)).getLookupValue(Mockito.anyString(),
	 * Mockito.anyString()); verify(adminServiceClient,
	 * times(1)).getProjectBillableIdbyProjectId(Mockito.anyLong());
	 * verify(bapSrvcClient,
	 * times(2)).getRequirementDetailByReqId(Mockito.anyLong());
	 * verify(tAssociateProjectRepository,times(1)).getByEmpIdAndProjId(Mockito.
	 * anyLong(), Mockito.anyLong());
	 * verify(tAssociateAllocationRepository,times(1)).getCurrentProjectAllocationId
	 * (Mockito.anyLong(),Mockito.anyLong(),
	 * Mockito.anyLong(),Mockito.anyLong(),Mockito.anyList());
	 * 
	 * }
	 */
	@Test
	public void saveRTWithinODCAndProjectAndBUTest() throws ResourceManagementException, ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		RMApprovalInputDto rtInputDto = new RMApprovalInputDto();
		rtInputDto.setUserId(55112L);
		rtInputDto.setRoleId(1L);
		rtInputDto.setFyiCurrentProgramManagerId(50336L);
		rtInputDto.setFyiTargetProgramManagerId(50337L);
		rtInputDto.setCurrentProjectId(41000L);
		rtInputDto.setProjectId(40001L);
		rtInputDto.setRequirementId(10L);
		rtInputDto.setCurrentRequirementId(10L);
		rtInputDto.setRoleName("PGM");
		rtInputDto.setBudgetAndCostCheck(true);
		List<RTResourceDto> resourceDetailList = new ArrayList<>();
		RTResourceDto resource = new RTResourceDto();
		resource.setEmpId(56778L);
		RTProjectDto currentProjectDetails = new RTProjectDto();
		currentProjectDetails.setProjectUtilization(70L);
		currentProjectDetails.setAllocationDate(dateFormat.parse("2020-04-01"));
		currentProjectDetails.setEstimatedReleaseDate(dateFormat.parse("2020-04-30"));
		currentProjectDetails.setRequirementId(10L);
		RTProjectDto targetProjectDetails = new RTProjectDto();
		targetProjectDetails.setProjectUtilization(10L);
		targetProjectDetails.setAllocationDate(dateFormat.parse("2020-04-10"));
		targetProjectDetails.setEstimatedReleaseDate(dateFormat.parse("2020-05-10"));
		resource.setCurrentProjectDetails(currentProjectDetails);
		resource.setTargetProjectDetails(targetProjectDetails);
		resourceDetailList.add(resource);
		rtInputDto.setResourceList(resourceDetailList);
		
		TAssociateProject tAssociateProject1=new TAssociateProject();
		tAssociateProject1.setEmployeeId(52331l);
		
		TAssociateAllocation tAssociateAlloaction = new TAssociateAllocation();
		tAssociateAlloaction.setBillableStatusId(1l);
		tAssociateAlloaction.setRequirementId(10L);
		tAssociateAlloaction.setStatusId(1L);
		tAssociateAlloaction.setTransactionHistoryId(7L);
		tAssociateAlloaction.setFtePercent(25.00);
		tAssociateAlloaction.setTAssociateProject(tAssociateProject1);
		TAssociateProject tAssociateProject=new TAssociateProject();
		tAssociateProject.setProjectId(41000L);
		tAssociateProject.setEmployeeId(52331l);
		tAssociateProject.setTAssociateAllocation(tAssociateAlloaction);
		
		List<TAssociateProjectDto> tAssociateProjectListDto = new ArrayList<>();
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		TAssociateAllocationDto tAssociateAllocationDto = new TAssociateAllocationDto();
		tAssociateProjectDto.setProjectId(123L);
		tAssociateProjectDto.setEmployeeId(52336L);
		tAssociateProjectDto.setStatusId(1L);
		tAssociateAllocationDto.setActualAllocationStartDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocationDto.setEstAllocationEndDate(dateFormat.parse("2020-04-10"));
		tAssociateAllocationDto.setBillableStatusId(1l);
		tAssociateAllocationDto.setFtePercent(100D);
		tAssociateAllocationDto.setStatusId(3L);
		tAssociateAllocationDto.setRequirementId(6L);
		tAssociateAllocationDto.setRoleId(1L);
		tAssociateAllocationDto.setWorkLocationId(4L);
		tAssociateAllocationDto.setBaseHours(8D);
		tAssociateProjectDto.setTAssociateAllocation(tAssociateAllocationDto);
		tAssociateProjectListDto.add(tAssociateProjectDto);
		
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto(); 
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");
		
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		projectBudgetDto.setId(1l);
		projectBudgetDto.setMonth("2020-01");
		projectBudgetDto.setAvailableBudget(10D);
		projectBudgetDto.setConsumedBudget(100D);
		projectBudgetDto.setProjectId("test");
		projectBudgetDto.setBudgetCurrency(10000D);
		projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-01-30"));
		projectBudget.add(projectBudgetDto);
		ModuleStatusDto moduleStatusDto=new ModuleStatusDto();
		moduleStatusDto.setModuleId(1l);
		
		
		
		TAssociateDeAllocationDto tAssociateDeallocationDto =new TAssociateDeAllocationDto();
		tAssociateDeallocationDto.setAssociateAllocationId(1l);
		tAssociateDeallocationDto.setProjectId(40001l);
		tAssociateDeallocationDto.setEmployeeId(tAssociateProject.getEmployeeId());
		tAssociateDeallocationDto.setCreatedBy(52336l);
		tAssociateDeallocationDto.setWorkflowStatusId(5l);
		tAssociateDeallocationDto.setRequirementId(10l);
		tAssociateDeallocationDto.setFtePercent(40);
		tAssociateDeallocationDto.setDeallocationReasonId(1l);
		tAssociateDeallocationDto.setWorkflowReasonId(1L);
		tAssociateDeallocationDto.setStatusId(5l);
		tAssociateDeallocationDto.setLastUpdatedBy(52336l);
		tAssociateDeallocationDto.setCreatedDate(dateFormat.parse("2020-04-01"));
		tAssociateDeallocationDto.setLastUpdatedDate(dateFormat.parse("2020-04-01"));
		tAssociateDeallocationDto.setEffectiveEndDate(dateFormat.parse("2020-04-01"));

		List<TAssociateDeAllocationDto> tAssociateDeallocationList = new ArrayList<>();
		tAssociateDeallocationList.add(tAssociateDeallocationDto);
		
		TAssociateDeAllocation associateDeallocation = new TAssociateDeAllocation();
		associateDeallocation.setAssociateAllocationId(1l);
		associateDeallocation.setProjectId(40001l);
		associateDeallocation.setEmployeeId(tAssociateProject.getEmployeeId());
		associateDeallocation.setCreatedBy(52336l);
		associateDeallocation.setWorkflowStatusId(5l);
		associateDeallocation.setRequirementId(10l);
		List<TAssociateDeAllocation> associateDeallocationList = new ArrayList<>();
		associateDeallocationList.add(associateDeallocation);
		PrimaryUsersDto userDto =new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList=new ArrayList<>();
		userList.add(userDto);
		LookupValueDto lookupValue=new LookupValueDto();
		lookupValue.setLookUpId(1l);

		when(tAssociateAllocationRepository.getCurrentProjectData(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(tAssociateAlloaction);
		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(asssociateDeallocationMapper.associateDeallocationDtoToAssociateDeallocations(tAssociateDeallocationList)).thenReturn(associateDeallocationList);
		when(tAssociateAllocationRepository.getCurrentProjectAllocationId(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyList())).thenReturn(tAssociateAlloaction);
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		when(resourceAllocationServiceImpl.performBudgetControlCheck(Mockito.any(),Mockito.any(),Mockito.anyMap())).thenReturn(true);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(moduleStatusDto);
		when(adminServiceClient.getLookupValue(Mockito.anyString(), Mockito.anyString())).thenReturn(lookupValue);
		when(tAssociateProjectRepository.getByEmpIdAndProjId(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(tAssociateProject);
		when(adminServiceClient.getProjectBillableIdbyProjectId(Mockito.anyLong())).thenReturn(2l);
		when(adminServiceClient.getLookUpById(Mockito.anyLong())).thenReturn(lookupValue);
		when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
		resourceTransferServiceImpl.saveRTWithinODCAndProjectAndBU(rtInputDto);		
		//verify(adminServiceClient, times(1)).getLookupValue(Mockito.anyString(), Mockito.anyString());
		verify(adminServiceClient, times(1)).getProjectBillableIdbyProjectId(Mockito.anyLong());
		verify(bapSrvcClient, times(2)).getRequirementDetailByReqId(Mockito.anyLong());
		verify(tAssociateProjectRepository,times(1)).getByEmpIdAndProjId(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong());
		verify(tAssociateAllocationRepository,times(1)).getCurrentProjectAllocationId(Mockito.anyLong(),Mockito.anyLong(),
				Mockito.anyLong(),Mockito.anyLong(),Mockito.anyList());

	}
		
	@Test
	public void saveRTWithinODCAndProjectAndBUAdminTest() throws ResourceManagementException, ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		RMApprovalInputDto rtInputDto = new RMApprovalInputDto();
		rtInputDto.setUserId(55112L);
		rtInputDto.setRoleId(1L);
		rtInputDto.setFyiCurrentProgramManagerId(50336L);
		rtInputDto.setFyiTargetProgramManagerId(50337L);
		rtInputDto.setCurrentProjectId(41000L);
		rtInputDto.setProjectId(40001L);
		rtInputDto.setRequirementId(10L);
		rtInputDto.setCurrentRequirementId(10L);
		rtInputDto.setRoleName("ADMIN");
		List<RTResourceDto> resourceDetailList = new ArrayList<>();
		RTResourceDto resource = new RTResourceDto();
		resource.setEmpId(56778L);
		RTProjectDto currentProjectDetails = new RTProjectDto();
		currentProjectDetails.setProjectUtilization(70L);
		currentProjectDetails.setAllocationDate(dateFormat.parse("2020-04-01"));
		currentProjectDetails.setEstimatedReleaseDate(dateFormat.parse("2020-04-30"));
		currentProjectDetails.setRequirementId(10L);
		RTProjectDto targetProjectDetails = new RTProjectDto();
		targetProjectDetails.setProjectUtilization(10L);
		targetProjectDetails.setAllocationDate(dateFormat.parse("2020-04-10"));
		targetProjectDetails.setEstimatedReleaseDate(dateFormat.parse("2020-05-10"));
		resource.setCurrentProjectDetails(currentProjectDetails);
		resource.setTargetProjectDetails(targetProjectDetails);
		resourceDetailList.add(resource);
		rtInputDto.setResourceList(resourceDetailList);
		
		TAssociateProject tAssociateProject1=new TAssociateProject();
		tAssociateProject1.setEmployeeId(52331l);
		
		TAssociateAllocation tAssociateAlloaction = new TAssociateAllocation();
		tAssociateAlloaction.setBillableStatusId(1l);
		tAssociateAlloaction.setRequirementId(10L);
		tAssociateAlloaction.setStatusId(1L);
		tAssociateAlloaction.setTransactionHistoryId(7L);
		tAssociateAlloaction.setFtePercent(25D);
		tAssociateAlloaction.setTAssociateProject(tAssociateProject1);
		TAssociateProject tAssociateProject=new TAssociateProject();
		tAssociateProject.setEmployeeId(52331l);
		tAssociateProject.setTAssociateAllocation(tAssociateAlloaction);
		
		List<TAssociateProjectDto> tAssociateProjectListDto = new ArrayList<>();
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		TAssociateAllocationDto tAssociateAllocationDto = new TAssociateAllocationDto();
		tAssociateProjectDto.setProjectId(123L);
		tAssociateProjectDto.setEmployeeId(52336L);
		tAssociateProjectDto.setStatusId(1L);
		tAssociateAllocationDto.setActualAllocationStartDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocationDto.setEstAllocationEndDate(dateFormat.parse("2020-04-10"));
		tAssociateAllocationDto.setFtePercent(100D);
		tAssociateAllocationDto.setStatusId(3L);
		tAssociateAllocationDto.setRequirementId(6L);
		tAssociateAllocationDto.setRoleId(1L);
		tAssociateAllocationDto.setWorkLocationId(4L);
		tAssociateAllocationDto.setBaseHours(8D);
		tAssociateProjectDto.setTAssociateAllocation(tAssociateAllocationDto);
		tAssociateProjectListDto.add(tAssociateProjectDto);
		
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto(); 
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");
		
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		projectBudgetDto.setId(1l);
		projectBudgetDto.setMonth("2020-01");
		projectBudgetDto.setAvailableBudget(10D);
		projectBudgetDto.setConsumedBudget(100D);
		projectBudgetDto.setProjectId("test");
		projectBudgetDto.setBudgetCurrency(10000D);
		projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-01-30"));
		projectBudget.add(projectBudgetDto);
		ModuleStatusDto moduleStatusDto=new ModuleStatusDto();
		moduleStatusDto.setModuleId(1l);
		
		
		
		TAssociateDeAllocationDto tAssociateDeallocationDto =new TAssociateDeAllocationDto();
		tAssociateDeallocationDto.setAssociateAllocationId(1l);
		tAssociateDeallocationDto.setProjectId(40001l);
		tAssociateDeallocationDto.setEmployeeId(tAssociateProject.getEmployeeId());
		tAssociateDeallocationDto.setCreatedBy(52336l);
		tAssociateDeallocationDto.setWorkflowStatusId(5l);
		tAssociateDeallocationDto.setRequirementId(10l);
		tAssociateDeallocationDto.setFtePercent(40);
		tAssociateDeallocationDto.setDeallocationReasonId(1l);
		tAssociateDeallocationDto.setWorkflowReasonId(1L);
		tAssociateDeallocationDto.setStatusId(5l);
		tAssociateDeallocationDto.setLastUpdatedBy(52336l);
		tAssociateDeallocationDto.setCreatedDate(dateFormat.parse("2020-04-01"));
		tAssociateDeallocationDto.setLastUpdatedDate(dateFormat.parse("2020-04-01"));
		tAssociateDeallocationDto.setEffectiveEndDate(dateFormat.parse("2020-04-01"));

		List<TAssociateDeAllocationDto> tAssociateDeallocationList = new ArrayList<>();
		tAssociateDeallocationList.add(tAssociateDeallocationDto);
		
		TAssociateDeAllocation associateDeallocation = new TAssociateDeAllocation();
		associateDeallocation.setAssociateAllocationId(1l);
		associateDeallocation.setProjectId(40001l);
		associateDeallocation.setEmployeeId(tAssociateProject.getEmployeeId());
		associateDeallocation.setCreatedBy(52336l);
		associateDeallocation.setWorkflowStatusId(5l);
		associateDeallocation.setRequirementId(10l);
		List<TAssociateDeAllocation> associateDeallocationList = new ArrayList<>();
		associateDeallocationList.add(associateDeallocation);
		PrimaryUsersDto userDto =new PrimaryUsersDto();
		userDto.setCustomerCode("CISCO");
		userDto.setProjectCode("AMS");
		userDto.setProjectId(50001l);
		userDto.setRoleId(1l);
		userDto.setRoleName("PM");
		userDto.setUserId(52336l);
		userDto.setUserName("xyz");
		List<PrimaryUsersDto> userList=new ArrayList<>();
		userList.add(userDto);
		LookupValueDto lookupValue=new LookupValueDto();
		lookupValue.setLookUpId(1l);

		when(bapSrvcClient.getRoleBasedPrimaryOwnersList(Mockito.anyLong(), Mockito.anyList())).thenReturn(userList);
		when(asssociateDeallocationMapper.associateDeallocationDtoToAssociateDeallocations(tAssociateDeallocationList)).thenReturn(associateDeallocationList);
		when(tAssociateAllocationRepository.getCurrentProjectAllocationId(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyList())).thenReturn(tAssociateAlloaction);
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong())).thenReturn(projectBudget);
		when(resourceAllocationServiceImpl.performBudgetControlCheck(Mockito.any(),Mockito.any(),Mockito.anyMap())).thenReturn(true);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(resourceRequirementDto);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(moduleStatusDto);
		when(adminServiceClient.getLookupValue(Mockito.anyString(), Mockito.anyString())).thenReturn(lookupValue);
		when(tAssociateProjectRepository.getByEmpIdAndProjId(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong())).thenReturn(tAssociateProject);
		when(adminServiceClient.getProjectBillableIdbyProjectId(Mockito.anyLong())).thenReturn(1l);
		when(adminServiceClient.getLookUpById(Mockito.anyLong())).thenReturn(lookupValue);
		when(adminServiceClient.getLookuIdByTypeAndDescr(Mockito.anyString(),Mockito.anyString())).thenReturn(1l);
		when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
		resourceTransferServiceImpl.saveRTWithinODCAndProjectAndBU(rtInputDto);		
		//verify(adminServiceClient, times(1)).getLookupValue(Mockito.anyString(), Mockito.anyString());
		verify(adminServiceClient, times(1)).getProjectBillableIdbyProjectId(Mockito.anyLong());
		verify(bapSrvcClient, times(2)).getRequirementDetailByReqId(Mockito.anyLong());
		verify(tAssociateProjectRepository,times(1)).getByEmpIdAndProjId(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong());
		verify(tAssociateAllocationRepository,times(1)).getCurrentProjectAllocationId(Mockito.anyLong(),Mockito.anyLong(),
				Mockito.anyLong(),Mockito.anyLong(),Mockito.anyList());


	}

	@Test
	public void rejectRTWithinODCAndProjectAndBUTest() throws ResourceManagementException, ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		RMApprovalInputDto rtInputDto = new RMApprovalInputDto();
		rtInputDto.setUserId(55112L);
		rtInputDto.setRoleId(1L);
		rtInputDto.setFyiCurrentProgramManagerId(50336L);
		rtInputDto.setFyiTargetProgramManagerId(50337L);
		rtInputDto.setCurrentProjectId(41000L);
		rtInputDto.setProjectId(40001L);
		rtInputDto.setRequirementId(10L);
		rtInputDto.setCurrentRequirementId(10L);
		List<RTResourceDto> resourceDetailList = new ArrayList<>();
		RTResourceDto resource = new RTResourceDto();
		resource.setEmpId(56778L);
		RTProjectDto currentProjectDetails = new RTProjectDto();
		currentProjectDetails.setProjectUtilization(70L);
		currentProjectDetails.setAllocationDate(dateFormat.parse("2020-04-01"));
		currentProjectDetails.setEstimatedReleaseDate(dateFormat.parse("2020-04-30"));
		currentProjectDetails.setRequirementId(10L);
		RTProjectDto targetProjectDetails = new RTProjectDto();
		targetProjectDetails.setProjectUtilization(10L);
		targetProjectDetails.setAllocationDate(dateFormat.parse("2020-04-10"));
		targetProjectDetails.setEstimatedReleaseDate(dateFormat.parse("2020-05-10"));
		resource.setCurrentProjectDetails(currentProjectDetails);
		resource.setTargetProjectDetails(targetProjectDetails);
		resourceDetailList.add(resource);
		rtInputDto.setResourceList(resourceDetailList);
		
		TAssociateAllocation tAssociateAlloaction = new TAssociateAllocation();
		tAssociateAlloaction.setRequirementId(10L);
		tAssociateAlloaction.setStatusId(1L);
		tAssociateAlloaction.setTransactionHistoryId(7L);
		
		List<TAssociateProjectDto> tAssociateProjectListDto = new ArrayList<>();
		TAssociateProjectDto tAssociateProjectDto = new TAssociateProjectDto();
		TAssociateAllocationDto tAssociateAllocationDto = new TAssociateAllocationDto();
		tAssociateProjectDto.setProjectId(123L);
		tAssociateProjectDto.setEmployeeId(52336L);
		tAssociateProjectDto.setStatusId(1L);
		tAssociateAllocationDto.setActualAllocationStartDate(dateFormat.parse("2020-04-01"));
		tAssociateAllocationDto.setEstAllocationEndDate(dateFormat.parse("2020-04-10"));
		tAssociateAllocationDto.setFtePercent(100D);
		tAssociateAllocationDto.setStatusId(3L);
		tAssociateAllocationDto.setRequirementId(6L);
		tAssociateAllocationDto.setRoleId(1L);
		tAssociateAllocationDto.setWorkLocationId(4L);
		tAssociateAllocationDto.setBaseHours(8D);
		tAssociateProjectDto.setTAssociateAllocation(tAssociateAllocationDto);
		tAssociateProjectListDto.add(tAssociateProjectDto);
		
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto(); 
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");
		
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto = new ProjectBudgetDto();
		projectBudgetDto.setId(1l);
		projectBudgetDto.setMonth("2020-01");
		projectBudgetDto.setAvailableBudget(10D);
		projectBudgetDto.setConsumedBudget(100D);
		projectBudgetDto.setProjectId("test");
		projectBudgetDto.setBudgetCurrency(10000D);
		projectBudgetDto.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto.setProjectEndDate(dateFormat.parse("2020-01-30"));
		projectBudget.add(projectBudgetDto);
		
		List<Long> transactionIdList = new ArrayList<>();
		transactionIdList.add(10L);
		
		when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
		when(tAssociateAllocationRepository.getCurrentProjectAllocationId(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyList())).thenReturn(tAssociateAlloaction);
		resourceTransferServiceImpl.rejectRTWithinODCAndProjectAndBU(List.of(rtInputDto));		
		verify(tAssociateAllocationRepository, times(1)).getCurrentProjectAllocationId(Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong(),Mockito.anyList());

	}

	@Test
	public void getAllocatedResourceFTESwitchOdcTest() throws ResourceManagementException
	{
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");
		resourceRequirementAndFteDto.setEmployeeList(employeeList);
		
	//	doNothing().when(resourceTransferServiceImpl).getAllocatedResource(Mockito.anyLong());
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(tAssociateAllocationRepository.getTotalAllocatedBillbleFteForTransfer(Mockito.anyLong())).thenReturn(123.0);
    	when(tAssociateAllocationRepository.getTotalAllocatedEBRFteForTransfer(Mockito.anyLong())).thenReturn(123.00);
		when(bapSrvcClient.getProjectFte(Mockito.anyLong())).thenReturn(resourceRequirementAndFteDto);
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
		ResourceRequirementAndFteDto  newresourceRequirementAndFteDto = resourceTransferServiceImpl.getAllocatedResourceFTE(123L,"switchWithinOdc");
		assertNotNull(newresourceRequirementAndFteDto);
	}
	
	   
	@Test
	public void getAllocatedResourceFTETest() throws ResourceManagementException
	{
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");
		resourceRequirementAndFteDto.setEmployeeList(employeeList);
		
	//	doNothing().when(resourceTransferServiceImpl).getAllocatedResource(Mockito.anyLong());
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(tAssociateAllocationRepository.getTotalAllocatedBillbleFteForTransfer(Mockito.anyLong())).thenReturn(123.0);
		when(tAssociateAllocationRepository.getTotalAllocatedEBRFteForTransfer(Mockito.anyLong())).thenReturn(123.0);
		when(bapSrvcClient.getProjectFte(Mockito.anyLong())).thenReturn(resourceRequirementAndFteDto);
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());

		
		
		ResourceRequirementAndFteDto  newresourceRequirementAndFteDto = resourceTransferServiceImpl.getAllocatedResourceFTE(123L,"transferBetweenPhases");
		assertNotNull(newresourceRequirementAndFteDto);
		verify(tAssociateAllocationRepository,times(1)).getTotalAllocatedBillbleFteForTransfer(Mockito.anyLong());
		verify(tAssociateAllocationRepository,times(1)).getTotalAllocatedEBRFteForTransfer(Mockito.anyLong());
		verify(bapSrvcClient,times(1)).getProjectFte(Mockito.anyLong());
	}
	
	
	@Test
	public void getAllocatedResourceFTETSwitchWithinBuTest() throws ResourceManagementException
	{
		ResourceRequirementAndFteDto resourceRequirementAndFteDto = new ResourceRequirementAndFteDto();
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");
		resourceRequirementAndFteDto.setEmployeeList(employeeList);
		
		
		  ProjectDto projectDto = new ProjectDto(); 
		  projectDto.setProjectId(4444L);
		  projectDto.setProjectName("test-1");
			
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
        when(bapSrvcClient.getIntransitProjectId(Mockito.anyLong())).thenReturn(projectDto);
        when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(tAssociateAllocationRepository.getTotalAllocatedBillbleFteForTransfer(Mockito.anyLong())).thenReturn(123.0);
		when(tAssociateAllocationRepository.getTotalAllocatedEBRFteForTransfer(Mockito.anyLong())).thenReturn(123.0);
		when(bapSrvcClient.getProjectFte(Mockito.anyLong())).thenReturn(resourceRequirementAndFteDto);
		ResourceRequirementAndFteDto  newresourceRequirementAndFteDto = resourceTransferServiceImpl.getAllocatedResourceFTE(123L,"switchWithinBU");
		assertNotNull(newresourceRequirementAndFteDto);
		verify(bapSrvcClient,times(1)).getIntransitProjectId(Mockito.anyLong());
	}
	

	@Test
	public void getAllocatedResourceTest() throws ResourceManagementException {
		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(1);
		associateList.add(allocatedResourceProjection); 

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeNumber(52330l);
		
		List<ResourceRequirementDto> rRList = new ArrayList<>();
		ResourceRequirementDto rRDto = new ResourceRequirementDto();
		rRDto.setReqId(6L);
		rRDto.setBillable(2.0);
		rRDto.setBillingEffortsPerHrs(1234.0);
		rRList.add(rRDto);

		List<TAssociateSkill> associateSkill = new ArrayList<TAssociateSkill>();
		TAssociateSkill tAssociateSkill = new TAssociateSkill();
		tAssociateSkill.setAssociateSkillId(1l);
		tAssociateSkill.setAssociateId(52330l);
		tAssociateSkill.setSkillId(1l);
		associateSkill.add(tAssociateSkill); 
		
		List<SkillTaxonomyDto> skillTaxanomyList = new ArrayList<SkillTaxonomyDto>();
		SkillTaxonomyDto skillTaxonomyDto = new SkillTaxonomyDto();
		skillTaxonomyDto.setEmployeeId(52330l);
		skillTaxonomyDto.setL4SkillId(1l);
		skillTaxonomyDto.setL4skillName("test");
		skillTaxanomyList.add(skillTaxonomyDto);
		
		Map<Long, EmployeeSkillDto> skillFamilyMap = new HashMap<Long, EmployeeSkillDto>();
		EmployeeSkillDto empskillDto = new EmployeeSkillDto();
		empskillDto.setEmployeeId(52330l);
		empskillDto.setL4SkillId(List.of(1l));
		empskillDto.setSkillFamilyList(skillTaxanomyList);
		skillFamilyMap.put(52330l, empskillDto);
		
		List<Long> listOfIds = new ArrayList<Long>();
		listOfIds.add(1l);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(tAssociateAllocationRepository.getAllocatedResourceToTransfer(Mockito.anyLong()))
				.thenReturn(associateList);
		when(adminServiceClient.getAssociatesDetailsbyEmpIds(Mockito.anyList())).thenReturn(employeeList);
		   when(resourceAllocationServiceImpl.getSkillFamilyForAssociate(Mockito.anyList())).thenReturn(skillFamilyMap);
				when(skillRepository.findByAssociateIdIn(Mockito.anyList())).thenReturn(associateSkill);
				when(skillRepository.getSkillListForEmployee(Mockito.anyLong())).thenReturn(listOfIds);
			when(adminServiceClient.getSkillFamilyByskillId(Mockito.anyList())).thenReturn(skillTaxanomyList);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(rRList);
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
    //    when(tAssociateAllocationRepository.getAllocatedResourceListForTransfer(Mockito.anyLong(), Mockito.anyList(),
	//			Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(),
	//			Mockito.anyLong())).thenReturn(associateList);
	//	when(allocatedResourceHelperClass.getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList())).thenReturn(associateList);
		when(allocatedResourceHelperClass.getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean())).thenReturn(associateList);

		List<EmployeeDto> empList = resourceTransferServiceImpl.getAllocatedResource(123L);
		assertNotNull(empList); 
    //    verify(tAssociateAllocationRepository,times(1)).getAllocatedResourceListForTransfer(Mockito.anyLong(), Mockito.anyList(),
	//			Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(),
	//			Mockito.anyLong());
		//   verify(allocatedResourceHelperClass,times(1)).getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList());	
		   verify(allocatedResourceHelperClass,times(1)).getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean());	

		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyLong());
	} 
	
	@Test
	public void getAllocatedResourceEBRTest() throws ResourceManagementException {
		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(2);
		allocatedResourceProjection.setdefaultSkillId(1l);
		associateList.add(allocatedResourceProjection);
    
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(2l);
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");
		employeeList.add(employeeDto);
		
		List<ResourceRequirementDto> rRList = new ArrayList<>();
		ResourceRequirementDto rRDto = new ResourceRequirementDto();
		rRDto.setReqId(2);
		rRDto.setBillable(2.0);
		rRDto.setBillingEffortsPerHrs(1234.0);
		rRList.add(rRDto);
		
		List<Long> empIds = new ArrayList<>(); 
		empIds.add(52330l);
		Map <Long ,EmployeeDto> empMap = new HashMap<Long ,EmployeeDto>();
		empMap.put(52330L, employeeDto);
		
		List<TAssociateSkill> associateSkill = new ArrayList<TAssociateSkill>();
		TAssociateSkill tAssociateSkill = new TAssociateSkill();
		tAssociateSkill.setAssociateSkillId(1l);
		tAssociateSkill.setAssociateId(52330l);
		tAssociateSkill.setSkillId(1l);
		associateSkill.add(tAssociateSkill); 
		
		
		List<SkillTaxonomyDto> skillTaxanomyList = new ArrayList<SkillTaxonomyDto>();
		SkillTaxonomyDto skillTaxonomyDto = new SkillTaxonomyDto();
		skillTaxonomyDto.setEmployeeId(52330l);
		skillTaxonomyDto.setL4SkillId(1l);
		skillTaxonomyDto.setL4skillName("test");
		skillTaxanomyList.add(skillTaxonomyDto);

        
		List<Long> listOfIds = new ArrayList<Long>();
		listOfIds.add(1l);
		
		when(skillRepository.findByAssociateIdIn(Mockito.anyList())).thenReturn(associateSkill);
		when(skillRepository.getSkillListForEmployee(Mockito.anyLong())).thenReturn(listOfIds);
		when(adminServiceClient.getSkillFamilyByskillId(Mockito.anyList())).thenReturn(skillTaxanomyList);

		
		//ResourceTransferServiceImpl resourceTransferServiceImpl2 = new ResourceTransferServiceImpl();
		ResourceTransferServiceImpl resourceTransferServiceImpl1 = Mockito.spy(resourceTransferServiceImpl);
		  Mockito.doReturn(empMap).when(resourceTransferServiceImpl1).getPractiseDetails
		  (Mockito.anyList());
		 
		when(resourceTransferServiceImpl1.getPractiseDetails(Mockito.anyList())).thenReturn(empMap);
		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(tAssociateAllocationRepository.getAllocatedResourceToTransfer(Mockito.anyLong()))
				.thenReturn(associateList);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(rRList);
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
		//  when(tAssociateAllocationRepository.getAllocatedResourceListForTransfer(Mockito.anyLong(), Mockito.anyList(),
		//			Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(),
		//			Mockito.anyLong())).thenReturn(associateList);
		//when(allocatedResourceHelperClass.getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList())).thenReturn(associateList);
		when(allocatedResourceHelperClass.getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean())).thenReturn(associateList);
		when(adminServiceClient.getAssociatesDetailsbyEmpIds(Mockito.anyList())).thenReturn(employeeList);

		List<EmployeeDto> empList = resourceTransferServiceImpl.getAllocatedResource(123L);
		assertNotNull(empList);   
//		 verify(tAssociateAllocationRepository,times(1)).getAllocatedResourceListForTransfer(Mockito.anyLong(), Mockito.anyList(),
//					Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(),
//					Mockito.anyLong());
		//   verify(allocatedResourceHelperClass,times(1)).getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList());	
		   verify(allocatedResourceHelperClass,times(1)).getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean());	
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyLong());
	}
	 
	@Test
	public void getAllocatedResourceNonBillableTest() throws ResourceManagementException {
		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(3);
		associateList.add(allocatedResourceProjection);

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");

		List<ResourceRequirementDto> rRList = new ArrayList<>();
		ResourceRequirementDto rRDto = new ResourceRequirementDto();
		rRDto.setReqId(6L);
		rRDto.setBillable(2.0);
		rRDto.setBillingEffortsPerHrs(1234.0);
		rRList.add(rRDto);
		
		List<TAssociateSkill> associateSkill = new ArrayList<TAssociateSkill>();
		TAssociateSkill tAssociateSkill = new TAssociateSkill();
		tAssociateSkill.setAssociateSkillId(1l);
		tAssociateSkill.setAssociateId(52330l);
		tAssociateSkill.setSkillId(1l);
		associateSkill.add(tAssociateSkill); 
       
		List<Long> listOfIds = new ArrayList<Long>();
		listOfIds.add(1l);
		
		when(skillRepository.findByAssociateIdIn(Mockito.anyList())).thenReturn(associateSkill);
		when(skillRepository.getSkillListForEmployee(Mockito.anyLong())).thenReturn(listOfIds);
	

		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		when(tAssociateAllocationRepository.getAllocatedResourceToTransfer(Mockito.anyLong()))
				.thenReturn(associateList);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(rRList);
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
		//   when(tAssociateAllocationRepository.getAllocatedResourceListForTransfer(Mockito.anyLong(), Mockito.anyList(),
		//			Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(),
		//			Mockito.anyLong())).thenReturn(associateList);
	//	when(allocatedResourceHelperClass.getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList())).thenReturn(associateList);
		when(allocatedResourceHelperClass.getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean())).thenReturn(associateList);
		when(adminServiceClient.getAssociatesDetailsbyEmpIds(Mockito.anyList())).thenReturn(employeeList);

		List<EmployeeDto> empList = resourceTransferServiceImpl.getAllocatedResource(123L);
		assertNotNull(empList); 
	//	 verify(tAssociateAllocationRepository,times(1)).getAllocatedResourceListForTransfer(Mockito.anyLong(), Mockito.anyList(),
	//				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(),
	//				Mockito.anyLong());
	 //  verify(allocatedResourceHelperClass,times(1)).getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList());	
		   verify(allocatedResourceHelperClass,times(1)).getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean());	
		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyLong());
	}
	
	@Test
	public void getAllocatedResourceNullTest() throws ResourceManagementException {
		List<AllocatedResourceProjection> associateList = new ArrayList<>();
		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(null);
		associateList.add(allocatedResourceProjection);

		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");

		List<ResourceRequirementDto> rRList = new ArrayList<>();
		ResourceRequirementDto rRDto = new ResourceRequirementDto();
		rRDto.setReqId(6L);
		rRDto.setBillable(2.0);
		rRDto.setBillingEffortsPerHrs(1234.0);
		rRList.add(rRDto);
		
		List<TAssociateSkill> associateSkill = new ArrayList<TAssociateSkill>();
		TAssociateSkill tAssociateSkill = new TAssociateSkill();
		tAssociateSkill.setAssociateSkillId(1l);
		tAssociateSkill.setAssociateId(52330l);
		tAssociateSkill.setSkillId(1l);
		associateSkill.add(tAssociateSkill); 
       
		List<Long> listOfIds = new ArrayList<Long>();
		listOfIds.add(1l);
		
		when(skillRepository.findByAssociateIdIn(Mockito.anyList())).thenReturn(associateSkill);
		when(skillRepository.getSkillListForEmployee(Mockito.anyLong())).thenReturn(listOfIds);
	

		when(adminServiceClient.getAssociatesDetails(Mockito.anyList())).thenReturn(employeeList);
		//when(tAssociateAllocationRepository.getAllocatedResourceToTransfer(Mockito.anyLong()))
		//		.thenReturn(associateList);
		when(tAssociateAllocationRepository.getAllocatedResourceToTransfer(Mockito.anyLong())).thenReturn(associateList);
		when(bapSrvcClient.getResourceRequiremetList(Mockito.anyLong())).thenReturn(rRList);
		when(adminServiceClient.getAllModuleDetailsList(Mockito.anyString())).thenReturn(getModuleList());
	//	 when(tAssociateAllocationRepository.getAllocatedResourceListForTransfer(Mockito.anyLong(), Mockito.anyList(),
	//				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(),
	//				Mockito.anyLong())).thenReturn(associateList);
	//	when(allocatedResourceHelperClass.getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList())).thenReturn(associateList);
		when(allocatedResourceHelperClass.getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean())).thenReturn(associateList);
		when(adminServiceClient.getAssociatesDetailsbyEmpIds(Mockito.anyList())).thenReturn(employeeList);

   
		List<EmployeeDto> empList = resourceTransferServiceImpl.getAllocatedResource(123L);
		
		assertNotNull(empList);
		//verify(tAssociateAllocationRepository, times(1)).getAllocatedResourceToTransfer(Mockito.anyLong());
//		 verify(tAssociateAllocationRepository,times(1)).getAllocatedResourceListForTransfer(Mockito.anyLong(), Mockito.anyList(),
//					Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList(), Mockito.anyList(),
//					Mockito.anyLong());  
		//   verify(allocatedResourceHelperClass,times(1)).getAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList());	
		   verify(allocatedResourceHelperClass,times(1)).getNewAllocatedEmployeeList(Mockito.anyLong(), Mockito.anyList(),Mockito.anyBoolean());	

		verify(bapSrvcClient, times(1)).getResourceRequiremetList(Mockito.anyLong());
	}
	
	
	@Test
	public void getProjectFromSameOdc() throws ResourceManagementException {
		List<ProjectDto> projectList = new ArrayList<>();
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");
		projectList.add(projectDto);
		when(bapSrvcClient.getProjectWithinSameOdc(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(projectList);
		List<ProjectDto> newProjectList = resourceTransferServiceImpl.getProjectfromSameOdc(123l,123l,123l);
		assertNotNull(newProjectList);
		verify(bapSrvcClient, times(1)).getProjectWithinSameOdc(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
	}

	
	@Test
	public void getResourceFromIntransitProject() throws ResourceManagementException {
		
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");

		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");

		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(1);
		allocatedResourceProjection.setdefaultSkillId(1l);

		ResourceRequirementDto rRDto = new ResourceRequirementDto();
		rRDto.setReqId(2);
		rRDto.setBillable(2.0);
		rRDto.setBillingEffortsPerHrs(1234.0);
		rRDto.setRequirementRole("PM");
		rRDto.setResourceRequirementLocation("Pune");
		
		List<TAssociateSkill> associateSkill = new ArrayList<TAssociateSkill>();
		TAssociateSkill tAssociateSkill = new TAssociateSkill();
		tAssociateSkill.setAssociateSkillId(1l);
		tAssociateSkill.setAssociateId(52330l);
		tAssociateSkill.setSkillId(1l);
		associateSkill.add(tAssociateSkill); 
		
		List<SkillTaxonomyDto> skillTaxanomyList = new ArrayList<SkillTaxonomyDto>();
		SkillTaxonomyDto skillTaxonomyDto = new SkillTaxonomyDto();
		skillTaxonomyDto.setL4SkillId(1l);
		skillTaxonomyDto.setEmployeeId(5233l);
		skillTaxonomyDto.setL1PracticeId(1l);
		skillTaxonomyDto.setNicheSkillFlag(true);
		skillTaxanomyList.add(skillTaxonomyDto);
		 
		List<Long> listOfIds = new ArrayList<Long>();
		listOfIds.add(1l);
		
		  
		when(skillRepository.findByAssociateIdIn(Mockito.anyList())).thenReturn(associateSkill);
		when(skillRepository.getSkillListForEmployee(Mockito.anyLong())).thenReturn(listOfIds);
       when(adminServiceClient.getSkillFamilyByskillId(Mockito.anyList())).thenReturn(skillTaxanomyList);


		when(bapSrvcClient.getIntransitProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(tAssociateAllocationRepository.getIntrnsitProjectResource(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(allocatedResourceProjection);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(rRDto);
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(employeeDto);
		EmployeeDto empDto = resourceTransferServiceImpl.getResourceFromIntransitProject(123l, "abc");
		assertNotNull(empDto);
		verify(bapSrvcClient,times(1)).getIntransitProjectId(Mockito.anyLong());
		verify(tAssociateAllocationRepository,times(1)).getIntrnsitProjectResource(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong());
		verify(bapSrvcClient,times(1)).getRequirementDetailByReqId(Mockito.anyLong());
		
	}  
	
	@Test
	public void getResourceFromIntransitProjectNull() throws ResourceManagementException {
		
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");

		when(bapSrvcClient.getIntransitProjectId(Mockito.anyLong())).thenReturn(null);
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);

		when(tAssociateAllocationRepository.getIntrnsitProjectResource(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(null);
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(null);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(null);
		EmployeeDto empDto = resourceTransferServiceImpl.getResourceFromIntransitProject(123l, "123");
		assertNull(empDto);
		
		
	}
	
	@Test
	public void getResourceFromIntransitProjectProjectNull() throws ResourceManagementException {

		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");

		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(employeeDto);
		when(bapSrvcClient.getIntransitProjectId(Mockito.anyLong())).thenReturn(null);
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
		when(tAssociateAllocationRepository.getIntrnsitProjectResource(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
				.thenReturn(null);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(null);
		EmployeeDto empDto = resourceTransferServiceImpl.getResourceFromIntransitProject(123l,"123");

	 	assertNull(empDto);

	}
	
	@Test
	public void getResourceFromIntransitProjectionNull() throws ResourceManagementException {
		
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setAssociateAllocationId(1L);
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("Akshay Tiwari");
		employeeDto.setBillingStatus("Billiable");
		employeeDto.setEmployeeLocation("Pune");
		

		ProjectionFactory factory = new SpelAwareProxyProjectionFactory();
		AllocatedResourceProjection allocatedResourceProjection = factory
				.createProjection(AllocatedResourceProjection.class);
		allocatedResourceProjection.setAssociateAllocationId(2l);
		allocatedResourceProjection.setRequirementId(2);
		allocatedResourceProjection.setEmployeeId(52330l);
		allocatedResourceProjection.setFtePercent(20l);
		allocatedResourceProjection.setProjectId(13l);
		allocatedResourceProjection.setBillableStatusId(1);

		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(12345);
		projectDto.setProjectName("TestProject");
		List<TAssociateSkill> associateSkill = new ArrayList<TAssociateSkill>();
		TAssociateSkill tAssociateSkill = new TAssociateSkill();
		tAssociateSkill.setAssociateSkillId(1l);
		tAssociateSkill.setAssociateId(52330l);
		tAssociateSkill.setSkillId(1l);
		associateSkill.add(tAssociateSkill); 
       
		List<Long> listOfIds = new ArrayList<Long>();
		listOfIds.add(1l);
		
		
		when(skillRepository.findByAssociateIdIn(Mockito.anyList())).thenReturn(associateSkill);
		when(skillRepository.getSkillListForEmployee(Mockito.anyLong())).thenReturn(listOfIds);
	
		when(adminServiceClient.getEmployeeByNameOrId(Mockito.anyString())).thenReturn(employeeDto);
		when(bapSrvcClient.getIntransitProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString())).thenReturn(1l);
		when(tAssociateAllocationRepository.getIntrnsitProjectResource(Mockito.anyLong(), Mockito.anyLong(),Mockito.anyLong(),Mockito.anyLong()))
		.thenReturn(allocatedResourceProjection);
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(null);
		EmployeeDto empDto = resourceTransferServiceImpl.getResourceFromIntransitProject(123l, "ABC");
		assertNotNull(empDto);
		
	}

	
	@Test
	public void approveRTApprovalForAllocReqTest() throws ResourceManagementException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
		
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);
		
		List<RTResourceDto> rtResourceDtoList = new ArrayList<>();
		RTResourceDto rtResourceDto = new RTResourceDto();
		rtResourceDto.setEmpId(111l);
		RTProjectDto rtprojectDto = new RTProjectDto();
		rtprojectDto.setAllocationDate(new Date());
		rtResourceDto.setTargetProjectDetails(rtprojectDto);
		rtResourceDtoList.add(rtResourceDto);
		rmApprovalInputDtoObj.setResourceList(rtResourceDtoList);
		rtResourceDto.setTargetProjectDetails(rtprojectDto);
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMDA");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(1L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		rsrcWrkflwObj.setStatusId(0l);
		when(tAssociateAllocationRepository.getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(resourceWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		when(adminServiceClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminServiceClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);
		doNothing().when(sendMailHelperServiceObj).sendEmailForApprovalConfirmation(Mockito.any(), Mockito.anyString());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		resourceTransferServiceImpl.approveOrRejectRTApproval(RMApprovalInputDtlsList);
		verify(tAssociateAllocationRepository, times(1)).getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong());
	}

	@Test
	public void approveRTApprovalForAllocReqRoleIdZeroTest() throws ResourceManagementException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		rmApprovalInputDtoObj.setCurrentProjectId(2l);
		rmApprovalInputDtoObj.setCurrentRequirementId(10l);
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);

		List<RTResourceDto> rtResourceDtoList = new ArrayList<>();
		RTResourceDto rtResourceDto = new RTResourceDto();
		rtResourceDto.setEmpId(111l);
		
		RTProjectDto rtTargetprojectDto = new RTProjectDto();
		rtTargetprojectDto.setAllocationDate(new Date());
		rtTargetprojectDto.setProjectUtilization(100l);
		rtTargetprojectDto.setRequirementId(10l);
		rtResourceDto.setTargetProjectDetails(rtTargetprojectDto);
		
		RTProjectDto rtCurrentProjectDto = new RTProjectDto();
		rtCurrentProjectDto.setAllocationDate(new Date());
		rtCurrentProjectDto.setProjectUtilization(100l);
		rtCurrentProjectDto.setRequirementId(12l);
		rtResourceDto.setCurrentProjectDetails(rtCurrentProjectDto);
		
		rtResourceDtoList.add(rtResourceDto);
		rmApprovalInputDtoObj.setResourceList(rtResourceDtoList);

		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		tAssociateAllocationObj.setActualAllocationStartDate(new Date());
        TAssociateProject associateProject = new TAssociateProject();
		associateProject.setAssociateProjectId(1l);
		associateProject.setEmployeeId(111l);
		associateProject.setLastUpdatedDate(new Date());
		tAssociateAllocationObj.setTAssociateProject(associateProject);
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMT");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(0L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(0L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		rsrcWrkflwObj.setStatusId(0l);
		ModuleStatusDto statusDto = new ModuleStatusDto();
		statusDto.setModuleId(12l);
		statusDto.setAction("TRANSFER");
		statusDto.setParentModule("RESOURCE_MANAGEMENT");
		statusDto.setSubModule("RESOURCE_TRANSFER");
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);


		when(tAssociateAllocationRepository.getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(resourceWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		when(adminServiceClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminServiceClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		doNothing().when(sendMailHelperServiceObj).sendEmailForApprovalConfirmation(Mockito.any(), Mockito.anyString());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(statusDto.getModuleId());
		doNothing().when(tAssociateAllocationRepository).deactivateResourceAllocation(Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),Mockito.any(), Mockito.anyLong());
		when(tAssociateAllocationRepository.getPreviousDataByTransactionHistoryId(Mockito.anyList()))
				.thenReturn(rAllocationDtlsListObj);
		doNothing().when(resourceManagementServiceImpl).releaseAllocatedBudgetForAlloc(Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong());
		when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
		when(tAssociateAllocationRepository.getCurrentProjectDataForTransfer(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),Mockito.anyList(),Mockito.anyLong(),Mockito.anyList())).thenReturn(tAssociateAllocationObj);
		doNothing().when(sendMailHelperServiceObj).sendEmailForFinalApprovalConfirmation(Mockito.any(),
				Mockito.anyString(), Mockito.anyLong());
		resourceTransferServiceImpl.approveOrRejectRTApproval(RMApprovalInputDtlsList);
		verify(tAssociateAllocationRepository, times(1)).getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong());
	}

	
	@Test
	public void approveRTApprovalForUnEqualProjectFteTest() throws ResourceManagementException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("APPROVED");
		rmApprovalInputDtoObj.setCurrentProjectId(2l);
		rmApprovalInputDtoObj.setCurrentRequirementId(10l);
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);

		List<RTResourceDto> rtResourceDtoList = new ArrayList<>();
		RTResourceDto rtResourceDto = new RTResourceDto();
		rtResourceDto.setEmpId(111l);
		
		RTProjectDto rtTargetprojectDto = new RTProjectDto();
		rtTargetprojectDto.setAllocationDate(new Date());
		rtTargetprojectDto.setProjectUtilization(70l);
		rtTargetprojectDto.setRequirementId(10l);
		rtResourceDto.setTargetProjectDetails(rtTargetprojectDto);
		
		RTProjectDto rtCurrentProjectDto = new RTProjectDto();
		rtCurrentProjectDto.setAllocationDate(new Date());
		rtCurrentProjectDto.setProjectUtilization(100l);
		rtCurrentProjectDto.setRequirementId(12l);
		rtResourceDto.setCurrentProjectDetails(rtCurrentProjectDto);
		
		rtResourceDtoList.add(rtResourceDto);
		rmApprovalInputDtoObj.setResourceList(rtResourceDtoList);

		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		tAssociateAllocationObj.setActualAllocationStartDate(new Date());
		TAssociateProject associateProject = new TAssociateProject();
		associateProject.setAssociateProjectId(1l);
		associateProject.setEmployeeId(111l);
		associateProject.setLastUpdatedDate(new Date());
		tAssociateAllocationObj.setTAssociateProject(associateProject);
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMT");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(0L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(0L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		rsrcWrkflwObj.setStatusId(0l);
		ModuleStatusDto statusDto = new ModuleStatusDto();
		statusDto.setModuleId(12l);
		statusDto.setAction("TRANSFER");
		statusDto.setParentModule("RESOURCE_MANAGEMENT");
		statusDto.setSubModule("RESOURCE_TRANSFER");
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);


		when(tAssociateAllocationRepository.getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(resourceWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		when(adminServiceClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminServiceClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		doNothing().when(sendMailHelperServiceObj).sendEmailForApprovalConfirmation(Mockito.any(), Mockito.anyString());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		when(resourceManagementServiceImpl.getModuleStatusId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(statusDto.getModuleId());
		doNothing().when(tAssociateAllocationRepository).deactivateResourceAllocation(Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),Mockito.any(), Mockito.anyLong());
		when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
		when(tAssociateAllocationRepository.getPreviousDataByTransactionHistoryId(Mockito.anyList()))
				.thenReturn(rAllocationDtlsListObj);
		doNothing().when(resourceManagementServiceImpl).releaseAllocatedBudgetForAlloc(Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong());
		when(tAssociateAllocationRepository.getCurrentProjectDataForTransfer(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),Mockito.anyList(),Mockito.anyLong(),Mockito.anyList())).thenReturn(tAssociateAllocationObj);
		doNothing().when(sendMailHelperServiceObj).sendEmailForFinalApprovalConfirmation(Mockito.any(),
				Mockito.anyString(), Mockito.anyLong());
		resourceTransferServiceImpl.approveOrRejectRTApproval(RMApprovalInputDtlsList);
		verify(tAssociateAllocationRepository, times(1)).getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong()); 
	}
	
	
	
	@Test
	public void rejectRMApprovalForAllocReqTest() throws ResourceManagementException, ParseException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("REJECTED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		
		List<RTResourceDto> rtResourceDtoList = new ArrayList<>();
		RTResourceDto rtResourceDto = new RTResourceDto();
		rtResourceDto.setEmpId(111l);
		RTProjectDto rtprojectDto = new RTProjectDto();
		rtprojectDto.setAllocationDate(new Date());
		rtResourceDto.setTargetProjectDetails(rtprojectDto);
		rtResourceDtoList.add(rtResourceDto);
		rmApprovalInputDtoObj.setResourceList(rtResourceDtoList);
		rtResourceDto.setTargetProjectDetails(rtprojectDto);
		
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		tAssociateAllocationObj.setFtePercent(100.00);
		tAssociateAllocationObj.setActualAllocationStartDate(new Date());
		tAssociateAllocationObj.setActualAllocationEndDate(new Date());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		tAssociateAllocationObj.setActualAllocationEndDate(dateFormat.parse(("2020-07-30")));
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMDA");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(1L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(1L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		rsrcWrkflwObj.setStatusId(0l);
		
		ProjectDto projectDto = new ProjectDto();
		projectDto.setProjectId(1l);
		projectDto.setExecutionLocationId(2l);
				
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryId(1l);
		countryDto.setCountryName(ResourceManagementConstant.SOUTH_AFRICA);
		
		when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(getProjectBudgetDto());
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateAllocationRepository.getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(resourceWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(adminServiceClient.getProjectbyProjectId(Mockito.anyLong())).thenReturn(projectDto);
		when(adminServiceClient.getCountryByLocationId(Mockito.anyLong())).thenReturn(countryDto);

		doNothing().when(resourceAllocationServiceImpl).updateBudget(Mockito.any());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		resourceManagementServiceImpl.callSendEmailUtility(usrDtlsMap, 1);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		resourceTransferServiceImpl.approveOrRejectRTApproval(RMApprovalInputDtlsList);
		verify(tAssociateAllocationRepository, times(1)).getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong());
	}

	@Test
	public void rejectRMApprovalForAllocReqRoleNullTest() throws ResourceManagementException, ParseException {
		List<RMApprovalInputDto> RMApprovalInputDtlsList = new ArrayList<>();
		RMApprovalInputDto rmApprovalInputDtoObj = new RMApprovalInputDto();
		rmApprovalInputDtoObj.setProjectId(1);
		rmApprovalInputDtoObj.setRequirementId(1);
		rmApprovalInputDtoObj.setRequestType(ResourceManagementConstant.RM_TRANSFER_REQUEST_CODE);
		rmApprovalInputDtoObj.setApproverAction("REJECTED");
		List<Long> resourceIdList = new ArrayList<>();
		resourceIdList.add(111L);
		rmApprovalInputDtoObj.setEmployeeIdList(resourceIdList);
		rmApprovalInputDtoObj.setRoleId(1);
		rmApprovalInputDtoObj.setUserId(1);
		
		List<RTResourceDto> rtResourceDtoList = new ArrayList<>();
		RTResourceDto rtResourceDto = new RTResourceDto();
		rtResourceDto.setEmpId(111l);
		RTProjectDto rtprojectDto = new RTProjectDto();
		rtprojectDto.setAllocationDate(new Date());
		rtResourceDto.setTargetProjectDetails(rtprojectDto);
		rtResourceDtoList.add(rtResourceDto);
		rmApprovalInputDtoObj.setResourceList(rtResourceDtoList);
		rtResourceDto.setTargetProjectDetails(rtprojectDto);
		
		RMApprovalInputDtlsList.add(rmApprovalInputDtoObj);
		List<Long> statusIdList = new ArrayList<Long>();
		statusIdList.add(3L);
		statusIdList.add(4L);
		List<TAssociateAllocation> rAllocationDtlsListObj = new ArrayList<>();
		TAssociateAllocation tAssociateAllocationObj = new TAssociateAllocation();
		tAssociateAllocationObj.setAssociateAllocationId(1L);
		tAssociateAllocationObj.setFtePercent(100.00);
		tAssociateAllocationObj.setActualAllocationStartDate(new Date());
		tAssociateAllocationObj.setActualAllocationEndDate(new Date());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		tAssociateAllocationObj.setActualAllocationEndDate(dateFormat.parse(("2020-07-30")));
		rAllocationDtlsListObj.add(tAssociateAllocationObj);
		ModuleStatusDto moduleStatusDto = new ModuleStatusDto();
		moduleStatusDto.setModuleId(1L);
		ModuleStatusDto moduleDto = new ModuleStatusDto();
		moduleDto.setModuleCode("RMDA");
		ResourceWorkflow rsrcWrkflwObj = new ResourceWorkflow();
		rsrcWrkflwObj.setCurrentRoleId(0L);
		rsrcWrkflwObj.setCurrentUserId(1L);
		rsrcWrkflwObj.setNextRoleId(0L);
		rsrcWrkflwObj.setResourceWrkflwId(1L);
		rsrcWrkflwObj.setNextUserId(1L);
		rsrcWrkflwObj.setWrkflwTypeId(1L);
		rsrcWrkflwObj.setWrkflwDefinitionId(1L);
		rsrcWrkflwObj.setStatusId(0l);
		ModuleStatusDto statusDto = new ModuleStatusDto();
		statusDto.setModuleId(12l);
		statusDto.setAction("REJECTED");
		statusDto.setParentModule("RESOURCE_MANAGEMENT");
		statusDto.setSubModule("RESOURCE_ALLOCATION");

		when(allocatedResourceHelperClass.getallModuleData()).thenReturn(getAllNewModuleList());
		when(budgetControlServiceClient.getProjectMonthlyBudgetsDetails(Mockito.anyLong()))
				.thenReturn(getProjectBudgetDto());
		when(bapSrvcClient.getRequirementDetailByReqId(Mockito.anyLong())).thenReturn(getResourceRequirementDto());
		when(tAssociateAllocationRepository.getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong())).thenReturn(rAllocationDtlsListObj);
		when(adminServiceClient.getModuleStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(moduleStatusDto);
		when(adminServiceClient.getModuleDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(moduleDto);
		when(resourceWorkflowRepository.getRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getRowDataOfDefaultStatus(Mockito.anyLong(), Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong())).thenReturn(rsrcWrkflwObj);
		when(resourceWorkflowRepository.getPreviousRowData(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(rsrcWrkflwObj);
		doNothing().when(resourceAllocationServiceImpl).updateBudget(Mockito.any());
		Map<String, List<Long>> usrDtlsMap = new HashMap<>();
		List<Long> userIdList = new ArrayList<>();
		userIdList.add(1L);
		usrDtlsMap.put("TO", userIdList);
		usrDtlsMap.put("Cc", userIdList);
		resourceManagementServiceImpl.callSendEmailUtility(usrDtlsMap, 1);
		doNothing().when(sendMailUtil).sendMail(Mockito.anyObject());
		doNothing().when(tAssociateAllocationRepository).updateStatusAndEffectiveEndDate(Mockito.anyLong(),
				Mockito.anyList(), Mockito.any(), Mockito.anyLong(), Mockito.any());
		doNothing().when(resourceManagementServiceImpl).releaseAllocatedBudgetForAlloc(Mockito.anyList(),
				Mockito.anyLong(), Mockito.anyLong());
		doNothing().when(resourceManagementServiceImpl).updateProjectStatus(Mockito.anyLong());
		resourceTransferServiceImpl.approveOrRejectRTApproval(RMApprovalInputDtlsList);
		verify(tAssociateAllocationRepository, times(1)).getRAllocationDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList(), Mockito.anyLong(),Mockito.anyLong());
	}
	private ResourceRequirementDto getResourceRequirementDto() {
		ResourceRequirementDto resourceRequirementDto = new ResourceRequirementDto();
		resourceRequirementDto.setBillingEffortsPerHrs(10);
		resourceRequirementDto.setShore("onsite");
		return resourceRequirementDto;
	}

	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	private List<ProjectBudgetDto> getProjectBudgetDto() throws ParseException {
		List<ProjectBudgetDto> projectBudget = new ArrayList<>();
		ProjectBudgetDto projectBudgetDto1 = new ProjectBudgetDto();
		projectBudgetDto1.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto1.setBudgetCurrency(5.0);
		projectBudgetDto1.setMonth("2020-06");
		projectBudgetDto1.setAvailableBudget(200000.00);
		projectBudgetDto1.setConsumedBudget(10.00);

		projectBudget.add(projectBudgetDto1);

		ProjectBudgetDto projectBudgetDto2 = new ProjectBudgetDto();
		projectBudgetDto2.setProjectStartDate(dateFormat.parse("2020-04-01"));
		projectBudgetDto2.setBudgetCurrency(5.0);
		projectBudgetDto2.setMonth("2020-07");
		projectBudgetDto2.setAvailableBudget(300000.00);
		projectBudgetDto2.setConsumedBudget(10d);
		projectBudget.add(projectBudgetDto2);
		return projectBudget;
	}
	
	
	
	public List<ModuleStatusDto> getModuleList() {
		/*
		 * System.out.println(projectId);
		 * System.out.println(wfStatusIdForAllocationOrTransferApproved);
		 * System.out.println(statusIdForAllocationActive); // null
		 * System.out.println(requirementIds);
		 * System.out.println(statusIdForDeAllocationDeActive); // null
		 * System.out.println(wfStatusIdForSavedOrSubmittedForDeallocation);
		 * System.out.println(wfStatusIdForSavedOrSubmittedForTransfer);
		 * System.out.println(wfIdForSubmittedForExtension); // null
		 */
		List<ModuleStatusDto> moduleList = new ArrayList<>();
		ModuleStatusDto moduleStatusDtoAllocation = new ModuleStatusDto();
		moduleStatusDtoAllocation.setModuleId(1l);
		moduleStatusDtoAllocation.setModuleCode("RM");
		moduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setAction("APPROVED");
		moduleList.add(moduleStatusDtoAllocation);
		ModuleStatusDto newmoduleStatus2DtoAllocation = new ModuleStatusDto();
		newmoduleStatus2DtoAllocation.setModuleId(2l);
		newmoduleStatus2DtoAllocation.setModuleCode("RM");
		newmoduleStatus2DtoAllocation.setSubModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setParentModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setAction("DEACTIVE");
		moduleList.add(newmoduleStatus2DtoAllocation);
		ModuleStatusDto newmoduleStatusDtoAllocation = new ModuleStatusDto();

		newmoduleStatusDtoAllocation.setModuleId(2l);
		newmoduleStatusDtoAllocation.setModuleCode("RM");
		newmoduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setAction("ACTIVE");
		moduleList.add(newmoduleStatusDtoAllocation);

		ModuleStatusDto moduleStatusDtoTransfer = new ModuleStatusDto();
		moduleStatusDtoTransfer.setModuleId(1l);
		moduleStatusDtoTransfer.setModuleCode("RM");
		moduleStatusDtoTransfer.setSubModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setAction("APPROVED");
		moduleList.add(moduleStatusDtoTransfer);

		ModuleStatusDto moduleStatusDtoDeallocationSved = new ModuleStatusDto();
		moduleStatusDtoDeallocationSved.setModuleId(1l);
		moduleStatusDtoDeallocationSved.setModuleCode("RM");
		moduleStatusDtoDeallocationSved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSved.setAction(ResourceManagementConstant.DEALLOCATION_ACTION_SAVED);
		moduleList.add(moduleStatusDtoDeallocationSved);
		ModuleStatusDto moduleStatusDtoDeallocationSubmitted = new ModuleStatusDto();
		moduleStatusDtoDeallocationSubmitted.setModuleId(1l);
		moduleStatusDtoDeallocationSubmitted.setModuleCode("RM");
		moduleStatusDtoDeallocationSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSubmitted.setAction(ResourceManagementConstant.SUBMITTED);
		moduleList.add(moduleStatusDtoDeallocationSubmitted);
		ModuleStatusDto moduleStatusDtoDeallocationApproved = new ModuleStatusDto();
		moduleStatusDtoDeallocationApproved.setModuleId(1l);
		moduleStatusDtoDeallocationApproved.setModuleCode("RM");
		moduleStatusDtoDeallocationApproved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationApproved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationApproved.setAction(ResourceManagementConstant.APPROVED_ACTION);
		moduleList.add(moduleStatusDtoDeallocationApproved);
		ModuleStatusDto moduleStatusDtoDeallocationRejected = new ModuleStatusDto();
		moduleStatusDtoDeallocationRejected.setModuleId(1l);
		moduleStatusDtoDeallocationRejected.setModuleCode("RM");
		moduleStatusDtoDeallocationRejected.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationRejected.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationRejected.setAction(ResourceManagementConstant.REJECTED);
		moduleList.add(moduleStatusDtoDeallocationRejected);

		ModuleStatusDto moduleStatusDtoTansferSved = new ModuleStatusDto();
		moduleStatusDtoTansferSved.setModuleId(1l);
		moduleStatusDtoTansferSved.setModuleCode("RM");
		moduleStatusDtoTansferSved.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTansferSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTansferSved.setAction(ResourceManagementConstant.TRANSFER_ACTION_SAVED);
		moduleList.add(moduleStatusDtoTansferSved);
		ModuleStatusDto moduleStatusDtoTransferSubmitted = new ModuleStatusDto();
		moduleStatusDtoTransferSubmitted.setModuleId(1l);
		moduleStatusDtoTransferSubmitted.setModuleCode("RM");
		moduleStatusDtoTransferSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTransferSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransferSubmitted.setAction(ResourceManagementConstant.SUBMITTED);
		moduleList.add(moduleStatusDtoTransferSubmitted);
		ModuleStatusDto moduleStatusDtoTransferRejected = new ModuleStatusDto();
		moduleStatusDtoTransferRejected.setModuleId(1l);
		moduleStatusDtoTransferRejected.setModuleCode("RM");
		moduleStatusDtoTransferRejected.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTransferRejected.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransferRejected.setAction(ResourceManagementConstant.REJECTED);
		moduleList.add(moduleStatusDtoTransferRejected);
		
		ModuleStatusDto moduleStatusDtoExtension = new ModuleStatusDto();
		moduleStatusDtoExtension.setModuleId(1l);
		moduleStatusDtoExtension.setModuleCode("RM");
		moduleStatusDtoExtension.setSubModule("RESOURCE_EXTENSION");
		moduleStatusDtoExtension.setParentModule("RESOURCE_EXTENSION");
		moduleStatusDtoExtension.setAction("SUBMITTED FOR EXTENSION");
		moduleList.add(moduleStatusDtoExtension);

		moduleList.add(moduleStatusDtoTransferSubmitted);

		return moduleList;
	}

	
	public HashBasedTable<String, String, Long> getAllNewModuleList() {
		 
		List<ModuleStatusDto> moduleList = new ArrayList<>();
		ModuleStatusDto moduleStatusDtoAllocation = new ModuleStatusDto();
		moduleStatusDtoAllocation.setModuleId(1l);
		moduleStatusDtoAllocation.setModuleStatusId(1l);
		moduleStatusDtoAllocation.setModuleCode("RM");
		moduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocation.setAction("APPROVED");
		moduleList.add(moduleStatusDtoAllocation);
		
		ModuleStatusDto moduleStatusDtoAllocationDeactive = new ModuleStatusDto();
		moduleStatusDtoAllocationDeactive.setModuleId(1l);
		moduleStatusDtoAllocationDeactive.setModuleStatusId(1l);
		moduleStatusDtoAllocationDeactive.setModuleCode("RM");
		moduleStatusDtoAllocationDeactive.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationDeactive.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationDeactive.setAction("DEACTIVATE");
		moduleList.add(moduleStatusDtoAllocationDeactive);
		
		ModuleStatusDto moduleStatusDtoAllocationSAVED = new ModuleStatusDto();
		moduleStatusDtoAllocationSAVED.setModuleId(1l);
		moduleStatusDtoAllocationSAVED.setModuleStatusId(1l);
		moduleStatusDtoAllocationSAVED.setModuleCode("RM");
		moduleStatusDtoAllocationSAVED.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSAVED.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSAVED.setAction("SAVED");
		moduleList.add(moduleStatusDtoAllocationSAVED);
		
		ModuleStatusDto moduleStatusDtoAllocationSUBMITTED = new ModuleStatusDto();
		moduleStatusDtoAllocationSUBMITTED.setModuleId(1l);
		moduleStatusDtoAllocationSUBMITTED.setModuleStatusId(1l);
		moduleStatusDtoAllocationSUBMITTED.setModuleCode("RM");
		moduleStatusDtoAllocationSUBMITTED.setSubModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSUBMITTED.setParentModule("RESOURCE_ALLOCATION");
		moduleStatusDtoAllocationSUBMITTED.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoAllocationSUBMITTED);
	
		
		ModuleStatusDto newmoduleStatus2DtoAllocation = new ModuleStatusDto();
		newmoduleStatus2DtoAllocation.setModuleId(2l);
		newmoduleStatus2DtoAllocation.setModuleStatusId(2l);
		newmoduleStatus2DtoAllocation.setModuleCode("RM");
		newmoduleStatus2DtoAllocation.setSubModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setParentModule("RESOURCE_DEALLOCATION");
		newmoduleStatus2DtoAllocation.setAction("DEACTIVATE");
		moduleList.add(newmoduleStatus2DtoAllocation);
		ModuleStatusDto newmoduleStatusDtoAllocation = new ModuleStatusDto();

		newmoduleStatusDtoAllocation.setModuleId(2l);
		newmoduleStatusDtoAllocation.setModuleStatusId(1l);
		newmoduleStatusDtoAllocation.setModuleCode("RM");
		newmoduleStatusDtoAllocation.setSubModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setParentModule("RESOURCE_ALLOCATION");
		newmoduleStatusDtoAllocation.setAction("ACTIVATE");
		moduleList.add(newmoduleStatusDtoAllocation);

		ModuleStatusDto moduleStatusDtoTransfer = new ModuleStatusDto();
		moduleStatusDtoTransfer.setModuleId(1l);
		moduleStatusDtoTransfer.setModuleStatusId(1l);
		moduleStatusDtoTransfer.setModuleCode("RM");
		moduleStatusDtoTransfer.setSubModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransfer.setAction("APPROVED");
		moduleList.add(moduleStatusDtoTransfer);

		ModuleStatusDto moduleStatusDtoDeallocationSved = new ModuleStatusDto();
		moduleStatusDtoDeallocationSved.setModuleId(1l);
		moduleStatusDtoDeallocationSved.setModuleStatusId(1l);
		
		moduleStatusDtoDeallocationSved.setModuleCode("RM");
		moduleStatusDtoDeallocationSved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSved.setAction("SAVED");
		moduleList.add(moduleStatusDtoDeallocationSved);
		
		
		
		
		ModuleStatusDto moduleStatusDtoDeallocationSubmitted = new ModuleStatusDto();
		moduleStatusDtoDeallocationSubmitted.setModuleId(1l);
		moduleStatusDtoDeallocationSubmitted.setModuleStatusId(1l);
		moduleStatusDtoDeallocationSubmitted.setModuleCode("RM");
		moduleStatusDtoDeallocationSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationSubmitted.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoDeallocationSubmitted);
		ModuleStatusDto moduleStatusDtoDeallocationApproved = new ModuleStatusDto();
		moduleStatusDtoDeallocationApproved.setModuleId(1l);
		moduleStatusDtoDeallocationApproved.setModuleCode("RM");
		moduleStatusDtoDeallocationApproved.setModuleStatusId(1l);
		moduleStatusDtoDeallocationApproved.setSubModule(ResourceManagementConstant.RESOURCE_DEALLOCATION);
		moduleStatusDtoDeallocationApproved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoDeallocationApproved.setAction("APPROVED");
		moduleList.add(moduleStatusDtoDeallocationApproved);

		ModuleStatusDto moduleStatusDtoTansferSved = new ModuleStatusDto();
		moduleStatusDtoTansferSved.setModuleId(1l);  
		moduleStatusDtoTansferSved.setModuleStatusId(1l);
		moduleStatusDtoTansferSved.setModuleCode("RM");
		moduleStatusDtoTansferSved.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTansferSved.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTansferSved.setAction("SAVED");
		moduleList.add(moduleStatusDtoTansferSved);
		
		ModuleStatusDto moduleStatusDtoTansferRejected = new ModuleStatusDto();
		moduleStatusDtoTansferRejected.setModuleId(1l);  
		moduleStatusDtoTansferRejected.setModuleStatusId(1l);
		moduleStatusDtoTansferRejected.setModuleCode("RM");
		moduleStatusDtoTansferRejected.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTansferRejected.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTansferRejected.setAction("REJECTED");
		moduleList.add(moduleStatusDtoTansferRejected);
		
		ModuleStatusDto moduleStatusDtoTransferSubmitted = new ModuleStatusDto();
		moduleStatusDtoTransferSubmitted.setModuleId(1l);
		moduleStatusDtoTransferSubmitted.setModuleStatusId(1l);
		moduleStatusDtoTransferSubmitted.setModuleCode("RM");
		moduleStatusDtoTransferSubmitted.setSubModule(ResourceManagementConstant.RESOURCE_TRANSFER);
		moduleStatusDtoTransferSubmitted.setParentModule("RESOURCE_TRANSFER");
		moduleStatusDtoTransferSubmitted.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoTansferSved);
		ModuleStatusDto moduleStatusDtoExtension = new ModuleStatusDto();
		moduleStatusDtoExtension.setModuleId(1l);
		moduleStatusDtoExtension.setModuleStatusId(1l);    
		moduleStatusDtoExtension.setModuleCode("RM");
		moduleStatusDtoExtension.setSubModule("RESOURCE_EXTENSION");
		moduleStatusDtoExtension.setParentModule("RESOURCE_EXTENSION"); 
		moduleStatusDtoExtension.setAction("SUBMITTED");
		moduleList.add(moduleStatusDtoExtension);
		
		ModuleStatusDto moduleDeallocRejected = new ModuleStatusDto();
		moduleDeallocRejected.setModuleId(1l);
		moduleDeallocRejected.setModuleStatusId(1l);    
		moduleDeallocRejected.setModuleCode("RM");
		moduleDeallocRejected.setSubModule("RESOURCE_DEALLOCATION");
		moduleDeallocRejected.setParentModule("RESOURCE_DEALLOCATION"); 
		moduleDeallocRejected.setAction("REJECTED");
		moduleList.add(moduleDeallocRejected);

		moduleList.add(moduleStatusDtoTransferSubmitted);
		
		HashBasedTable<String, String, Long> table = HashBasedTable.create();
		for (ModuleStatusDto temp : moduleList) {
			table.put(temp.getSubModule(), temp.getAction(), temp.getModuleStatusId());
		}
		return table;

	}   
	

}
