package com.zensar.zenfulcrum.resourcrmanagement.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zensar.zenfulcrum.resourcemanagement.controller.ResourceAllocationController;
import com.zensar.zenfulcrum.resourcemanagement.dto.EmployeeDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.RMResponseDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.SkillTaxonomyDto;
import com.zensar.zenfulcrum.resourcemanagement.dto.TAssociateProjectDto;
import com.zensar.zenfulcrum.resourcemanagement.exception.ResourceManagementException;
import com.zensar.zenfulcrum.resourcemanagement.service.ResourceAllocationService;
import com.zensar.zenfulcrum.resourcemanagement.util.ResourceManagementConstant;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class ResourceAllocationControllerTest {

	@InjectMocks
	private ResourceAllocationController resourceAllocationController;

	@Mock
	private ResourceAllocationService resourceAllocationService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getEarmarkedAssociatesTest() throws ResourceManagementException {
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(1l);
		employeeDto.setEmployeeName("Test");
		List<EmployeeDto> employeesObj = new ArrayList<>();
		employeesObj.add(employeeDto);
		when(resourceAllocationService.getEarmarkedAssociates(Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(employeesObj);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceAllocationController.getEarmarkedAssociates(123l, 1l);
		assertNotNull(responseEntityObj);
		assertEquals(200, responseEntityObj.getStatusCodeValue());
		verify(resourceAllocationService, times(1)).getEarmarkedAssociates(Mockito.anyLong(), Mockito.anyLong());
	}

	@Test
	public void getEarmarkedAssociatesForNoContent() throws ResourceManagementException {
		when(resourceAllocationService.getEarmarkedAssociates(Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceAllocationController.getEarmarkedAssociates(123l, 1l);
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceAllocationService, times(1)).getEarmarkedAssociates(Mockito.anyLong(), Mockito.anyLong());
	}

	@Test
	public void saveResourceAllocationsTest() throws ResourceManagementException, ParseException {
		TAssociateProjectDto allocationDto = new TAssociateProjectDto();

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(allocationDto);
		doNothing().when(resourceAllocationService).saveResourceAllocations(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.any());
		ResponseEntity<RMResponseDto> responseEntityObj = resourceAllocationController.saveResourceAllocations(123l,
				123l, allocationDtoList);
		assertNotNull(responseEntityObj);
		assertEquals(201, responseEntityObj.getStatusCodeValue());
		verify(resourceAllocationService, times(1)).saveResourceAllocations(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.any());
	}

	@Test
	public void saveResourceAllocationsTestNull() throws ResourceManagementException, ParseException {
		ResponseEntity<RMResponseDto> responseEntityObj = resourceAllocationController.saveResourceAllocations(123l,
				123l, null);
		assertEquals(400, responseEntityObj.getStatusCodeValue());
	}

	@Test
	public void getAllocationDetailTest() throws ResourceManagementException {
		List<EmployeeDto> employeeList = new ArrayList<>();
		EmployeeDto dto = new EmployeeDto();
		dto.setEmployeeId(52330l);
		dto.setEmployeeName("Akshay T");
		dto.setEmployeePracticeId(2);
		dto.setPracticeName("AMS");
		dto.setBand("E2");
		dto.setRole("SOFTWARE ENGINEER");

		employeeList.add(dto);
		when(resourceAllocationService.getAssociatesDetails(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(employeeList);
		ResponseEntity<RMResponseDto> response = resourceAllocationController.getAssociateDetail(Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyList());
		assertNotNull(response);
		verify(resourceAllocationService, times(1)).getAssociatesDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList());
	}

	@Test
	public void getAllocationDetailNoContentTest() throws ResourceManagementException {
		when(resourceAllocationService.getAssociatesDetails(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList()))
				.thenReturn(null);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceAllocationController
				.getAssociateDetail(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList());
		assertEquals(204, responseEntityObj.getStatusCodeValue());
		verify(resourceAllocationService, times(1)).getAssociatesDetails(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyList());
	}

	@Test
	public void getAssociateTravelDetailTest() throws ResourceManagementException {
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("Akshay T");
		employeeDto.setEmployeePracticeId(2);
		employeeDto.setPracticeName("AMS");
		employeeDto.setBand("E2");
		employeeDto.setRole("SOFTWARE ENGINEER");
		when(resourceAllocationService.getAssociatesForTravelByIdOrName(Mockito.anyString(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(employeeDto);
		ResponseEntity<RMResponseDto> response = resourceAllocationController.getAssociatesForTravelByIdOrName("xyz", 123l, 34l);
		assertNotNull(response);
		verify(resourceAllocationService, times(1)).getAssociatesForTravelByIdOrName(Mockito.anyString(), Mockito.anyLong(), Mockito.anyLong());
	}

	@Rule
	public ExpectedException expectation = ExpectedException.none();
	
	@Test
	public void getAssociateTravelDetailNoContentTest() throws ResourceManagementException {
		
		expectation.expect(ResourceManagementException.class);
		expectation.expectMessage(ResourceManagementConstant.NO_TRAVEL_RESOURCE);
		resourceAllocationController.getAssociatesForTravelByIdOrName("xyz", 123l, 343l);
	}

	@Test
	public void saveResourceTravelAllocationsTest() throws ResourceManagementException {
		TAssociateProjectDto allocationDto = new TAssociateProjectDto();

		List<TAssociateProjectDto> allocationDtoList = new ArrayList<>();
		allocationDtoList.add(allocationDto);

		doNothing().when(resourceAllocationService).saveResourceTravelAllocations(allocationDtoList);
		ResponseEntity<RMResponseDto> responseEntityObj = resourceAllocationController
				.saveResourceTravelAllocations(allocationDtoList);
		assertNotNull(responseEntityObj);
		assertEquals(201, responseEntityObj.getStatusCodeValue());
		verify(resourceAllocationService, times(1)).saveResourceTravelAllocations(allocationDtoList);

	}

	@Test
	public void saveResourceTravelAllocationsTestNull() throws ResourceManagementException {
		ResponseEntity<RMResponseDto> responseEntityObj = resourceAllocationController
				.saveResourceTravelAllocations(null);
		assertEquals(400, responseEntityObj.getStatusCodeValue());
	}
	
	@Test
	public void getpoolToIntransitAllocationDtls() throws ResourceManagementException {
		List<EmployeeDto> empDto = new ArrayList<EmployeeDto>();
		
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(52330l);
		employeeDto.setEmployeeName("Akshay T");
		employeeDto.setEmployeePracticeId(2);
		employeeDto.setPracticeName("AMS");
		employeeDto.setBand("E2");
		employeeDto.setRole("SOFTWARE ENGINEER");
		empDto.add(employeeDto);
		
		when(resourceAllocationService.getpoolToIntransitAllocationDtls(Mockito.anyString(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(empDto);
		ResponseEntity<RMResponseDto> response = resourceAllocationController.getpoolToIntransitAllocationDtls("52330", 1l, 1l);
		assertNotNull(response);
		verify(resourceAllocationService, times(1)).getpoolToIntransitAllocationDtls(Mockito.anyString(), Mockito.anyLong(), Mockito.anyLong());
	}

	
	@Test
	public void getpoolToIntransitAllocationDtlsNull() throws ResourceManagementException {
		when(resourceAllocationService.getpoolToIntransitAllocationDtls(Mockito.anyString(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		ResponseEntity<RMResponseDto> response = resourceAllocationController.getpoolToIntransitAllocationDtls("52330", 1l, 1l);
        assertEquals(204, response.getStatusCodeValue());
		verify(resourceAllocationService, times(1)).getpoolToIntransitAllocationDtls(Mockito.anyString(), Mockito.anyLong(), Mockito.anyLong());

	}
	
	
	@Test
	public void getSkillListForResourceTest() throws ResourceManagementException {
		List<SkillTaxonomyDto> skillsDto = new ArrayList<>();
		SkillTaxonomyDto skillDto = new SkillTaxonomyDto();
		skillDto.setEmployeeId(12345l);
		skillDto.setL4SkillId(12l);
		skillDto.setL4skillName("Java");
		skillsDto.add(skillDto);
		
		when(resourceAllocationService.getSkillListForResource(Mockito.anyLong())).thenReturn(skillsDto);
		ResponseEntity<RMResponseDto> response = resourceAllocationController.getSkillListForResource(12345l);
		assertNotNull(response);
		verify(resourceAllocationService, times(1)).getSkillListForResource(12345l);
	}

	
	@Test
	public void getSkillListForResourceNullTest() throws ResourceManagementException {
		when(resourceAllocationService.getSkillListForResource(Mockito.anyLong())).thenReturn(null);
		ResponseEntity<RMResponseDto> response = resourceAllocationController.getSkillListForResource(12345l);
        assertEquals(204, response.getStatusCodeValue());
		verify(resourceAllocationService, times(1)).getSkillListForResource(12345l);

	}
	   
	
}